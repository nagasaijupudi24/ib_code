import { useEffect,createContext, useContext, useState  } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { EDakHome } from "./pages/eDakHome.jsx";
import { EdakNewForm } from "./pages/eDakNewForm.jsx";
import { EDakViewForm } from "./pages/eDakViewForm.jsx";
import Views from "./pages/eDakViews.jsx";
import ATRViews from "./pages/ATRViews.jsx";
// import { ENoteAtrworkflowform } from "./pages/eDakAtrForm.jsx";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useIsAuthenticated,
} from "@azure/msal-react";
import * as Msal from "msal"; 
import { msalConfig } from "./config.js";
import { useMsalAuthentication } from "@azure/msal-react";
import { SearcheDak } from "./pages/searcheDak.jsx";
import { useMsal, useAccount } from "@azure/msal-react";
import { InteractionType } from "@azure/msal-browser";
import { loginRequest } from "./config.js";
import { Landingpage } from "./pages/landingpage.jsx";
// Passcode route
import { EDakPasscode } from "./pages/eDakPasscode.jsx"
import PageNotFound from "./pages/404page.jsx";

// const userAgentApplication = new Msal.UserAgentApplication(msalConfig);
// const request = {
//   scopes: ['User.Read', 'User.ReadBasic.All', 'email'],
// };

// Function to get access token
export const getAccessToken = async (loginRequest, instance) => {
  try {
    const response = await instance.acquireTokenSilent(loginRequest);
    // console.log("Access Token:", response.accessToken);
    // return apiHeader;
    return response.accessToken;
  } catch (error) {
    console.error("Failed to get access token:", error);
    throw new Error("Failed to get access token");
  }
}
const TabContext = createContext();

export const useTabContext = () => useContext(TabContext);
function App() {
  const isAuthenticated = useIsAuthenticated();
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [activeTab, setActiveTab] = useState('My eDak'); // Default active tab
  const [passcodenaviagate, setPasscodeNaviage] = useState('New'); // Default passcode page redirect

  const setTab = (tabName) => {
    setActiveTab(tabName);
  };
    // Added for page redirect to view page after creating passcode --> Kavya(23/07)
    const setPasscodeNavigate = (pageName) => {
      setPasscodeNaviage(pageName);
    }

  // const dispatch = useDispatch();
  // console.log(isAuthenticated,"isAuthenticated");

  // Silent login
  // const { login, result, error } = useMsalAuthentication(InteractionType.Silent, loginRequest);

  // Auto redirect to login
  useMsalAuthentication(InteractionType.Redirect);

  useEffect(() => {
    async function getTokenSilently() {
      const tokenRequest = {
        // scopes: ['User.Read', 'User.ReadBasic.All', 'email'],
        // loginHint: accounts[0].username,
        account,
      };

      await instance.acquireTokenSilent(tokenRequest);
      // dispatch({ type: AuthActions.SET_TOKEN, payload: res.accessToken });
      // dispatch({ type: AuthActions.SET_CLAIMS, payload: accounts[0].username });
    }
    if (isAuthenticated && inProgress === 'none') {
      getTokenSilently();
    }
  }, [isAuthenticated]);

  return (
    <div className="App">
        <AuthenticatedTemplate>
        <TabContext.Provider value={{ activeTab, setTab, setPasscodeNavigate, passcodenaviagate  }}>
          <Router>
            <Routes>
            <Route path="/" element={<EDakHome />} />
              <Route path="/datagridpage" element={<EDakHome />} />
              <Route path="/searcheDak" element={<SearcheDak />} />
              <Route path="/eDakForm/:id" element={<EdakNewForm />} />
              <Route path="/eDakViewForm/:id" element={<EDakViewForm />} />
              <Route path="/views/:id" element={<Views />} />
              <Route path="/atrviews/:id" element={<ATRViews />} />
              <Route path="/edakpasscode" element={<EDakPasscode />} />
              {/* <Route path="/eNoteAtrworkflowform/:id" element={<ENoteAtrworkflowform />}/> */}
              {/* <Route path="/eNoteAtrworkflowform/:id" element={<ENoteAtrworkflowform />}/> */}
              <Route path="*"  element={<PageNotFound />}/>
            </Routes>
          </Router>  
          </TabContext.Provider >
        </AuthenticatedTemplate>
        <UnauthenticatedTemplate>
        <TabContext.Provider value={{ activeTab, setTab, setPasscodeNavigate, passcodenaviagate  }}>
          <Router>
            <Routes>
              {/* <Route path="/" element={<EDakHome />} /> */}
              <Route path="/" element={<Landingpage />} />
              <Route path="*" element={<PageNotFound />}/>
            </Routes>
          </Router>
          </TabContext.Provider>
        </UnauthenticatedTemplate>
    </div>
  );
}

export default App;
