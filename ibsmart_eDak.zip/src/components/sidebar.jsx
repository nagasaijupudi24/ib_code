import React, { useState, useEffect } from "react";
// Import Kendo Components
import {
  ExpansionPanel,
  ExpansionPanelContent,
} from "@progress/kendo-react-layout";
import { Reveal } from "@progress/kendo-react-animation";
// Import External Libraries
import { Link } from "react-router-dom";
// Imported svg images
import list from "../../src/assets/list.svg";
import homeIcon from "../../src/assets/HomeIcon.svg"; // Imported Home icon for home button
// Import components
import { datagridlistitems } from "../pages/datagridlistitems";
import { getAccessToken } from "../App.js";
import { loginRequest } from "../config.js";
import { useMsal, useAccount } from "@azure/msal-react";
import { API_BASE_URL, API_ENDPOINTS, API_COMMON_HEADERS } from "../config.js";
import { chevronDownIcon, chevronUpIcon } from "@progress/kendo-svg-icons";

export const Sidebar = ({ defaultOpenComponent }) => {
  const handleToggle = () => setExpanded(!expanded);
  const [isFirstDivVisible, setFirstDivVisibility] = useState(false);
  const [isToggleClicked, setIsToggleClicked] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [sidenavMenu, setSideNavMenu] = useState(datagridlistitems);

  const handleToggleHover = ({ defaultOpenComponent }) => {
    setFirstDivVisibility(!isFirstDivVisible);
    setIsToggleClicked((prev) => !prev);
  };

  useEffect(() => {
    findDeptSuperAdmin();
  },[]);

  useEffect(() => {
    // Add or remove the 'overflow-hidden' class on the body based on the visibility of the div
    document.body.classList.toggle("overflow-hidden", isFirstDivVisible);
  }, [isFirstDivVisible]);

  useEffect(() => {
    if (defaultOpenComponent) {
      setFirstDivVisibility(!isFirstDivVisible);
      setIsToggleClicked(true)
       }
  }, [defaultOpenComponent]);

  const findDeptSuperAdmin = async() => {

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(`${API_BASE_URL}${API_ENDPOINTS.Find_Super_Dept_Admin(accounts[0]?.username)}`,
      {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
      }
    ).then(response => {
      return response.json();
    }).then(data => {
      if(data.isSuperAdmin) {
        setSideNavMenu(datagridlistitems);
      } 
      else if(data.isDepartmentAdmin) {
        const validatedMenu = datagridlistitems.filter(item => (item.id !=="Administration"));
        const validateAtr = validatedMenu.map(item => item.id==="ATR Views"?{...item,items:item.items.filter(item => item !== "All ATR")}:item);
        setSideNavMenu(validateAtr);
      }else {
        const validatedMenu = datagridlistitems.filter(item => (item.id !=="Administration" && item.id !=="Department Admin"));
        const validateAtr = validatedMenu.map(item => item.id==="ATR Views"?{...item,items:item.items.filter(item => item !== "All ATR")}:item);
        setSideNavMenu(validateAtr);
      }
    })
  }

  const getLinkForItem = (item) => {
    if (item === sidenavMenu[1].items[0]) {
      return "/eDakForm";
    } else if (item === sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[0]) {
      return `/views/${sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[0]}`;
    } else if (item === sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[1]) {
      return `/views/${sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[1]}`;
    } else if (item === sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[2]) {
      return `/views/${sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[2]}`;
    } else if (item === sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[3]) {
      return `/views/${sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[3]}`;
    } else if (item === sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[4]) {
      return `/views/${sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[4]}`;
    } else if (item === sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[5]) {
      return `/views/${sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Views')].items[5]}`;
    } else if (item === sidenavMenu[sidenavMenu.findIndex(obj => obj.id === 'Reports')].items[0]) {
      return "/searcheDak";
    } else {
      return "";
    }
  };

  return (
    <div>
    <div className="homeButtonContainer">
        <Link to="/datagridpage" className="homeButton">
          <img src={homeIcon} alt="Home Icon" className="homeIcon" />
          <span className="homeTooltip">eDak Home</span>
        </Link>
      </div>
      {isFirstDivVisible && (
        <div className="sideBarContainer">
          {sidenavMenu.map((item, index) => (
            <ExpansionPanel
              style={customStyles.expansionSidebar}
              title={
                <div className="mobile_menu">
                  <div
                    style={customStyles.expansionTitle}
                    dangerouslySetInnerHTML={{ __html: item.image }}
                  />
                  {item.id}
                  {index !== 0 && ( // Render down arrow only for items other than the first one
                    <div className="expansionSide"></div>
                  )}
                </div>
              }
              collapseSVGIcon= {item.id === "Home" || item.id === "Create eDak" || item.id === "Create/Reset Passcode" ?<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"></svg>:chevronUpIcon}
              expandSVGIcon= {item.id === "Home" || item.id === "Create eDak" || item.id === "Create/Reset Passcode" ?<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"></svg>:chevronDownIcon}
              expanded={expanded === item.id}
              tabIndex={0}
              expandIcon=""
              onAction={(event) => {
                if (item.id.includes("Create eDak")) {
                  // Redirect logic for the first item
                  window.location.href = "/eDakform/new";
                } else if (item.id.includes("Home")) {
                  window.location.href = "/datagridpage";
                } 
                else if (item.id.includes("Create/Reset Passcode")) {
                  window.location.href = "/edakpasscode"
                }
                else {
                  // Adjust this line based on your linking logic
                  setExpanded(event.expanded ? "" : item.id);
                }
              }}
              className={index === 0 ? "hide-default-icon" : ""}
            >
              <Reveal>
                {expanded === item.id && (
                  <ExpansionPanelContent>
                    <ul style={customStyles.expansionPanel}>
                      {item.items.map(
                        (listItem, listItemIndex) =>
                          index !== 0 && (
                            <Link
                              to={getLinkForItem(listItem)}
                              style={{ textDecoration: "none" }}
                              onClick={handleToggleHover}
                              key={listItemIndex}
                            >
                              <li
                                className="list-item"
                                style={customStyles.listStyle}
                              >
                                {listItem}
                              </li>
                            </Link>
                          )
                      )}
                    </ul>
                  </ExpansionPanelContent>
                )}
              </Reveal>
            </ExpansionPanel>
          ))}
        </div>
      )}
      <div
        className="sideBarClose"
        style={{
          paddingLeft: isToggleClicked ? "20%" : "30px",
          paddingRight: isToggleClicked ? "auto" : "auto",
        }}
      >
        {!isToggleClicked && (
          <img
            src={list}
            className="cursor homeLogo"
            alt="HomeIcon"
            onClick={handleToggleHover}
          />
        )}
        {isToggleClicked && (
          <span className="k-icon k-font-icon k-i-close cursor sideBarmenuCloseIc" onClick={handleToggleHover}></span>
        )}
      </div>
    </div>
  );
};
// Customized system styles can be inserted into a div elements
const customStyles = {
  expansionPanel : { paddingLeft: "0px", marginBottom: "0px" },
  expansionTitle : { width: "18px", marginRight: "6px" },
  expansionSidebar : {margin: "10px"},
  listStyle : { listStyleType: "none" }
}