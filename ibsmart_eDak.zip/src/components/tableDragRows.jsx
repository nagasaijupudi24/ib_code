import * as React from 'react';
// import kendo components
import { Grid, GridColumn as Column } from '@progress/kendo-react-grid';
import { DragAndDrop } from '@progress/kendo-react-common';
import { Button } from "@progress/kendo-react-buttons";
// import internal components
import { DraggableRow } from '../resources/draggable-row';
import { DragHandleCell } from '../resources/drag-handle-cell';
import '../styles/responsiveDesign.css'


export const ReorderContext = React.createContext({
  reorder: () => { },
  dragStart: () => { }
});

export const TableDraggableRows = (props) => {
  const { recipientName, typeOfTable, recipientTable, reviewerTable, CCTable } = props;
  const [gridData, setGridData] = React.useState(props.data);
  const [gridHeight, setGridHeight] = React.useState('auto');
  const [activeItem, setActiveItem] = React.useState(null);

  React.useEffect(() => {
    setGridData(props.data)
  }, [props])

  const updatedDate = (current) => {
    const updatedRow = gridData.filter((obj, index) => index !== current);
    props.onDelate(gridData.find((obj, ind) => ind === current));
    setGridData(updatedRow);
  }

  const reorder = (dataItem, direction) => {
    if (activeItem === dataItem) {
      return;
    }
    let reorderedData = gridData.slice();
    let prevIndex = reorderedData.findIndex(p => p === activeItem);
    let nextIndex = reorderedData.findIndex(p => p === dataItem) + (direction === 'before' ? -1 : 0);
    reorderedData.splice(prevIndex, 1);
    reorderedData.splice(nextIndex, 0, activeItem || reorderedData[0]);
    setGridData(reorderedData.map((obj, ind) => { return { ...obj, approverOrder: ind + 1 } }));
    props.onOrderChange(reorderedData.map((obj, ind) => { return { ...obj, approverOrder: ind + 1 } }));
  };

  const dragStart = dataItem => {
    setActiveItem(dataItem);
  };

  const handleRadioChange = (event, dataItem) => {
    const { value } = event.target;
    const updatedData = gridData.map(item => {
      if (item === dataItem) {
        return { ...item, signedBy: value === 'true' };
      }
      return item;
    });

    props.handleRadioChange(dataItem);
    setGridData(updatedData);
  };

  return <ReorderContext.Provider value={{
    reorder: reorder,
    dragStart: dragStart
  }}>
    <DragAndDrop>
      <div style={{ overflowX: "auto", overflowY: "none !important" }}>
        <Grid
          style={{ height: gridHeight }}
          data={gridData}
          dataItemKey={'noteApproverMasterId'}
          rowRender={(row, rowProps) => <DraggableRow elementProps={row.props} {...rowProps} />}
          className="custom-grid-table"
        >
          <Column title="" width="50%" cell={DragHandleCell} />
          <Column title="S.No" width="100" cell={(props) => {
            return <td>{props.dataIndex + 1}</td>;
          }} />

          {recipientTable !== "eDakform" && CCTable !== "CCform" && (<Column field="approverEmailName" title={typeOfTable} className='mobile_responsive_dragTable'/>)}
          {CCTable === "CCform" && <Column field="displayName" title="Name"  className='mobile_responsive_dragTable'/>}
          {reviewerTable !== "reviewerform" && recipientTable === "eDakform" && CCTable !== "CCform" && (<Column field="displayName" title={recipientName}  className='mobile_responsive_dragTable'/>)}
          {reviewerTable !== "reviewerform" && recipientTable === "eDakform" && CCTable !== "CCform" && (<Column field="groupName" title="Group Name" className='mobile_responsive_dragTable'/>)}
          {<Column field="srNo" title="SR No"  className='mobile_responsive_dragTable'/>}
          {<Column field="designation" title="Designation"  className='mobile_responsive_dragTable'/>}
          {recipientTable !== "eDakform" && CCTable !== "CCform" && (<Column title="Signed By" width="100px" cell={(props) => (
            <td style={{ textAlign: "center" }}>
              <div>
                <label>
                  <input
                    type="radio"
                    name={`signedBy_${props.dataItem.signedBy}`}
                    value="true"
                    checked={props.dataItem.signedBy === true}
                    onChange={(event) => handleRadioChange(event, props.dataItem)}
                  />
                </label>
              </div>
            </td>
          )} />)}
          <Column width="120%" cell={props => {
            return (<td>
              <Button
                onClick={() => { updatedDate(props?.dataIndex) }}
              >
                <span className="k-icon-sm k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>
                Delete
              </Button>
            </td>)
          }} title="Action" />
        </Grid>
      </div>
    </DragAndDrop>

  </ReorderContext.Provider>;
};
