/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { LogLevel } from "@azure/msal-browser";

/**
 * Configuration object to be passed to MSAL instance on creation.
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */
// "Instance": "https://login.microsoftonline.com/",
// "Domain": "xencia.com",
// "TenantId": "75f2a99b-01fd-48f2-ac60-d4a7a44fd0cc",
// "ClientId": "e77908ab-8705-4f9a-b103-515ef6f69535",
// "ClientSecret": "Ayl8Q~VPcbGTe53TrrkiBiOkKAErJDweV8t6GcAK",
// "CallbackPath": "/signin-oidc",
// "Scopes": "access_as_user"\


// console.log(process.env.REACT_APP_ClientId);
// console.log(process.env.REACT_APP_Redirect_URL);
export const msalConfig = {
  auth: {
    // clientId: "b3fc558c-f399-4d3b-aa6c-ac70624e07a8",
    // authority: "https://login.microsoftonline.com/75f2a99b-01fd-48f2-ac60-d4a7a44fd0cc",
    // redirectUri: "https://inb-enote.xencia.com",
    clientId: process.env.REACT_APP_ClientId,
    authority: process.env.REACT_APP_Authority,
    redirectUri: process.env.REACT_APP_eDak_URL,

    /*clientId: "ab1333a0-e6bc-4ba8-b67b-4f4378b37e7e",
    authority: "https://login.microsoftonline.com/19e8abd9-a4ec-4a12-a8e7-ad170593e0b2",
    // redirectUri: "https://smartofficeDev-enote.indianbank.in",
    redirectUri: "https://smartofficeuat-enote.indianbank.in",*/

    // clientId: "e77908ab-8705-4f9a-b103-515ef6f69535",
    // clientId: "73c2abaa-f13a-415c-aa1a-7cce420f85b0",
    // redirectUri: "https://smartofficeuat-edak.indianbank.in",
    // redirectUri: "http://localhost:3000",
  },
  cache: {
    cacheLocation: "sessionStorage", // This configures where your cache will be stored
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            // console.error(message);
            return;
          case LogLevel.Info:
            // console.info(message);
            return;
          case LogLevel.Verbose:
            // console.debug(message);
            return;
          case LogLevel.Warning:
            // console.warn(message);
            return;
          default:
            return;
        }
      },
    },
  },
};

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit:
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */
export const loginRequest = {
  // scopes: ['https://graph.microsoft.com/User.Read'],
  // AUD: "api://b3fc558c-f399-4d3b-aa6c-ac70624e07a8",
  scopes: [process.env.REACT_APP_Scopes],
  // scopes: ["api://b3fc558c-f399-4d3b-aa6c-ac70624e07a8/User.Read"],
  // scopes: ["api://ab1333a0-e6bc-4ba8-b67b-4f4378b37e7e/IBSmartOfficeScope"],
  // scopes: ["https://graph.microsoft.com/User.Read"],
  // loginHint: "" 
  // loginHint: "admin@M365x70282966.onmicrosoft.com" // or your login hint if needed
};

export const API_COMMON_HEADERS = {
  "Content-type": "application/json; charset=UTF-8",
  "Access-Control-Allow-Origin":process.env.REACT_APP_eDak_URL
}

/**
 * Add here the scopes to request when obtaining an access token for MS Graph API. For more information, see:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md
 */
export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
};

// export const API_BASE_URL = "http://localhost:8081";
// export const API_BASE_URL = "https://inb-api.xencia.com";

// IB Dev
/*export const API_BASE_URL = "https://smartofficeDev-api.indianbank.in";
export const IB_Domain_URL = "https://smartofficeDev.indianbank.in";
export const IB_eNoteDomain_URL = "https://smartofficeDev-enote.indianbank.in";
export const IB_eCommitteeDomain_URL = "https://smartofficeDev-ecommittee.indianbank.in";*/

// IB UAT
/*export const API_BASE_URL = "https://smartofficeuat-api.indianbank.in";
export const IB_Domain_URL = "https://smartofficeuat.indianbank.in";
export const IB_eNoteDomain_URL = "https://smartofficeuat-enote.indianbank.in";
export const IB_eCommitteeDomain_URL = "https://smartofficeuat-ecommittee.indianbank.in";*/

export const API_BASE_URL = process.env.REACT_APP_APIBase_URL;
export const IB_Domain_URL = process.env.REACT_APP_Home_URL;
export const IB_eNoteDomain_URL = process.env.REACT_APP_eNote_URL;
export const IB_eCommitteeDomain_URL = process.env.REACT_APP_eCommittee_URL;
export const IB_eDakDomain_URL = process.env.REACT_APP_eDak_URL;


// export const API_BASE_URL = "https://indianbankxenciaapp.azurewebsites.net";
// export const API_ALLOW_ORIGIN = "https://inb.xencia.com";

export const API_ENDPOINTS = {
  GET_DROPDOWNDATA: "/api/EDaks/getDropdownData",
  GET_Group: "/api/EDaks/GetGroup",
  Get_Group_Users:"/api/EDaks/GetGroupUsers",
  GET_UserDetails: "/api/Azure/GetUserDetailsGraphALL",
  GET_UserDetails_Search: "/api/Azure/GetUserDetailsGraphALL",
  ATR_GetRequest: "/api/ATRStatus/Atrs",
  ATR_GetAllRequests: "/api/ATRStatus/GetAtrsStatusBaseAll",
  ATR_GetRequestsByStatus: "/api/ATRStatus/GetAtrsStatusBase",
  ATR_AssigneeAction: "/api/ATRStatus/AtrStatusUpdate",
  ATR_RequesterAction: "/api/ATRStatus/AtrStatusUpdateFromRequester",
  eDak_GetRequests: "/api/EDaks/getDaksList",
  eDak_GetAllRequest: "/api/EDaksViews/AllRequests",
  eDak_GetClosed: "/api/EDaksViews/Closed",
  eDak_GetAllProgress:"/api/EDaksViews/InProgress",
  eDak_GetAllPendingForClose:"/api/EDaksViews/PendingforClose",
  eDak_GetPendingForClose:"/api/EDaksViews/PendingforClose",
  eDak_GetLandingCount:"/api/EDaks/getLandingPageCounts",
  eDak_Closed: "api/EDaks/CloseEdak",
  eDak_GetRequestsRoleBased: "/api/EDakNavigationMenu/getDakList",
  eDak_GetNotedeDakRequests: "/api/EDaks/getNotedDaksList",
  eDak_GetEDMDeDakList: "/api/ENote/getEDMDNoteList",
  eDak_GeteDakSecretaryofApprover:"/api/NoteApproversMaster/GetNoteSecretaryfromApprover",
  eDak_AddForm: "/api/EDaks/AddDaks",
  eDak_EditForm: "/api/EDaks/EditDaks",
  eDak_GetGeneralDetails: "/api/EDaks/getDaksGeneralDetails",
  eDak_ChangeApprover: "/api/EDaks/ChangeApprover",
  eDak_GeteDakSecretary: "/api/NoteSecretary/GetNoteSecretary",
  eDak_CallBackeDak: "/api/ENote/CallBackNote",
  eDak_CancelDak: "/api/ENote/CancelNote",
  eDak_dakApproverStatusChange: "/api/EDaks/ChangeApproverStaus",
  eDak_AcknowledgeEdak:"/api/EDaks/AcknowledgeEdak",
  eDak_UpdateDakReferresStatus: "/api/NoteReferre/UpdateNoteReferrerStatus",
  eDak_InserDakSecretary: "/api/NoteSecretary/InsertNoteSecretary",
  eDak_AddDakMarkedInformation: "/api/NoteMarkedInformation/AddNoteMarkedInformation",
  eDak_GetATRCreators: "/api/ATRCreators/getATRCreators",
  eDak_GetATRAssignees: "/api/ATRAssignees/getATRAssignees",
  eDak_SearchDaks: "/api/EDakSearch/SearchDaks",
  eDak_GetRefferedDakList: "/api/ENote/getRefferedNoteList",
  eDak_GetChart:"/api/EDaks/GetEdakChartInfo",
  eDak_findIsloginUserSecretary: "/api/NoteSecretary/IdentifySecretary",
  eDak_ChangeRecipientStaus:"/api/EDaks/ChangeRecipientStaus",
  eDak_ClosedEdak:"/api/EDaks/CloseEdak",
  eDak_GetDakApprovers: (department) => `/api/EDaksApprovers/getApprover?department=${encodeURIComponent( department)}`,
  eDak_GetDakReviewer: (department) => `/api/EDaksApprovers/getReviewer?department=${encodeURIComponent( department )}`,
  GET_UserDetailsByPrincipalName: (username) => `/api/Azure/GetUserDetailsByPrincipalName?userPrincipalName=${username}`,
  Search_UserDetails: (username) => `/api/Azure/GetUserDetailsByStartChar?userPrincipalName=${username}`,
  Find_Super_Dept_Admin: (username) => `/api/Department/FindAdminorDepartmentAdmin?userPrincipalName=${username}`,
  GET_Department_List:"/api/EDaks/getDepartments",
  GET_Base64:`/api/ENote/GetBase64`,
  Get_Draft_Requests:"/api/EDaksViews/DraftList",

  eDak_AddPasscode: "/api/NotePasscode/AddPasscode",
  eDak_VerifyPasscode: "/api/NotePasscode/VerifyPasscode",
  eDak_SendOTP:"/api/NotePasscode/SendOTP",
  eDak_Group: (groupName) =>`/api/Azure/GetGroupsGraphALL?groupName=${groupName}`,
  eNote_VerifyUserPasscode :  (username) => `/api/NotePasscode/PasscodeAvailability?userPrincipalName=${username}`
};