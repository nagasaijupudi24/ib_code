import React, { useState, useEffect } from "react";
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import { Link } from "react-router-dom";
import { Button } from "@progress/kendo-react-buttons";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { useParams } from "react-router";
import { GridPDFExport } from "@progress/kendo-react-pdf";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import { CSVLink } from "react-csv";
import { useMsal } from "@azure/msal-react";
import {
  ColumnMenu
} from "./custom-cells";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
// import { employees } from './employees';
import { Sidebar } from "../components/sidebar";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { PageLoader } from "../components/pageLoader";
import "../styles/datagridpage.css";
import "../styles/forms.css";
import DateObject from "react-date-object";
import { orderBy } from "@progress/kendo-data-query";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";

const initialSort = [
  {
    field: "modifiedDate",
    dir: "desc",
  },
];

const DATA_ITEM_KEY = "id";
const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};

const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};

const ATRViews = () => {

  const idGetter = (item) => item.id;
  const { id } = useParams();
  const [filterValue, setFilterValue] = React.useState("");
  const [filteredData, setFilteredData] = React.useState([]);
  const [currentSelectedState, setCurrentSelectedState] = React.useState({});
  const [dataState, setDataState] = React.useState(initialDataState);
  const [data, setData] = React.useState(filteredData);
  const [apiData, setApiData] = React.useState([]);
  const [dataResult, setDataResult] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentHeading, setCurrentHeading] = useState();
  const { accounts } = useMsal();
  const [selectedView, setSelectedView] = useState("");

  const switchNoteId = (id) => {
    setCurrentHeading(id);
    setIsLoading(true);
    switch (id) {
      case "Pending ATR":
        fetchApiData(API_ENDPOINTS.ATR_GetRequestsByStatus, "Pending", "pendingAtr");
        setSelectedView(id);
        break;
      case "Pending ATR Sectt":
        fetchApiData(API_ENDPOINTS.ATR_GetRequestsByStatus, "Completed","pendingAtrSectt");
        setSelectedView(id);
        break;
      case "Completed ATR":
        fetchApiData(API_ENDPOINTS.ATR_GetRequestsByStatus, "Accepted", "completedAtr");
        setSelectedView(id);
        break;
      case "All ATR":
        fetchApiDataAll();
        setSelectedView(id);
        break;
      default:
        fetchApiData(API_ENDPOINTS.ATR_GetRequestsByStatus, "Pending", "pendingAtr");
        setSelectedView("Pending ATR");
        return 1;
    }
  };

  useEffect(() => {
    switchNoteId(id); // Set the default noteId
  }, [id]);

  const fetchApiData = async (endPoint, statusTxt, type) => {
    // const endpnt = `${API_BASE_URL}/api/ATRStatus/${endPoint}`;
    setFilterValue('');

    const accessToken = await getAccessToken({...loginRequest,loginHint:accounts[0].username});

    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
    });

    const enumsObj = await dropdowns.json();
    const endpoint = `${API_BASE_URL}${endPoint}`;

    try {
      const response = await fetch(endpoint, {
        method: "Post",
        body: JSON.stringify({
          AtrStatus: enumsObj.ATRStatusEnum.find((x) => x.dValue === statusTxt).id,
          LoginMailId: accounts[0].username,
          ATRReportType: type,
        }),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
      });

      if (response.ok) {
        const apiObj = await response.json();
        const resData = apiObj.pendingATRsList;
        const apiCstData = orderBy(resData, initialSort);
        // Bug fix - 300 - 27/03
        // const apiCstData = upObj.map(x=>({...x,modifiedDate:new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"),createdDate:new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A")}));

        console.log(apiCstData);

        if (apiObj.statusMessage === "Success") {
          setApiData(apiCstData);
          setFilteredData(apiCstData);
          setData(apiCstData);
          setDataResult(process(apiCstData, dataState));
          setDataState({ ...dataState, total: apiCstData.length });
        } else {
          console.error(
            "Error fetching data: Invalid API response",
            apiCstData
          );
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchApiDataAll = async () => {

    setFilterValue('');

    const accessToken = await getAccessToken({...loginRequest,loginHint:accounts[0].username});

    try {
      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.ATR_GetAllRequests}`,
        {
          method: "Post",
          body: JSON.stringify({
            LoginMailId: accounts[0].username,
          }),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
        }
      );

      if (response.ok) {
        const apiObj = await response.json();

        const resData = apiObj.pendingATRsList;
        const apiCstData = orderBy(resData, initialSort);
        // Bug fix - 300 - 27/03
        // const apiCstData = upObj.map(x=>({...x,modifiedDate:new DateObject(new Date(data.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"),createdDate:new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A")}));

        if (apiObj.statusMessage === "Success") {
          setApiData(apiCstData);
          setFilteredData(apiCstData);
          setData(apiCstData);
          setDataResult(process(apiCstData, dataState));
          setDataState({ ...dataState, total: apiCstData.length });
        } else {
          console.error(
            "Error fetching data: Invalid API response",
            apiCstData
          );
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);
    console.log(apiData);
    console.log(filteredData);
    console.log(dataResult);

    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);
      // }

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      // setFilteredData(newData);
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiData.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );
  const dataStateChange = (event) => {
    if (event.dataState && filteredData) {
      setDataResult(process(filteredData, event.dataState));
      setDataState(event.dataState);
    }
  };
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );

  const setSelectedValue = (data) => {
    let newData = data.map((item) => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items),
        };
      } else {
        return {
          ...item,
          ["selected"]: currentSelectedState[idGetter(item)],
        };
      }
    });
    return newData;
  };

  const newData = setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: [],
  });
  // console.log(newData)
  const onHeaderSelectionChange = React.useCallback(
    (event) => {
      const checkboxElement = event.syntheticEvent.target;
      const checked = checkboxElement.checked;

      // Check if data is defined and an array
      // if (Array.isArray(data)) {
      const newSelectedState = {};
      data.forEach((item) => {
        newSelectedState[idGetter(item)] = checked;
      });

      setCurrentSelectedState(newSelectedState);

      const newData = data.map((item) => ({
        ...item,
        [SELECTED_FIELD]: checked,
      }));

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);
      // }
    },
    [data, dataState]
  );
  const onSelectionChange = (event) => {
    // if (event && event.dataItem && data) {
    const selectedProductId = event.dataItem.atrId;

    const newData = data.map((item) => {
      if (item.atrId === selectedProductId) {
        item.selected = !item.selected;
      }
      return item;
    });

    setCurrentSelectedState((prevState) => ({
      ...prevState,
      [selectedProductId]: !prevState[selectedProductId],
    }));

    const newDataResult = processWithGroups(newData, dataState);
    setDataResult(newDataResult);
    // }
  };
  const getNumberOfItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfItems(item.items);
      } else {
        count++;
      }
    });
    return count;
  };
  const getNumberOfSelectedItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfSelectedItems(item.items);
      } else {
        count = count + (item.selected === true ? 1 : 0);
      }
    });
    return count;
  };
  const checkHeaderSelectionValue = () => {
    let selectedItems = getNumberOfSelectedItems(newData);
    return newData.length > 0 && selectedItems == getNumberOfItems(newData);
  };
  let _pdfExport;
  const exportExcel = () => {
    _export.save();
  };
  let _export;
  const exportPDF = () => {
    _pdfExport.save();
  };

  const exportCSVHeader = () => {
    return [
      { key: "noteNumber", label: "Note#" },
      /* Bug fix - 293 - 27/03 */
      { key: "atrAssignerEmailName", label: "Assignee" },
      { key: "departmentName", label: "Department" },
      /* Bug fix - 293 - 27/03 */
      { key: "approverEmailName", label: "Assigned By" },
      { key: "strAtrStatus", label: "Status" },
      { key: "subject", label: "Subject" },
      { key: "remarks", label: "Remarks" },
      { key: "createdDate", label: "Created Date" },
    ];
  }

  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    const columnsConfig = [
      { field: "noteNumber", title: "Note#" },
      /* Bug fix - 293 - 27/03 */
      { field: "atrAssignerEmailName", title: "Assignee" },
      { field: "departmentName", title: "Department" },
      /* Bug fix - 293 - 27/03 */
      { field: "approverEmailName", title: "Assigned By" },
      { field: "strAtrStatus", title: "Status" },
      { field: "subject", title: "Subject" },
      { field: "remarks", title: "Remarks" },
      { field: "createdDate", title: "Created Date" },
    ];

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "noteNumber" ? (
            <td>
              <Link
                style={{ color: "red" }}
                to={`/eNoteAtrworkflowform/${props.dataItem["atrId"]}`}
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {/* Bug fix - 300 - 27/03 */}
              {column.title.includes("Date")
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm:ss A")
                : props.dataItem[column.field]}
               {/* {props.dataItem[column.field]} */}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  return (
    <div>
      <Navbar header="IB Smart Office - eDak" />
      <Sidebar />
      <div className="container datagridpage">
        <div className="SectionHeads row">{currentHeading}s</div>

        {isLoading ? (
          <PageLoader />
        ) : (
          <Grid
            className="cstGridStyles"
            pageable={{ pageSizes: true }}
            data={dataResult}
            sortable={true}
            total={resultState.total}
            onDataStateChange={dataStateChange}
            {...dataState}
            onExpandChange={onExpandChange}
            expandField="expanded"
            dataItemKey={DATA_ITEM_KEY}
            // selectedField={SELECTED_FIELD}
            // onHeaderSelectionChange={onHeaderSelectionChange}
            // onSelectionChange={onSelectionChange}
            // groupable={true}
            size={"small"}
            resizable={true}
          >
            <GridToolbar>
              <Input
                value={filterValue}
                onChange={onFilterChange}
                style={{
                  border: "2px solid #ccc",
                  boxShadow: "inset 0px 0px 0.5px 0px rgba(0,0,0,0.0.1)",
                  width: "170px",
                  height: "30px",
                  marginRight: "10px",
                }}
                placeholder="Search in all columns..."
              />
              <div className="export-btns-container">
                {/* <Button onClick={exportExcel}>Export to Excel</Button>
                <Button onClick={exportPDF}>Export to PDF</Button> */}
                <Button style={{ marginLeft: "5px" }}>
                  <CSVLink
                    filename={`eNote-${selectedView.replace(
                      / /g,
                      ""
                    )}${new DateObject(new Date()).format("DDMMYYYYhhmmss")}`}
                    // Bug fix - 300 - 27/03
                    data={filteredData.map((x) => ({...x, modifiedDate: new DateObject( new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"),createdDate: new DateObject( new Date(x.createdDate) ).format("DD-MMM-YYYY hh:mm:ss A"),}))}
                    headers={exportCSVHeader()}
                  >
                    Export CSV
                  </CSVLink>
                </Button>
              </div>
            </GridToolbar>

            {/* <Column
              filterable={false}
              field={SELECTED_FIELD}
              width={50}
              headerSelectionValue={checkHeaderSelectionValue()}
            />*/}

            {renderColumnsWithData(dataResult)}
          </Grid>
        )}
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};

export default ATRViews;