import React, { useEffect,useState } from "react";
// Import Kendo Components
import { getter } from "@progress/kendo-react-common";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import {
  setGroupIds,
} from "@progress/kendo-react-data-tools";
import { Button } from "@progress/kendo-react-buttons";
// Import External Libraries
import { CSVLink } from "react-csv";
import { Link } from "react-router-dom";
import { useMsal } from "@azure/msal-react";
import DateObject from "react-date-object";
// Import components
import { ColumnMenu } from "./custom-cells";
import { fetchNoteData } from "./apiService";
// import css
import "../styles/forms.css"

const DATA_ITEM_KEY = "id";
const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};
const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};
export const Dashboard = ({ apiOutput, selectedView }) => {
  const { accounts } = useMsal();
  const idGetter = getter("id");
  const [filterValue, setFilterValue] = useState("");
  const [filteredData, setFilteredData] = useState(apiOutput);
  const [currentSelectedState, setCurrentSelectedState] = useState({});
  const [dataState, setDataState] = useState(initialDataState);
  const [dataResult, setDataResult] = useState(
    process(filteredData, dataState)
  );
  const [data, setData] = useState(filteredData);
  const [apiData, setApiData] = useState([]);

  useEffect(() => {
    setApiData(apiOutput);
    setFilteredData(apiOutput);

    let processedData = process(apiOutput, initialDataState);
    setDataResult(processedData);
    setDataState({ ...dataState, total: apiOutput.length });
    setFilterValue("");
  }, [apiOutput]);

  // filter data based on search text for all columns 
  // const onFilterChange = (ev) => {
  //   let value = ev.value;
  //   setFilterValue(value);

  //   if (!value) {
  //     setFilteredData(apiData);
  //     setDataResult(
  //       process(apiData, (dataState) => ({
  //         ...dataState,
  //         total: apiData.length,
  //       }))
  //     );
  //   } else {
  //     let newData = apiData.filter((item) => {
  //       for (const property in item) {
  //         if (
  //           item[property] &&
  //           item[property].toString &&
  //           item[property]
  //             .toString()
  //             .toLocaleLowerCase()
  //             .includes(value.toLocaleLowerCase())
  //         ) {
  //           return true;
  //         }
  //         if (
  //           item[property] &&
  //           item[property].toLocaleDateString &&
  //           item[property].toLocaleDateString().includes(value)
  //         ) {
  //           return true;
  //         }
  //       }
  //       return false;
  //     });

  //     setFilteredData(newData);
  //     let clearedPagerDataState = {
  //       ...dataState,
  //       take: 10,
  //       skip: 0,
  //     };
  //     let processedData = process(newData, clearedPagerDataState);
  //     setDataResult(processedData);
  //     setDataState({ ...dataState, total: newData.length });
  //     setData(newData);
  //   }
  // };
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = useState(
    processWithGroups(
      apiOutput.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );

  // Grid dataStateChange handler
  const dataStateChange = (event) => {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };

  // Grid Expand chnage handler
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );

  // Grid setSelectedValue handler
  // const setSelectedValue = (data) => {
  //   let newData = data.map((item) => {
  //     if (item.items) {
  //       return {
  //         ...item,
  //         items: setSelectedValue(item.items),
  //       };
  //     } else {
  //       return {
  //         ...item,
  //         ["selected"]: currentSelectedState[idGetter(item)],
  //       };
  //     }
  //   });
  //   return newData;
  // };

  // const newData = setExpandedState({
  //   data: setSelectedValue(resultState.data),
  //   collapsedIds: [],
  // });
  
  // Grid get number of items 
  // const getNumberOfItems = (data) => {
  //   let count = 0;
  //   data.forEach((item) => {
  //     if (item.items) {
  //       count = count + getNumberOfItems(item.items);
  //     } else {
  //       count++;
  //     }
  //   });
  //   return count;
  // };
 
  // Grid get number of selected  items 
  // const getNumberOfSelectedItems = (data) => {
  //   let count = 0;
  //   data.forEach((item) => {
  //     if (item.items) {
  //       count = count + getNumberOfSelectedItems(item.items);
  //     } else {
  //       count = count + (item.selected == true ? 1 : 0);
  //     }
  //   });
  //   return count;
  // };

  // CSV column headers 
  const exportCSVHeader = () => {
    return [
      { key: "dakNumber", label: "Dak ID" },
      { key: "createdByName", label: "Requester" },
      { key: "subject", label: "Subject" },
      { key: "strStatus", label: "Status" },
      { key: "receivedDate", label: "Received Date" },
      { key: "createdDate", label: "Created Date" }
    ];
  }

  // Based on Data column with will render
  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    const columnsConfig = [
      { field: "dakNumber", title: "Dak ID" },
      { field: "createdByName", title: "Requester" },
      { field: "subject", title: "Subject" },
      { field: "strStatus", title: "Status" },
      { field: "receivedDate", title: "Received Date" },
      { field: "createdDate", title: "Created Date" }
    ];

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "dakNumber" ? (
            <td>
              <Link className="dakColor"
                to={
                  (props.dataItem["status"] === 1 ||
                    props.dataItem["status"] === 3) &&
                  props.dataItem["createdBy"] === accounts[0]?.username
                    ? `/eDakform/${props.dataItem["dakId"]}`
                    : `/eDakViewForm/${props.dataItem["dakId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {column.title.includes("Date") && props.dataItem[column.field]
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm  A")
                : props.dataItem[column.field]
                  ? props.dataItem[column.field]
                  : ""}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  //  Grid Header cell handler
  const onHeaderCellClick = (event) => {
    const clickedColumn = event.column;
    if (clickedColumn.field === "request") {
      // Extract dakId from the clicked column
      const dakId = clickedColumn.dataItem.dakId;
      // Fetch data based on the dakId
      fetchNoteData(dakId);
    }
  };
  return (
    <div>
      <Grid
        className="cstGridlandPgStyles"
       
        onHeaderCellClick={onHeaderCellClick}
        // pageable={{ pageSizes: true }}
        pageable={{ pageSizes: [5, 10, 15, 20] }}
        data={dataResult}
        sortable={true}
        total={resultState.total}
        onDataStateChange={dataStateChange}
        {...dataState}
        onExpandChange={onExpandChange}
        expandField="expanded"
        dataItemKey={DATA_ITEM_KEY}
        selectedField={SELECTED_FIELD}
        size={"small"}
        resizable={true}
      >
        <GridToolbar>
          <Input
            value={filterValue}
            onChange={onFilterChange}
            className="searchCSS"
            placeholder="Search in all columns..."
          />
          <div className="export-btns-container">
            <Button className="exportCSV">
              <CSVLink
                filename={`eNote-${selectedView.replace(
                  / /g,
                  ""
                )}${new DateObject(new Date()).format("DD-MMM-YYYY hh:mm A")}`}
                data={filteredData.map((x) => ({...x, modifiedDate: new DateObject( new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm A"),
                createdDate: new DateObject( new Date(x.createdDate) ).format("DD-MMM-YYYY hh:mm A"),}))}
                headers={exportCSVHeader()}
              >
                Export CSV
              </CSVLink>
            </Button>
          </div>
        </GridToolbar>
        {renderColumnsWithData(dataResult)}
      </Grid>
    </div>
  );
};