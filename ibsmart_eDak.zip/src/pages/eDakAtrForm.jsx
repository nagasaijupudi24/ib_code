import React, { useState } from "react";
import {
  Form,
  Field,
  FormElement,
  FieldWrapper,
} from "@progress/kendo-react-form";
import { Input, TextArea } from "@progress/kendo-react-inputs";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { Button } from "@progress/kendo-react-buttons";
// import "../styles/eNoteApplicationform.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/forms.css";
import Navbar from "../components/navbar";
import { Sidebar } from "../components/sidebar";
import Footer from "../components/footer";
// import { Upload } from "@progress/kendo-react-upload";
import { useEffect } from "react";
import DateObject from "react-date-object";
import { useNavigate, useParams } from "react-router-dom";
import { SvgIcon } from "@progress/kendo-react-common";
import {
  filePdfIcon,
  fileWordIcon,
  fileImageIcon,
  fileTxtIcon,
  fileDataIcon,
  fileIcon,
} from "@progress/kendo-svg-icons";
import { useMsal } from "@azure/msal-react";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { infoCircleIcon } from "@progress/kendo-svg-icons";
// import { Loader } from "@progress/kendo-react-indicators";
import { PageLoader } from "../components/pageLoader";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";

/*const atrObj = {
    noteTo: "Test",
    status: "",
    creationDate: "",
    atrNoteid: "",
    department: "",
    subject: "",
    assingedBy: "",
    remarks: "",
    actionTaken: "",
    actionTakenDate: "",
    comments: "",
  };*/

const CustomDialogTitleBar = () => {
  return (
    <div
      className="custom-title"
    >
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};

const CustomConfirmDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span> Confirmation
    </div>
  );
};

export const ENoteAtrworkflowform = () => {
  
  const [isEditMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [crtAtrObj, setcrtAtrObj] = useState({});
  const [enumObj, setEnumObj] = useState();
  const [updateState, setupdateState] = useState(false);
  const [actionTaken, setactionTaken] = useState("");
  const [actionTakenDt, setactionTakenDt] = useState(new Date());
  const [comments, setcomments] = useState("");
  const id = useParams();
  const { accounts } = useMsal();
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [dialogSuccess, setdialogSuccess] = React.useState(false);
  const [dialogFailure, setdialogFailure] = React.useState(false);
  const [isAssignee, setIsAssignee] = React.useState(false);
  const [isRequester, setIsRequester] = React.useState(false);
  const navigate = useNavigate();
  const [requesterStatusType, setrequesterStatusType] =
    React.useState("Accepted");
  const [redrirectTo] = React.useState("/atrviews/Completed%20ATR");
  const [failureDailogTxt,setFailureDailogTxt] = React.useState("");
  const [failuremsg] = React.useState("Something went  wrong please try again!");
  const [actionTakenError, setActionTakenError] = useState('');
  const [reqCommentsError, setReqCommentsError] = useState('');
  const [isPendingWith, setIsPendingWith] = useState('');
  const [actionTakenDateError, setActionTakenDateError] = useState('');
  const [actionTakenBorderColor, setActionTakenBorderColor] = useState('rgba(0, 0, 0, 0.12)');
  const [actionTakenDateBorderColor, setActionTakenDateBorderColor] = useState('rgba(0, 0, 0, 0.12)');
  const [reqCommentsBorderColor, setReqCommentsBorderColor] = useState('rgba(0, 0, 0, 0.12)');
  const [confirmDailogObj, setConfirmDailogObj] = React.useState({
    Confirmtext: "",
    Description: "",
  });
  const [supportDoclink, setSupportDoclinks] = useState({});

  const handleCloseDlg = async () => {
    setDialogOpen(!dialogOpen);
  };

  const [supportDocWarning, SetSupportDocWarning] = useState({
    "file.txt": {
      filename: "",
      isValid: false,
      warningMsg: "",
      fileExtnsion: "",
    },
  });

  // supportDoc files info
  const [filesInfo, SetFileinfo] = useState([]);

  useEffect(() => {
    setIsLoading(true);

    const fetchApiData = async (id) => {

    const accessToken = await getAccessToken({...loginRequest,loginHint:accounts[0].username});
    //get enum objects
    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
    });
      const enumsObj = await dropdowns.json();
      setEnumObj(enumsObj);

      await fetch(`${API_BASE_URL}${API_ENDPOINTS.ATR_GetRequest}`, {
        method: "POST",
        body: JSON.stringify({
          AtrId: id,
        }),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          console.log(data,"data")
          setupdateState(true);
          setcrtAtrObj(data);
          getSupportDocHyperlink(data.atrSupportDocumentsDTO);
          setactionTaken(crtAtrObj.actionTaken || "");
          setactionTakenDt(crtAtrObj.actionTakenDate?new Date(crtAtrObj.actionTakenDate):new Date());
          setcomments(crtAtrObj.noteRequesterComments || "");
          // setIsAssignee(data.atrCreatorEmail === accounts[0].username);
          setIsAssignee((crtAtrObj.atrStatus === enumsObj.ATRStatusEnum.find((x) => x.dValue === "Pending").id || crtAtrObj.atrStatus === enumsObj.ATRStatusEnum.find((x) => x.dValue === "Returned").id) && data.atrAssigneeEmail === accounts[0].username);
          setIsRequester(crtAtrObj.atrStatus === enumsObj.ATRStatusEnum.find((x) => x.dValue === "Completed").id && data.noteRequester === accounts[0].username);
          setIsPendingWith(crtAtrObj.atrStatus === enumsObj.ATRStatusEnum.find((x) => x.dValue === "Accepted").id?"":crtAtrObj.atrStatus === enumsObj.ATRStatusEnum.find((x) => x.dValue === "Completed").id? data.noteRequesterName:data.atrAssignerEmailName);
          if (data.atrSupportDocumentsDTO.length > 0) {
            let upFileObj = data.atrSupportDocumentsDTO.map(x=>({
              supportingDocumentFileName:x.supportingDocumentFileName,supportDocumentPath:x.supportDocumentPath
            }))
            SetFileinfo(upFileObj);
          }
          setIsLoading(false);
          console.log(crtAtrObj);
        })
        .catch((err) => {
          console.error("Error fetching data:", err);
          setIsLoading(false);
        });
    };
    fetchApiData(id.id); // Set the default noteId
  }, [updateState]);

  const multipleDocUpload = () => {
    let waringmsg = "";
    // let isValidFile = true;
    const arrayExtension = [
      ".png",
      ".jpg",
      ".pdf",
      ".doc",
      ".docx",
      ".xlsx",
      ".eml",
    ];
    const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
    const selectedFile = document.getElementById("multiDoc").files;
    const TempfileInfo = filesInfo;

    const promises = [];
    const fileCount = selectedFile.length;

    for (let i = 0; i < fileCount; i++) {
      const fileToLoad = selectedFile[i];
      const fileExtession = fileToLoad.name.split(".");

      // Check for special characters in the filename
      if (validname.test(fileToLoad.name)) {
        // isValidFile = false;
        waringmsg = "File name should not contain special characters";
        SetSupportDocWarning({
          ...supportDocWarning,
          [fileToLoad.name]: {
            filename: fileToLoad.name,
            isValid: true,
            warningMsg: waringmsg,
            fileExtnsion: fileExtession[fileExtession.length - 1],
          },
        });
      }

      // Check if the file type is allowed
      if (
        !arrayExtension.includes(`.${fileExtession[fileExtession.length - 1]}`)
      ) {
        // isValidFile = false;
        waringmsg = "File type is not allowed";
        SetSupportDocWarning({
          ...supportDocWarning,
          [fileToLoad.name]: {
            filename: fileToLoad.name,
            isValid: true,
            warningMsg: waringmsg,
            fileExtnsion: fileExtession[fileExtession.length - 1],
          },
        });
        // return;
      }

      // Check file size (5MB limit)
      if (fileToLoad.size > 5242880) {
        waringmsg = "File size should not exceed more than 5MB";
        // isValidFile = false;
        SetSupportDocWarning({
          ...supportDocWarning,
          [fileToLoad.name]: {
            filename: fileToLoad.name,
            isValid: true,
            warningMsg: waringmsg,
            fileExtnsion: fileExtession[fileExtession.length - 1],
          },
        });
        // return;
      }

      const fileReader = new FileReader();
      const promise = new Promise((resolve) => {
        fileReader.onload = function (fileLoadedEvent) {
          resolve({
            name: fileToLoad.name,
            base64: fileLoadedEvent.target.result,
          });
        };
      });

      fileReader.readAsDataURL(fileToLoad);
      promises.push(promise);
    }

    Promise.all(promises)
      .then((fileDataArray) => {
        const updatedTempFileInfo = fileDataArray.reduce(
          (acc, fileData) => {
            const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
            if (!ObjExist.includes(fileData.name)) {
              acc.push({
                // noteSupportingDocumentId: 0,
                // noteId: 0,
                supportDocumentPath: fileData.base64.split(",")[1],
                supportingDocumentFileName: fileData.name,
                // createdDate: new Date(),
                // createdBy: accounts[0].username,
                // modifiedDate: new Date(),
                // modifiedBy: accounts[0].username,
              });
            }
            return acc;
          },
          [...TempfileInfo]
        );
        console.log(TempfileInfo);

        SetFileinfo(updatedTempFileInfo);
      })
      .catch((error) => {
        console.error("Error reading files:", error);
      });
      console.log(supportDocWarning,"supportDocWarning")
  };

  /* Validates Form Data */
  const validateForm = () => {
    const errors = {};
    if (!actionTaken.trim()) {
      setActionTakenError("Action Taken field should not be empty.");
      errors["ActionTaken"] = "NoteTo field should not be empty.";
      setActionTakenBorderColor("#f31700");
    } else {
      setActionTakenError("");
      setActionTakenBorderColor("");
    }
    if (!actionTakenDt) {
      setActionTakenDateError("Action Taken Date field should not be empty.");
      errors["ActionTakenDate"] =
        "Action Taken Date field should not be empty.";
      setActionTakenDateBorderColor("#f31700");
    } else {
      setActionTakenDateError("");
      setActionTakenDateBorderColor("");
    }

    return errors;
  };

  // checking file type and return file icon
  const getFileIcon = (filename) => {
    const fileSplit = filename.split(".");
    const extnsion = `.${fileSplit[fileSplit.length - 1]}`;
    let fileType = fileIcon;
    if (extnsion === ".pdf") {
      fileType = filePdfIcon;
    }
    if (extnsion === ".doc" || extnsion === ".docx") {
      fileType = fileWordIcon;
    }
    if (extnsion === ".png" || extnsion === ".jpg") {
      fileType = fileImageIcon;
    }
    if (extnsion === ".txt") {
      fileType = fileTxtIcon;
    }
    if (extnsion === ".xlsx") {
      fileType = fileDataIcon;
    }
    return fileType;
  };

  const handleOnChangeActionTaken = (event) => {
    setactionTaken(event.target.value);
    setActionTakenBorderColor('');
    setActionTakenError('');
    console.log(actionTaken);
  };

  const handleOnChangeActionTakenDt = (event) => {
    setactionTakenDt(event.target.value);
    setActionTakenDateError('');
    setActionTakenDateBorderColor('');
    console.log(actionTaken);
  };

  const handleClsDlgSuccess = () => {
    setdialogSuccess(!dialogSuccess);
    navigate(redrirectTo);
  };

  const handleDlgBtnSuccess = () => {
    setdialogSuccess(!dialogSuccess);
    navigate(redrirectTo);
  };

  const handleClsDlgFailure = () => {
    setdialogFailure(!dialogFailure);
  };

  const handleDlgBtnFailure = () => {
    setdialogFailure(!dialogFailure);
  };

  const handleatrComments = (event) => {
    setcomments(event.target.value);
  };

  const handleExit = () => {
    navigate(redrirectTo);
  };
   // supportDoc link
   const getSupportDocHyperlink = (supportDoc) => {
    if (supportDoc.length > 0 && supportDoc !== null) {

      supportDoc.map(obj => {
        if (obj.supportBase64 !== null) {
          const byteCharacters = atob(obj.supportBase64);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          // checking file type
          const fileType = getFileType(obj.supportingDocumentFileName);
          // Create a Blob object
          // const blob = new Blob([byteArray], { type: 'application/doc' });
          const blob = new Blob([byteArray], { type: `application/${fileType}` });
          updateSupportDoclink(obj.supportingDocumentFileName, window.URL.createObjectURL(blob));
        }
        else {
          updateSupportDoclink(obj.supportingDocumentFileName, obj.supportDocumentPath);

        }
      })
    }
  }

  const updateSupportDoclink = (fileName, url) => {
    setSupportDoclinks(prevLinks => ({
      ...prevLinks,
      [fileName]: { fileName: fileName, href: url }
    }));
  };
  // getfileType
  const getFileType = (filename) => {
    let fileType = "doc"
    if (filename.endsWith(".pdf")) {
      fileType = "pdf";
    }
    if (filename.endsWith(".doc") || filename.endsWith(".docx")) {
      fileType = "doc";
    }
    if (
      filename.endsWith(".png") ||
      filename.endsWith(".jpg") ||
      filename.endsWith(".img") ||
      filename.endsWith(".svg")
    ) {
      fileType = "image";
    }
    if (filename.endsWith(".txt")) {
      fileType = "txt";
    }
    if (filename.endsWith(".xlsx")) {
      fileType = "xlsx";
    }
    if (filename.endsWith(".eml")) {
      fileType = "eml";
    }
    return fileType;

  }

  // remove multiple attchemnts
  const onRemoveMultiAttachment = (id) => {
    // SetSupportDocWarning( x=> {  
    //   const copy = {...x};
    //   delete copy[filesInfo[id].supportingDocumentFileName];
    //   return copy
    // });
    // console.log(supportDocWarning);
    SetFileinfo(filesInfo.filter((obj, ind) => ind !== id));
  };

  const handleBtnActionComplete = () => {
    let isFilesValid = true;
    filesInfo.map((x) => {
      isFilesValid = !(
        x.supportingDocumentFileName in supportDocWarning
      );
    });

    const validateFields = validateForm();

    if (isFilesValid && Object.keys(validateFields).length === 0) {
      setConfirmDailogObj({
        Confirmtext: "Are you sure you want to Complete this ATR?",
        Description:
          "Please check the details filled along with attachment and click on confirm button to complete the ATR.",
      });
      setDialogOpen(!dialogOpen);
    } else {
      setdialogFailure(true);
      setFailureDailogTxt("Please fill the mandatory fields, check and remove if there are any invalid files attached.")
    }
  };

  const handleBtnAccept = () => {
    setConfirmDailogObj({
      Confirmtext: "Are you sure you want to Accept this action taken?",
      Description:
        "Please check the details filled along with attachment and click on confirm button to accept the action taken.",
    });
    setrequesterStatusType("Accepted");
    setDialogOpen(!dialogOpen);
  };

  const handleBtnReturn = () => {
    if(!comments.trim()){
      setdialogFailure(true);
      setFailureDailogTxt("Please fill the comments to return the ATR.")
      setReqCommentsError("Comments field cannot not be empty.");
      setReqCommentsBorderColor("#f31700");      
    }else{
    setConfirmDailogObj({
      Confirmtext: "Are you sure you want to return this ATR to assignee?",
      Description:
        "Please click on Confirm button to return this ATR to assignee.",
    });
    setReqCommentsError("");
    setReqCommentsBorderColor("");
    setrequesterStatusType("Returned");
    setDialogOpen(!dialogOpen);
  }
  };

  //Handle - Action Complete update by Assignee
  const handleDlgActionComplete = async () => {
    setDialogOpen(!dialogOpen);

    // let actionTkDate = new DateObject(new Date(actionTakenDt)).format("DD-MMM-YYYY hh:mm:ss");
    let actionTkDate = new DateObject(new Date(actionTakenDt)).format("DD/MM/YYYY");

    let params = {
      atrId: crtAtrObj.atrId,
      noteId: crtAtrObj.noteId,
      atrStatus: enumObj.ATRStatusEnum.find((x) => x.dValue === "Completed").id,
      actionTaken: actionTaken,
      strActionTakenDate: actionTkDate,
      createdBy: accounts[0].username,
      atrSupportDocumentsDTO: filesInfo
    };
    
    setIsLoading(!isLoading);

    const accessToken = await getAccessToken({...loginRequest,loginHint:accounts[0].username});

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.ATR_AssigneeAction}`,
      {
        method: "Post",
        body: JSON.stringify(params),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
      }
    )
      .then((res) => {
        // setIsLoading(!isLoading);
        // console.log(res);
        return res.json();
      })
      .then((data) => {
        console.log(data);
        setIsLoading(false);
        if (data.statusMessage === "Success") {
          setdialogSuccess(true);
        } else {
          setdialogFailure(true);
          setFailureDailogTxt(failuremsg);
        }
      })
      .catch((err) => {
        console.log(err);
        setdialogFailure(true);
        setFailureDailogTxt(failuremsg);
      });
  };

  //handle - Accept and Return update by Requester
  const handleDlgRequester = async () => {
    setDialogOpen(!dialogOpen);

    let params = {
      atrId: crtAtrObj.atrId,
      // atrStatus: requesterStatusType === "Accepted" ? 3 : 1,
      ActionerComment: comments,
      createdBy: accounts[0].username,
      RequesterStatus: requesterStatusType, //Accepted/Returned
    };
    setIsLoading(!isLoading);

    const accessToken = await getAccessToken({...loginRequest,loginHint:accounts[0].username});

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.ATR_RequesterAction}`,
      {
        method: "Post",
        body: JSON.stringify(params),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
      }
    )
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        console.log(data);
        setIsLoading(false);
        if (data.statusMessage === "Success") {
          setdialogSuccess(true);
        } else {
          setdialogFailure(true);
          setFailureDailogTxt(failuremsg);
        }
      })
      .catch((err) => {
        console.log(err);
        setdialogFailure(true);
        setFailureDailogTxt(failuremsg);
      });
  };

  return (
    <>
      <Navbar header="IB Smart Office - eDak"/>
      <Sidebar />
      <div className="FormMaincontainer cstATRForm">
        <div className="container">
          {/* <div className="pgTitleContainer">
          <h1
            style={{
              textAlign: "left",
              // fontFamily: "'Quicksand', sans-serif",
              fontSize: "22px",
            }}
          >
            ATR workflow form:
          </h1>
          </div> */}
          <div className="SectionHeads eNoteAtrFormHdr row">
            {/* ATR Workflow Form */}
            <div className="cstformHdrLeftContainer">
              {crtAtrObj.strAtrStatus === ""?"":`Pending With: ${isPendingWith}`}
            </div>
            <div className="cstformHdrMiddleContainer">
               ATR Workflow Form
            </div>
            <div className="cstformHdrRightContainer">
              {`Status: ${crtAtrObj.strAtrStatus}`}
            </div>

          </div>
          {/* <div className="FormHead"> </div> */}
          <Form
            render={(formRenderProps) => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="noteTo">Note To:</label>
                          <Field
                            component={Input}
                            id="noteTo"
                            name="Noteto"
                            key={crtAtrObj.designation}
                            defaultValue={crtAtrObj.designation}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="status">Status:</label>
                          <Field
                            component={Input}
                            id="status"
                            name="Status"
                            key={crtAtrObj.strAtrStatus}
                            defaultValue={crtAtrObj.strAtrStatus}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="creationDate">Creation Date:</label>
                          <Field
                            component={Input}
                            id="creationDate"
                            name="CreationDate"
                            key={crtAtrObj.createdDate}
                            defaultValue={new DateObject(
                              new Date(crtAtrObj.createdDate)
                            ).format("DD-MM-YYYY")}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="atrNoteid">ATR Note ID:</label>
                          <Field
                            component={Input}
                            id="atrNoteid"
                            name="ATRNoteId"
                            key={crtAtrObj.noteNumber}
                            defaultValue={crtAtrObj.noteNumber}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="department">Department:</label>
                          <Field
                            component={Input}
                            id="department"
                            name="Department"
                            key={crtAtrObj.departmentName}
                            defaultValue={crtAtrObj.departmentName}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="subject">Subject:</label>
                          <Field
                            component={Input}
                            id="subject"
                            name="Subject"
                            key={crtAtrObj.subject}
                            defaultValue={crtAtrObj.subject}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="assingedBy">Assigned By:</label>
                          <Field
                            component={Input}
                            id="assingedBy"
                            name="AssignedBy"
                            key={crtAtrObj.approverEmail}
                            defaultValue={crtAtrObj.approverEmailName}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="remarks">Remarks:</label>
                          <Field
                            component={Input}
                            id="remarks"
                            name="Remarks"
                            key={crtAtrObj.remarks}
                            defaultValue={crtAtrObj.remarks}
                            readOnly={!isEditMode}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    {!(isRequester) && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <label htmlFor="comments">Comments:</label>
                            <TextArea
                              component={Input}
                              id="comments"
                              name="Comments"
                              // key={crtAtrObj.noteRequesterComments}
                              onChange={handleatrComments}
                              value={comments === null?"":comments}
                              // defaultValue={crtAtrObj.noteRequesterComments}
                              readOnly={!isEditMode}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="actionTaken">Action Taken:{isAssignee && <span className="required-asterisk">*</span>}</label>
                          <TextArea
                            component={Input}
                            id="actionTaken"
                            name="ActionTaken"
                            // key={crtAtrObj.actionTaken}
                            value={actionTaken === null?"":actionTaken}
                            defaultValue={actionTaken}
                            style={{ borderColor: actionTakenBorderColor }}
                            onChange={handleOnChangeActionTaken}
                            readOnly={!(isAssignee)}
                          />
                        </div>
                        <div style={{ color: '#f31700', fontStyle: 'italic', fontSize: '12px', marginTop: '4px' }}>{actionTakenError}</div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <label htmlFor="actionTakendate" >
                            Action Taken Date:{ isAssignee && <span className="required-asterisk">*</span>}
                          </label>
                          {isAssignee ? 
                          <DatePicker
                            format={"dd-MM-yyyy"}
                            placeholder="Choose a date..."
                            onChange={handleOnChangeActionTakenDt}
                            value={actionTakenDt}
                            defaultValue={new Date(actionTakenDt)}
                            style={{ borderColor: actionTakenDateBorderColor }}
                            readOnly={true}
                          />:
                          <Field
                            component={Input}
                            id="actionTkn"
                            name="actionTakenDate"
                            key={actionTakenDt}
                            defaultValue={new DateObject(new Date(actionTakenDt)).format("DD-MM-YYYY")}
                            readOnly={!isEditMode}
                          />}
                          {/* {!(crtAtrObj.atrStatus === 1 && crtAtrObj.atrAssignerEmail === accounts[0].username
                              ) && <Field
                              component={Input}
                              id="actionTakenDate"
                              name="ActionTakendate"
                              key={crtAtrObj.actionTakenDate}
                              hidden={(crtAtrObj.atrStatus === 1 && crtAtrObj.approverEmail === accounts[0].username)}
                              defaultValue={new DateObject(
                                new Date(crtAtrObj.actionTakenDate)
                              ).format("DD/MM/YYYY")}
                              readOnly={!isEditMode}
                            />} */}
                        </div>
                        <div style={{ color: '#f31700', fontStyle: 'italic', fontSize: '12px', marginTop: '4px' }}>{actionTakenDateError}</div>
                      </FieldWrapper>
                    </div>
                    {isRequester && (
                      <div className="col-md-6" vis>
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <label htmlFor="comments">Comments:</label>
                            <TextArea
                              component={Input}
                              id="comments"
                              name="Comments"
                              value={comments}
                              defaultValue={comments}
                              onChange={handleatrComments}
                              style={{ borderColor: reqCommentsBorderColor }}
                              //readOnly={!isEditMode}
                            />
                          </div>
                          <div style={{ color: '#f31700', fontStyle: 'italic', fontSize: '12px', marginTop: '4px' }}>{reqCommentsError}</div>
                        </FieldWrapper>
                      </div>
                    )}
                  </div>
                </fieldset>

                {isAssignee && (
                    <div>
                      <div className="SectionHeads eNoteAtrFormHdr row">
                        Attach Support Documents
                      </div>

                      {/* multidoc controller */}
                      <div className="SectionRow row">
                        <div className="Attachemntfileinfo-ind">
                          <input
                            type="file"
                            id="multiDoc"
                            multiple="multiple"
                            onChange={multipleDocUpload}
                            style={{ width: "105px" }}
                          />
                        </div>
                        {filesInfo?.map((obj, ind) => (
                          <div className="Attachemntfileinfo-ind" key={ind}>
                            <span className="attachemntIconInfoConationer">
                              <span className="AttchemntIconWraper">
                                {/* Assuming you have different icons for different file types */}
                                <SvgIcon
                                  icon={getFileIcon(
                                    obj.supportingDocumentFileName
                                  )}
                                  size="xxlarge"
                                />
                                <span className="attachemnrt-warningifoConatiner">
                                  <div className="attachemnrt-warningifo-fileinfo">
                                    {obj.supportingDocumentFileName}
                                  </div>
                                  <span
                                    style={{ color: "red", fontSize: "10px" }}
                                  >
                                    {
                                      supportDocWarning[
                                        obj.supportingDocumentFileName
                                      ]?.warningMsg
                                    }
                                  </span>
                                </span>
                                {/* <span>{obj.supportingDocumentFileName}<br /><span style={{ color: "red", fontSize: "10px" }}>{supportDocWarning[obj.supportingDocumentFileName]?.warningMsg}</span></span> */}
                              </span>
                              <span
                                className="AttchemntIconWraperCancel"
                                onClick={() => onRemoveMultiAttachment(ind)}
                              >
                                X
                              </span>
                            </span>
                          </div>
                        ))}
                        {/* <Upload batch={false} restrictions={{ allowedExtensions: [".pdf", ".doc", ".docx", ".xlsx", ".eml"], maxFileSize: 5242880, }} multiple={true} defaultFiles={[]} withCredentials={false} accept="string" saveUrl={'https://demos.telerik.com/kendo-ui/service-v4/upload/save'} removeUrl={'https://demos.telerik.com/kendo-ui/service-v4/upload/remove'} />
                         */}
                        <div style={{ textAlign: "right", color: "green" }}>
                         Allowed Formats (images,pdf,eml,doc,docx,xlsx only) Upto 5MB max.
                        </div>
                      </div>
                    </div>
                  )}

                {!(isAssignee) && (
                  <div>
                    <div className="SectionHeads eNoteAtrFormHdr row">
                      Workflow Log
                    </div>
                    <div className="SectionRow row">
                      <table className="SectionRow cstATRFormTbl tableStyle" style={{ width: "100%" }}>
                        <tr>
                          <th>Action</th>
                          <th>Action By</th>
                          <th>Action Date</th>
                        </tr>
                        {crtAtrObj.atrWorkflowsDTO?.map((obj, ind) => (
                          <tr key={ind}>
                            <td>{obj.action}</td>
                            {/* Bug fix - 293 - 27/03 */}
                            <td>{obj.actionByName}</td>
                            <td>
                              {new DateObject(new Date(obj.createdDate)).format(
                                "DD-MMM-YYYY hh:mm:ss A"
                              )}
                            </td>
                          </tr>
                        ))}
                      </table>
                    </div>
                  </div>
                )}

                {!(isAssignee) && (
                  <div>
                    <div className="SectionHeads eNoteAtrFormHdr row">
                      File Attachments
                    </div>
                    <div
                      className="SectionRow row"
                    >
                      <table className="cstATRFormTbl tableStyle" style={{ width: "100%" }}>
                          <tr>
                            <th>Document link</th>
                            <th>Attached By</th>
                            <th>Attached Date</th>
                          </tr>
                          { crtAtrObj.atrSupportDocumentsDTO?.map((doc, ind) => (
                            <tr key={ind}>
                              <td>
                                <a
                                  href={supportDoclink[doc.supportingDocumentFileName].href}
                                  // target="_blank"
                                  // rel="noopener noreferrer"
                                  download={doc.supportingDocumentFileName}
                                >
                                  {doc.supportingDocumentFileName}
                                </a>
                              </td>
                              {/* Bug fix - 293 - 27/03 */}
                              <td>{doc.createdByName}</td>
                              <td>{new DateObject(new Date(doc.createdDate)).format(
                                "DD-MMM-YYYY hh:mm:ss A"
                              )}</td>
                            </tr>
                          ))}
                      </table>
                    </div>
                  </div>
                )}

                <div
                  className="k-form-buttons"
                  style={{
                    justifyContent: "center",
                    marginBottom: "20px",
                    marginTop: "20px",
                  }}
                >
                  {isAssignee && (
                      <Button
                        type={"submit"}
                        onClick={handleBtnActionComplete}
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                      >
                        <span className="k-icon-sm k-icon k-font-icon  k-i-track-changes-accept cursor atrFormBtnStyles"></span>
                        Action Completed
                      </Button>
                    )}
                  {isRequester && (
                      <Button
                        type={"submit"}
                        onClick={handleBtnAccept}
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                      >
                        <span className="k-icon-xs k-icon k-font-icon  k-i-checkmark cursor atrFormBtnStyles"></span>
                        Accept
                      </Button>
                    )}
                  {isRequester && (
                      <Button
                        onClick={handleBtnReturn}
                        type={"submit"}
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                      >
                        <span className="k-icon-xs k-icon k-font-icon  k-i-undo cursor atrFormBtnStyles"></span>
                        Return
                      </Button>
                    )}
                  <Button
                    type={"submit"}
                    onClick={handleExit}
                    className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                  >
                    <span className="k-icon-sm k-icon k-font-icon  k-i-x-circle cursor atrFormBtnStyles"></span>
                    Exit
                  </Button>
                </div>
                {isLoading && ( <PageLoader/>)}
                {dialogOpen && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={handleCloseDlg}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      {confirmDailogObj.Confirmtext}
                    </p>
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                      }}
                    >
                      {confirmDailogObj.Description}
                    </p>
                    <DialogActionsBar>
                      {isAssignee && (
                        <Button
                          className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                          onClick={handleDlgActionComplete}
                          // disabled={isLoading}
                        >
                          <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                          Confirm
                        </Button>
                      )}
                      {isRequester && (
                        <Button
                          className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                          onClick={handleDlgRequester}
                        >
                          <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                          Confirm
                        </Button>
                      )}
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleCloseDlg}
                      >
                        <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}

                {dialogSuccess && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleClsDlgSuccess}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      ATR updation completed successfully!
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleDlgBtnSuccess}
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {dialogFailure && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleClsDlgFailure}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      {failureDailogTxt}
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleDlgBtnFailure}
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
              </FormElement>
            )}
          />
        </div>
      </div>
      {/* <div className="pgFooterContainer"> */}
      <Footer />
      {/* </div> */}
    </>
  );
};