import React, { useState, useEffect } from "react";
// Import Kendo Components
import { Button } from "@progress/kendo-react-buttons";
import { orderBy } from "@progress/kendo-data-query";
import { DropDownList } from "@progress/kendo-react-dropdowns";
// Import External Libraries
import { useMsal, useAccount } from "@azure/msal-react";
import DateObject from "react-date-object";
// Import components
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Dashboard } from "./dashboard";
import { Sidebar } from "../components/sidebar";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { PageLoader } from "../components/pageLoader";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";
import { ChartContainer } from "../components/edakChartInfo";
import { useTabContext } from "../App";
// Import CSS styles
import "../styles/datagridpage.css";

const initialSort = [
  {
    field: "dakId",
    dir: "desc",
  }
];

export const EDakHome = () => {
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const { activeTab } = useTabContext();
  const [activeButton, setActiveButton] = useState(activeTab);
  const [myPendingAction, setMyPendingAction] = useState(0);
  const [myPendingForApproval, setMyPendingForApproval] = useState(0);
  const [myFollowUp, setMyFollowUp] = useState(0);
  const [apiOutput, setapiOutput] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSecretary, setIsSecretary] = useState(true);
  const [selectedView, setSelectedView] = useState("");
  const [apiOutputforChart, setApiOutputforChart] = useState([]);
  const [myDak, setMyDak] = useState(0);
  const [count, setCount] = useState("");
  const [isMobileView, setIsMobileView] = useState(window.innerWidth <= 768);
  const [selectedOption, setSelectedOption] = useState(null);

  useEffect(() => {
    // on load call chartData API
    handleButtonClick(activeTab);
    getCount(activeTab);

    const initialOption = options.find(option => option.value === activeTab);
    setSelectedOption(initialOption);

    const handleResize = () => {
      setIsMobileView(window.innerWidth <= 1105);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // get data for charts 
  const fetchDataForcharts = async (endPoint, accessToken) => {
    // custom colors 
    const colorCodes = [
      "#7731a3", // Deep Purple
      "rgb(254, 215, 76)", // Yellow
      "#ba3294", // Purple
      "rgb(78, 185, 167)", // Turquoise
      "#d92b2b", // Red
      "rgb(12, 77, 162)", // Blue
      "#4dc313", // Green
      "#1e6bb5", // Dark Blue
      "rgb(255, 165, 0)" // Orange
    ];

    try {
      const response = await fetch(
        `${API_BASE_URL}${endPoint}?userEmailId=${accounts[0].username}`,
        {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        }
      );

      if (response.ok) {
        let dakCount = 0;
        setIsLoading(false);
        const apiOutput = await response.json();
        // adding color property to Response. adding custom colors dynamically
        apiOutput.lstEdakChart = apiOutput.lstEdakChart?.map((obj, index) => { return { ...obj, color: colorCodes[index], status: `${obj.status}: ${obj.count}` } });
        // adding color property to Response. adding custom colors dynamically
        apiOutput.lstSourceTypeCount = apiOutput.lstSourceTypeCount?.map((obj, index) => { return { ...obj, color: colorCodes[index], status: `${obj.status}: ${obj.count}` } })
        //Get the total count for edak using count property.

        apiOutput.lstEdakChart.map(obj => dakCount = dakCount + obj.count)
        setMyDak(dakCount);
        setApiOutputforChart(apiOutput);
      }
    }
    catch {
      console.log("err")
    }
  }
  // To get the full count for eDak pending list
  const getCount = async (listType) => {

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eDak_GetLandingCount}?createdBy=${accounts[0].username}`,
      {
        method: "POST",
        body: JSON.stringify({
          status: 5,
          createdBy: accounts[0].username,
        }),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      }
    )
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        setCount(data);
        switch (listType) {
          case "My Pending for Action":
            setMyPendingAction(data?.myPendingforAction);
            break;
          case "My Pending for Approval":
            setMyPendingForApproval(data?.myPendingforApproval);
            break;
          case "My Follow up":
            setMyFollowUp(data?.myFollowUp);
            break;
          default:
            break;
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };
  // Based on button text API will call
  const handleButtonClick = async (buttonText) => {
    setActiveButton(buttonText);
    setIsLoading(true);
    getCount(buttonText);
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
    });
    const enumsObject = await dropdowns.json();
    let listType;
    switch (buttonText) {
      case "My Pending for Action":
        listType = "My Pending for Action";
        fetchApiData(API_ENDPOINTS.eDak_GetRequests, enumsObject.status.find((x) => x.dValue === "In Progress").id, buttonText, accessToken, listType);
        break;
      case "My Pending for Approval":
        listType = "My Pending for Approval";
        fetchApiData(API_ENDPOINTS.eDak_GetRequests, enumsObject.status.find((x) => x.dValue === "In Progress").id, buttonText, accessToken, listType);
        break;
      case "My Follow up":
        listType = "My Follow up";
        fetchApiData(API_ENDPOINTS.eDak_GetRequests, enumsObject.status.find((x) => x.dValue === "In Progress").id, buttonText, accessToken, listType);
        break;
      case "My eDak":
        fetchDataForcharts(API_ENDPOINTS.eDak_GetChart, accessToken);
        break;
      default:
        listType = "My Pending for Action";
        fetchApiData(API_ENDPOINTS.eDak_GetRequests, enumsObject.status.find((x) => x.dValue === "In Progress").id, "My Pending for Action", accessToken, listType);
        getCount(listType); // Call getCount here
        break;
    }
  };

  // Based on button click  this function will call 
  const fetchApiData = async (apiEndpoint, status, buttonText, accessToken, listType) => {
    setSelectedView(buttonText);
    try {
      const response = await fetch(`${API_BASE_URL}${apiEndpoint}`, {
        method: "POST",
        body: JSON.stringify({

          createdBy: accounts[0].username,
          listType: listType,
        }),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      });

      if (response.ok) {
        const apiData = await response.json();
        if (apiData.pendingDakList) {
          let resData = apiData.pendingDakList;
          const ordData = orderBy(resData, initialSort);
          // converting date object for  modifieddate and createdDate
          const apiCstData = ordData.map(x => ({
            ...x, modifiedDate: new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm A"), //seconds hand removed
            createdDate: new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm A")
          }));
          setapiOutput(apiCstData);
          // based on button text  store  the total count of Response 
          /*  switch (buttonText) {
             case "My Pending for Action":
               setMyPendingAction(count.myPendingforAction);
               break;
             case "My Pending for Approval":
               setMyPendingForApproval(count.myPendingforApproval);
               break;
             case "My Follow up":
               setMyFollowUp(count.myFollowUp);
               break;
             // Add more cases for other buttons if needed
             default:
               break; */
          // }
          getCount(buttonText);
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }

    setIsLoading(false);
  };

  const options = [
    { text: "My eDak", value: "My eDak" },
    { text: "My Pending for Action", value: "My Pending for Action" },
    { text: "My Pending for Approval", value: "My Pending for Approval" },
    { text: "My Follow up", value: "My Follow up" }, 
  ];

  const handleSelect = (event) => {
    const selectedValue = event.target.value;
    
    setSelectedOption(options.find(option => option.value === selectedValue));
    // selectedValue
    setSelectedOption(selectedValue);
    handleButtonClick(selectedValue?.value);
  };

  const renderDropdown = () => (
    <DropDownList
      className="landing_Page_Dropdown"
      data={options}
      value={selectedOption}
      textField="text"
      dataItemKey="value"
      onChange={handleSelect}
      defaultItem={{ text: "Select an option", value: null }}
    />
  );

  const renderButtons = () => (

    <div className="row landingPgTopBtnRow">
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "22%" : "22%",
          background:
            activeButton === "My eDak" ? "#034ea1" : "",
          color: activeButton === "My eDak" ? "#ffff" : "",
        }}
        onClick={() => handleButtonClick("My eDak")}
      >
        My eDak
        {activeButton === "My eDak" && (<span className="landingPgTopBtncontent">{myDak}</span>)}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "22%" : "22%",
          background:
            activeButton === "My Pending for Action" ? "#034ea1" : "",
          color:
            activeButton === "My Pending for Action" ? "#ffff" : "#333333",
        }}
        onClick={() => handleButtonClick("My Pending for Action")}
      >
        My Pending Action
        {activeButton === "My Pending for Action" && (
          <span className="landingPgTopBtncontent">
            {myPendingAction}
          </span>
        )}        
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "22%" : "22%",
          background:
            activeButton === "My Pending for Approval"
              ? "#034ea1"
               : "",
          color:
            activeButton === "My Pending for Approval"
              ? "#ffff"
               : "",
        }}
        onClick={() => handleButtonClick("My Pending for Approval")}
      >
        My Pending Approval
        {activeButton === "My Pending for Approval" && (
          <span className="landingPgTopBtncontent">
            {myPendingForApproval}
          </span>
        )}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "22%" : "22%",
          background:
            activeButton === "My Follow up" ? "#034ea1" : "",
          color: activeButton === "My Follow up" ? "#ffff" : "",
        }}
        onClick={() => handleButtonClick("My Follow up")}   
             
      >My Follow up
      
      {activeButton === "My Follow up" && (
                <span className="landingPgTopBtncontent" >
                  {myFollowUp}
                </span>
              )}</Button>      
    </div>
  );

  return (
    <div>
      <Navbar header="IB Smart Office - eDak" />
      <Sidebar defaultOpenComponent={true} />
      <div className="container datagridpage">
        <div className="datagridPghdrBtns">
          <div className="row landingPgTopBtnRow">
            {/* <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "22%" : "22%",
                background:
                  activeButton === "My eDak" ? "#034ea1" : "",
                color: activeButton === "My eDak" ? "#ffff" : "",
              }}
              onClick={() => handleButtonClick("My eDak")}
            >
              My eDak
              {activeButton === "My eDak" && (<span className="landingPgTopBtncontent">{myDak}</span>)}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "22%" : "22%",
                background:
                  activeButton === "My Pending for Action" ? "#034ea1" : "",
                color:
                  activeButton === "My Pending for Action" ? "#ffff" : "#333333",
              }}
              onClick={() => handleButtonClick("My Pending for Action")}
            >
              My Pending Action
              {activeButton === "My Pending for Action" && (
                <span className="landingPgTopBtncontent">
                  {myPendingAction}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "22%" : "22%",
                background:
                  activeButton === "My Pending for Approval"
                    ? "#034ea1"
                    : "",
                color:
                  activeButton === "My Pending for Approval"
                    ? "#ffff"
                    : "",
              }}
              onClick={() => handleButtonClick("My Pending for Approval")}
            >
              My Pending Approval
              {activeButton === "My Pending for Approval" && (
                <span className="landingPgTopBtncontent">
                  {myPendingForApproval}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "22%" : "22%",
                background:
                  activeButton === "My Follow up" ? "#034ea1" : "",
                color: activeButton === "My Follow up" ? "#ffff" : "",
              }}
              onClick={() => handleButtonClick("My Follow up")}
            >
              My Follow up
              {activeButton === "My Follow up" && (
                <span className="landingPgTopBtncontent" >
                  {myFollowUp}
                </span>
              )}
            </Button> */}
            {isMobileView ? renderDropdown() : renderButtons()}
          </div>
        </div>
        {isLoading ?
          <PageLoader /> :
          activeButton === "My eDak" ?
            <ChartContainer apiOutput={apiOutputforChart} count={myDak} /> :
            <Dashboard apiOutput={apiOutput} selectedView={selectedView} />
        }
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};
