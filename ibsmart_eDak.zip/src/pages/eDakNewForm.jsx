import React, { useState, useEffect } from "react";
// Import Kendo Components
import { Form, Field, FormElement, FieldWrapper } from "@progress/kendo-react-form";
import { Input, TextArea } from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { Button } from "@progress/kendo-react-buttons";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { Label, Hint } from "@progress/kendo-react-labels";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
// Import Kendo icon Components
import { infoCircleIcon } from "@progress/kendo-svg-icons";
import { SvgIcon } from "@progress/kendo-react-common";
import {
  filePdfIcon,
  fileWordIcon,
  fileImageIcon,
  fileTxtIcon,
  fileDataIcon,
  fileIcon,
  xIcon,
} from "@progress/kendo-svg-icons";
// Import External Libraries
import { Link, useParams } from "react-router-dom";
import { useMsal, useAccount } from "@azure/msal-react";
import { useNavigate } from "react-router-dom";
import DateObject from "react-date-object";
import Clock from 'react-live-clock';
// Import components
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Sidebar } from "../components/sidebar";
import { TableDraggableRows } from "../components/tableDragRows";
import { PageLoader } from "../components/pageLoader";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";
import useAutosave from "../hooks/useAutoSave.hook";
import { useTabContext } from "../App";
// Import CSS styles
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/forms.css";
import "../styles/responsiveDesign.css";

// Displays the custom dialog title name
const CustomDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};
const CustomConfirmDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span> Confirmation
    </div>
  );
};
// Table fields for approver and reviewer user
const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",
  },
  {
    field: "srNo",
    header: "SR No",
    width: "120px",
  },
];

// mobile view responsive
const mobileColumns = [
  {
    field: "displayName",
    header: "Person Name",
    width: "100px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "100px",
  },
  {
    field: "srNo",
    header: "SR No",
    width: "70px",
  },
];

const orgUsersGroupPickerColumnMapping = [
  {
    field: "displayName",
    header: "Group Name",
    width: "400px",
  }
]

export const ReorderContext = React.createContext({
  reorder: () => { },
  dragStart: () => { },
});

export const EdakNewForm = () => {
  // Value render clears the value in field when we click on close icon in dropdown
  const valueRender = (element, value, fieldName) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      setGroupNames('');
      setState(prevState => ({
        ...prevState,
        [fieldName]: '', // Clear the value of the specified field
      }));
      setGroupData([]);
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} className="venderChildProps_">
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props,
    }, children);
  };
  // change -13/05  clear  department Value 
  // const valueRenderDepartment = (element, value) => {
  //   const clearValue = (e) => {
  //     e.stopPropagation();
  //     e.preventDefault();
  //     setSelectedDepartment(null)
  //     //  change 16/05  on clear of department approver and reviwers need to clear 
  //    setUserDepertment('');
  //    seteDakApproverData([]);
  //    seteDakReviewerData([])
  //   };
  //   if (!value) {
  //     return element;
  //   }
  //   const children = [
  //     <span key={1} style={{
  //       overflow: 'hidden',
  //       textOverflow: 'ellipsis',
  //       flexGrow: 1
  //     }}>
  //       {element.props.children}
  //     </span>,
  //     <SvgIcon icon={xIcon} onClick={clearValue} />
  //   ];
  //   return React.cloneElement(element, {
  //     ...element.props
  //   }, children);
  // };
  const  {setTab} =useTabContext();
  const navigate = useNavigate();
  const [SourceType, setsourceType] = useState([]);
  const [DocumentType, setDocumenttype] = useState([]);
  const [MovementType, setMovementType] = useState([]);
  const [NameoftheAgency, setNameoftheAgency] = useState([]);
  const [Category, setCategory] = useState([]);
  const [ActionType, setActionType] = useState([]);
  const [ReminderFequency, setreminderFequency] = useState([]);
  const [ReminderType, setReminderType] = useState([]);
  const [noteComments, setNoteComments] = useState([]);
  const [eDakapproverData, seteDakApproverData] = useState([]);
  const [edakreviewerData, seteDakReviewerData] = useState([]);
  const [departmentError] = useState("");
  const [errorsourceBorderColor, seterrorsourceBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [errordocumentBorderColor, seterrordocumentBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [errorcategoryBorderColor, seterrorcategoryBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [errorSubjectBorderColor, seterrorSubjectBorderColor] = useState('rgba(0, 0, 0, 0.12)');
  const [errorOther, seterrorOther] = useState('rgba(0, 0, 0, 0.12)');
  const [errorCommentsBorderColor, seterrorCommentsBorderColor] = useState('rgba(0, 0, 0, 0.12)');
  const [errorSearchBorderColor, seterrorSearchBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [errorActionTypeBorderColor, seterrorActionTypeBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [errormovement, setErrorMovement] = useState("rgba(0, 0, 0, 0.12)");
  const [errorTo, seterrorTo] = useState("rgba(0, 0, 0, 0.12)");
  const [errorNameofAgency, setErrorNameofAgency] = useState("rgba(0, 0, 0, 0.12)");
  const [errorOtherAction, seterrorOtherAction] = useState("rgba(0, 0, 0, 0.12)");
  const [errorReminderType, seterrorReminderType] = useState("rgba(0, 0, 0, 0.12)");
  const [errorReminderFreq, seterrorReminderFreq] = useState("rgba(0, 0, 0, 0.12)");
  const [errorReceivedDate, setReceivedDate] = useState("rgba(0, 0, 0, 0.12)");
  const [errorTargetDate, seterrorTargetDateBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const urlParam = useParams();
  const [dakId] = useState(urlParam.id);
  const [draftId, setDraftId] = useState(dakId === "new" ? 0 : dakId);
  // const [redirectTo] = useState("/views/In%20Progress");
  const [redirectTo] = useState("/datagridpage");
  const [selectedReveiwer, setSelectedReviewer] = useState(null);
  const [selectReceipient, setSelectReceipient] = useState(null)
  const [combovalueApprover, setComboValueApprover] = useState(null);
  const [visible, setVisible] = useState(false);
  const [visibleCancelCfrm, setVisibleCancelCfrm] = useState(false);
  const [alertvisible, setAlertVisible] = useState(false);
  const [visiblesave, setVisibleSave] = useState(false);
  const [validationErrors, setValidationErrors] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [isSecretaryExist, setisSecretaryExist] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState(false);
  const [enumsObj, setEnumsObj] = useState(null);
  const [isNewForm] = useState(dakId === "new");
  const [souceTypeField, setSouceTypeField] = useState(false);
  const [agencyOtherField, setSelectAgency] = useState('Other');  // condition for agency type when other is selected
  const [showAgency, setShowAgency] = useState(false);
  const [showReceivedDate, setShowReceivedDate] = useState(false);
  const [showTo, setShowTo] = useState(false);
  const [actionOther, setSelectAction] = useState('Other'); // condition for action type when other is selected
  const [showAction, setShowAction] = useState(false);
  const [showFollowUpDate, setshowFollowUpDate] = useState(false); // condition for action type when follow up is selected follow up date field should display
  const [showTargetDate, setShowTargetDate] = useState(false); // condition to show target date when in Action Type is not selected for Information and Follow-up
  const [reminderFrequency, setReminderFrequency] = useState(false); // condition for action type when Information is selected Reminder Frequency field should not display
  const [hideRecipitent, sethideRecipitent] = useState(true);
  const [orgEmployees, setOrgEmployees] = useState([]);
  const [userData, setUserData] = useState([]);
  const [usermailRecipients, setMailRecipients] = useState([]);
  const [groupData, setGroupData] = useState([]);
  const [groupNames, setGroupNames] = useState('');
  const [groupMasterId, setGroupMasterId] = useState(null);
  const [groupMasterIds, setGroupMasterIds] = useState([]);
  const [signedBy, setSignedBy] = useState({});
  const [selectedreceivedDate, setSelectedReceivedDate] = useState(null);
  const [selectFollowUpDate, setSelectFollowUpDate] = useState(null);
  const [selectTargetDate, setSelectTargetDate] = useState(null);
  const [selectCC, setSelectedCC] = useState(null)
  const [edakCCData, setEdakCCData] = useState([]);
  const [selectMailRecipient, setMailRecipient] = useState(null)
  const [edakMailRecipientData, setEdakMailRecipientData] = useState([]);
  const [hideRecipient, setHideRecipient] = useState(true);
  const [groupGeneral, setGroupGeneral] = useState(null);
  const [recipientData, setRecipientData] = useState([]);
  const [showError, setShowError] = useState(false);
  const [showTargetError, setShowTargetError] = useState(false);
  const [showFollowError, setshowFollowError] = useState(false);
  // const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [departmentList, setDepartmentList] = useState([]);
  // const [departmentBorderColor, setDepartmentBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [supportingDocError, setSupportingError] = useState("");
  const [allOrgUsers, setAllOrgUsers] = useState([]);
  const [groupNamesData,setGroupNamesData] = useState([]);
  const [pdfPath,setpdfPath] = useState(null);
  const max = 250;
  const isMobile = window.innerWidth <= 768;
  const [state, setState] = useState({
    // General Details
    department: "",
    sourceType: "",
    documentType: "",
    movementType: "",
    nameOfAgency: "",
    other: "",
    receivedDate: "",
    to: "",
    category: "",
    search: "",
    comments: "",
    cc: "",
    subject: "",
    // Recipient Details
    actionType: "",
    otherAction: "",
    mailRecipient: "",
    followUpDate: "",
    targetDate: "",
    reminderType: "",
    reminderFrequency: "",
    recipients: [],
    group: "",
    supportingdocument: "",
    createdBy: "",
    status: "",
    statusMsg: "",
    createdDate: "",
    groupName: ""
  });
  const [filesInfo, SetFileinfo] = useState([]);
  const [wordandPdfWarring, SetWordPDFInfowarring] = useState({
    PDFInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
    },
    wordInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
    },
  });
  const [supportDocWarning, SetSupportDocWarning] = useState({});
  const { accounts,instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [userDepartment, setUserDepertment] = useState("");
  const [userDesignation, setUserDesignation] = useState("");
  const [isSaveAndSubmitActionCompleted, setisSaveAndSubmitActionCompleted] = useState(false)

  useEffect(() => {
    setIsLoading(true);
    getUserDepartment();
  }, []);

  // useEffect(() => {
  //   const fetchGroups = async () => {
  //     try {
  //       const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
  //       const groupMasterId = await getGroups(groupId, groupNames, accessToken);
  //       setGroupMasterId(groupMasterId);
  //       console.log(groupMasterId,"groupMasterId");

  //     } catch (error) {
  //       console.error("Error fetching groups:", error);
  //     }
  //   };
  //   fetchGroups();
  // }, [groupId, groupNames]);

  //Get login users department and designation
  const getUserDepartment = async () => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      const obj = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetailsByPrincipalName(accounts[0].username)}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      });
      const departmentDetails = await obj.json();
      setUserDepertment(departmentDetails[0].department);
      setUserDesignation(departmentDetails[0].jobTitle);
      await getDefaultConfigData(departmentDetails[0].department);
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  };

  // Change 13/05 API call for department list
  const getDepartmentList = async () => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const obj = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_Department_List}`
      , {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }
    );
    const departmentDetailsList = await obj.json();
    setDepartmentList(departmentDetailsList)
    // console.log(departmentDetailsList, "departmentDetailsList");
  }

   /* get defalutApprovers on change of department 

  Change 16/05 on change department this function will call */


const getDefaultConfigApprovers=async (userDepartment)=>{
  // if (isNewForm) {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const approverresponse = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eDak_GetDakApprovers(userDepartment)}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
    }
    );

    const reviewerresponse = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eDak_GetDakReviewer(userDepartment)}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
    }
    );

    const edakapprover = await approverresponse.json();
    const edakreviewer = await reviewerresponse.json();
    if (edakapprover) {
      seteDakApproverData(edakapprover);
      seteDakApproverData(edakapprover.map(obj => { return { ...obj, signedBy: false } }));
    }
    if (edakreviewer)
      seteDakReviewerData(edakreviewer);
      seteDakReviewerData(edakreviewer.map(obj => { return { ...obj, signedBy: false } }));
    }

  //Get all the dropdowns and pre configured data
  const getDefaultConfigData = async (userDepartment) => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      //get enum objects
      const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      });
      const dropdownslist = await dropdowns.json();
      getDepartmentList();
      setEnumsObj(dropdownslist);
      setsourceType(dropdownslist.sourceType);
      setDocumenttype(dropdownslist.DocumentType);
      setMovementType(dropdownslist.movementType);
      setNameoftheAgency(dropdownslist.nameofAgency);
      setCategory(dropdownslist.Category);
      setActionType(dropdownslist.ActionType);
      setreminderFequency(dropdownslist.ReminderFrequency);
      setReminderType(dropdownslist.ReminderType);


      if (!(isNewForm)) {
        await fetchEdakdetails(userDepartment, dropdownslist.PurposeonApproval);
      }
       // Comment get default approvers

      if (isNewForm) {
        const approverresponse = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eDak_GetDakApprovers(userDepartment)}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
        });
        const reviewerresponse = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eDak_GetDakReviewer(userDepartment)}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
        });
        const edakapprover = await approverresponse.json();
        const edakreviewer = await reviewerresponse.json();
        if (edakapprover) {
          seteDakApproverData(edakapprover.map(obj => { return { ...obj, signedBy: false } }));
        }
        if (edakreviewer)
          seteDakReviewerData(edakreviewer.map(obj => { return { ...obj, signedBy: false } }));
        setIsLoading(false);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setIsLoading(false);
    }
  };
  
  //Get eDak data for Edit form on load
  const fetchEdakdetails = async () => {
    setIsLoading(true);
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eDak_GetGeneralDetails}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify({ dakId: dakId }),
        }
      );
      if (!response.ok) {
        // Handle error, for example set an error state
        console.error("Error fetching data:", response.statusText);
        return;
      }
      const data = await response.json();
     
      const getGroupId = data?.recipientDetailsDTO[0]?.groupMasterId;
      setGroupGeneral(getGroupId);

      const mailrecipientDTO = data.mailRecipientsDTO.map((item) => item.strMailRecipient);

      const ccDataMap = data.ccmaildto.length > 0 ? data.ccmaildto?.map(item => ({
        approverEmail: item.ccMail,
        createdBy: item.createdBy,
        createdDate: item.createdDate,
        modifiedBy: item.modifiedBy,
        modifiedDate: item.modifiedDate
      })) : [];

      const getGroupDat = data?.recipientDetailsDTO.map((item) => ({
        groupMasterId: item.groupMasterId,
        groupName: item.strGroup,
      }));

      setState({
        ...data,
        status: data.status,
        sourceType: data.strSourceType === "0" ? "" : data.strSourceType,
        documentType: data.strDocumentType === "0" ? "" : data.strDocumentType,
        movementType: data.strMovementType === "0" ? "" : data.strMovementType,
        nameOfAgency: data.strNameofAgency === "0" ? "" : data.strNameofAgency,
        to: data.to || "",
        category: data.strCategory === "0" ? "" : data.strCategory,
        subject: data.subject || "",
        search: data.searchKeyword || "",
        comments: data.comments || "",
        cc: ccDataMap, // Setting cc field with ccmaildto array
        reminderType: data.recipientDetailsDTO[0]?.strReminderType || "",
        reminderFrequency: data.recipientDetailsDTO[0]?.strReminderFrequency || "",
        group: data.recipientDetailsDTO[0]?.strGroup || "", // Extracting strGroup from each item in recipientDetailsDTO
        createdBy: data.createdBy,
        actionType: data.recipientDetailsDTO[0]?.strDakActionType || "",
        statusMsg: data.strStatus,
        uploadLetter: data.uploadLetter || "",
        uploadLetterFileName: data.uploadLetterFileName || "",
        daksApproversDTO: data.daksApproversDTO,
        createdDate: new DateObject(new Date(data.createdDate)).format("DD-MMM-YYYY hh:mm A"), //Seconds hand removed
        mailRecipient: mailrecipientDTO,
        recipientsDTO: data.recipientsDTO,
        directionsDTO: data.directionsDTO,
        other: data.otherOrganization,
      });
      // Department change
      // setSelectedDepartment(data?.departmentName?data?.departmentName:null);
      if (data.recipientDetailsDTO.length > 0) {
        setSelectTargetDate(data.recipientDetailsDTO[0]?.targetDate === null ? null : new Date(data.recipientDetailsDTO[0]?.targetDate));
        setSelectFollowUpDate(data.recipientDetailsDTO[0]?.followUpDate === null ? null : new Date(data.recipientDetailsDTO[0]?.followUpDate));
      }
      setNoteComments(data.edakComments);
      setSelectedReceivedDate(data.receivedDate === null ? "" : new Date(data.receivedDate))
      setSouceTypeField(data.strSourceType === "External");
      setShowReceivedDate(data.strMovementType === "Inward");
      setShowTo(data.strMovementType === "Outward");
      setShowAction(data.strActionType === "Other");
      setShowAgency(data.strNameofAgency === "Other");
      setReminderFrequency(data.strActionType !== "Information");
      setshowFollowUpDate(data.strActionType === "Follow-up");
      setShowTargetDate((data.strActionType !== "Information" && data.strActionType !== ""));

      SetWordPDFInfowarring({
        PDFInfo: {
          fileName: data?.uploadLetterFileName,
          warningMsg: "",
          filePath: data?.uploadLetter,
          isValid: data?.uploadLetterFileName === "" || data?.uploadLetterFileName === null ? false : true,
        },
        wordInfo: {
          fileName: data?.edakWordFileName,
          warningMsg: "",
          filePath: data?.noteWordPath,
          isValid: data?.edakWordFileName === "" || data?.edakWordFileName === null ? false : true,
        },
      });
      setpdfPath(data?.uploadLetter);
      SetFileinfo(data.dakSupportingDocumentsDTO);
      const fetchedakApprover = data.daksApproversDTO?.filter((obj) => obj.edakApproverType === 2 || obj.approverType === 2);
      seteDakApproverData(fetchedakApprover);

      seteDakReviewerData(data.daksApproversDTO?.filter((obj) => obj.edakApproverType === 1 || obj.approverType === 1));
      console.log(data.daksApproversDTO,"fetchedakApprover");

      // for getting group name for recipient table data
      const fetchedakrecipient = data?.recipientsDTO
        .filter((obj) => obj.recipientStatus === 1)
        .map((recipient) => {
          return {
            ...recipient,
            displayName: recipient.recipientsMailName,
            groupName: recipient.groupName,
          };
        });
      setGroupData(fetchedakrecipient);

      const fetchedakCCData = data?.ccmaildto.map((item) => {
        return {
          ...item,
          displayName: item.ccMailName,
        };
      });
      setEdakCCData(fetchedakCCData);

      const fetchedakMailrecipientData = data?.mailRecipientsDTO.map((item) => {
        return {
          ...item,
          displayName: item.strMailRecipient,
        };
      });
      setEdakMailRecipientData(fetchedakMailrecipientData)

    } catch (error) {
      console.error("Error fetching data:", error.message);
    }
    setIsLoading(false);
  };

  // Hide and show for information field
  const informationValidation = () => {
    let isInformationVisible = false;
    if (state.actionType === 'Information' || state.actionType === "") {
      isInformationVisible = false;
    } else {
      isInformationVisible = true;
    }
    return isInformationVisible
  }
  // Hide and show for other field in action type
  const OtherValidation = () => {
    let isOtherVisible = false;
    if (state.actionType === 'Other') {
      isOtherVisible = true;
    } else {
      isOtherVisible = false;
    }
    return isOtherVisible
  }
  // Hide and show for target date
  const targetFieldValidation = () => {
    let isTargetDateVisible = false;
    if (state.actionType === 'Information' || state.actionType === "Follow-up" || state.actionType === "") {
      isTargetDateVisible = false;
    }
    else {
      isTargetDateVisible = true;
    }
    return isTargetDateVisible
  }
  // Hide and show for received date
  const receivedFieldValidation = () => {
    let isreceivedDateVisible = false;
    if (state.sourceType === "Internal" || state.movementType === "Outward" || state.sourceType === "" || state.movementType === "") {
      isreceivedDateVisible = false;
    } else {
      isreceivedDateVisible = true;
    }
    return isreceivedDateVisible
  }
  // Hide and show for follow up date
  const followUpValidation = () => {
    let isFollowValidation = false;
    if (state.actionType === "Follow-up") {
      isFollowValidation = true;
    }
    else {
      isFollowValidation = false;
    }
    return isFollowValidation
  }

  // Delete Approvers from Approvers/Reviewers table
  const deletereviewer = (data) => {
    if (data && data.approverType === 1 || data.edakApproverType === 1) {
      const updatedData = edakreviewerData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      seteDakReviewerData(updatedData);
    }
    if (data && data.approverType === 2 || data.edakApproverType === 2) {
      const updatedData = eDakapproverData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      seteDakApproverData(updatedData);
    }
  };

  // Delete function for removing Mail Recipients
  const deleteMailRecipients = (data) => {
    if (data) {
      const updatedData = edakMailRecipientData.filter(
        (row) => row.approverEmail !== data.approverEmail || row.mailRecipient !== data.mailRecipient
      )
      setEdakMailRecipientData(updatedData);
    }
  }

  // Delete function for removing CC
  const deleteCC = (data) => {
    if (data) {
      const updatedData = edakCCData.filter(
        (row) => row.approverEmail !== data.approverEmail || row.ccMail !== data.ccMail
      );
      setEdakCCData(updatedData);
    }
  }

  // Delete function for removing Recipients
  const deleteRecipients = (data) => {
    if (data) {
      // Filter out the selected recipient from groupData
      const updatedGroupData = groupData.filter((row) => row.userPrincipalName !== data.userPrincipalName ||  row.recipientsMail !== data.recipientsMail);
      setGroupData(updatedGroupData);
      console.log(updatedGroupData,"updatedGroupData");

      // Filter out the selected recipient from recipientData
      const updatedRecipientData = recipientData.filter((row) => row.approverEmail !== data.approverEmail);
      setRecipientData(updatedRecipientData);
      console.log(updatedRecipientData,"updatedRecipientData");
    }
  }

  //  Approvers orderChange from Approvers/Reviewers table   
  const orderChange = (data) => {
    if (data.some(obj => obj.approverType === 1)) {
      seteDakReviewerData(data)
    }
    if (data.some(obj => obj.approverType === 2)) {
      seteDakApproverData(data);
    }
  }
  // Autosave functionaites  is implemented here
  useAutosave(() => {
    if (!isSaveAndSubmitActionCompleted && isNewForm) {
      handleAutoSave();
    }
  }, 3 * 60 * 1000);
  /* -------------------Form fields handlers START ---------------------- */
  /* Data Handles */

    // Change -13/05 added dropdown for department user will select department name 
    // const handleSelectedDepartment =(event)=>{
    //   setSelectedDepartment(event.target.value);

    //  // on departmet change  call getDefaultConfigApprovers function and update userDepartment
    // setUserDepertment(event.target.value);
    // getDefaultConfigApprovers(event.target.value)
    // setDepartmentBorderColor("");
    // }
  const handleSourceTypeChange = (event) => {
    const selectedValue = event.target.value;
    const clearDocumentType = state.documentType === "Note" || state.documentType === "Email";
    setState((prevState) => ({
      ...prevState,
      sourceType: selectedValue,
      documentType: clearDocumentType ? "" : prevState.documentType,
      movementType: "", // Clear movementType when sourceType changes
      receivedDate: null
    }));
    seterrorsourceBorderColor("");
    setHideRecipient(selectedValue === "External");
    if (selectedValue === 'External') {
      setSouceTypeField(true);
      sethideRecipitent(false)
    } else {
      setSouceTypeField(false);
      setShowTo(false);
      setShowAgency(false);
      setState((prevState) => ({ ...prevState, nameOfAgency: "" }));
      setState((prevState) => ({ ...prevState, to: "" }));
      setState((prevState) => ({ ...prevState, other: "" }));
      sethideRecipitent(true)
    }
  };
  const handleAgencyType = (event) => {
    const otherValue = event.target.value;
    setState((prevState) => ({ ...prevState, nameOfAgency: event.target.value }));

    setSelectAgency(otherValue);
    if (otherValue === 'Other') {
      setShowAgency(true);
    } else {
      setShowAgency(false);
      setState((prevState) => ({ ...prevState, other: "" })); // Clear the value of other
    }
    setErrorNameofAgency("");
  };
  const handleMovementType = (event) => {
    const selectedValue = event.target.value;
    setState({
      ...state,
      movementType: selectedValue,
    });
    setErrorMovement("");
    if (state.sourceType === "External") {
      setShowReceivedDate(true); // Show received date only when movementType is Inward and sourceType is External
    } else {
      setShowReceivedDate(false);
    }
    if (selectedValue === 'Inward') {
      setShowReceivedDate(true);
    } else {
      setShowReceivedDate(false);
    }
    if (selectedValue === 'Outward' && state.sourceType === "External") {
      setShowTo(true);
      sethideRecipitent(false)
    } else {
      setShowTo(false);
      setState((prevState) => ({ ...prevState, to: "" }));
      sethideRecipitent(true)
    }
  };
  const setFilteredValueDocumentType = () => {
    let documentTypeOptions;
    if (!state.sourceType) {
      // If no source type is selected, show only "Letter" as default in document type
      documentTypeOptions = ['Letter'];
    } else if (state.sourceType === 'Internal') {
      // If "Internal" is selected in sourceType dropdown, filter out "Email" option
      documentTypeOptions = DocumentType.filter((option) => option.dValue !== 'Email').map((x) => x.dValue);
    } else if (state.sourceType === 'External') {
      // If "External" is selected in sourceType dropdown, filter out "Note" option
      documentTypeOptions = DocumentType.filter((option) => option.dValue !== 'Note').map((x) => x.dValue);
    } else {
      // If any other option is selected in NoteTo dropdown, return all options
      documentTypeOptions = DocumentType.map((x) => x.dValue);
    }
    return documentTypeOptions;
  };
  const handleDocumentType = (event) => {
    setState((prevState) => ({ ...prevState, documentType: event.target.value }));
    seterrordocumentBorderColor("");
  };
  const handleSubjectChange = (event) => {
    setState((prevState) => ({ ...prevState, subject: event.target.value }));
    seterrorSubjectBorderColor("");
  };
  const handleSearchChange = (event) => {
    setState((prevState) => ({ ...prevState, search: event.target.value }));
    seterrorSearchBorderColor("");
  };
  const handleCommentChange = (event) => {
    setState((prevState) => ({ ...prevState, comments: event.target.value }));
    seterrorCommentsBorderColor("");
  };
  const handleOtherChange = (event) => {
    setState((prevState) => ({ ...prevState, other: event.target.value }));
    seterrorOther("");
  };
  const handleToChange = (event) => {
    setState((prevState) => ({ ...prevState, to: event.target.value }));
    seterrorTo("");
  };
  const handleCategoryType = (event) => {
    setState((prevState) => ({ ...prevState, category: event.target.value }));
    seterrorcategoryBorderColor("");
  };
  const handleActionTypeChange = (event) => {
    const actionValue = event.target.value;
    setState((prevState) => ({ ...prevState, actionType: event.target.value }));

    setSelectAction(actionValue);
    if (actionValue === 'Other') {
      setShowAction(true);
    } else {
      setShowAction(false);
    }
    if (actionValue === "Follow-up") {
      setshowFollowUpDate(true);
    } else {
      setshowFollowUpDate(false);
    }
    if (actionValue === "Information") {
      setShowTargetDate(false);
      setReminderFrequency(false)
    } else if (actionValue === "Follow-up") {
      setShowTargetDate(false);
      setReminderFrequency(true)
    } else {
      setShowTargetDate(true)
      setReminderFrequency(true)
    }
    seterrorActionTypeBorderColor('');
  };
  const handleActionOtherChange = (event) => {
    setState((prevState) => ({ ...prevState, otherAction: event.target.value }));
    seterrorOtherAction("");
  };
  const onChangeRemainderType = (event) => {
    setState((prevState) => ({ ...prevState, reminderType: event.target.value }));
    seterrorReminderType("");
  }
  const onChangeRemainderFrequency = (event) => {
    setState((prevState) => ({ ...prevState, reminderFrequency: event.target.value }));
    seterrorReminderFreq("");
  }

  const [showCloseIcon, setShowCloseIcon] = useState(false);
  
  const onFilterGroupChange = async (event) => {
    setShowCloseIcon(event.filter.value.length > 0);
    if (event.filter.value.length >= 4) {
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
        try {
            const response = await fetch(
              `${API_BASE_URL}${API_ENDPOINTS.eDak_Group(event.filter.value)}`,
              {
                method: "GET",
                headers: {
                    ...API_COMMON_HEADERS,
                    Authorization: `Bearer ${accessToken}`,
                },
              }
            );
            const data = await response.json();

            const orgUsers = data.map(x => ({
              displayName: x.displayName === null ? "NA" : x.displayName,
              groupIdValue: x.id === null ? "NA" : x.id  // Store groupIdValue
            }));

            setGroupNamesData(orgUsers);
        } catch (err) {
            console.log(err);
        }
    } else {
      setGroupNamesData([]);
    }
};

  // on change group
//   const onChangegroup = async (event) => {
//     const selectedGroupName = event.target.value;
//     const groupId = Group.find(group => group.groupName === selectedGroupName)?.groupId;
//       if (selectedGroupName === groupNames) {
//         return; 
//       }

//       // Update state with the new group name
//       setGroupNames(selectedGroupName);
//     try {
//       const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
//       const groupMasterId = await onFilterGroupChange({ filter: { value: groupId } });
      
//       // Construct new groupMasterId object
//       const newGroupMasterId = {
//         groupName: selectedGroupName,
//         groupMasterId: groupMasterId
//       };
  
//       // Update state with the new groupMasterId
//       setGroupMasterIds(prevGroupMasterIds => [...prevGroupMasterIds, newGroupMasterId]);
  
//       const groupUsers = await getGroupUsers(groupId, selectedGroupName, accessToken);
//       if (groupUsers.length > 0) {
//         setGroupData(prevGroupData => [
//           ...prevGroupData.filter(user => user.groupName !== selectedGroupName),
//           ...groupUsers
//         ]);
//       }
//     } catch (error) {
//       console.error("Error fetching groups:", error);
//     }
  
//     setGroupNames('');
// };


const onChangegroup = async (event) => {
  const selectedGroupName = event.target.value;

  // Find groupIdValue based on selectedGroupName
  const groupIdValue = selectedGroupName?.groupIdValue;
  const groupselectedValue = selectedGroupName?.displayName

  try {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const newGroupMasterId = {
      groupName: groupselectedValue,
      groupMasterId: groupIdValue,
    };
    setGroupMasterIds(prevGroupMasterIds => [...prevGroupMasterIds, newGroupMasterId]);

    const groupUsers = await getGroupUsers(groupIdValue, groupselectedValue, accessToken);

    if (Array.isArray(groupUsers) && groupUsers.length > 0) {
      setGroupData(prevGroupData => [
        ...prevGroupData.filter(user => user.groupName !== groupselectedValue),
        ...groupUsers,
      ]);
    }
  } catch (error) {
    console.error('Error fetching groups:', error);
  }

  setGroupNames('');
};


const getGroupUsers = async (groupIdValue, selectedGroupName, accessToken) => {
  try {
    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.Get_Group_Users}?groupId=${groupIdValue}&groupName=${selectedGroupName}`, {
      method: 'GET',
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
    });

    if (response.ok) {
      let data = await response.json();

      const newGroupUsers = data.map(x => ({
        department: x.department === null ? 'NA' : x.department,
        displayName: x.displayName === null ? 'NA' : x.displayName,
        jobTitle: x.jobTitle === null ? 'NA' : x.jobTitle,
        userPrincipalName: x.userPrincipalName,
        srNo: x.srNo === null ? 'NA' : x.srNo,
        groupName: selectedGroupName,
      }));

      const currentGroupData = [...groupData];
      const filteredGroupData = currentGroupData.filter(user => user.groupName !== selectedGroupName);
      const updatedGroupData = [
        ...filteredGroupData,
        ...newGroupUsers.filter(newUser => !currentGroupData.some(existingUser => existingUser.userPrincipalName === newUser.userPrincipalName)),
      ];

      setGroupData(updatedGroupData);
      return newGroupUsers;
    } else {
      console.error('Error fetching group users:', response.statusText);
      return [];
    }
  } catch (error) {
    console.error('Error fetching group users:', error);
    return [];
  }
};

  /* -------------------Form fields handlers END ---------------------- */

  /* Form mandatory fields and file validation handler */

  const validateForm = (isApproverValid, isReviewerValid, isRecipientValid) => {
    const errors = {};

    // let isFilesValid = true;

    // if (filesInfo > 0) {
    //   filesInfo.map((x) => {
    //     if (x.supportingDocumentFileName in supportDocWarning)
    //       isFilesValid = !(x.supportingDocumentFileName in supportDocWarning);
    //   });
    // }
    // let isFilesValid = true;

    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
      console.log(vaildMultiplefile, "vaildMultiplefile")
    }

    // if(!selectedDepartment){
    //   errors["Depertment"] ="Department";
    //   setDepartmentBorderColor("#f31700");
    // }else{
    //   setDepartmentBorderColor("");

    // }

    if (!selectedreceivedDate) {
      setShowError(true);
    } else {
      setShowError(false);
    }
    if (!selectTargetDate) {
      setShowTargetError(true);
    } else {
      setShowTargetError(false);
    }
    if (!selectFollowUpDate) {
      setshowFollowError(true);
    } else {
      setshowFollowError(false);
    }

    if (!state.sourceType) {
      errors["SourceType"] = "Source Type field should not be empty";
      seterrorsourceBorderColor("#f31700")
    } else {
      seterrorsourceBorderColor("")
    }

    if (!state.documentType) {
      errors["DocumentType"] = "Document Type field should not be empty";
      seterrordocumentBorderColor("#f31700")
    } else {
      seterrordocumentBorderColor("")
    }

    if (state.sourceType === "External" && !state.movementType) {
      errors["MovementType"] = "Movement Type field should not be empty";
      setErrorMovement("#f31700");
    } else {
      setErrorMovement("")
    }

    if (state.movementType === "Outward" && !state.to) {
      errors["to"] = "To field should not be empty";
      seterrorTo("#f31700");
    } else {
      seterrorTo("")
    }

    if (state.sourceType === "External" && state.movementType === "Inward" && !selectedreceivedDate) {
      errors["ReceivedDate"] = "Received Date field should not be empty";
      setReceivedDate("#f31700")
    } else {
      setReceivedDate("")// Clear received date error if validation passes
    }


    if (state.sourceType === "External" && !state.nameOfAgency) {
      errors["nameOfAgency"] = "Name of Agency field should not be empty";
      setErrorNameofAgency("#f31700")
    } else {
      setErrorNameofAgency("")
    }

    if (state.nameOfAgency === "Other" && !state.other) {
      errors["other"] = "Other organization field should not be empty";
      seterrorOther("#f31700");
    } else {
      seterrorOther("")
    }

    if (!state.category) {
      errors["category"] = "Category field should not be empty";
      seterrorcategoryBorderColor("#f31700")
    } else {
      seterrorcategoryBorderColor("")
    }

    if (!state.subject.trim()) {
      errors["Subject"] = "Subject field should not be empty";
      seterrorSubjectBorderColor("#f31700")
    } else {
      seterrorSubjectBorderColor("")
    }

    if (!state.search.trim()) {
      errors["Search"] = "Search Text field should not be empty";
      seterrorSearchBorderColor("#f31700")
    } else {
      seterrorSearchBorderColor("")
    }

    if (!state.comments.trim()) {
      errors["Comments"] = "Comments field should not be empty";
      seterrorCommentsBorderColor("#f31700")
    } else {
      seterrorCommentsBorderColor("")
    }

    if (eDakapproverData.length === 0) {
      errors["Approvers"] = "Please select atleast one Approver to submit request"
    }

    const reviewerSignedByError = !edakreviewerData.some(item => item.signedBy === true);
    const approverSignedByError = !eDakapproverData.some(item => item.signedBy === true);

    if (reviewerSignedByError && approverSignedByError) {
      errors["SignedBy"] = "Please select 'Signed By' for at least one reviewer or approver";
    }

    if ((!state.sourceType || state.sourceType === "Internal" || state.movementType === "Inward") && !state.actionType) {
      errors["actionType"] = "Action Type field should not be empty";
      seterrorActionTypeBorderColor("#f31700");
    } else {
      seterrorActionTypeBorderColor("");
    }

    if (state.actionType === "Follow-up" && !selectFollowUpDate) {
      errors["FollowupDate"] = "Follow-up Date field should not be empty";
      setReceivedDate("#f31700")
    } else {
      setReceivedDate("")// Clear received date error if validation passes
    }

    if (((state.actionType === 'Reply' || state.actionType === "Compliance") || (state.actionType === "Reply through AGM/DGM/GM" || state.actionType === "Other")) && !selectTargetDate) {
      errors["TargetDate"] = "Target Date field should not be empty";
      seterrorTargetDateBorderColor("#f31700");
    } else {
      setReceivedDate("");
      seterrorTargetDateBorderColor("");  // Clear received date error if validation passes
    }

    if ((!state.sourceType || state.sourceType === "Internal" || state.movementType === "Inward") && state.actionType !== "Information" && !state.reminderType) {
      errors["reminderType"] = "Reminder Type field should not be empty";
      seterrorReminderType("#f31700")
    } else {
      seterrorReminderType("")
    }

    if ((!state.sourceType || state.sourceType === "Internal" || state.movementType === "Inward") && state.actionType !== "Information" && !state.reminderFrequency) {
      errors["reminderFrequency"] = "Reminder Frequency field should not be empty";
      seterrorReminderFreq("#f31700");
    } else {
      seterrorReminderFreq("");
    }

    if ((!state.sourceType || state.sourceType === "Internal" || state.movementType === "Inward") && state.actionType === "Other" && !state.otherAction) {
      errors["otherAction"] = "Other Action field should not be empty";
      seterrorOtherAction("#f31700")
    } else {
      seterrorOtherAction("")
    }

    if (!(state.movementType === "Outward") && groupData.length === 0) {
      errors["selectReceipient"] = "Recipient Details";
    }

    if (isApproverValid || isReviewerValid) {
      errors["Login user"] = "Login user cannot be part of Approvers/Reviewers.";
    }

    if (isRecipientValid) {
      errors["Login user"] = "Login user cannot be part of Approvers/Reviewers.";
    }

    if ((wordandPdfWarring?.PDFInfo.fileName === null || wordandPdfWarring?.PDFInfo.fileName === "" || wordandPdfWarring?.PDFInfo.isValid === false)) {
      errors["PDFInfo"] = "Please select Valid Pdf File";
    }

    // if (!isFilesValid) {
    //   errors["Supporting Documents"] = "Please select valid files";
    // }

    if (Object.keys(supportDocWarning).length > 0 || totalFileSize > 26214400) {
      if (Object.keys(supportDocWarning).length > 0) {
        errors["Supporting Documents"] = "Please select vaild files";
      }
      if (totalFileSize > 26214400) {
        errors["Supporting DocumentsMaxSize"] = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
      }
    }

    if (Object.keys(errors).length > 0) {
      const errorMessagesArray = Object.values(errors);
      setErrorMessages(errorMessagesArray);
      setValidationErrors(true);
    }

    return errors;
  };

  /* Auto save Form Data */
  const handleAutoSave = async () => {
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    // }

    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      const updatedeDakReviewerData = edakreviewerData.map((item, ind) => ({
        ...item,
        strEdakApproverStatus: ind === 0 ? "Pending" : "Waiting",
        signedBy: signedBy[item.noteApproverMasterId] || false,
      }));

      const updatedeDakApproverData = eDakapproverData.map((item, ind) => ({
        ...item,
        strEdakApproverStatus:
          edakreviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
        signedBy: signedBy[item.noteApproverMasterId] || false,
      }));

      const updateRecipietData = groupData.map((item, ind) => ({
        ...item,
      }))
      const recipientsDTO = updateRecipietData.map(item => ({
        recipientId: item.recipientId,
        recipientDetailsId: item.recipientDetailsId,
        recipientsMail: item.approverEmail || item.userPrincipalName || item.recipientsMail,
        groupMasterId: groupMasterIds.find(group => group.groupName === item.groupName)?.groupMasterId || item.groupName,
        GroupName: groupMasterIds.find(group => group.groupName === item.groupName)?.groupName || item.groupName,
        createdDate: item.createdDate,
        createdBy: item.createdBy,
        modifiedDate: item.modifiedDate,
        modifiedBy: item.modifiedBy
      }));

      const ccDataMap = edakCCData.map(item => ({
        ccMail: item.approverEmail,
        createdBy: item.createdBy,
        createdDate: item.createdDate,
        modifiedBy: item.modifiedBy,
        modifiedDate: item.modifiedDate
      }));

      const mailRecipientDataMap = edakMailRecipientData.map(item => ({
        mailRecipientId: 0,
        recipientDetailsId: 0,
        mailRecipient: item.approverEmail,
        createdBy: item.createdBy,
        createdDate: item.createdDate,
        modifiedBy: item.modifiedBy,
        modifiedDate: item.modifiedDate
      }))

      const recipientDetailsDTO = (() => {
        if (!(state.movementType === "Outward")) {
          return [{
            dakActionType: state.actionType ? ActionType.find(x => x.dValue === state.actionType).id : 0,
            otherActionType: state.otherAction,
            followUpDate: selectFollowUpDate,
            targetDate: selectTargetDate,
            reminderType: state.reminderType ? ReminderType.find(x => x.dValue === state.reminderType).id : 0,
            reminderFrequency: state.reminderFrequency ? ReminderFequency.find(x => x.dValue === state.reminderFrequency).id : 0,
            groupMasterId: groupMasterId,
            createdDate: new Date(),
            createdBy: accounts[0].username,
            modifiedDate: new Date(),
            modifiedBy: accounts[0].username,
          }];
        } else {
          return [];
        }
      })();
      const base64PDFParams = wordandPdfWarring.PDFInfo.filePath || {};
      const params = {
        dakId: isNewForm ? draftId : dakId,
        category: state.category ? Category.find(x => (x.dValue === state.category)).id : 0,
        subject: state.subject,
        departmentId: 0,
        // departmentId: selectedDepartment?departmentList.find(obj=>obj.departmentName === selectedDepartment).departmentId:0,
        requester: accounts[0].username,
        sourceType: state.sourceType ? SourceType.find(x => (x.dValue === state.sourceType)).id : 0,
        movementType: state.movementType ? MovementType.find(x => (x.dValue === state.movementType)).id : 0,
        requestDate: new Date(),
        status: enumsObj.status.find(x => x.dValue === "Draft").id,
        documentType: state.documentType ? DocumentType.find(x => (x.dValue === state.documentType)).id : 0,
        to: state.to,
        nameofAgency: state.nameOfAgency ? NameoftheAgency.find(x => (x.dValue === state.nameOfAgency)).id : 0,
        recipients: state.recipients,
        reciviedDate: selectedreceivedDate ? new Date(selectedreceivedDate) : null,
        searchKeyword: state.search,
        comments: state.comments,
        dakActionType: state.actionType ? ActionType.find(x => (x.dValue === state.actionType)).id : 0,
        createdBy: accounts[0].username,
        modifiedBy: accounts[0].username,
        otherOrganization: state.other,
        otherActionType: state.otherAction,
        departmentName: userDepartment,
        // departmentName: selectedDepartment,
        dakSupportingDocumentsDTO: totalFileSize > 26214400 ? [] : fileupdated, //filesInfo,
        // uploadLetter: wordandPdfWarring.PDFInfo.filePath,
        uploadLetter1: base64PDFParams.part1,
        uploadLetter2: base64PDFParams.part2,
        uploadLetter3: base64PDFParams.part3,
        uploadLetter4: base64PDFParams.part4,
        uploadLetter5: base64PDFParams.part5,
        uploadLetter6: base64PDFParams.part6,
        uploadLetter7: base64PDFParams.part7,
        uploadLetter8: base64PDFParams.part8,
        uploadLetter9: base64PDFParams.part9,
        uploadLetter10: base64PDFParams.part10,
        uploadLetterFileName: wordandPdfWarring.PDFInfo.fileName,
        daksApproversDTO: [
          ...updatedeDakReviewerData,
          ...updatedeDakApproverData,
        ],
        ccmaildto: [...ccDataMap],
        autosave:true,
        recipientDetailsDTO: recipientDetailsDTO,
        recipientsDTO: [...recipientsDTO],
        mailRecipientsDTO: [...mailRecipientDataMap],
        modifiedByName: accounts[0].username,
        requesterName: accounts[0].username,
        createdByName: accounts[0].username,
        signedBy: accounts[0].username,
        fromDate: new Date(),
        ToDate: new Date(),
        commentsBy: accounts[0].username,
      }

      const response = await fetch(
        `${API_BASE_URL}${draftId === 0 ? API_ENDPOINTS.eDak_AddForm : API_ENDPOINTS.eDak_EditForm}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      ).then(async (data) => {
        const res = await data.json();
        setDraftId(res.dakId)
        if (res.statusMessage === "Success") {

        } else {
          console.log("Something went wrong please try again.");
        }
        setIsLoading(false);

      }).catch((err) => {
        console.log(err, "errr");
      });
      // }
    } catch {
      console.log("error")
    }
  };

  //It helps to cancel the eDak 
  const onCanceleDakform = async () => {
    setIsLoading(true);
    setVisibleCancelCfrm(false);

    let params = {
      dakId: dakId,
      createdBy: accounts[0].username,
    };

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(`${API_BASE_URL}${API_ENDPOINTS.eDak_CancelDak}`, {
      method: "POST",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(params),
    })

      .then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Success") {
          setSuccessMessage("The request for cancellation has been successfull.");
          setVisibleSave(!visiblesave);
        } else {
          setShowNotification(true);
          setNotificationMsg("Something went wrong please try again.");
        }
        setIsLoading(false);
      })
      .catch((err) => {
        setShowNotification(true);
        setNotificationMsg("Something went wrong please try again.");
        console.log(err);
        setIsLoading(false);
      });
  };

  /* it helps tp save or update draft data on Save as draft*/
  const handleSave = async () => {
    const errors = {};
    setIsLoading(true);
    setisSaveAndSubmitActionCompleted(true);
    let totalFileSize = 0
    let isFilesValid = true;
    filesInfo.map((x) => {
      isFilesValid = !(x.supportingDocumentFileName in supportDocWarning);
    });

    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });
    if (isSecretaryExist && (wordandPdfWarring?.wordInfo.fileName && wordandPdfWarring?.wordInfo.isValid === false)) {
      errors["wordDocInfo"] = "Please select vaild file";
    }
    if (wordandPdfWarring?.PDFInfo.fileName && wordandPdfWarring?.PDFInfo.isValid === false) {
      errors["PDFInfo"] = "Please select vaild file";
    }
    // if (filesInfo.length > 0 && !isFilesValid) {
    //   errors["Supporting Documents"] = "Please select vaild files";
    // }
    if ((filesInfo.length > 0 && !isFilesValid) || totalFileSize > 26214400) {
      if (filesInfo.length > 0 && !isFilesValid) {
        errors["Supporting Documents"] = "Please select vaild files"
      }
      if (totalFileSize > 26214400) {
        errors["Supporting DocumentsMaxSize"] = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
      }
    }

    if (Object.keys(errors).length === 0) {

      try {
        const updatedeDakReviewerData = edakreviewerData.map((item, ind) => ({
          ...item,
          strEdakApproverStatus: ind === 0 ? "Pending" : "Waiting",
        }));

        const updatedeDakApproverData = eDakapproverData.map((item, ind) => ({
          ...item,
          strEdakApproverStatus:
            edakreviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
        }));

        const updateRecipietData = groupData.map((item, ind) => ({
          ...item,
        }))

        const recipientDetailsDTO = (() => {
          if (!(state.movementType === "Outward")) {
            return [{
              dakActionType: state.actionType ? ActionType.find(x => x.dValue === state.actionType).id : 0,
              otherActionType: state.otherAction,
              followUpDate: selectFollowUpDate,
              targetDate: selectTargetDate,
              reminderType: state.reminderType ? ReminderType.find(x => x.dValue === state.reminderType).id : 0,
              reminderFrequency: state.reminderFrequency ? ReminderFequency.find(x => x.dValue === state.reminderFrequency).id : 0,
              groupMasterId: groupMasterId || null,
              // groupMasterId: 6,
              createdDate: new Date(),
              createdBy: accounts[0].username,
              modifiedDate: new Date(),
              modifiedBy: accounts[0].username,
            }];
          } else {
            return [];
          }
        })();
        const base64PDFParams = wordandPdfWarring.PDFInfo.filePath || {};
        const params = {
          dakId: isNewForm ? draftId : dakId,
          category: state.category ? Category.find(x => (x.dValue === state.category)).id : 0,
          subject: state.subject,
          departmentId: 0,
          // departmentId:  selectedDepartment?departmentList.find(obj=>obj.departmentName === selectedDepartment).departmentId:0,
          requester: accounts[0].username,
          sourceType: state.sourceType ? SourceType.find(x => (x.dValue === state.sourceType)).id : 0,
          movementType: state.movementType ? MovementType.find(x => (x.dValue === state.movementType)).id : 0,
          requestDate: new Date(),
          status: enumsObj.status.find(x => x.dValue === "Draft").id,
          documentType: state.documentType ? DocumentType.find(x => (x.dValue === state.documentType)).id : 0,
          to: state.to,
          nameofAgency: state.nameOfAgency ? NameoftheAgency.find(x => (x.dValue === state.nameOfAgency)).id : 0,
          recipients: state.recipients,
          receivedDate: selectedreceivedDate || null,
          searchKeyword: state.search,
          comments: state.comments,
          dakActionType: state.actionType ? ActionType.find(x => (x.dValue === state.actionType)).id : 0,
          createdBy: accounts[0].username,
          modifiedBy: accounts[0].username,
          ccmaildto: edakCCData.map(item => ({
            ccMail: item.approverEmail || item.ccMail,
            createdBy: item.createdBy,
            createdDate: item.createdDate,
            modifiedBy: item.modifiedBy,
            modifiedDate: item.modifiedDate
          })),
          otherOrganization: state.other,
          otherActionType: state.otherAction,
          departmentName: userDepartment,
          // departmentName: selectedDepartment,
          dakSupportingDocumentsDTO: fileupdated, //filesInfo,
          uploadLetter: isNewForm ? null : (wordandPdfWarring.PDFInfo.filePath !== pdfPath ? null : pdfPath),
          // uploadLetter: wordandPdfWarring.PDFInfo.filePath,
          uploadLetter1: base64PDFParams.part1,
          uploadLetter2: base64PDFParams.part2,
          uploadLetter3: base64PDFParams.part3,
          uploadLetter4: base64PDFParams.part4,
          uploadLetter5: base64PDFParams.part5,
          uploadLetter6: base64PDFParams.part6,
          uploadLetter7: base64PDFParams.part7,
          uploadLetter8: base64PDFParams.part8,
          uploadLetter9: base64PDFParams.part9,
          uploadLetter10: base64PDFParams.part10,
          uploadLetterFileName: wordandPdfWarring.PDFInfo.fileName,
          daksApproversDTO: [
            ...updatedeDakReviewerData,
            ...updatedeDakApproverData,
          ],
          recipientDetailsDTO: recipientDetailsDTO,
          recipientsDTO: updateRecipietData.map(item => ({
            recipientId: item.recipientId,
            recipientDetailsId: item.recipientDetailsId,
            recipientsMail: item.approverEmail || item.userPrincipalName || item.recipientsMail,
            groupMasterId: groupMasterIds.find(group => group.groupName === item.groupName)?.groupMasterId || item.groupMasterId,
            GroupName: groupMasterIds.find(group => group.groupName === item.groupName)?.groupName || item.groupName,
            groupName: item.groupName,
            createdDate: item.createdDate,
            createdBy: item.createdBy,
            modifiedDate: item.modifiedDate,
            modifiedBy: item.modifiedBy,
          })),
          mailRecipientsDTO: edakMailRecipientData.map(item => ({
            mailRecipientId: 0,
            recipientDetailsId: 0,
            mailRecipient: item.approverEmail || item.mailRecipient,
            createdBy: item.createdBy,
            createdDate: item.createdDate,
            modifiedBy: item.modifiedBy,
            modifiedDate: item.modifiedDate
          })),
          modifiedByName: accounts[0].username,
          requesterName: accounts[0].username,
          createdByName: accounts[0].username,
          signedBy: accounts[0].username,
          fromDate: new Date(),
          ToDate: new Date(),
          commentsBy: accounts[0].username,
          autosave:false,
        }

        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
        await fetch(
          `${API_BASE_URL}${draftId === 0 ? API_ENDPOINTS.eDak_AddForm : API_ENDPOINTS.eDak_EditForm}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify(params),
          }
        ).then(response => {
          return response.json();
        }).then(data => {
          if (data.statusMessage === "Success") {
            setSuccessMessage("The request for eDak has been drafted successfull.");
            setVisibleSave(true);
          } else {
            setShowNotification(true);
             setNotificationMsg(`eDak form submission failed. 
             ${data.statusMessage}`);
          }
        }).catch(err => {
          console.error("Error submitting form:", err);
          setShowNotification(true);
          setNotificationMsg(err);
        })
      } catch (error) {
        console.error("Error submitting form:", error);
        setShowNotification(true);
        setNotificationMsg(error);
      }
    } else {
      setShowNotification(true);
      setNotificationMsg("Invalid files attached. Kindly remove the invalid files.");
    }
    setIsLoading(false);
  };

  //Submit handler helps to validate mandatory fields and prompt confirm dailog

  const handleSubmit = async () => {
    setIsLoading(true);
    setVisible(false);
    setisSaveAndSubmitActionCompleted(true);
    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });
    try {
      const updatedeDakReviewerData = edakreviewerData.map((item, ind) => ({
        ...item,
        strEdakApproverStatus: ind === 0 ? "Pending" : "Waiting",
      }));

      const updatedeDakApproverData = eDakapproverData.map((item, ind) => ({
        ...item,
        strEdakApproverStatus:
          edakreviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
      }));

      const updateRecipietData = groupData.map((item, ind) => ({
        ...item,
      }))

      // const recipientsDTO = updateRecipietData.map(item => ({
      //   recipientId: item.recipientId,
      //   recipientDetailsId: item.recipientDetailsId,
      //   recipientsMail: item.approverEmail || item.userPrincipalName || item.recipientsMail,
      //   GroupName: groupMasterIds.find(group => group.groupName === item.groupName)?.groupName || item.groupName,
      //   groupMasterId: groupMasterIds.find(group => group.groupName === item.groupName)?.groupMasterId || item.groupMasterId,
      //   createdDate: item.createdDate,
      //   groupName: item.groupName,
      //   createdBy: item.createdBy,
      //   modifiedDate: item.modifiedDate,
      //   modifiedBy: item.modifiedBy
      // }));

      const ccDataMap = edakCCData.map(item => ({
        ccMail: item.approverEmail,
        createdBy: item.createdBy,
        createdDate: item.createdDate,
        modifiedBy: item.modifiedBy,
        modifiedDate: item.modifiedDate
      }));
      console.log(ccDataMap,"ccDataMap");

      const mailRecipientDataMap = edakMailRecipientData.map(item => ({
        mailRecipientId: 0,
        recipientDetailsId: 0,
        mailRecipient: item.approverEmail,
        createdBy: item.createdBy,
        createdDate: item.createdDate,
        modifiedBy: item.modifiedBy,
        modifiedDate: item.modifiedDate
      }))
      console.log(mailRecipientDataMap,"mailRecipientDataMap");

      const recipientDetailsDTO = (() => {
        if (!(state.movementType === "Outward")) {
          return [{
            dakActionType: state.actionType ? ActionType.find(x => x.dValue === state.actionType).id : 0,
            otherActionType: state.otherAction,
            followUpDate: selectFollowUpDate,
            targetDate: selectTargetDate,
            reminderType: state.reminderType ? ReminderType.find(x => x.dValue === state.reminderType).id : 0,
            reminderFrequency: state.reminderFrequency ? ReminderFequency.find(x => x.dValue === state.reminderFrequency).id : 0,
            groupMasterId: groupMasterId,
            createdDate: new Date(),
            createdBy: accounts[0].username,
            modifiedDate: new Date(),
            modifiedBy: accounts[0].username,
          }];
        } else {
          return [];
        }
      })();

      const base64PDFParams = wordandPdfWarring.PDFInfo.filePath;

      const params = {
        dakId: isNewForm ? draftId : dakId,
        category: state.category ? Category.find(x => (x.dValue === state.category)).id : 0,
        subject: state.subject,
        departmentId: 0,
        // departmentId: selectedDepartment?departmentList.find(obj=>obj.departmentName === selectedDepartment).departmentId:0, 
        requester: accounts[0].username,
        sourceType: state.sourceType ? SourceType.find(x => (x.dValue === state.sourceType)).id : 0,
        movementType: state.movementType ? MovementType.find(x => (x.dValue === state.movementType)).id : 0,
        requestDate: new Date(),
        status: enumsObj.status.find(x => x.dValue === "In Progress").id,
        documentType: state.documentType ? DocumentType.find(x => (x.dValue === state.documentType)).id : 0,
        to: state.to,
        nameofAgency: state.nameOfAgency ? NameoftheAgency.find(x => (x.dValue === state.nameOfAgency)).id : 0,
        recipients: state.recipients,
        receivedDate: selectedreceivedDate ? new Date(selectedreceivedDate) : null,
        searchKeyword: state.search,
        comments: state.comments,
        dakActionType: state.actionType ? ActionType.find(x => (x.dValue === state.actionType)).id : 0,
        createdBy: accounts[0].username,
        modifiedBy: accounts[0].username,
        ccmaildto: [...ccDataMap],
        otherOrganization: state.other,
        otherActionType: state.otherAction,
        // departmentName: selectedDepartment,
        departmentName: userDepartment,
        dakSupportingDocumentsDTO: fileupdated,// filesInfo,
        // uploadLetter: wordandPdfWarring.PDFInfo.filePath,
        uploadLetter: isNewForm ? null : (wordandPdfWarring.PDFInfo.filePath !== pdfPath ? null : pdfPath),
        uploadLetter1: base64PDFParams.part1,
        uploadLetter2: base64PDFParams.part2,
        uploadLetter3: base64PDFParams.part3,
        uploadLetter4: base64PDFParams.part4,
        uploadLetter5: base64PDFParams.part5,
        uploadLetter6: base64PDFParams.part6,
        uploadLetter7: base64PDFParams.part7,
        uploadLetter8: base64PDFParams.part8,
        uploadLetter9: base64PDFParams.part9,
        uploadLetter10: base64PDFParams.part10,
        uploadLetterFileName: wordandPdfWarring.PDFInfo.fileName,
        daksApproversDTO: [
          ...updatedeDakReviewerData,
          ...updatedeDakApproverData,
        ],
        recipientDetailsDTO: recipientDetailsDTO,
        recipientsDTO: updateRecipietData.map(item => ({
          recipientId: item.recipientId,
          recipientDetailsId: item.recipientDetailsId,
          recipientsMail: item.approverEmail || item.userPrincipalName || item.recipientsMail,
          groupMasterId: groupMasterIds.find(group => group.groupName === item.groupName)?.groupMasterId || item.groupMasterId,
          GroupName: groupMasterIds.find(group => group.groupName === item.groupName)?.groupName || item.groupName,
          createdDate: item.createdDate,
          createdBy: item.createdBy,
          modifiedDate: item.modifiedDate,
          modifiedBy: item.modifiedBy,
        })),
        mailRecipientsDTO: [...mailRecipientDataMap],
        modifiedByName: accounts[0].username,
        requesterName: accounts[0].username,
        createdByName: accounts[0].username,
        signedBy: accounts[0].username,
        fromDate: new Date(),
        ToDate: new Date(),
        commentsBy: accounts[0].username,
        autosave:false,
      }

      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      const response = await fetch(
        `${API_BASE_URL}${(isNewForm && draftId === 0) ? API_ENDPOINTS.eDak_AddForm : API_ENDPOINTS.eDak_EditForm}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      );
      const data = await response.json();
      if (data.statusMessage === "Success") {
        setAlertVisible(true);
      } else {
        setShowNotification(true);
        setNotificationMsg("eDak form submission failed. Please try again.");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setShowNotification(true);
      setNotificationMsg(error.message || "An error occurred while submitting the form.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenDialog = async () => {
    let isApproverValid = eDakapproverData.find((x) => x.approverEmail === accounts[0].username) !== undefined;
    let isReviewerValid = edakreviewerData.find((x) => x.approverEmail === accounts[0].username) !== undefined;

    if (!userDepartment) {
      setShowNotification(true);
      setNotificationMsg("User department cannot be blank. Please contact system administrator.");
      return;
    }
    const errors = validateForm(isApproverValid, isReviewerValid);

    if (Object.keys(errors).length === 0) {
      setVisible(!visible);
    }
  };

  const handleCloseDialog = async () => {
    setVisible(!visible);
  };

  const handleSaveClose = async () => {
    setVisibleSave(false);
  };

  const handleClosevalidationDialog = async () => {
    setValidationErrors(false);
  };

  //It helps to validate and convert to Base64 to attach documents - Word Info
  const convertBase64Word = () => {
    var selectedFile = document.getElementById("WordDocfile").files;
    let cstWarningMsg = "";
    let isValidFile = true;
    if (selectedFile.length > 0) {
      var fileExtension = selectedFile[0].name.split(".");
      var fileName = selectedFile[0].name;
      if (
        !(
          fileName.toLowerCase().endsWith("docx") ||
          fileName.toLowerCase().endsWith("doc") 
        )
      ) {
        cstWarningMsg = "File type not allowed";
        isValidFile = false;
      }

      if (selectedFile[0].size > 26214400) {
        cstWarningMsg = "File size should not exceed more then 25 MB";
        isValidFile = false;
      }
      if (checkingSpl(selectedFile[0].name)) {
        isValidFile = false;
        cstWarningMsg = "File name sholud not contain special characters";
      }

      if (isValidFile) {
        var fileToLoad = selectedFile[0];
        // FileReader function for read the file.
        var fileReader = new FileReader();
        // Onload of file read the file content
        fileReader.onload = function (fileLoadedEvent) {
          let base64 = fileLoadedEvent.target.result;
          const RemovedHeaderFormBase64 = base64.split(",");
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            wordInfo: {
              fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
              fileName: selectedFile[0].name,
              filePath: RemovedHeaderFormBase64[1],
              isValid: isValidFile,
              warningMsg: cstWarningMsg
            },
          });
        };
        // Convert data to base64
        fileReader.readAsDataURL(fileToLoad);
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: "",
            isValid: isValidFile,
            warningMsg: cstWarningMsg
          },
        });
      }
    }
  };

  //It helps to validate and convert to Base64 to attach documents - PDF Info
  const convertPDFToBase64 = () => {
    var selectedFile = document.getElementById("PDFDocfile").files;
    let cstWarningMsg = "";
    let isValidFile = true;
    if (selectedFile.length > 0) {
      var fileExtension = selectedFile[0].name.split(".");
      var fileName = selectedFile[0].name;
      if (!(fileName.toLowerCase().endsWith("pdf"))) {
        cstWarningMsg = "File type not allowed";
        isValidFile = false;
      }
     /* Bug -396 fixed
      File size increse 5mb to 25MB 
25 mb = 26214400
   10 mb = 10485760 */
      if (selectedFile[0].size > 10485760) {
        cstWarningMsg = "File size should not exceed more then 10 MB";
        isValidFile = false;
      }
      if (checkingSpl(selectedFile[0].name)) {
        isValidFile = false;
        cstWarningMsg = "File name sholud not contain special characters";
      }

      if (isValidFile) {
        var fileToLoad = selectedFile[0];
        // FileReader function for read the file.
        var fileReader = new FileReader();
        // Onload of file read the file content
        fileReader.onload = function (fileLoadedEvent) {
          let base64 = fileLoadedEvent.target.result;
          const RemovedHeaderFormBase64 = base64.split(",")[1];
          // Added for base 64 split params ---> Kavya(18-07)
          const partLength = Math.ceil(RemovedHeaderFormBase64.length / 10);
          const parts = [];

          console.log(parts,"parts");
  
          for (let i = 0; i < 10; i++) {
            parts.push(RemovedHeaderFormBase64.slice(i * partLength, (i + 1) * partLength));
          }
          // Print data in console
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            PDFInfo: {
              fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
              fileName: selectedFile[0].name,
              // filePath: RemovedHeaderFormBase64[1],
              // Added for base 64 split params ---> Kavya(18-07)
              filePath: {
                part1: parts[0],
                part2: parts[1],
                part3: parts[2],
                part4: parts[3],
                part5: parts[4],
                part6: parts[5],
                part7: parts[6],
                part8: parts[7],
                part9: parts[8],
                part10: parts[9]
              },
              isValid: isValidFile,
              warningMsg: cstWarningMsg
            },
            wordInfo: {
              fileExtension: "",
              fileName: "",
              filePath: "",
              isValid: false,
            },
          });
        };
        // Convert data to base64
        fileReader.readAsDataURL(fileToLoad);
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          PDFInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: {},
            isValid: isValidFile,
            warningMsg: cstWarningMsg
          },
          wordInfo: {
            fileExtension: "",
            fileName: "",
            filePath: "",
            isValid: false,
          },
        });
      }
    }
  };

  //Helps to validate multiple docs - Support documents
  const checkingSpl = (test) => {
    var specialCharPattern = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;

    // Test the input string against the pattern
    return specialCharPattern.test(test);
  };

  //It helps to validate and attach documents - support documents
 
  const multipleDocUpload = () => {
    // if(isNewForm){
    let reamingFileSize = 26214400;
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        reamingFileSize = reamingFileSize - obj.supportingDocumentPathLength
      );
    }

    let isValidFile = true;
    let waringmsg = "";
    // let isValidFile = true;
    const arrayExtension = [
      // ".png",
      // ".jpg",
      ".pdf",
      ".doc",
      ".docx",
      ".xlsx",
      ".PDF",
      ".DOC",
      ".DOCX",
      ".XLSX",
      // ".eml",
    ];
    /* eslint-disable-next-line no-useless-escape */
    const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
    // const validname = /[!@#$%^&amp;*(){}[\];:,&lt;&gt;?\/\\]/
    const selectedFile = document.getElementById("multiDoc").files;
    const TempfileInfo = filesInfo;

    const promises = [];
    const fileCount = selectedFile.length;

    for (let i = 0; i < fileCount; i++) {
      const fileToLoad = selectedFile[i];
      const fileExtession = fileToLoad.name.split(".");


      // Check if the file type is allowed
      if (!filesInfo?.some(obj => obj.supportingDocumentFileName === fileToLoad.name)) {
        if (
          !arrayExtension.includes(`.${fileExtession[fileExtession.length - 1]}`)
        ) {
          // isValidFile = false;
          isValidFile = false;
          waringmsg = "File type is not allowed";
          SetSupportDocWarning({
            ...supportDocWarning,
            [fileToLoad.name]: {
              filename: fileToLoad.name,
              isValid: true,
              warningMsg: waringmsg,
              fileExtnsion: fileExtession[fileExtession.length - 1],
            },
          });
          // return;
        }
        // Check for special characters in the filename
        else if (validname.test(fileToLoad.name)) {
          isValidFile = false;
          // isValidFile = false;
          waringmsg = "File name should not contain special characters";
          SetSupportDocWarning({
            ...supportDocWarning,
            [fileToLoad.name]: {
              filename: fileToLoad.name,
              isValid: true,
              warningMsg: waringmsg,
              fileExtnsion: fileExtession[fileExtession.length - 1],
            },
          });
        }

        // Check file size (5MB limit)
        /* File size increse 5mb to 25MB */
        /*   25 mb = 26214400
          10 mb = 10485760 */
        // if (fileToLoad.size > 26214400) {
        else if (fileToLoad.size > reamingFileSize) {
          isValidFile = false;
          waringmsg = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
          setSupportingError(waringmsg)
          // isValidFile = false;
          /*  SetSupportDocWarning({
             ...supportDocWarning,
             [fileToLoad.name]: {
               filename: fileToLoad.name,
               isValid: true,
               warningMsg: "",
               fileExtnsion: fileExtession[fileExtession.length - 1],
             },
           }); */
          // return;
        }
      }

      // else {
      // setSupportingError(waringmsg);
      const fileReader = new FileReader();

      const promise = new Promise((resolve) => {
        fileReader.onload = function (fileLoadedEvent) {
          // Added for base 64 split params ---> Kavya(19-07)
          const base64 = fileLoadedEvent.target.result.split(",")[1];
          const partLength = Math.ceil(base64.length / 10);
          const parts = [];
          for (let j = 0; j < 10; j++) {
            parts.push(base64.slice(j * partLength, (j + 1) * partLength));
          }
  
          resolve({
            name: fileToLoad.name,
            parts: parts,
            size: fileToLoad.size
          });
        };
      });

      fileReader.readAsDataURL(fileToLoad);
      promises.push(promise);
    }

    Promise.all(promises)
      .then((fileDataArray) => {

        const updatedTempFileInfo = fileDataArray.reduce(
          (acc, fileData) => {
            const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
            if (!ObjExist.includes(fileData.name)) {

              acc.push({
                noteSupportingDocumentId: 0,
                noteId: 0,
                // supportingDocumentPath: fileData.base64.split(",")[1],
                supportingDocumentFileName: fileData.name,
                createdDate: new Date(),
                createdBy: accounts[0].username,
                modifiedDate: new Date(),
                modifiedBy: accounts[0].username,
                 // Added for base 64 split params parts ---> Kavya(19-07)
                supportingDocumentPath1: fileData.parts[0],
                supportingDocumentPath2: fileData.parts[1],
                supportingDocumentPath3: fileData.parts[2],
                supportingDocumentPath4: fileData.parts[3],
                supportingDocumentPath5: fileData.parts[4],
                supportingDocumentPath6: fileData.parts[5],
                supportingDocumentPath7: fileData.parts[6],
                supportingDocumentPath8: fileData.parts[7],
                supportingDocumentPath9: fileData.parts[8],
                supportingDocumentPath10: fileData.parts[9],
                supportingDocumentPathLength: fileData.size
              });
            }
            return acc;
          },
          [...TempfileInfo]
        );

        SetFileinfo(updatedTempFileInfo);
      })
      .catch((error) => {
        console.error("Error reading files:", error);
      });
  };

  /* Add Reviewers, CC, Mail recipients, recipients and Approvers Data */
  const handleComboChangeReviewer = (event) => {
    setSelectedReviewer(event.value);
  };

  const handleonChangeCC = (event) => {
    setSelectedCC(event.value); 
  }

  const handleMailRecipient = (event) => {
    setMailRecipient(event.value);
  }

  const handleRecipientChange = (event) => {
    setSelectReceipient(event.value);
  }

  const handleComboChangeApprover = (event) => {
    setComboValueApprover(event.value);
  };
  // Condition for signedBy
  const handleRadioChange = (data) => {
    const approversinfo = [...edakreviewerData, ...eDakapproverData];
    if (data) {
      const updated = approversinfo?.map(obj => {
        if (obj.approverEmail === data.approverEmail) {
          return {
            ...obj,
            signedBy: true
          }
        } else {
          return {
            ...obj,
            signedBy: false
          }
        }
      });
      seteDakReviewerData(updated.filter(obj => obj.approverType === 1 || obj.edakApproverType === 1));
      seteDakApproverData(updated.filter(obj => obj.approverType === 2 || obj.edakApproverType === 2));
    }
  };

  //Helps to add selected reviewer to the reviewers table
  const handleAddRow = async () => {
    if (!selectedReveiwer) {
      setShowNotification(true);
      setNotificationMsg("Please select reviewer then click on Add.");
      return;
    }

    let isApproverValid =
      eDakapproverData.find((x) => x.approverEmail === selectedReveiwer.userPrincipalName) ===
      undefined;
    let isReviewerValid =
      edakreviewerData.find((x) => x.approverEmail === selectedReveiwer.userPrincipalName) ===
      undefined;
    let isRecipientValid =
      groupData.find((x) => x.displayName === selectedReveiwer.displayName) ===
      undefined;

    if (isApproverValid && isReviewerValid && isRecipientValid && selectedReveiwer.userPrincipalName !== accounts[0].username && selectedReveiwer.userPrincipalName !== state.createdBy) {
      const newRow = {
        approverType: 1,
        approverEmail: selectedReveiwer.userPrincipalName,
        approverOrder: edakreviewerData.length + 1,
        approverStatus: 1,
        srNo: selectedReveiwer.srNo,
        designation: selectedReveiwer.jobTitle,
        approverEmailName: selectedReveiwer.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
      };
      seteDakReviewerData((prevData) => [...prevData, newRow]);
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected reviewer can not be same as existing Reviewers/Recipient."
      );
    }
    setSelectedReviewer(null);
    setOrgEmployees([]);

  };

  const handleOpenCC = () => {
    if (!selectCC) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectCC.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  };
 
  const handleOpenReviewer = () => {
    if (!selectedReveiwer) {
      console.log("test");
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectedReveiwer.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  };

  const handleOpenApprover = () => {
    if (!combovalueApprover) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(combovalueApprover.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  const handleOpenMailRecipient = () => {
    if (!selectMailRecipient) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectMailRecipient.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  const handleOpenRecipients = () => {
    if (!selectReceipient) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectReceipient.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }
  
  //Helps to add selected recipients to the recipients table
  const handleAddRecipients = async () => {
    if (!selectReceipient) {
        setShowNotification(true);
        setNotificationMsg("Please select recipients then click on Add.");
        return;
    }

    const isApproverValid = eDakapproverData.find(
      x => x.approverEmail === selectReceipient.userPrincipalName
    ) === undefined;

    const isReviewerValid = edakreviewerData.find(
      x => x.approverEmail === selectReceipient.userPrincipalName
    ) === undefined;

    const isReceiverValid = groupData.find(
      x => x.displayName === selectReceipient.displayName
    ) === undefined;

    if (
        isReceiverValid &&
        isApproverValid &&
        isReviewerValid &&
        selectReceipient.userPrincipalName !== accounts[0].username &&
        selectReceipient.userPrincipalName !== state.createdBy
    ) {
        const newRow = {
          approverType: 1,
          approverEmail: selectReceipient.userPrincipalName,
          approverOrder: edakreviewerData.length + 1,
          approverStatus: 1,
          srNo: selectReceipient.srNo,
          designation: selectReceipient.jobTitle,
          displayName: selectReceipient.displayName,
          createdDate: new Date(),
          createdBy: accounts[0].username,
          modifiedDate: new Date(),
          modifiedBy: accounts[0].username,
          groupName: null
        };

        const updatedRecipientData = [...recipientData, newRow];
        setGroupData([...groupData, newRow]);
        setRecipientData(updatedRecipientData);
    } else {
        setShowNotification(true);
        setNotificationMsg(
          "The selected recipient cannot be the same as existing Reviewers/Approvers."
        );
    }

    // Clear input field and reset states
    setSelectReceipient(null);
    setOrgEmployees([]);
    setGroupNames(''); // Reset the groupNames state
};


  //Helps to add selected mail recipients to the mail recipients table
  const handleAddMailRecipentRow = async () => {
    if (!selectMailRecipient) {
      setShowNotification(true);
      setNotificationMsg("Please select mail recipients then click on Add.");
      return;
    }

    if (!edakMailRecipientData.some((x) => x.displayName === selectMailRecipient.displayName)) {
      const newRow = {
        approverType: 4,
        approverEmail: selectMailRecipient.userPrincipalName,
        srNo: selectMailRecipient.srNo,
        designation: selectMailRecipient.jobTitle,
        displayName: selectMailRecipient.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
      };
      setEdakMailRecipientData((prevData) => [...prevData, newRow]);
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected mail recipients can not be same as existing mail recipients."
      );
    }
    setMailRecipient(null);
  };
  //Helps to add selected CC to the mail CC table
  const handleAddCCRow = async () => {
    if (!selectCC) {
      setShowNotification(true);
      setNotificationMsg("Please select CC then click on Add.");
      return;
    }

    if (!edakCCData.some((x) => x.displayName === selectCC.displayName)) {
      const newRow = {
        approverType: 3,
        approverEmail: selectCC.userPrincipalName,
        srNo: selectCC.srNo,
        designation: selectCC.jobTitle,
        displayName: selectCC.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
      };
      setEdakCCData((prevData) => [...prevData, newRow]);
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected CC cannot be the same as an existing CC."
      );
    }
    setSelectedCC(null);
    setOrgEmployees([]);
  };
  //Helps to add selected approver to the approvers table
  const handleAddRowApprover = async () => {
    if (!combovalueApprover) {
      setShowNotification(true);
      setNotificationMsg("Please select approver then click on Add.");
      return;
    }

    let isApproverValid =
      eDakapproverData.find((x) => x.approverEmail === combovalueApprover.userPrincipalName) ===
      undefined;
    let isReviewerValid =
      edakreviewerData.find((x) => x.approverEmail === combovalueApprover.userPrincipalName) ===
      undefined;

    let isRecieverValid =
      groupData.find((x) => x.displayName === combovalueApprover.displayName) ===
      undefined;

    if (isApproverValid && isReviewerValid && isRecieverValid && combovalueApprover.userPrincipalName !== accounts[0].username && combovalueApprover.userPrincipalName !== state.createdBy) {
      const newRow = {
        approverType: 2,
        approverEmail: combovalueApprover.userPrincipalName,
        approverOrder: eDakapproverData.length + 1 || 1,
        approverStatus: 1,
        srNo: combovalueApprover.srNo,
        designation: combovalueApprover.jobTitle,
        approverEmailName: combovalueApprover.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username
      };
      seteDakApproverData((prevData) => [...prevData, newRow]);

      let upApprObj = [...eDakapproverData, newRow];
      if (upApprObj?.length > 0) {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: "",
            fileName: "",
            filePath: "",
            isValid: false,
          },
        });
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: "",
            fileName: "",
            filePath: "",
            isValid: false,
          },
        });
      }
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected approver can not be same as existing Reviewers/Recipients."
      );
    }
    setComboValueApprover(null);
    setOrgEmployees([]);
  };

  //It helps to remove Word/PDF attachments
  const onRemoveAttachmentWarning = (key) => {
    if (key === "PDFInfo") {
      SetWordPDFInfowarring({
        PDFInfo: {
          fileExtension: "",
          fileName: "",
          warningMsg: "",
          filePath: "",
          isValid: false,
        },
        wordInfo: {
          fileExtension: "",
          fileName: "",
          warningMsg: "",
          filePath: "",
          isValid: false,
        },
      });
    }
    if (key === "wordInfo") {
      SetWordPDFInfowarring({
        ...wordandPdfWarring,
        [key]: { fileExtension: "", fileName: "", isValid: false },
      });
    }
  };

  //Helps to attache icon based on file extension
  const getFileIcon = (filename) => {
    const fileSplit = filename.split(".");
    const extnsion = `.${fileSplit[fileSplit.length - 1]}`;
    let fileType = fileIcon;
    if (extnsion === ".pdf") {
      fileType = filePdfIcon;
    }
    if (extnsion === ".doc" || extnsion === ".docx") {
      fileType = fileWordIcon;
    }
    if (extnsion === ".png" || extnsion === ".jpg") {
      fileType = fileImageIcon;
    }
    if (extnsion === ".txt") {
      fileType = fileTxtIcon;
    }
    if (extnsion === ".xlsx") {
      fileType = fileDataIcon;
    }
    return fileType;
  };

  // remove multiple attchemnts - support documents
  const onRemoveMultiAttachment = (id) => {
    const filename = filesInfo.find((obj, index) => index === id).supportingDocumentFileName;
    delete supportDocWarning[filename];
    SetSupportDocWarning(supportDocWarning);
    let reamingFileSize = 26214400;
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map((obj, index) => {
        if (index !== id) {
          totalFileSize = totalFileSize + obj.supportingDocumentPathLength
        }
      }

      );


      if (totalFileSize <= 26214400) {
        setSupportingError("");
      }
      console.log(vaildMultiplefile, "vaildMultiplefile")
    }
    SetFileinfo(filesInfo.filter((obj, ind) => ind !== id));
  };

  //Helps to filter the people picker dropdown vaules
  const pplFilterMultiColumn = async (event) => {
    if (event.filter.value.length >= 4) {
      setOrgEmployees([]);
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            return { department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName, srNo: x.srNo === null ? "NA" : x.srNo }
          });
          setUserData(orgUsers);
          setMailRecipients(orgUsers);
          // if (event.filter.value.length === 4) {
            setOrgEmployees(orgUsers);
          // }
          setAllOrgUsers(orgUsers);
        })
        .catch((err) => {
          setOrgEmployees([]);
          console.log(err);
        });
    } else if(event.filter.value.length < 4){
      setOrgEmployees([]);
    }
  };

  //HTML - render
  return (
    <div>
      <Navbar header="IB Smart Office - eDak" />
      <Sidebar />
      <div className="FormMaincontainer">
        <div className="container">
          <div className="HeaderButtonsContainer row">
            <div className="cstformHdrLeftContainer mobileTitleNewForm">
              {isNewForm ? "" : `Status: ${state.statusMsg}`}
            </div>
            <div className="cstformHdrMiddleContainer mobileTitleNewForm">
              eDak - {isNewForm ? "New" : `${state.dakNumber}`}
            </div>
            <div className="cstformHdrRightContainer mobileTitleNewForm">
              {isNewForm ? (
                <span>
                  Date: <Clock format={"DD-MMM-YYYY hh:mm:ss A"} ticking={true} />
                </span>
              ) : (
                `Created: ${state.createdDate}`
              )}
            </div>
          </div>
        </div>
        <div className="container">
          <Form
            render={() => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="errorMsg">All fields marked "*" are mandatory</div>
                  <div className="SectionHeads row">General Section</div>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Department:<span className="required-asterisk">*</span>
                          </Label>
                          {userDepartment && (
                            <Field
                              component={Input}
                              name="Department"
                              value={state.department}
                              defaultValue={userDepartment}
                              className="departmentBorder_"
                              readOnly
                            />
                          )}
                            {/* Removing this field and added dropdown -13/05*/}
                            {/* <DropDownList
                            data={departmentList.map((x) => x.departmentName)}
                            // defaultItem={"Select"}
                            onChange={handleSelectedDepartment}
                            value={selectedDepartment}
                            name="DepartMent"
                            // required={true}
                            style={{ borderColor: departmentBorderColor }}
                            valueRender={element => valueRenderDepartment(element, selectedDepartment)}
                          /> */}
                        </div>
                        <div className="errorMsg">{departmentError}</div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Source Type:<span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            data={SourceType.map((x) => x.dValue)}
                            onChange={handleSourceTypeChange}
                            value={state.sourceType}
                            name="SourceType"
                            style={{ borderColor: errorsourceBorderColor }}
                            valueRender={element => valueRender(element, state.sourceType, 'sourceType')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Document Type:<span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            data={setFilteredValueDocumentType()}
                            onChange={handleDocumentType}
                            value={state.documentType}
                            name="DocumentType"
                            style={{ borderColor: errordocumentBorderColor }}
                            valueRender={element => valueRender(element, state.documentType, 'documentType')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    {souceTypeField && (
                      <div className="col-md-6">
                        <div>
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Movement Type<span className="required-asterisk">*</span>
                              </Label>
                              <DropDownList
                                name="MovementType"
                                value={state.movementType}
                                data={MovementType.map((x) => x.dValue)}
                                onChange={handleMovementType}
                                style={{ borderColor: errormovement }}
                                valueRender={element => valueRender(element, state.movementType, 'movementType')}
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      </div>
                    )}
                    {souceTypeField && (
                      <div className="col-md-6">
                        <div>
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Name of the Agency<span className="required-asterisk">*</span>
                              </Label>
                              <DropDownList
                                name="NameOfAgency"
                                value={state.nameOfAgency}
                                data={NameoftheAgency.map((x) => x.dValue)}
                                onChange={handleAgencyType}
                                style={{ borderColor: errorNameofAgency, }}
                                valueRender={element => valueRender(element, state.nameOfAgency, 'nameOfAgency')}
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      </div>
                    )}
                    {showAgency && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Other Organization:<span className="required-asterisk">*</span>
                            </Label>
                            <TextArea
                              maxLength={max}
                              onChange={handleOtherChange}
                              value={state.other}
                              rows={1}
                              style={{ borderColor: errorOther }}
                            />
                            <Hint direction={"end"}>
                              {state.other.length} / {max}
                            </Hint>
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {receivedFieldValidation() && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Received Date :<span className="required-asterisk">*</span>
                            </Label>
                            <DatePicker
                              max={new Date()}
                              placeholder="Received Date..."
                              onChange={(event) => {
                                const selectedDate = new Date(event.target.value);
                                const utcDate = new Date(Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()));
                                setSelectedReceivedDate(utcDate);
                              }}
                              format={"dd-MM-yyyy"}
                              className={showError && !selectedreceivedDate ? "invalidColor" : ""}
                              value={selectedreceivedDate || state.receivedDate}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {showTo && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              To:<span className="required-asterisk">*</span>
                            </Label>
                            <TextArea
                              maxLength={max}
                              onChange={handleToChange}
                              value={state.to}
                              rows={1}
                              style={{ borderColor: errorTo }}
                            />
                            <Hint direction={"end"}>
                              {state.to.length} / {max}
                            </Hint>
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    <div className="col-md-6">
                      <div>
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Category<span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              name="category"
                              value={state.category}
                              data={Category.map((x) => x.dValue)}
                              onChange={handleCategoryType}
                              style={{ borderColor: errorcategoryBorderColor }}
                              valueRender={element => valueRender(element, state.category, 'category')}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Subject:<span className="required-asterisk">*</span>
                          </Label>
                          <TextArea
                            maxLength={max}
                            onChange={handleSubjectChange}
                            value={state.subject}
                            rows={1}
                            style={{ borderColor: errorSubjectBorderColor }}
                          />
                          <Hint direction={"end"}>
                            {state.subject.length} / {max}
                          </Hint>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Search Keyword:<span className="required-asterisk">*</span>
                          </Label>
                          <TextArea
                            maxLength={max}
                            onChange={handleSearchChange}
                            value={state.search}
                            rows={1}
                            style={{ borderColor: errorSearchBorderColor }}
                          />
                          <Hint direction={"end"}>
                            {state.search.length} / {max}
                          </Hint>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Comments:<span className="required-asterisk">*</span>
                          </Label>
                          <TextArea
                            maxLength={max}
                            onChange={handleCommentChange}
                            value={state.comments}
                            rows={1}
                            style={{ borderColor: errorCommentsBorderColor }}
                          />
                          <Hint direction={"end"}>
                            {state.comments.length} / {max}
                          </Hint>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-lg-12">
                      <FieldWrapper>
                        <div>
                          <Label className="k-form-label">CC:</Label>
                          <MultiColumnComboBox
                            data={orgEmployees}
                            filterable={true}
                            columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                            // columns={orgUsersPplPickerColumnMapping}
                            value={
                              selectCC === null
                                ? null
                                : selectCC.displayName
                            }
                            onOpen={handleOpenCC}
                            onFilterChange={pplFilterMultiColumn}
                            onChange={handleonChangeCC}
                            style={{ width: isMobile ? "auto" : "300px",marginRight: "5px", }} // Adjust width
                            placeholder="Add CC..."
                          />
                          <Button onClick={handleAddCCRow}>
                            <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                            Add
                          </Button>
                          <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                          <div className="cstDisableGridScroll">
                            <TableDraggableRows
                              typeOfTable="User Name"
                              data={edakCCData}
                              onDelate={deleteCC}
                              onOrderChange={orderChange}
                              CCTable="CCform"
                            />
                          </div>
                        </div>
                      </FieldWrapper>
                    </div>
                  </div>
                  <div className="SectionHeads row">Reviewer/Approver Details</div>
                  <div className="SectionRow row">
                    <div className="multiComboBox_">
                      <MultiColumnComboBox
                        data={orgEmployees}
                        filterable={true}
                        // columns={orgUsersPplPickerColumnMapping}
                        columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                        value={
                          selectedReveiwer === null
                            ? null
                            : selectedReveiwer.displayName
                        }
                        onFilterChange={pplFilterMultiColumn}
                        onChange={handleComboChangeReviewer}
                        onOpen={handleOpenReviewer}
                        style={{ width: isMobile ? "auto" : "300px",marginRight: "5px", }} // Adjust width
                        placeholder="Add Reviewer..."
                      />
                      <Button onClick={handleAddRow}>
                        <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                        Add
                      </Button>
                    </div>

                    {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                    <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                    <div className="cstDisableGridScroll">
                      <TableDraggableRows
                        typeOfTable="Reviewer"
                        data={edakreviewerData}
                        onDelate={deletereviewer}
                        onOrderChange={orderChange}
                        handleRadioChange={handleRadioChange}
                        reviewerTable="reviewerform" />
                    </div>
                    <div className="approvalContentStyle_"></div>
                    <div className="multiComboBox_">
                      <MultiColumnComboBox
                        data={orgEmployees}
                        filterable={true}
                        // columns={orgUsersPplPickerColumnMapping}
                        columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                        value={
                          combovalueApprover === null
                            ? null
                            : combovalueApprover.displayName
                        }
                        onFilterChange={pplFilterMultiColumn}
                        onChange={handleComboChangeApprover}
                        onOpen={handleOpenApprover}
                        style={{ width: isMobile ? "auto" : "300px",marginRight: "5px", }} // Adjust width
                        placeholder="Add Approver..."
                      />
                      <Button onClick={handleAddRowApprover}>
                        <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                        Add<span className="required-asterisk">*</span></Button>
                    </div>
                    {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                    <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                    <div className="cstDisableGridScroll">

                      <TableDraggableRows
                        typeOfTable="Approver"
                        data={eDakapproverData}
                        onDelate={deletereviewer}
                        handleRadioChange={handleRadioChange}
                        onOrderChange={orderChange}
                      />
                    </div>
                    <div className="approvalContentStyle_"></div>
                  </div>
                  {hideRecipitent && (
                    <div>
                      <div className="SectionHeads row">Recipient Details</div>
                      <div className="SectionRow row">
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Action Type:<span className="required-asterisk">*</span>
                              </Label>
                              <DropDownList
                                data={ActionType.map((x) => x.dValue)}
                                onChange={handleActionTypeChange}
                                value={state.actionType}
                                name="actionType"
                                style={{ borderColor: errorActionTypeBorderColor }}
                                valueRender={element => valueRender(element, state.actionType, 'actionType')}
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                        {OtherValidation() && (
                          <div className="col-md-6">
                            <FieldWrapper>
                              <div className="k-form-field-wrap">
                                <Label className="k-form-label">
                                  Other Action Type:<span className="required-asterisk">*</span>
                                </Label>
                                <TextArea
                                  maxLength={max}
                                  onChange={handleActionOtherChange}
                                  value={state.otherAction}
                                  rows={1}
                                  style={{ borderColor: errorOtherAction }}
                                />
                                <Hint direction={"end"}>
                                  {state.otherAction.length} / {max}
                                </Hint>
                              </div>
                            </FieldWrapper>
                          </div>
                        )}
                        {followUpValidation() && (
                          <div className="col-md-6">
                            <FieldWrapper>
                              <div className="k-form-field-wrap">
                                <Label className="k-form-label">
                                  Follow Up Date :<span className="required-asterisk">*</span>
                                </Label>
                                <DatePicker
                                  min={new Date()}
                                  placeholder="Follow Up Date..."
                                  onChange={(event) => {
                                    const selectedDate = new Date(event.target.value);
                                    const utcDate = new Date(Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()));
                                    setSelectFollowUpDate(utcDate);
                                  }}
                                  format={"dd-MM-yyyy"}
                                  className={showFollowError && !selectFollowUpDate ? "invalidColor" : ""}
                                  value={selectFollowUpDate || state.targetDate}

                                />
                              </div>
                            </FieldWrapper>
                          </div>
                        )}
                        {targetFieldValidation() && (
                          <div className="col-md-6">
                            <FieldWrapper>
                              <div className="k-form-field-wrap">
                                <Label className="k-form-label">
                                  Target Date :<span className="required-asterisk">*</span>
                                </Label>
                                <DatePicker
                                  min={new Date()}
                                  placeholder="Target Date..."
                                  onChange={(event) => {
                                    const selectedDate = new Date(event.target.value);
                                    const utcDate = new Date(Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()));
                                    setSelectTargetDate(utcDate);
                                  }}
                                  format={"dd-MM-yyyy"}
                                  className={showTargetError && !selectTargetDate ? "invalidColor" : ""}
                                  value={selectTargetDate || state.targetDate}
                                />
                              </div>
                            </FieldWrapper>
                          </div>
                        )}
                        {informationValidation() && (
                          <div className="col-md-6">
                            <FieldWrapper>
                              <div className="k-form-field-wrap">
                                <Label className="k-form-label">
                                  Reminder Type:<span className="required-asterisk">*</span>
                                </Label>
                                <DropDownList
                                  data={ReminderType.map((x) => x.dValue)}
                                  onChange={onChangeRemainderType}
                                  value={state.reminderType}
                                  name="reminderType"
                                  style={{ borderColor: errorReminderType }}
                                  valueRender={element => valueRender(element, state.reminderType, 'reminderType')}
                                />
                              </div>
                            </FieldWrapper>
                          </div>
                        )}
                        {informationValidation() && (
                          <div className="col-md-6">
                            <FieldWrapper>
                              <div className="k-form-field-wrap">
                                <Label className="k-form-label">
                                  Reminder Frequency:<span className="required-asterisk">*</span>
                                </Label>
                                <DropDownList
                                  data={ReminderFequency.map((x) => x.dValue)}
                                  onChange={onChangeRemainderFrequency}
                                  value={state.reminderFrequency}
                                  name="reminderFrequency"
                                  style={{ borderColor: errorReminderFreq }}
                                  valueRender={element => valueRender(element, state.reminderFrequency, 'reminderFrequency')}
                                />
                              </div>
                            </FieldWrapper>
                          </div>
                        )}
                        <div className="col-md-12">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Mail Recipients:
                              </Label>

                              <MultiColumnComboBox
                                data={orgEmployees}
                                filterable={true}
                                // columns={orgUsersPplPickerColumnMapping}
                                columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                                value={
                                  selectMailRecipient === null
                                    ? null
                                    : selectMailRecipient.displayName
                                }
                                onFilterChange={pplFilterMultiColumn}
                                onChange={handleMailRecipient}
                                onOpen={handleOpenMailRecipient}
                                style={{ width: isMobile ? "auto" : "300px",marginRight: "5px", }} // Adjust width
                                placeholder="Recipients..."
                              />
                              <Button onClick={handleAddMailRecipentRow}>
                                <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                Add
                              </Button>
                              <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                              <div className="cstDisableGridScroll">
                                <TableDraggableRows
                                  typeOfTable="Name"
                                  data={edakMailRecipientData}
                                  onDelate={deleteMailRecipients}
                                  onOrderChange={orderChange}
                                  CCTable="CCform"
                                />
                              </div>
                            </div>
                          </FieldWrapper>
                        </div>
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">Group:</Label>
                              <MultiColumnComboBox className="comboGroup"
                                data={groupNamesData}
                                onChange={onChangegroup}
                                value={groupNames || state.group}
                                name="groupNames"
                                style={{ width: isMobile ? "100%" : "300px",marginRight: "5px", }} // Adjust width
                                filterable={true}
                                columns={orgUsersGroupPickerColumnMapping}
                                onFilterChange={onFilterGroupChange}
                                placeholder="Select Group..."
                                clearButton={showCloseIcon} // Conditionally show/hide the close icon
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                        <div className="col-md-6" style={{ marginTop: "12px" }}>
                          <div className="multiComboBox_">
                            <Label className="k-form-label">Recipients:<span className="required-asterisk">*</span></Label>
                            <MultiColumnComboBox
                              data={orgEmployees}
                              filterable={true}
                              // columns={orgUsersPplPickerColumnMapping}
                              columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                              value={selectReceipient ? selectReceipient.displayName : null}
                              onFilterChange={pplFilterMultiColumn}
                              onChange={handleRecipientChange}
                              onOpen={handleOpenRecipients}
                              style={{ width: isMobile ? "auto" : "300px",marginRight: "5px", }} // Adjust width
                              placeholder="Recipients..."
                            />
                            <Button onClick={handleAddRecipients}>
                              <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                              Add
                            </Button>
                          </div>
                        </div>
                        <div className="cstDisableGridScroll">
                          <TableDraggableRows
                            recipientName="User Name"
                            data={groupData}
                            onDelate={deleteRecipients}
                            onOrderChange={orderChange} recipientTable="eDakform"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                  {(!isNewForm && state.status === enumsObj?.status.find(x => x.dValue === "Returned").id) &&
                    (<div>
                      <div className="SectionHeads eNoteAtrFormHdr row">
                        Comments
                      </div>
                      <div className="SectionRow row">
                        <table className="SectionRow cstATRFormTbl tableStyle" style={{ width: "100%" }}>
                          <tr>
                            <th className="approvalform-tableCol-width-1">Page#</th>
                            <th className="approvalform-tableCol-width-1">Doc Reference</th>
                            <th className="approvalform-tableCol-width-5">Comments</th>
                            <th className="approvalform-tableCol-width-3">Comment By</th>
                          </tr>
                          {noteComments?.map((comment) => (
                            <tr key={comment.edakComments}>
                              <td className="approvalform-tableCol-width-1">{comment.pageNumber}</td>
                              <td className="approvalform-tableCol-width-1">{comment.docReferrence}</td>
                              <td className="approvalform-tableCol-width-5">{comment.comments}</td>
                              <td className="approvalform-tableCol-width-3">{comment.commentsByName}</td>
                            </tr>
                          )
                          )}
                        </table>
                      </div>
                    </div>
                    )}
                  <div className="SectionHeads row">File Attachments</div>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      {" "}
                      <Label className="k-form-label">
                        Upload Letter<span className="required-asterisk">*</span>
                      </Label>
                      <div className="Attachemntfileinfo-ind">
                        <input
                          type="file"
                          id="PDFDocfile"
                          onChange={convertPDFToBase64}
                          className="attachmentFileWidth"
                        />
                      </div>
                      {wordandPdfWarring?.PDFInfo.fileName === null ||
                        wordandPdfWarring?.PDFInfo.fileName === "" ? null : (
                        <div className="Attachemntfileinfo-ind">
                          <span className="attachemntIconInfoConationer">
                            <span className="AttchemntIconWraper">
                              <SvgIcon
                                icon={getFileIcon
                                  (wordandPdfWarring?.PDFInfo.fileName)
                                }
                                size="xxlarge"
                              />
                              <span className="attachemnrt-warningifoConatiner">
                                <div className="attachemnrt-warningifo-fileinfo">
                                  {wordandPdfWarring?.PDFInfo.fileName}
                                </div>
                                <span className="attachmentWarning_">
                                  {wordandPdfWarring?.PDFInfo.warningMsg}
                                </span>
                              </span>
                            </span>
                            <span
                              className="AttchemntIconWraperCancel"
                              onClick={() =>
                                onRemoveAttachmentWarning("PDFInfo")
                              }
                            >
                              X
                            </span>
                          </span>
                        </div>
                      )}
                      <div className="attachmentHint_">
                        Allowed only one PDF.Upto 10MB max.
                      </div>
                    </div>
                    <div className="col-md-6">
                      <Label className="k-form-label">Supporting Documents</Label>
                      {/* multidoc controller */}
                      <div className="Attachemntfileinfo-ind">
                        <input
                          type="file"
                          id="multiDoc"
                          onChange={multipleDocUpload}
                          className="attachmentFileWidth"
                        />
                         <div>
                          <span
                            className="attachmentWarning_"
                          >
                            {
                              supportingDocError
                            }
                          </span>
                        </div>
                      </div>
                      {filesInfo?.map((obj, ind) => (
                        <div className="Attachemntfileinfo-ind" key={ind}>
                          <span className="attachemntIconInfoConationer">
                            <span className="AttchemntIconWraper">
                              {/* Assuming you have different icons for different file types */}
                              <SvgIcon
                                icon={getFileIcon(
                                  obj.supportingDocumentFileName
                                )}
                                size="xxlarge"
                              />
                              <span className="attachemnrt-warningifoConatiner">
                                <div className="attachemnrt-warningifo-fileinfo">
                                  {obj.supportingDocumentFileName}
                                </div>
                                <span className="attachmentWarning_">
                                  {
                                    supportDocWarning[
                                      obj.supportingDocumentFileName
                                    ]?.warningMsg
                                  }
                                </span>
                              </span>
                            </span>
                            <span
                              className="AttchemntIconWraperCancel"
                              onClick={() => onRemoveMultiAttachment(ind)}
                            >
                              X
                            </span>
                          </span>
                        </div>
                      ))}
                      <div className="attachmentHint_">
                        {/* Allowed Formats (images,pdf,eml,doc,docx,xlsx only) Upto 5MB max. */}
                        Allowed Formats (pdf,doc,docx,xlsx only) Upto 25MB max.
                      </div>
                    </div>
                  </div>
                </fieldset>
                <div className="FormButtonsContainer k-form-buttons">
                  {(isNewForm || state.status === 1 &&
                    (!isNewForm &&
                      state.createdBy === accounts[0].username)) && (
                      <Button
                        type={"button"}
                        onClick={handleSave}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className=" k-icon-xs k-icon k-font-icon k-i-save cursor allIconsforPrimary-btn"></span>
                        <save>
                          Save as Draft
                        </save>
                      </Button>
                    )}
                  {(isNewForm ||
                    (!isNewForm && (state.status === 1 || state.status === 3) &&
                      state.createdBy === accounts[0].username)) && (
                      <Button
                        onClick={handleOpenDialog}
                        type={"submit"}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon k-i-launch cursor allIconsforPrimary-btn"></span>
                        Submit
                      </Button>
                    )}
                  {!isNewForm &&
                    state.status === 4 &&
                    state.createdBy === accounts[0].username && (
                      <span className="eNote-ApprovalButton">
                        <Button
                          onClick={() => setVisibleCancelCfrm(true)}
                          className="formBtnColor"
                        >
                          <span className="k-icon-sm k-icon k-font-icon k-i-cancel cursor allIconsforPrimary-btn"></span>
                          Cancel Note
                        </Button>
                      </span>
                    )}
                  <Link to="/datagridpage">
                    <Button
                      type={"submit"}
                      className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                    >
                      <span className="k-icon-sm k-icon k-font-icon  k-i-x-circle cursor allIconsforPrimary-btn"></span>
                      Exit
                    </Button>
                  </Link>
                </div>
                {isLoading && <PageLoader />}
                {visiblesave && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleSaveClose}
                  >
                    <p className="dialogcontent_">
                      {successMessage}
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => {setTab("My Pending for Action");navigate(redirectTo)}}
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visible && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={handleCloseDialog}
                  >
                    <p className="dialogcontent_">
                      Are you sure you want to submit this request?
                    </p>
                    <p className="dialogcontent_">
                      Please check the details filled along with attachment and
                      click on Confirm button to submit request.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                        onClick={handleSubmit}
                      >
                        <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                        Confirm
                      </Button>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleCloseDialog}
                      >
                        <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visibleCancelCfrm && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={() => setVisibleCancelCfrm(false)}
                  >
                    <p className="dialogcontent_">
                      Are you sure you want to cancel this request?
                    </p>
                    <p className="dialogcontent_">
                      Please click on Confirm button to cancel request.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                        onClick={onCanceleDakform}
                      >
                        <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                        Confirm
                      </Button>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => setVisibleCancelCfrm(false)}
                      >
                        <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {alertvisible && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setAlertVisible(false)}
                  >
                    <p className="dialogcontent_">
                      The request for eDak has been submitted successfully.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => {setTab("My Pending for Action");navigate(redirectTo)}}
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {validationErrors && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleClosevalidationDialog}
                  >
                    <p className="cstDailogValidmsg">
                      <div className="dialogAlignment_">
                        <p className="dialogParap_">Please fill up all the mandatory fields</p>
                        <ul className="dialogUI">
                          {errorMessages.map((message, index) => (
                            <li className="dialogList_" key={index}>{message}</li>
                          ))}
                        </ul>
                        <p>
                          <strong>Note:</strong> Invalid files are not allowed
                        </p>
                      </div>
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={handleClosevalidationDialog}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {showNotification && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setShowNotification(false)}
                  >
                    <p className="dialogcontent_">
                      {notificationMsg}
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={() => setShowNotification(false)}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
              </FormElement>
            )}
          />
        </div>
      </div>
      <Footer />
    </div>
  );
};