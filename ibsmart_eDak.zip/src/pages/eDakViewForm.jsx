/* eslint-disable array-callback-return */
import React, { useState, useEffect } from "react";
import "../styles/homepage.css";
import Navbar from "../components/navbar";
import { Sidebar } from "../components/sidebar";
import Footer from "../components/footer";
import { useMsal, useAccount } from "@azure/msal-react";
import { useParams } from "react-router-dom";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { Label } from "@progress/kendo-react-labels";
import {
  Form,
  FormElement,
  FieldWrapper,
} from "@progress/kendo-react-form";

import { DropDownList } from "@progress/kendo-react-dropdowns";
import { SvgIcon } from "@progress/kendo-react-common";
import {
  filePdfIcon,
  fileWordIcon,
  fileImageIcon,
  fileTxtIcon,
  fileDataIcon,
  fileIcon,
  infoCircleIcon,
} from "@progress/kendo-svg-icons";
import "../styles/forms.css";
// import { Reveal } from "@progress/kendo-react-animation";
// import { PDFViewer } from "@progress/kendo-react-pdf-viewer";
import { Button } from "@progress/kendo-react-buttons";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
// navigetor
import { useNavigate } from "react-router-dom";
// loader
import { PageLoader } from "../components/pageLoader";
// multiplecolum commbo box
import { MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";
import DateObject from "react-date-object";
import { Link } from "react-router-dom";
import { Input, TextArea, RadioButton } from "@progress/kendo-react-inputs";
import { useTabContext } from "../App";
// Import css styles,images and encrypt function for passcode
import "../styles/passcode.css"
import view from "../assets/view.png"
import hide from "../assets/hide.png"
import CryptoJS from 'crypto-js';

const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",

  },
];
export const EDakViewForm = () => {
  const id = useParams();
  let isAcknowledged = false;
  const navigate = useNavigate();
  const { setTab } = useTabContext();
  const { setPasscodeNavigate } = useTabContext();
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  // const [redirect] = useState("/views/In%20Progress");
  const [redirect] = useState("/datagridpage");
  // general Commenta
  const [generalcmtInfoobj, SetGeneralCmtInfoObj] = useState({
    DocRef: "",
    Comments: "",
    PageNo: "",
    iEdit: false,
  });

  // dialog box for refer and  change Approver
  const [dialogForRefereeAndChangeApprover, setDialogForRefereeAndChangeApprover] = useState(false);
  // General commnets info array
  const [generalcmtforAllCmt, SetGeneralcmtforAllCmt] = useState([]);

  //  supportDoc files info  //
  const [supportDocfilesInfo, setSupportDocfilesInfo] = useState([]);
  const [attachReplyDocfilesInfo, setattachReplyDocfilesInfo] = useState([]);
  const [isVaildRecipientsComments, setIsVaildRecipientsComments] = useState(false);
  const [isVaildCompliationDate, setIsVaildCompliationDate] = useState(false);

  //word doc and gist doc details
  /* const [wordandPdfInfo, SetWordPDFInfowarring] = useState({
    wordInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
      isDownloadble: false,
      base64: ""
    },
  }); */
  const [supportDocWarning, SetSupportDocWarning] = useState({

  });
  const [attachReplyDocWarning, setAttachReplyDocWaning] = useState({
    "file.txt": {
      filename: "",
      isValid: false,
      warningMsg: "",
      fileExtnsion: "",
    }
  });
  const [actionBtn, setActionBtn] = useState("");
  //  dailog for confiramation
  const [dialogOpen, setdialogOpen] = useState(false);
  // dailog for Success
  const [dialogSuccess, setDialogSuccess] = useState(false);
  // dailog for Failure
  const [dialogFailure, setDialogFailure] = useState(false);
  // getNoteSecretary 
  // const [getNoteSecretaryUserInfo, setGetNoteSecretaryUserInfo] = useState([]);
  const [orgEmployees, setOrgEmployees] = useState([]);

  //  Succuss Msg
  const [successMsg, SetSuccessMsg] = useState("");
  // current actioner email
  const [isLoading, SetIsLoading] = useState(true);
  // alert box dailog and dcesiption
  const [confirmDailogObj, setConfirmDailogObj] = React.useState({
    Confirmtext: "",
    Description: "",
  });
  const [changeapprovervisible, setChangeApproverVisible] = useState(false);
  const [userComboValidationDialog, setUserComboValidationDialog] = useState(false);
  const [userNotifyInfo, setUserNotifyInfo] = useState("");
  const [changeApprovercombovalue, setChangeApprovercombovalue] = useState(null);
  const [pdfLink, setPdfLink] = useState("")
  const [supportDoclink, setSupportDoclinks] = useState({});
  const [replysupportDoclink, setReplySupportDoclinks] = useState({});
  const [enumObj, setEnumObj] = useState(null);
  const [recipientsActionType, setRecipientsActionType] = useState("Complete");
  const [completionDate, setCompletionDate] = useState(null)
  const [forwardUser, setForwardUser] = useState(null);
  const [recipientsComments, setrecipientsComments] = useState("");
  const [directionsComments, setDirectionsComments] = useState('');
  const [dakData, setDakData] = useState(null);
  const [selectedCurrentApprover, setSelectedCurrentApprover] = useState("");
  const [approverDetailsDTO, setApproverDetailsDTO] = useState([]);
  const [closedDate, setClosedDate] = useState(null);
  const [sentDate, setSentdDate] = useState(null);
  const [validationErrors, setValidationErrors] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  // 348 -bug  06/05
  const [isReturnValidtion, setIsReturnValidtion] = useState(false);
  const [isSentDateVaild, setIsSentDateVaild] = useState(false);
  const [isCloseDateVaild, setIsCloseDateVaild] = useState(false);
  const [isDirectionCmtVaild, setIsCmtDirectionVaild] = useState(false);
  const [supportingDocError, setSupportingError] = useState("");
  // Passcode validation and input
  const [passcodeVerification, setPasscodeVerification] = useState(false);
  const [isPasscodeVisible, setIsPasscodeVisible] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [validPasscode, setValidPasscode] = useState(false);
  const [validMsg, setValidmsg] = useState(false);
  const [verifyPasscode, setVerifypasscode] = useState("false");

  useEffect(() => {
    SetIsLoading(true);
    VerifyUserPasscode();
    const fetchData = async () => {
      try {
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

        // const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
        const getDakGeneralDetailsresponse = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eDak_GetGeneralDetails}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify({ dakId: id.id }),
          }
        );
        const dakData = await getDakGeneralDetailsresponse.json();
        if (isAcknowledged === false) {
          eDak_AcknowledgeEdak(dakData)
        }

        // console.log(dakData, "darkData")
        setDakData(dakData);
        // getSupportDocHyperlink(dakData?.dakSupportingDocumentsDTO);
        // downloadBase64PDFFile(dakData?.uploadLetterBase64 || "");
        // getReplyDocHyperLink(dakData?.edakReplyDocumentsDTO);

        // const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
        const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
        });

        const enumsObj = await dropdowns.json();
        setEnumObj(enumsObj)
        // console.log(enumsObj, "enumsObj")
        SetIsLoading(false);

      } catch (error) {
        SetIsLoading(false);
        console.error("Error fetching data:", error);
      }
    };
    // isAcknowledged = true
    // SetIsLoading(false);
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  //AcknowledgeEdak
  const eDak_AcknowledgeEdak = async (dakData) => {
    if (dakData?.recipientDetailsDTO && dakData?.recipientsDTO?.length > 0 && dakData?.recipientsDTO) {
      if (dakData && dakData?.status === 6 &&
        (dakData?.isAcknowledged === null ||
          dakData?.isAcknowledged === false) &&
        dakData?.recipientDetailsDTO[0]?.strDakActionType === "Information" &&
        dakData?.createdBy === accounts[0].username
      ) {
        isAcknowledgedfunction();
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
        const params = {

          dakId: id.id,
          acknowledgedDate: new Date(),
          isAcknowledged: true,
          CreatedBy: accounts[0].username

        }
        await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eDak_AcknowledgeEdak}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify(params),
          }
        );
      }
    }
  }

  // Convert base64 to URL -PDF

  const downloadBase64PDFFile = async (path) => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const parmas = {
      supportingDocumentPath: path
    }
    const notePDFINfo = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)

      }
    );
    const pdfDetails = await notePDFINfo?.text();
    if (pdfDetails !== "File Not Available!") {
      console.log(pdfDetails);
      const byteCharacters = atob(pdfDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      window.open(window.URL.createObjectURL(blob))
      // setPdfLink(window.URL.createObjectURL(blob))
    }
  }

  const isAcknowledgedfunction = () => {
    isAcknowledged = true
  }

  // convert supporting doc
  const getSupportDocHyperlink = async (filePath, fileName) => {
    SetIsLoading(true);
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const parmas = {
      supportingDocumentPath: filePath
    }
    const getSupportingDocs = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)

      }
    );
    const supportDocDetails = await getSupportingDocs?.text();

    if (supportDocDetails !== "File Not Available!") {
      const byteCharacters = atob(supportDocDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      // Create a Blob object
      const byteArray = new Uint8Array(byteNumbers);
      // checking file type
      const fileType = getFileType(fileName);
      // Create a Blob object

      const blob = new Blob([byteArray], { type: `application/${fileType}` });
      if (fileType.toLowerCase() === "pdf") {
        window.open(window.URL.createObjectURL(blob));
        SetIsLoading(false);
      } else {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        document.body.appendChild(link);
        link.click();

        // Clean up and remove the link
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
      }
    }
    SetIsLoading(false);
  }

  //Convert base64 to URL - supportDoc
  const getReplyDocHyperLink = async (filePath, fileName) => {
    SetIsLoading(true);
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const parmas = {
      supportingDocumentPath: filePath
    }
    const getSupportingDocs = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)

      }
    );
    const supportDocDetails = await getSupportingDocs?.text();

    if (supportDocDetails !== "File Not Available!") {
      console.log(supportDocDetails, "supportDocDetails")
      const byteCharacters = atob(supportDocDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      // Create a Blob object
      const byteArray = new Uint8Array(byteNumbers);
      const fileType = getFileType(fileName);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: `application/${fileType}` });
      if (fileType.toLowerCase() === "pdf") {
        window.open(window.URL.createObjectURL(blob));
        SetIsLoading(false);
      } else {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        document.body.appendChild(link);
        link.click();

        // Clean up and remove the link
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
      }
      SetIsLoading(false);
    }
    // if (replyDocDetails.length > 0 && replyDocDetails !== null) {
    //   replyDocDetails.map(obj => {
    //     const byteCharacters = atob(obj.supportBase64);
    //     const byteNumbers = new Array(byteCharacters.length);
    //     for (let i = 0; i < byteCharacters.length; i++) {
    //       byteNumbers[i] = byteCharacters.charCodeAt(i);
    //     }
    //     const byteArray = new Uint8Array(byteNumbers);
    //     // checking file type
    //     const fileType = getFileType(fileName);
    //     // Create a Blob object
    //     const blob = new Blob([byteArray], { type: `application/${fileType}` });
    //     window.open(window.URL.createObjectURL(blob));
    //     // updateReplySupportDoclink(obj.replyDocumentFileName, window.URL.createObjectURL(blob));
    //   })
    // }
  }

  // updting all the support Doc links in Object 
  const updateReplySupportDoclink = (fileName, url) => {
    setReplySupportDoclinks(prevLinks => ({
      ...prevLinks,
      [fileName]: { fileName: fileName, href: url }
    }));
  };

  // updting all the support Doc links in Object 
  const updateSupportDoclink = (fileName, url) => {
    setSupportDoclinks(prevLinks => ({
      ...prevLinks,
      [fileName]: { fileName: fileName, href: url }
    }));
  };

  // getfileType  -checking file type 
  const getFileType = (filename) => {
    let fileType = "doc"
    if (filename.endsWith(".pdf")) {
      fileType = "pdf";
    }
    if (filename.endsWith(".doc") || filename.endsWith(".docx")) {
      fileType = "doc";
    }
    if (
      filename.endsWith(".png") ||
      filename.endsWith(".jpg") ||
      filename.endsWith(".img") ||
      filename.endsWith(".svg")
    ) {
      fileType = "image";
    }
    if (filename.endsWith(".txt")) {
      fileType = "txt";
    }
    if (filename.endsWith(".xlsx")) {
      fileType = "xlsx";
    }
    if (filename.endsWith(".eml")) {
      fileType = "eml";
    }
    return fileType;
  }

  // supporting doc  control
  const multipleDocUpload = () => {
    if(verifyPasscode === "true") {
      let reamingFileSize = 26214400;
      let totalFileSize = 0;
      const inValidFileNames = Object.keys(supportDocWarning).filter(
        (fileName) => supportDocWarning[fileName]?.isValid === false
      );
      // filter valid files only if()
      if (supportDocfilesInfo.length > 0) {
        const vaildMultiplefile = supportDocfilesInfo.filter(obj => {
          if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
            return obj;
          }
        });
        vaildMultiplefile.map(obj => {
          reamingFileSize = reamingFileSize - obj.supportingDocumentPathLength;
          // totalFileSize =totalFileSize+ obj.supportingDocumentPathLength
        });
  
        console.log(vaildMultiplefile, "vaildMultiplefile")
      }
      if (dakData?.dakSupportingDocumentsDTO.length > 0) {
        dakData?.dakSupportingDocumentsDTO.map(obj => {
          reamingFileSize = reamingFileSize - obj.supportingDocumentPathLength
          // totalFileSize =totalFileSize+ obj.supportingDocumentPathLength
        });
      }
      // }
  
      // console.log(reamingFileSize , "supportingDocSize", supportDocfilesInfo)
      // console.log(totalFileSize -26214400, "totalFileSize")
      let warningmsg = "";
      // eslint-disable-next-line no-useless-escape
      const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
      const selectedFile = document.getElementById("multiDoc").files;
      const TempfileInfo = supportDocfilesInfo;
      const promises = [];
      const fileCount = selectedFile.length;
      for (let i = 0; i < fileCount; i++) {
        const fileToLoad = selectedFile[i];
        const fileExtession = fileToLoad.name.split(".");
        // Check for special characters in the filename
  
        if (!dakData?.dakSupportingDocumentsDTO?.some(obj => obj.supportingDocumentFileName === fileToLoad.name)) {
          // Check if the file type is allowed
          if (
            !(
              (fileToLoad.name).toLowerCase().endsWith(".docx") ||
              (fileToLoad.name).toLowerCase().endsWith(".doc") ||
              (fileToLoad.name).toLowerCase().endsWith(".pdf") ||
              (fileToLoad.name).toLowerCase().endsWith(".xlsx")
              // fileToLoad.name.endsWith(".png") ||
              // fileToLoad.name.endsWith(".jpg") ||
              // fileToLoad.name.endsWith(".img") ||
              // fileToLoad.name.endsWith(".eml")
            )
          ) {
            warningmsg = "File type is not allowed";
            updateSupportDocWarning(
              fileToLoad.name,
              warningmsg,
              fileExtession[fileExtession.length - 1]
            );
          }
          if (validname.test(fileToLoad.name)) {
            warningmsg = "File name should not contain special characters";
            updateSupportDocWarning(
              fileToLoad.name,
              warningmsg,
              fileExtession[fileExtession.length - 1]
            );
          }
  
          // Check file size (5MB limit)
          /* 
          * Bug -396 fixed
          File size increse 5mb to 25MB 
    25 mb = 26214400
       10 mb = 10485760 */
          if (fileToLoad.size > reamingFileSize) {
            warningmsg = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
            /*   updateSupportDocWarning(
                fileToLoad.name,
                warningmsg,
                fileExtession[fileExtession.length - 1]
              ); */
            setSupportingError(warningmsg)
          }
  
  
          // File Reader.....
          const fileReader = new FileReader();
          const promise = new Promise((resolve) => {
            fileReader.onload = function (fileLoadedEvent) {
              // Added for base 64 split params ---> Kavya(29-07)
              const base64 = fileLoadedEvent.target.result.split(",")[1];
              const partLength = Math.ceil(base64.length / 10);
              const parts = [];
              for (let j = 0; j < 10; j++) {
                parts.push(base64.slice(j * partLength, (j + 1) * partLength));
              }
  
              resolve({
                name: fileToLoad.name,
                parts: parts,
                size: fileToLoad.size
              });
            };
          });
  
          fileReader.readAsDataURL(fileToLoad);
          promises.push(promise);
        }
      }
  
      Promise.all(promises)
        .then((fileDataArray) => {
          const updatedTempFileInfo = fileDataArray.reduce(
            (acc, fileData) => {
              // const decodedfile =atob
  
              const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
              if (!ObjExist.includes(fileData.name)) {
                acc.push({
                  // noteSupportingDocumentId: 0,
                  // noteId: dakData.dakId,
                  // supportingDocumentPath: fileData.base64.split(",")[1],
                  supportingDocumentPath1: fileData.parts[0],
                  supportingDocumentPath2: fileData.parts[1],
                  supportingDocumentPath3: fileData.parts[2],
                  supportingDocumentPath4: fileData.parts[3],
                  supportingDocumentPath5: fileData.parts[4],
                  supportingDocumentPath6: fileData.parts[5],
                  supportingDocumentPath7: fileData.parts[6],
                  supportingDocumentPath8: fileData.parts[7],
                  supportingDocumentPath9: fileData.parts[8],
                  supportingDocumentPath10: fileData.parts[9],
                  supportingDocumentFileName: fileData.name,
                  createdDate: new Date(),
                  createdBy: accounts[0].username,
                  modifiedDate: new Date(),
                  modifiedBy: accounts[0].username,
                  supportingDocumentPathLength: fileData.size
                });
              }
              return acc;
            },
            [...TempfileInfo]
          );
          setSupportDocfilesInfo(updatedTempFileInfo);
        })
  
        .catch((error) => {
          console.error("Error reading files:", error);
        });
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  };

  //update supportDoc
  const updateSupportDocWarning = (fileName, warningMsg, fileExtension) => {
    SetSupportDocWarning((prevState) => ({
      ...prevState,
      [fileName]: {
        filename: fileName,
        isValid: false,
        warningMsg: warningMsg,
        fileExtnsion: fileExtension,
      },
    }));
  };

  const updateAttachReplyDocWarnings = (fileName, warningMsg, fileExtension) => {
    setAttachReplyDocWaning((prevState) => ({
      ...prevState,
      [fileName]: {
        filename: fileName,
        isValid: false,
        warningMsg: warningMsg,
        fileExtnsion: fileExtension,
      },
    }));
  };

  // attach reply doc control
  // const addAttchReplyDoc = () => {
  //   let warningmsg = "";
  //   // eslint-disable-next-line no-useless-escape
  //   const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
  //   const selectedFile = document.getElementById("attachReplyDoc").files;
  //   const TempfileInfo = attachReplyDocfilesInfo;
  //   const promises = [];
  //   const fileCount = selectedFile.length;
  //   for (let i = 0; i < fileCount; i++) {
  //     const fileToLoad = selectedFile[i];
  //     const fileExtession = fileToLoad.name.split(".");
  //     // Check for special characters in the filename
  //     if (validname.test(fileToLoad.name)) {
  //       warningmsg = "File name should not contain special characters";
  //       updateAttachReplyDocWarnings(
  //         fileToLoad.name,
  //         warningmsg,
  //         fileExtession[fileExtession.length - 1]
  //       );
  //     }

  //     // Check if the file type is allowed
  //     if (
  //       !(
  //         fileToLoad.name.endsWith(".docx") ||
  //         fileToLoad.name.endsWith(".doc") ||
  //         fileToLoad.name.endsWith(".pdf") ||

  //         fileToLoad.name.endsWith(".xlsx") ||
  //         fileToLoad.name.endsWith(".DOC") ||
  //         fileToLoad.name.endsWith(".DOCX") ||
  //         fileToLoad.name.endsWith(".PDF") ||

  //         fileToLoad.name.endsWith(".XLSX")
  //       )
  //     ) {
  //       warningmsg = "File type is not allowed";
  //       updateAttachReplyDocWarnings(
  //         fileToLoad.name,
  //         warningmsg,
  //         fileExtession[fileExtession.length - 1]
  //       );
  //     }

  //     // Check file size (5MB limit)
  //     /* 
  //       * Bug -396 fixed
  //       File size increse 5mb to 25MB 
  //       25 mb = 26214400
  //       10 mb = 10485760
  //       5MB =5242880 
  //     */
  //     if (fileToLoad.size > 5242880) {
  //       warningmsg = "File size should not exceed more than 5MB";
  //       updateAttachReplyDocWarnings(
  //         fileToLoad.name,
  //         warningmsg,
  //         fileExtession[fileExtession.length - 1]
  //       );
  //     }
  //     // File Reader.....
  //     const fileReader = new FileReader();
  //     const promise = new Promise((resolve) => {
  //       fileReader.onload = function (fileLoadedEvent) {
  //         const base64 = fileLoadedEvent.target.result.split(",")[1];
  //         const partLength = Math.ceil(base64.length / 10);
  //         const parts = [];
  //         for (let j = 0; j < 10; j++) {
  //           parts.push(base64.slice(j * partLength, (j + 1) * partLength));
  //         }

  //         resolve({
  //           name: fileToLoad.name,
  //           parts: parts,
  //           size: fileToLoad.size
  //         });
  //       }
  //     });

  //     fileReader.readAsDataURL(fileToLoad);
  //     promises.push(promise);
  //   }
  //   Promise.all(promises)
  //     .then((fileDataArray) => {
  //       const updatedTempFileInfo = fileDataArray.reduce(
  //         (acc, fileData) => {
  //           const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
  //           if (!ObjExist.includes(fileData.name)) {
  //             acc.push({
  //               // noteSupportingDocumentId: 0,
  //               // noteId: noteData.noteId,
  //               // supportingDocumentPath: fileData.base64.split(",")[1],
  //               replyDocumentPath1: fileData.parts[0],
  //               replyDocumentPath2: fileData.parts[1],
  //               replyDocumentPath3: fileData.parts[2],
  //               replyDocumentPath4: fileData.parts[3],
  //               replyDocumentPath5: fileData.parts[4],
  //               replyDocumentPath6: fileData.parts[5],
  //               replyDocumentPath7: fileData.parts[6],
  //               replyDocumentPath8: fileData.parts[7],
  //               replyDocumentPath9: fileData.parts[8],
  //               replyDocumentPath10: fileData.parts[9],
  //               supportingDocumentFileName: fileData.name,
  //               // createdDate: new Date(),
  //               // createdBy: accounts[0].username,
  //               // modifiedDate: new Date(),
  //               // modifiedBy: accounts[0].username,
  //             });
  //           }
  //           return acc;
  //         },
  //         [...TempfileInfo]
  //       );
  //       setattachReplyDocfilesInfo(updatedTempFileInfo);
  //       // console.log(updatedTempFileInfo, "updatedTempFileInfo")
  //     })
  //     .catch((error) => {
  //       console.error("Error reading files:", error);
  //     });
  // };
  const addAttchReplyDoc = () => {
    if(verifyPasscode === "true") {
      let warningmsg = "";
      const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
      const selectedFile = document.getElementById("attachReplyDoc").files;
      const TempfileInfo = attachReplyDocfilesInfo;
      const promises = [];
      const fileCount = selectedFile.length;
    
      for (let i = 0; i < fileCount; i++) {
        const fileToLoad = selectedFile[i];
        const fileExtession = fileToLoad.name.split(".");
        // Check for special characters in the filename
        if (validname.test(fileToLoad.name)) {
          warningmsg = "File name should not contain special characters";
          updateAttachReplyDocWarnings(
            fileToLoad.name,
            warningmsg,
            fileExtession[fileExtession.length - 1]
          );
        }
    
        // Check if the file type is allowed
        if (
          !(
            fileToLoad.name.endsWith(".docx") ||
            fileToLoad.name.endsWith(".doc") ||
            fileToLoad.name.endsWith(".pdf") ||
            fileToLoad.name.endsWith(".xlsx") ||
            fileToLoad.name.endsWith(".DOC") ||
            fileToLoad.name.endsWith(".DOCX") ||
            fileToLoad.name.endsWith(".PDF") ||
            fileToLoad.name.endsWith(".XLSX")
          )
        ) {
          warningmsg = "File type is not allowed";
          updateAttachReplyDocWarnings(
            fileToLoad.name,
            warningmsg,
            fileExtession[fileExtession.length - 1]
          );
        }
    
        // Check file size (25MB limit)
        if (fileToLoad.size > 26214400) { // 25MB = 26214400 bytes
          warningmsg = "File size should not exceed more than 25MB";
          updateAttachReplyDocWarnings(
            fileToLoad.name,
            warningmsg,
            fileExtession[fileExtession.length - 1]
          );
        }
    
        // File Reader.....
        const fileReader = new FileReader();
        const promise = new Promise((resolve) => {
          fileReader.onload = function (fileLoadedEvent) {
            const base64 = fileLoadedEvent.target.result.split(",")[1];
            const partLength = Math.ceil(base64.length / 10);
            const parts = [];
            for (let j = 0; j < 10; j++) {
              parts.push(base64.slice(j * partLength, (j + 1) * partLength));
            }
    
            resolve({
              name: fileToLoad.name,
              parts: parts,
              size: fileToLoad.size
            });
          }
        });
    
        fileReader.readAsDataURL(fileToLoad);
        promises.push(promise);
      }
    
      Promise.all(promises)
        .then((fileDataArray) => {
          const updatedTempFileInfo = fileDataArray.reduce(
            (acc, fileData) => {
              const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
              if (!ObjExist.includes(fileData.name)) {
                acc.push({
                  supportingDocumentPath1: fileData.parts[0] || '',
                  supportingDocumentPath2: fileData.parts[1] || '',
                  supportingDocumentPath3: fileData.parts[2] || '',
                  supportingDocumentPath4: fileData.parts[3] || '',
                  supportingDocumentPath5: fileData.parts[4] || '',
                  supportingDocumentPath6: fileData.parts[5] || '',
                  supportingDocumentPath7: fileData.parts[6] || '',
                  supportingDocumentPath8: fileData.parts[7] || '',
                  supportingDocumentPath9: fileData.parts[8] || '',
                  supportingDocumentPath10: fileData.parts[9] || '',
                  supportingDocumentFileName: fileData.name,
                });
              }
              return acc;
            },
            [...TempfileInfo]
          );
          setattachReplyDocfilesInfo(updatedTempFileInfo);
        })
        .catch((error) => {
          console.error("Error reading files:", error);
        });
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  };
  

  // checking file type and return file icon
  const getFileIcon = (filename) => {
    let fileType = fileIcon;
    if (filename.endsWith(".pdf")) {
      fileType = filePdfIcon;
    }
    if (filename.endsWith(".doc") || filename.endsWith(".docx")) {
      fileType = fileWordIcon;
    }
    if (
      filename.endsWith(".png") ||
      filename.endsWith(".jpg") ||
      filename.endsWith(".img") ||
      filename.endsWith(".svg")
    ) {
      fileType = fileImageIcon;
    }
    if (filename.endsWith(".txt")) {
      fileType = fileTxtIcon;
    }
    if (filename.endsWith(".xlsx")) {
      fileType = fileDataIcon;
    }
    return fileType;
  };

  // checking on specialCharPattern char inn file name
  /* const checkingSpecialCharPattern = (test) => {
    // eslint-disable-next-line no-useless-escape
    var specialCharPattern = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
    // Test the input string against the pattern
    return specialCharPattern.test(test);
  }; */

  // remove multiple attchemnts suppoutDoc
  // const onRemoveMultiAttachment = (id) => {
  //   const filename = supportDocfilesInfo.find((obj, index) => index === id).supportingDocumentFileName;
  //   delete supportDocWarning[filename];
  //   SetSupportDocWarning(supportDocWarning);

  //   setSupportDocfilesInfo(supportDocfilesInfo.filter((obj, ind) => ind !== id));
  // };
  const onRemoveMultiAttachment = (id) => {
    const filename = supportDocfilesInfo.find((obj, index) => index === id).supportingDocumentFileName;
    delete supportDocWarning[filename];
    SetSupportDocWarning(supportDocWarning);
    // let reamingFileSize = 26214400;
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (supportDocfilesInfo.length > 0) {
      const vaildMultiplefile = supportDocfilesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map((obj, index) => {
        if (index !== id) {
          totalFileSize = totalFileSize + obj.supportingDocumentPathLength
        }
      }
      );
    }

    // 11/06
    if (dakData?.dakSupportingDocumentsDTO?.length > 0) {
      dakData?.dakSupportingDocumentsDTO.map(obj => {
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      })
    }
    if (totalFileSize <= 26214400) {
      setSupportingError("");
    }

    setSupportDocfilesInfo(supportDocfilesInfo.filter((obj, ind) => ind !== id));
  };

  // remove attach reply doc 
  const onRemoveAttachReplyDoc = (id) => {
    const fileName = attachReplyDocfilesInfo.find((obj, index) => index === id).supportingDocumentFileName;

    delete attachReplyDocWarning[fileName]
    setAttachReplyDocWaning(attachReplyDocWarning);
    setattachReplyDocfilesInfo(attachReplyDocfilesInfo.filter((obj, ind) => ind !== id));
  };

  // on selecting  change approver -this combobox is availble in Requester 
  const handleChangeApproverCombo = (e) => {

    const { value } = e.target;
    if (selectedCurrentApprover) {

      if (value) {
        const isApprover = dakData?.daksApproversDTO?.some(obj => obj.approverEmail === value.userPrincipalName);
        const isExistRecipentsDTO = dakData?.recipientsDTO?.some(obj => obj.recipientsMail === value.userPrincipalName)
        if (isApprover ||
          value.userPrincipalName === dakData?.createdBy ||
          accounts[0].username === value.userPrincipalName
          || isExistRecipentsDTO
        ) {
          setDialogForRefereeAndChangeApprover(false)
          setUserNotifyInfo(
            "The selected user cannot be same as existing Reviewers/Approvers/Recipients/Requester."
            // "The selected approver cannont be same as existing Reviewers/Requester/CurrentActioner"
          );
          setUserComboValidationDialog(true);
          setChangeApprovercombovalue(null);
        }
        else {
          setChangeApprovercombovalue(value)
        }
      }

    } else {
      setDialogForRefereeAndChangeApprover(false)
      setErrorMessages(["Please select user"]);
      setValidationErrors(true);
      // setUserNotifyInfo(
      //   "Please selecte approver then onClick on  Submit"
      // );
      // setUserComboValidationDialog(true);
    }
  };

  // handel general comments text area value
  const handelGenralComments = (e) => {
    if(verifyPasscode === "true") {
      const { name, value } = e.target;
      if (name === "PageNo") {
        const trimmedValue = value.replace(/\s/g, '');
        if (trimmedValue.length <= 5) {
          SetGeneralCmtInfoObj({
            ...generalcmtInfoobj,
            [name]: trimmedValue,
          });
        }
        else {
          setUserNotifyInfo(
            "Cannot add more than 5 characters."
          );
          setUserComboValidationDialog(true);
        }
      }
      else {
        SetGeneralCmtInfoObj({
          ...generalcmtInfoobj,
          [name]: value,
        });
      }
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }

  };

  // on change handler for edit fields
  const handelGenralCommentsEdit = (e) => {
    const { name, value, id } = e.target;
    const editGrid = generalcmtforAllCmt.map((obj, index) => {
      if (index === Number(id) && name === "PageNo") {
        const trimmedValue = value.replace(/\s/g, '');
        if (trimmedValue.length <= 5) {
          return {
            ...obj,
            [name]: trimmedValue,
          };
        }
        else {
          setUserNotifyInfo(
            "Cannot add more than 5 characters."
          );
          setUserComboValidationDialog(true);
          return obj
        }

      }
      else if (index === Number(id) && name === "DocRef") {
        return {
          ...obj,
          [name]: value,
        };
      }
      else if (index === Number(id) && name === "Comments") {
        return {
          ...obj,
          [name]: value,
        };
      }
      else {
        return obj;
      }
    });
    SetGeneralcmtforAllCmt(editGrid);

  };

  // save edited comments
  const handleGeneraleditedcommentsSave = (ind) => {
    const cmtsObj = [];
    generalcmtforAllCmt.map((obj, index) => {
      if (index === ind) {
        cmtsObj.push({
          DocRef: obj.DocRef,
          Comments: obj.Comments,
          PageNo: obj.PageNo,
        })
      }
    })
    if (
      (cmtsObj[0]?.DocRef).trim() !== "" &&
      (cmtsObj[0]?.PageNo).trim() !== "" &&
      (cmtsObj[0]?.Comments).trim() !== ""
    ) {

      const editGrid = generalcmtforAllCmt.map((obj, index) => {
        if (index === ind) {
          return {
            ...obj,
            isEdit: false,
          };
        } else {
          return obj
        }
      });
      SetGeneralcmtforAllCmt(editGrid);
    } else {
      setUserNotifyInfo(
        "Please fill in all the fields and then click Add Comments."
      );
      setUserComboValidationDialog(true);
    }
  }

  // enable inputs onclick of edit
  const handelingEdit = (ind) => {
    const editGrid = generalcmtforAllCmt.map((obj, index) => {
      if (index === ind) {
        return {
          ...obj,
          isEdit: true,
        };
      } else {
        return {
          ...obj,
          isEdit: false,
        };
      }
    });
    SetGeneralcmtforAllCmt(editGrid);
  };

  // add commnents obj to array varible
  const handelAddCmts = (e) => {
    e.preventDefault();
    if (
     
      (generalcmtInfoobj.Comments).trim() !== ""
    ) {
      SetGeneralcmtforAllCmt((prevState) => [...prevState, generalcmtInfoobj]);
      SetGeneralCmtInfoObj({
        DocRef: "",
        Comments: "",
        PageNo: "",
        isEdit: false,
      });
    }
    else {
      setUserNotifyInfo(
        "Please fill in the Comments field and then click Add Comments."
      );
      setUserComboValidationDialog(true);
    }
  };

  // delete general cmt
  const handelDeleteCmt = (ind) => {
    SetGeneralcmtforAllCmt(
      generalcmtforAllCmt.filter((obj, index) => index !== ind)
    );
  };

  // date and time converion
  const getdatetimeconversion = (date) => {
    const convertedDate = new DateObject(new Date(date)).format("DD-MMM-YYYY hh:mm A") //seconds hand removed
    return convertedDate;
  };

  // date converion
  const getdateconversion = (date) => {
    const convertedDate = new DateObject(new Date(date)).format("DD-MMM-YYYY")
    return convertedDate;
  };

  // get all supporting sizes
  const getAllSupportingDocSize = () => {
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (supportDocfilesInfo.length > 0) {
      const vaildMultiplefile = supportDocfilesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );

    }
    if (dakData?.dakSupportingDocumentsDTO?.length > 0) {
      dakData?.dakSupportingDocumentsDTO.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    return totalFileSize

  }

  const handlePasscodeChange = (e) => {
    const { value } = e.target;
    // Regular expression to allow only alphanumeric characters
    const alphanumericRegex = /^[a-zA-Z0-9]*$/;

    if (alphanumericRegex.test(value)) {
      setPasscode(value);
    }
  };

  // Verifing the passcode
  const passcodeVerificationFunction = async () => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      // Replace with your own secret key
      const secretKey = "SHA256";

      // Compute HMAC-SHA256 hash of the passcode with the secret key
      const hashedPasscode = CryptoJS.SHA256(passcode, secretKey).toString(CryptoJS.enc.Hex);

      const params = {
        Passcode: hashedPasscode,
        UserMail: accounts[0].username
      };

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eDak_VerifyPasscode}`,
        {
          method: "POST",
          body: JSON.stringify(params),
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
        }
      );

      const data = await response.text();

      if (data === "Passcode verification successful") {
        console.log("testtst");
        setPasscodeVerification(false);
        if (actionBtn === "Approve") {
          setConfirmDailogObj({
            Confirmtext: "Are you sure you want to approve this request?",
            Description:
              "Please check the details filled along with attachment and click on Confirm button to approve request.",
          });
          toggleDailogForConfirmation();
        }
        if (actionBtn === "Reject") {
          setConfirmDailogObj({
            Confirmtext: "Are you sure you want to reject  this request?",
            Description:
              "Please check the details filled along with attachment and click on Confirm button to reject request.",
          });
          toggleDailogForConfirmation();
        }
        if (actionBtn === "ReturnEdak") {
          setConfirmDailogObj({
            Confirmtext: "Are you sure you want to Return this request?",
            Description:
              " ",
          });
          toggleDailogForConfirmation();
        }
        if (actionBtn === "Completed") {
          setConfirmDailogObj({
            Confirmtext: "Are you sure you want to mark this request as completed?",
            Description:
              "Please check the details filled along with attachment and click on Confirm button to complete request.",
          });
          toggleDailogForConfirmation();
        }
        if (actionBtn === "Return") {
          setConfirmDailogObj({
            Confirmtext: "Are you sure you want to return this request?",
            Description:
              "Please check the details filled along with attachment and click on Confirm button to return request.",
          });
          toggleDailogForConfirmation();
        }
        if (actionBtn === "Forward") {
          setConfirmDailogObj({
            Confirmtext: "Are you sure you want to Forward this request?",
            Description:
              "Please check the details and click on Forward button to Forward request.",
          });
          toggleDailogForConfirmation();
        }
        if (actionBtn === "CloseEdak") {
          setConfirmDailogObj({
            Confirmtext: "Are you sure you want to Close this request?",
            Description:
              "Please check the details filled along with attachment and click on Confirm button to Close e-dak.",
          });
          toggleDailogForConfirmation();
        }
        if (actionBtn === "ChangeApprover") {
          setDialogForRefereeAndChangeApprover(false);
          onSubmittingChangeApproverDetails(changeApprovercombovalue);
        }
      } else {
        setError('Incorrect passcode entered please try again.');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const VerifyUserPasscode = async () => {
    let userPasscodeExist = 'false';
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      // Call eNote_VerifyUserPasscode API first
      const userPasscodeResponse = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eNote_VerifyUserPasscode(accounts[0].username)}`,
        {
          method: "POST",
          // body: JSON.stringify({ UserMail: accounts[0].username}),
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
        }
      );

      const userData = await userPasscodeResponse.text();
      if (userData) {
        userPasscodeExist = userData;
        setVerifypasscode(userData);
      }
    } catch (err) {
      console.error(err);
      // Handle error state or throw it further
      throw err;
    }
    return userPasscodeExist;
  }

  const handlepasscodeClose = () => {
    setPasscodeVerification(false);
    setError(false);
  }

  const handleRedirectToPasscode = () => {
    setPasscodeNavigate("View");
    navigate('/edakpasscode'); // Adjust the path to your target route
  };

  //on Approver btn click
  const approvlfunction = async () => {
    if(verifyPasscode === "true") {
      let maxFileSize = 26214400;
    let totalFileSize = getAllSupportingDocSize();
    setIsReturnValidtion(false);
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    if (Object.keys(supportDocWarning).length > 0 || totalFileSize > maxFileSize) {
      setActionBtn("Approve");
      if (totalFileSize > maxFileSize) {
        setUserNotifyInfo("Cumulative size of all the supporting documents should not be exceeded 25 MB.")

      }
      else if (Object.keys(supportDocWarning).length > 0) {
        setUserNotifyInfo(
          "Please check and remove if there are any invalid files attached."
        );
      }
      setUserComboValidationDialog(true);

    } else
      // 07-May - Directions mandatory validation exclude if Recipient are not availble - Venkat
      // if ((directionsComments.trim() === "" && dakData?.recipientDetailsDTO[0]?.strDakActionType !== "Information") ||
      if ((directionsComments.trim() === "" && (dakData?.strMovementType !== "Outward" || dakData.recipientsDTO.length > 0)) || inValidFileNames?.length > 1) {
        const errorMSg = [];
        if (directionsComments.trim() === "") {
          errorMSg.push("Directions are mandatory");
        } if (inValidFileNames?.length > 1) {
          errorMSg.push("Invalid files are not allowed");
        }
        setActionBtn("Approve");
        setErrorMessages(errorMSg);
        setValidationErrors(true);
      } else {
        if (verifyPasscode === "true") {
          setActionBtn("Approve");
          setIsCmtDirectionVaild(false);
          setPasscode('');
          setPasscodeVerification(true);
        } else {
          setIsCmtDirectionVaild(false);
          setValidPasscode(true);
          setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
          setActionBtn("Approve");
        }

        // Commented for passcode functionality
        // setConfirmDailogObj({
        //   Confirmtext: "Are you sure you want to approve this request?",
        //   Description:
        //     "Please check the details filled along with attachment and click on Confirm button to approve request.",
        // });
        // toggleDailogForConfirmation();
      }
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
    
  };

  //  on reject  btn click
  const rejectfunctuin = async () => {
    if(verifyPasscode === "true") {
      let maxFileSize = 26214400;
      let totalFileSize = getAllSupportingDocSize();
      setIsCmtDirectionVaild(false);
      const inValidFileNames = Object.keys(supportDocWarning).filter(
        (fileName) => supportDocWarning[fileName]?.isValid === false
      );
      if (Object.keys(supportDocWarning).length > 0 || totalFileSize > maxFileSize) {
        setActionBtn("Reject");
        if (totalFileSize > maxFileSize) {
          setUserNotifyInfo("Cumulative size of all the supporting documents should not be exceeded 25 MB.")
          setActionBtn("Reject");
        }
        else if (Object.keys(supportDocWarning).length > 0) {
          setActionBtn("Reject");
          setUserNotifyInfo(
            "Please check and remove if there are any invalid files attached."
          );
        }
        setUserComboValidationDialog(true);
  
      } else {
        if (generalcmtforAllCmt?.length === 0 ||
          inValidFileNames?.length > 1) {
          setActionBtn("Reject");
          const errorMSg = [];
          if (generalcmtforAllCmt?.length === 0) {
            errorMSg.push("comments are mandatory")
          }
          if (inValidFileNames.length > 1) {
            errorMSg.push("Invalid files are not allowed")
          }
  
          setErrorMessages(errorMSg);
          setValidationErrors(true);
        }
        else {
          if (verifyPasscode === "true") {
            setActionBtn("Reject");
            setIsReturnValidtion(false);
            setPasscode('');
            setPasscodeVerification(true);
          } else {
            setIsReturnValidtion(false);
            setValidPasscode(true);
            setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
            setActionBtn("Reject");
          }
  
          // Commented for passcode functionality
          // setConfirmDailogObj({
          //   Confirmtext: "Are you sure you want to reject  this request?",
          //   Description:
          //     "Please check the details filled along with attachment and click on Confirm button to reject request.",
          // });
  
          // toggleDailogForConfirmation();
        }
      }
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  
  };

  //  on return  btn click
  const returnfunction = async () => {
    if(verifyPasscode === "true") {
      let maxFileSize = 26214400;
    let totalFileSize = getAllSupportingDocSize();
    setIsCmtDirectionVaild(false);
    // if comments are empty disply popup
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    if (Object.keys(supportDocWarning).length > 0 || totalFileSize > maxFileSize) {
      setActionBtn("Approve");
      if (totalFileSize > maxFileSize) {
        setUserNotifyInfo("Cumulative size of all the supporting documents should not be exceeded 25 MB.")

      }
      else if (Object.keys(supportDocWarning).length > 0) {
        setUserNotifyInfo(
          "Please check and remove if there are any invalid files attached."
        );
      }
      setUserComboValidationDialog(true);

    } else
      if (generalcmtforAllCmt?.length === 0 || inValidFileNames.length > 1) {
        const errorMSg = [];
        if (generalcmtforAllCmt?.length === 0) {
          errorMSg.push("Comments are mandatory");

        }
        if (inValidFileNames.length > 1) {
          errorMSg.push("Invalid files are not allowed");
        }

        setErrorMessages(errorMSg);
        setValidationErrors(true);
        setActionBtn("Return");

      }
      else {
        if (verifyPasscode === "true") {
          setIsReturnValidtion(false);
          setActionBtn("Return");
          setPasscode('');
          setPasscodeVerification(true);
        } else {
          setIsReturnValidtion(false);
          setValidPasscode(true);
          setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
          setActionBtn("Return");
        }

        // Commented for passcode functionality
        // setConfirmDailogObj({
        //   Confirmtext: "Are you sure you want to return this request?",
        //   Description:
        //     "Please check the details filled along with attachment and click on Confirm button to return request.",
        // });
        // toggleDailogForConfirmation();
      }
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
   
  };

  // on Close e-darh btn click
  const onClickCloseEdak = async () => {
    if(verifyPasscode === "true") {
      if (dakData?.strMovementType === "Outward" && (closedDate === null || sentDate === null)) {
        const errorMSg = [];
        if (closedDate === null) {
          errorMSg.push("Close Date");
  
        }
        else {
          setIsCloseDateVaild(false);
        }
        if (sentDate === null) {
          errorMSg.push("Sent Date");
          setIsSentDateVaild(false);
  
        }
        setErrorMessages(errorMSg);
        setValidationErrors(true);
        setActionBtn("CloseEdak");
  
      } else if (closedDate === null) {
        const errorMSg = [];
        // if (closedDate === null) {
        errorMSg.push("Close Date");
        setIsCloseDateVaild(false);
        setErrorMessages(errorMSg);
        setValidationErrors(true);
        setActionBtn("CloseEdak");
        // }
  
      }
      else {
        if (verifyPasscode === "true") {
          setIsCloseDateVaild(false);
          setIsSentDateVaild(false);
          setActionBtn("CloseEdak");
          setPasscode('');
          setPasscodeVerification(true);
        } else {
          setIsCloseDateVaild(false);
          setIsSentDateVaild(false);
          setValidPasscode(true);
          setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
          setActionBtn("CloseEdak");
        }
  
        // Commented for passcode functionality
        // setConfirmDailogObj({
        //   Confirmtext: "Are you sure you want to Close this request?",
        //   Description:
        //     "Please check the details filled along with attachment and click on Confirm button to Close e-dak.",
        // });
        // toggleDailogForConfirmation();
      }
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  }

  // on 	Return e-Dak  btn click
  const onclickReturnEdak = async () => {
    if (verifyPasscode === "true") {
      setActionBtn("ReturnEdak");
      setPasscode('');
      setPasscodeVerification(true);
    } else {
      setValidPasscode(true);
      setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
      setActionBtn("ReturnEdak");
    }

    // Commented for passcode functionality
    // setConfirmDailogObj({
    //   Confirmtext: "Are you sure you want to Return this request?",
    //   Description:
    //     " ",
    // });
    // toggleDailogForConfirmation()
  }

  // on Completed
  const onClickComplete = async () => {
    if(verifyPasscode === "true") {
      const inValidFileNames = Object.keys(attachReplyDocWarning).filter(
        (fileName) => attachReplyDocWarning[fileName]?.isValid === false
      );
  
      console.log(inValidFileNames, "inValidFileNames")
  
      if (completionDate === null || recipientsComments.trim() === "" || inValidFileNames.length > 1) {
        const errorMSg = [];
        if (recipientsComments.trim() === "") {
          errorMSg.push("Recipients  Comments");
        }
        else {
          setIsVaildRecipientsComments(false);
        }
        if (completionDate === null) {
          errorMSg.push("Completion Date");
        }
        else {
          setIsVaildCompliationDate(false);
        }
        if (inValidFileNames.length > 1) {
          errorMSg.push("Invalid files are not allowed");
        }
        setActionBtn("Completed");
        setDialogForRefereeAndChangeApprover(false);
        setErrorMessages(errorMSg);
        setValidationErrors(true);
  
      }
      else {
        if (verifyPasscode === "true") {
          setIsVaildRecipientsComments(false);
          setIsVaildCompliationDate(false);
          setActionBtn("Completed");
          setPasscode('');
          setPasscodeVerification(true);
        } else {
          setIsVaildRecipientsComments(false);
          setIsVaildCompliationDate(false);
          setValidPasscode(true);
          setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
          setActionBtn("Completed");
        }
  
        // Commented for passcode functionality
        // setConfirmDailogObj({
        //   Confirmtext: "Are you sure you want to mark this request as completed?",
        //   Description:
        //     "Please check the details filled along with attachment and click on Confirm button to complete request.",
        // });
        // toggleDailogForConfirmation();
      }
  
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  
  }
  // on Completed
  const onClickForward = async () => {
    if (!forwardUser) {
      setDialogForRefereeAndChangeApprover(false);
      const errorMSg = [];
      errorMSg.push("Forward User")
      setErrorMessages(errorMSg);
      setValidationErrors(true);
      setActionBtn("Forward");
      /* setUserNotifyInfo(
        "Please select forward user than click on Forward."
      );
      setUserComboValidationDialog(true); */

    } else {
      if (verifyPasscode === "true") {
        setActionBtn("Forward");
        setPasscode('');
        setPasscodeVerification(true);
      } else {
        setValidPasscode(true);
        setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
        setActionBtn("Forward");
      }

      // Commented for passcode functionality
      // setConfirmDailogObj({
      //   Confirmtext: "Are you sure you want to Forward this request?",
      //   Description:
      //     "Please check the details and click on Forward button to Forward request.",
      // });
      // toggleDailogForConfirmation();
    }
  }

  //  on  changeApprover btn click
  const onClickChangeApprover = async () => {
    const approversInfo = [];
    dakData?.daksApproversDTO?.filter(obj => {
      if (obj.edakApproverStatus === 2 ||
        obj.edakApproverStatus === 1) {
        approversInfo.push({
          edakApproverId: obj.edakApproverId,
          approverEmail: obj.approverEmail,
          approverEmailName: obj.approverEmailName
        })
      }
    });

    dakData?.recipientsDTO?.filter(obj => {
      // bug -343 08/07
      if (obj.recipientStatus !== 4) {
        approversInfo.push({
          edakApproverId: obj.recipientId,
          approverEmail: obj.recipientsMail,
          approverEmailName: obj.recipientsMailName
        })
      }
    });
    setApproverDetailsDTO(approversInfo);
    setActionBtn("ChangeApprover");
    setDialogForRefereeAndChangeApprover(true);
  };

  //on click of confirmation btn it will call the api based on current  action.
  const onCofiormation = async () => {
    let findApproverStatus;
    let recipientStatus;

    switch (actionBtn) {
      case "Approve":
        // findApproverStatus = enumObj?.ApproverStatus?.find(obj => obj.dValue === "Approved").id
        findApproverStatus = 3
        approverStatusChangeAPI(findApproverStatus);
        // call approve funtion
        break;

      case "Reject":
        // call Reject function
        // findApproverStatus = enumObj?.ApproverStatus?.find(obj => obj.dValue === "Rejected").id
        findApproverStatus = 4;
        approverStatusChangeAPI(findApproverStatus);
        break;
      case "Return":
        // call Return function
        // findApproverStatus = enumObj?.ApproverStatus?.find(obj => obj.dValue === "Returned").id
        findApproverStatus = 5;
        approverStatusChangeAPI(findApproverStatus);
        break;
      case "CloseEdak":
        eDak_closed();
        // call close dakk function
        break;
      case "ReturnEdak":
        eDak_ReturnForRequestor();
        break;
      case "Completed":
        recipientStatus = 4;
        eDak_ChangeRecipientStaus(recipientStatus);
        break;
      case "Forward":
        recipientStatus = 3
        eDak_ChangeRecipientStaus(recipientStatus);
        break;
      default:
        // call the approve funcion
        break;
    }
    setdialogOpen(false);
  };

  // Approval checking if current actioner is approver or reviewer  and is  login user  approval btns will display
  const approverChecking = () => {
    let isCurrentActioner = false;

    if (dakData && dakData?.daksApproversDTO && dakData.daksApproversDTO.length === 1) {

      if (dakData?.status === 2 &&
        dakData.daksApproversDTO.some(obj =>
          obj.approverEmail === accounts[0].username &&
          (obj.edakApproverStatus === 2 || obj.edakApproverStatus === 1)
        )
      ) {
        isCurrentActioner = true;
      }
    } else {
      const prvsApprovers = dakData?.daksApproversDTO?.filter(obj => !obj.isFinalApprover);
      const isprvsApproversActionCompletd = prvsApprovers?.every(obj => obj.edakApproverStatus === 3);
      // console.log(isNotfinalApprover,"isNotfinalApprover")
      if (dakData?.status === 2 &&
        dakData?.daksApproversDTO.some(obj =>
          obj.approverEmail === accounts[0].username &&
          (obj.edakApproverStatus === 2 || obj.edakApproverStatus === 1) && !obj.isFinalApprover
        )
      ) {
        isCurrentActioner = true;
      } else if (dakData?.status === 2 &&
        isprvsApproversActionCompletd &&
        dakData?.daksApproversDTO.some(obj =>
          obj.approverEmail === accounts[0].username &&
          (obj.edakApproverStatus === 2 || obj.edakApproverStatus === 1) && obj.isFinalApprover
        )
      ) {
        isCurrentActioner = true;
      }
    }
    return isCurrentActioner;
  };

  const recepientChecking = () => {
    let isCurrentActioner = false;
    if (dakData?.recipientsDTO && dakData?.recipientDetailsDTO?.length > 0 && dakData?.recipientDetailsDTO) {

      if (
        (dakData?.status === 2 ||
          dakData?.status === 4) &&
        dakData !== null &&
        dakData?.recipientDetailsDTO[0]?.strDakActionType !== "Information" &&
        dakData?.daksApproversDTO?.every((obj) =>
          (obj.edakApproverStatus === 3) &&
          dakData?.recipientsDTO?.some(obj =>
            obj.recipientsMail === accounts[0].username &&
            obj.recipientStatus !== 4)
        )
      ) {
        isCurrentActioner = true;
      }
    }
    return isCurrentActioner;
  }

  // checking if all the approvals are competed or not
  const closeBtnCondtion = () => {
    let isVisiable = false;
    // if (dakData?.recipientDetailsDTO[0]?.strDakActionType === "Information" &&
    //   dakData?.status === 6 &&
    //   dakData?.createdBy === accounts[0].username) {
    //   isVisiable = true
    // }
    // else {
    if (dakData?.recipientsDTO?.length > 0 && dakData?.recipientDetailsDTO[0]?.strDakActionType !== "Information") {
      if (dakData?.status === 6 &&
        dakData?.recipientsDTO?.every(obj => obj.recipientStatus === 4 &&
          dakData?.createdBy === accounts[0].username)) {
        isVisiable = true
      }
    }
    else if (dakData?.status === 4 &&
      dakData?.daksApproversDTO?.every(obj => obj.edakApproverStatus === 3)
      && dakData?.createdBy === accounts[0].username
    ) {
      isVisiable = true
    }
    return isVisiable
  }

  //search selected user
  const onFillterALLUser = async (event) => {
    if (event.filter.value.length >= 4) {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            return { department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName }
          });
          setOrgEmployees(orgUsers);
        })
        .catch((err) => {
          setOrgEmployees([]);
          console.log(err);
        });
    }
    else {
      setOrgEmployees([]);
    }
  };


  // Success dialog toggle
  const SuccessDialogToggle = () => {
    setDialogSuccess(!dialogSuccess);
  };
  // Failure dialog toggle
  const faildDialogToggle = () => {
    setDialogFailure(true);
  };

  // confirmation dialog toggle
  const toggleDailogForConfirmation = () => {
    setdialogOpen(!dialogOpen);
  };

  // close the callback success dialog
  const handleCloseDialog = () => {
    setChangeApproverVisible(false);
    setTab("My Pending for Action")
    navigate(redirect);
  };

  const handleClosevalidationDialog = () => {
    if (actionBtn === "Approve") {
      if (directionsComments.trim() === "") {
        setIsCmtDirectionVaild(true);
      }
    }
    if (actionBtn === "CloseEdak") {
      if (closedDate === null) {
        setIsCloseDateVaild(true)
      }
      if (sentDate === null) {
        setIsSentDateVaild(true)
      }
    }
    if (actionBtn === "Completed") {
      if (recipientsComments.trim() === "") {
        setIsVaildRecipientsComments(true);
      }
      if (completionDate === null) {
        setIsVaildCompliationDate(true);

      }
    }
    if (actionBtn === "Return" || actionBtn === "Reject") { //if comments are empty open General Comments section
      // setExpanded("Comments Section");
      if (generalcmtforAllCmt?.length === 0) {
        setIsReturnValidtion(true);
      } else {
        setIsReturnValidtion(false);
      }

    }

    if (actionBtn === "ChangeApprover") {
      // After getting changeApprover  warning  again it will open changeApprover dialog box 
      setDialogForRefereeAndChangeApprover(true);
      setActionBtn("ChangeApprover");
    }
    if (actionBtn === "Forward") {
      setDialogForRefereeAndChangeApprover(true);
      setActionBtn("Forward");
    }
    setValidationErrors(false);
    setErrorMessages([]);

  }

  // oncloseUseNotify close
  const oncloseUseNotify = () => {
    // bug -348  06/05
    /* if (actionBtn === "Return" || actionBtn === "Reject") { //if comments are empty open General Comments section
        // setExpanded("Comments Section");
        setIsReturnValidtion(true);
    } */
    //  else
    if (actionBtn === "ChangeApprover") {
      // After getting changeApprover  warning  again it will open changeApprover dialog box 
      setDialogForRefereeAndChangeApprover(true);
      setActionBtn("ChangeApprover");
    }
    if (actionBtn === "Forward") {
      setDialogForRefereeAndChangeApprover(true);
      setActionBtn("Forward");
    }
    setUserComboValidationDialog(false);
  }

  // redirectHomePage  -on click of OK btn in success dialog it will direct to home page 
  const redirectHomePage = () => {
    setTab("My Pending for Action")
    navigate(redirect);
    setDialogSuccess(false);
  };

  // Based on approver status rendering diff icons
  const renderApproverIcon = (approverStatus) => {
    let icon = "k-i-clock";
    if (approverStatus === 1) {
      // icon="k-i-rotate-circle"
      icon = "k-i-rotate"
    }
    if (approverStatus === 2) {
      icon = "k-i-clock"
    }
    if (approverStatus === 3) {
      icon = "k-i-check-circle"
    }
    if (approverStatus === 4) {
      icon = "k-i-close-outline k-i-x-outline"
    }
    if (approverStatus === 5) {
      icon = "k-i-undo"
    }
    if (approverStatus === 6) {
      icon = "k-i-arrow-root"

    }

    return icon
  }
  // Based on recipent status rendering diff icons
  const renderRecipentrIcon = (approverStatus) => {
    let icon = "k-i-clock";
    if (approverStatus === 1) {
      // icon="k-i-rotate-circle"
      icon = "k-i-rotate"
    }
    if (approverStatus === 2) {
      icon = "k-i-clock"
    }
    if (approverStatus === 3) {
      icon = "k-i-undo"

    }
    if (approverStatus === 4) {
      icon = "k-i-check-circle"
      // icon = "k-i-close-outline k-i-x-outline"
    }
    /*  if (approverStatus === 5) {
       icon = "k-i-undo"
     }
     if (approverStatus === 6) {
       icon = "k-i-arrow-root"
 
     } */

    return icon
  }

  // Rendering custom Title and Icon for changeApprover/Refer/common dialog box
  const CustomTitleBar = () => {
    return (
      <div
        className="custom-title"
        style={{
          fontSize: "16px",
          lineHeight: "1.3em",
        }}
      >
        <SvgIcon icon={infoCircleIcon} />{" "}
        {actionBtn === "Forawrd" ? "Forward" : actionBtn === "ChangeApprover" ? "Change Approver" : "Alert!"}
      </div>
    );
  };

  //Rendering custom Title and Icon for success dialog
  const CustomSuccussTitleBar = () => {
    return (
      <div
        className="custom-title"
        style={{
          fontSize: "16px",
          lineHeight: "1.3em",
        }}
      >
        <SvgIcon icon={infoCircleIcon} /> Alert!
      </div>
    );
  };

  // Rendering custom Title and Icon for Confirmation dialog.
  const CustomConfirmationTitleBar = () => {
    return (
      <div className="custom-title ">
        <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span> Confirmation
      </div>
    );
  };

  // Submit changeApprover info
  const onSubmitforChangeApproverInfo = async () => {
    if (verifyPasscode === "true") {
      setPasscodeVerification(true);
      setPasscode('');
    } else {
      setDialogForRefereeAndChangeApprover(false);
      setValidPasscode(true);
      setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
    }
  }

  const approverStatusChangeAPI = async (edakApproverStatus) => {
    setdialogOpen(false);
    setDialogForRefereeAndChangeApprover(false);
    SetIsLoading(true);
    let maxFileSize = 26214400;
    let totalFileSize = 0;
    const currentApproverObj = dakData?.daksApproversDTO?.find(obj => obj.approverEmail === accounts[0].username);
    //get invaild file name 
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only 
    const vaildMultiplefile = supportDocfilesInfo.filter(obj => {
      if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
        return obj;
      }
    });
    vaildMultiplefile.map(obj =>
      totalFileSize = totalFileSize + obj.supportingDocumentPathLength
    );
    let fileupdated = vaildMultiplefile?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });
    supportDocfilesInfo.filter(obj => {
      if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
        vaildMultiplefile.push({
          dakId: dakData?.daKId,
          supportingDocumentPath: fileupdated,//vaildMultiplefile,
          supportingDocumentFileName: obj.supportingDocumentFileName,
          createdBy: accounts[0].username,
          modifiedBy: accounts[0].username
        })
        // return {supportingDocumentPath:obj.supportingDocumentPath,createdBy:accounts[0].username,modifiedBy:accounts[0].username};
      }
    });
    const approverComments = [];
    if (generalcmtforAllCmt.length > 0) {
      generalcmtforAllCmt?.forEach(obj => {
        approverComments.push({
          edakApproverId: currentApproverObj.edakApproverId,
          comments: obj.Comments,
          commentsBy: accounts[0].username,
          createdBy: accounts[0].username,
          modifiedBy: accounts[0].username,
          PageNumber: obj.PageNo,
          DocReferrence: obj.DocRef
        });
      });
    }

    const params = {
      // "daKId": dakData?.dakId,
      "daKId": id.id,
      "edakApproverId": currentApproverObj.edakApproverId,
      "approverType": currentApproverObj?.edakApproverType,
      "approverEmail": accounts[0].username,
      "approverOrder": currentApproverObj?.approverOrder,
      "edakApproverStatus": edakApproverStatus,
      "createdBy": accounts[0].username,
      "modifiedBy": accounts[0].username,
      "directionsDTO": directionsComments ? [
        {
          "daKId": dakData?.dakId,
          "comments": directionsComments,
          "commentsBy": accounts[0].username,
          "createdBy": accounts[0].username,
          "modifiedBy": accounts[0].username
        }
      ] : [],
      "edakSupportingDocumentsDTO": fileupdated,

      "edakCommentsDTO": approverComments
    }

    // console.log(JSON.stringify(params), "params");
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eDak_dakApproverStatusChange}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
      }
    )
      .then(async (data) => {
        const rep = await data.json();
        SetIsLoading(false);
        if (rep.statusMessage === "Failed") {
          SetIsLoading(false);
          setDialogFailure(true);
          //   SetSuccessMsg("Something went wrong please try again.");
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          if (actionBtn === "Approve") {
            SetSuccessMsg(
              "The eDak has been approved successfully."
            );
            SuccessDialogToggle();
          }
          if (actionBtn === "Reject") {
            SetSuccessMsg(
              "The eDak has been rejected successfully."
            );
            SuccessDialogToggle();
          }

          if (actionBtn === "Return") {
            SetSuccessMsg(
              "The eDak has been returned successfully."
            );
            SuccessDialogToggle();
          }
        }
      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  }

  // forWard/complete api call with reply document attachment
  // const eDak_ChangeRecipientStaus = async (recipientStatus) => {
  //   setdialogOpen(false);
  //   setDialogForRefereeAndChangeApprover(false);
  //   SetIsLoading(true);
  //   // current recipent obj
  //   const crntRecipentObj = dakData?.recipientsDTO?.find(obj => obj.recipientsMail === accounts[0].username)
  //   const inValidFileNames = Object.keys(attachReplyDocWarning).filter(
  //     (fileName) => attachReplyDocWarning[fileName]?.isValid === false
  //   );
  //   // filter valid files only 
  //   const vaildMultiplefile = []
  //   attachReplyDocfilesInfo.filter(obj => {
  //     if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
  //       vaildMultiplefile.push({
  //         recipientDetailsId: crntRecipentObj?.recipientDetailsId,
  //         ReplyDocumentPath: obj.supportingDocumentPath,
  //         ReplyDocumentFileName: obj.supportingDocumentFileName,
  //         createdBy: accounts[0].username,
  //         modifiedBy: accounts[0].username,
  //       })
  //     }
  //   });

  //   const params =
  //   {
  //     "dakId": id.id,
  //     "recipientDetailsId": crntRecipentObj?.recipientDetailsId,
  //     "recipientMailId": crntRecipentObj?.recipientsMail,
  //     "forwardedTo": forwardUser ? forwardUser.userPrincipalName : null,
  //     "recipientComment": recipientsComments,
  //     "completionDate": completionDate ? completionDate : null,
  //     "createdBy": accounts[0].username,
  //     "recipientStatus": recipientStatus,
  //     "dakReplyDocumentDTO": fileupdated,
  //     // "DepartmentName":
  //   }

  //   const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

  //   await fetch(
  //     `${API_BASE_URL}${API_ENDPOINTS.eDak_ChangeRecipientStaus}`,
  //     {
  //       method: "POST",
  //       headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
  //       body: JSON.stringify(params),
  //     }
  //   )
  //     .then(async (data) => {
  //       const rep = await data.json();
  //       SetIsLoading(false);
  //       if (rep.statusMessage === "Failed") {
  //         SetIsLoading(false);
  //         setDialogFailure(true);
  //         //   SetSuccessMsg("Something went wrong please try again.");
  //         faildDialogToggle();
  //       } else {
  //         SetIsLoading(false);
  //         if (actionBtn === "Completed") {
  //           SetSuccessMsg(
  //             "The eDak has been Completed successfully."
  //           );
  //           SuccessDialogToggle();
  //         }
  //         if (actionBtn === "Forward") {
  //           SetSuccessMsg(
  //             "The eDak has been forwarded suceesfully."
  //           );
  //           SuccessDialogToggle();
  //         }

  //       }
  //     })
  //     .catch((err) => {
  //       SetIsLoading(false);
  //       faildDialogToggle();
  //       console.log(err);
  //     });
  // }

  const eDak_ChangeRecipientStaus = async (recipientStatus) => {
    setdialogOpen(false);
    setDialogForRefereeAndChangeApprover(false);
    SetIsLoading(true);
  
    // Current recipient object
    const crntRecipentObj = dakData?.recipientsDTO?.find(obj => obj.recipientsMail === accounts[0].username);
  
    // Get invalid file names
    const inValidFileNames = Object.keys(attachReplyDocWarning).filter(
      (fileName) => attachReplyDocWarning[fileName]?.isValid === false
    );
  
    // Filter valid files and include reply document paths
    const vaildMultiplefile = attachReplyDocfilesInfo.filter(obj => {
      if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
        return {
          recipientDetailsId: crntRecipentObj?.recipientDetailsId,
          replyDocumentPath1: obj.supportingDocumentPath1 || '',
          replyDocumentPath2: obj.supportingDocumentPath2 || '',
          replyDocumentPath3: obj.supportingDocumentPath3 || '',
          replyDocumentPath4: obj.supportingDocumentPath4 || '',
          replyDocumentPath5: obj.supportingDocumentPath5 || '',
          replyDocumentPath6: obj.supportingDocumentPath6 || '',
          replyDocumentPath7: obj.supportingDocumentPath7 || '',
          replyDocumentPath8: obj.supportingDocumentPath8 || '',
          replyDocumentPath9: obj.supportingDocumentPath9 || '',
          replyDocumentPath10: obj.supportingDocumentPath10 || '',
          ReplyDocumentFileName: obj.supportingDocumentFileName,
          createdBy: accounts[0].username,
          modifiedBy: accounts[0].username,
        };
      }
      return null;
    }).filter(obj => obj !== null); // Remove null entries
  
    // Update fileupdated with detailed document paths
    const fileupdated = vaildMultiplefile.map(item => ({
      recipientDetailsId: item.recipientDetailsId,
      replyDocumentPath1: item.supportingDocumentPath1,
      replyDocumentPath2: item.supportingDocumentPath2,
      replyDocumentPath3: item.supportingDocumentPath3,
      replyDocumentPath4: item.supportingDocumentPath4,
      replyDocumentPath5: item.supportingDocumentPath5,
      replyDocumentPath6: item.supportingDocumentPath6,
      replyDocumentPath7: item.supportingDocumentPath7,
      replyDocumentPath8: item.supportingDocumentPath8,
      replyDocumentPath9: item.supportingDocumentPath9,
      replyDocumentPath10: item.supportingDocumentPath10,
      ReplyDocumentFileName: item.supportingDocumentFileName,
      createdBy: item.createdBy,
      modifiedBy: item.modifiedBy,
    }));
  
    // Parameters for API call
    const params = {
      "dakId": id.id,
      "recipientDetailsId": crntRecipentObj?.recipientDetailsId,
      "recipientMailId": crntRecipentObj?.recipientsMail,
      "forwardedTo": forwardUser ? forwardUser.userPrincipalName : null,
      "recipientComment": recipientsComments,
      "completionDate": completionDate ? completionDate : null,
      "createdBy": accounts[0].username,
      "recipientStatus": recipientStatus,
      "dakReplyDocumentDTO": fileupdated,
    };
  
    // Fetch access token
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
  
    // API call
    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eDak_ChangeRecipientStaus}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
      }
    )
      .then(async (data) => {
        const rep = await data.json();
        SetIsLoading(false);
        if (rep.statusMessage === "Failed") {
          setDialogFailure(true);
          faildDialogToggle();
        } else {
          if (actionBtn === "Completed") {
            SetSuccessMsg("The eDak has been Completed successfully.");
            SuccessDialogToggle();
          }
          if (actionBtn === "Forward") {
            SetSuccessMsg("The eDak has been forwarded successfully.");
            SuccessDialogToggle();
          }
        }
      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  };
  

  //Adding /updating Change Approver details 
  const onSubmittingChangeApproverDetails = async (value) => {
    if (value) {
      const isApprover = dakData?.daksApproversDTO?.some(obj => obj.approverEmailName === selectedCurrentApprover);
      const isRecipient = dakData?.recipientsDTO?.some(obj => obj.recipientsMailName === selectedCurrentApprover);
      let params = {
        dakId: id.id,
        newApproverEmail: isApprover ? changeApprovercombovalue.userPrincipalName : null,
        EDakApproverId: isApprover ? approverDetailsDTO?.find(obj => obj.approverEmailName === selectedCurrentApprover).edakApproverId : 0,
        approverEmail: isApprover ? approverDetailsDTO?.find(obj => obj.approverEmailName === selectedCurrentApprover).approverEmail : null,
        NewRecipientsMail: isRecipient ? changeApprovercombovalue.userPrincipalName : null,
        RecipientId: isRecipient ? approverDetailsDTO?.find(obj => obj.approverEmailName === selectedCurrentApprover).edakApproverId : 0,
        RecipientsMail: isRecipient ? approverDetailsDTO?.find(obj => obj.approverEmailName === selectedCurrentApprover).approverEmail : null,

        createdBy: accounts[0].username

      }

      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      // Make API call
      await fetch(`${API_BASE_URL}${API_ENDPOINTS.eDak_ChangeApprover}`, {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
      })
        .then(async (data) => {
          const res = await data.json();
          if (res.statusMessage === "Failed") {
            SetIsLoading(false);
            SetSuccessMsg("Something went wrong please try again.");
            faildDialogToggle();
          } else {
            SetIsLoading(false);
            setActionBtn("ChangeApprover");

            // Commented for passcode functionality
            setChangeApproverVisible(true)
            setDialogForRefereeAndChangeApprover(false);
          }
        })
        .catch((err) => {
          console.log(err);
          SetIsLoading(false);
          faildDialogToggle();
          // Handle errors if needed
        });
    }
    else {
      setDialogForRefereeAndChangeApprover(false);
      setUserNotifyInfo(
        "Please fill up all the mandatory fields."
      );
      setUserComboValidationDialog(true);
    }
  };

  // Handle Recipients action type
  const handleActionType = React.useCallback(
    (e) => {
      let isopen = false
      if (e.value === "Forward") {
        isopen = true
        isOpenForwardDialogbox(isopen)
        // setDialogForRefereeAndChangeApprover(true)
      }
      setRecipientsActionType(e.value);
    },
    [recipientsActionType]
  );
  const isOpenForwardDialogbox = (open) => {
    setDialogForRefereeAndChangeApprover(true)

  }

  //  Handle Recipients completionDate
  const onSelectedCompletionDate = (event) => {
    if(verifyPasscode === "true") {
      const selectedDate = new Date(event.target.value);
      const utcDate = new Date(Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()));
      // setSelectedReceivedDate(utcDate);
      setCompletionDate(utcDate);
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
   
  }

  //Handle Recipients comments
  const handlerecipientsComments = (event) => {
    if(verifyPasscode === "true") {
      setrecipientsComments(event.target.value);
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
    
  }

  //Handle Selected forward user
  const onSelectedForwardUser = (event) => {
    if (event.value) {
      const isuserExitApproverinfo = dakData?.daksApproversDTO?.some(obj => obj.approverEmail === event.value.userPrincipalName);
      const isExistRecipentsDTO = dakData?.recipientsDTO?.some(obj => obj.recipientsMail === event.value.userPrincipalName);
      if (isuserExitApproverinfo || isExistRecipentsDTO ||
        dakData?.createdBy === event.value.userPrincipalName
        || accounts[0].username === event.value.userPrincipalName) {
        setDialogForRefereeAndChangeApprover(false);
        setActionBtn("Forward");
        setUserNotifyInfo(
          "The selected forward user cannot be same as existing Reviewers/Approvers/Recipients/Requester."
        );
        setUserComboValidationDialog(true);
      }
      else {
        setForwardUser(event.value)
      }

    }
  }

  // Handle Directions comments
  const handleDirectionsComments = (event) => {
    if(verifyPasscode === "true") {
      setIsCmtDirectionVaild(false);
      setDirectionsComments(event.target.value);
    } else {
      setValidPasscode(true);
       // Changed the content --> Kavya (29-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  }

  // closed API 
  const eDak_closed = async () => {
    setdialogOpen(false);
    setDialogForRefereeAndChangeApprover(false);
    SetIsLoading(true);
    const params = {

      createdBy: accounts[0].username,
      closeDate: closedDate ? closedDate : null,
      sentDate: sentDate ? sentDate : null,
      // status: enumObj?.status?.find(obj => obj.dValue === "Closed").id,
      status: 7,
      dakId: id.id


    }
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eDak_ClosedEdak}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
      }
    )
      .then(async (data) => {
        const rep = await data.json();
        SetIsLoading(false);
        if (rep.status === 400) {
          SetIsLoading(false);
          setDialogFailure(true);
          //   SetSuccessMsg("Something went wrong please try again.");
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          SetSuccessMsg(
            "The eDak has been closed successfully."
          );
          SuccessDialogToggle();
        }
      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  }
  const eDak_ReturnForRequestor = async () => {
    setdialogOpen(false);
    setDialogForRefereeAndChangeApprover(false);
    SetIsLoading(true);
    const params = {
      "dakId": id.id,
      "category": dakData?.category,
      "subject": dakData?.subject,
      "departmentId": dakData?.departmentId,
      "requester": dakData?.requester,
      "sourceType": dakData?.sourceType,
      "movementType": dakData?.movementType,
      "requestDate": dakData?.requestDate,
      "status": 2,
      "documentType": dakData?.documentType,
      "to": dakData?.to,
      "nameofAgency": dakData?.nameofAgency,
      "recipients": [],
      "receivedDate": dakData?.receivedDate,
      "searchKeyword": dakData?.searchKeyword,
      "comments": dakData?.comments,
      "dakActionType": dakData?.dakActionType,
      "createdBy": accounts[0].username,
      "modifiedBy": accounts[0].username,
      "ccmaildto": dakData?.ccmaildto?.length > 0 ? dakData?.ccmaildto?.map(item => ({
        ccMail: item.ccMail,
        createdBy: item.createdBy,
        createdDate: item.createdDate,
        modifiedBy: item.modifiedBy,
        modifiedDate: item.modifiedDate

      })) : [],
      "otherOrganization": dakData?.otherOrganization,
      "otherActionType": dakData?.otherActionType,
      "departmentName": dakData?.departmentName,
      "dakSupportingDocumentsDTO": dakData?.dakSupportingDocumentsDTO?.length > 0 ? dakData?.dakSupportingDocumentsDTO?.map(obj => ({
        dakSupportingDocumentId: 0,
        dakId: id.id,
        supportingDocumentPath: obj.supportBase64,
        supportingDocumentFileName: obj.supportingDocumentFileName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,

      })) : [],
      "uploadLetter": dakData?.uploadLetterBase64,
      "uploadLetterFileName": dakData?.uploadLetterFileName,
      "daksApproversDTO": dakData?.daksApproversDTO,
      "recipientDetailsDTO":
        dakData?.recipientDetailsDTO?.length > 0 ? dakData?.recipientDetailsDTO?.map(obj => ({
          dakActionType: obj.dakActionType === null ? 0 : obj.dakActionType,
          otherActionType: obj.otherActionType === null ? "" : obj.otherActionType,
          followUpDate: obj.followUpDate,
          targetDate: obj.targetDate,
          reminderType: obj.reminderType === null ? 0 : obj.reminderType,
          reminderFrequency: obj.reminderFrequency === null ? 0 : obj.reminderFrequency,
          groupMasterId: obj.groupMasterId,
          createdDate: new Date(),
          createdBy: accounts[0].username,
          modifiedDate: new Date(),
          modifiedBy: accounts[0].username,
        })) : []
      ,
      "recipientsDTO":

        dakData?.recipientsDTO?.length > 0 ? dakData?.recipientsDTO?.map(item => ({
          // recipientId: item.recipientId,
          // recipientDetailsId: item.recipientDetailsId,
          recipientsMail: item.recipientsMail,
          // groupMasterId: item.groupMasterId,
          createdDate: item.createdDate,
          createdBy: item.createdBy,
          modifiedDate: item.modifiedDate,
          modifiedBy: item.modifiedBy
        })) : []
      ,
      "mailRecipientsDTO":
        dakData?.mailRecipientsDTO?.length > 0 ? dakData?.mailRecipientsDTO?.map(item => ({
          mailRecipientId: item.mailRecipientId,
          recipientDetailsId: item.recipientDetailsId,
          mailRecipient: item.mailRecipient,
          createdBy: item.createdBy,
          createdDate: item.createdDate,
          modifiedBy: item.modifiedBy,
          modifiedDate: item.modifiedDate
        })) : [],
      "modifiedByName": accounts[0].username,
      "requesterName": accounts[0].username,
      "createdByName": accounts[0].username,
      "signedBy": accounts[0].username,
      "fromDate": new Date(),
      "ToDate": new Date(),
      "commentsBy": accounts[0].username
    }
    // console.log(params,"params");
    // try{

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const response = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eDak_EditForm}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
        // body: params,
      }
    )
      .then(async (data) => {
        const rep = await data.json();
        SetIsLoading(false);
        if (rep.status === 400) {
          SetIsLoading(false);
          setDialogFailure(true);
          //   SetSuccessMsg("Something went wrong please try again.");
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          SetSuccessMsg(
            "The eDak has been returned successfully."
          );
          SuccessDialogToggle();
        }
      })

      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      })
    // }catch(err){


    // }
  };

  return (
    <div>
      <Navbar />
      <Sidebar />
      <div className="FormMaincontainer">
        <div className="container">
          <fieldset className={"k-form-fieldset"}>
            <div className="container">
              <div className="HeaderButtonsContainer row">
                <div className="cstformHdrLeftContainer">
                  {""}
                  {/* {`Pending with: ${dakData?.currentActionerName || ""}`} */}
                </div>
                <div className="cstformHdrMiddleContainer">
                  eDak - {dakData?.dakNumber || ""}
                </div>
                <div className="cstformHdrRightContainer">
                  {`Status : ${dakData ? dakData?.strStatus : ""}`}
                </div>
              </div>
            </div>
            <div className="container">
              <Form
                render={() => (
                  <FormElement>
                    <div className="SectionHeads row">Attachments</div>
                    <div className="SectionRow row">
                      <div>
                        {dakData && (
                          <p>
                            <strong>Main letter link</strong> : {""}
                            <span className="link-style"
                              // href='javascript:void(0)'
                              onClick={() => downloadBase64PDFFile(dakData?.uploadLetter)}
                              // href={pdfLink}
                              /*  to={""}
                                target="_blank" */
                              style={{ wordBreak: "break-word" }}
                            >
                              {dakData.uploadLetterFileName}
                            </span>
                            {/* <Link
                              to={pdfLink}
                              target="_blank"
                              style={{ wordBreak: "break-word" }}
                              rel="noopener noreferrer"
                            // download={dakData.uploadLetterFileName}
                            >
                              {dakData.uploadLetterFileName}
                            </Link> */}
                          </p>
                        )}


                        <p><strong>Support Documents</strong> :</p>
                        <table style={{ width: "100%" }} className="tableStyle">
                          <tbody>
                            {" "}
                            <tr>

                              <th
                                className="approvalform-tableCol-width-1"
                              >
                                Serial Number
                              </th>
                              <th
                                className="approvalform-tableCol-width-3"
                              >
                                Document link
                              </th>
                              <th
                                className="approvalform-tableCol-width-3"
                              >Attached By</th>
                              <th
                                className="approvalform-tableCol-width-3"
                              >Attached Date</th>
                            </tr>
                            {dakData?.dakSupportingDocumentsDTO?.map(
                              (doc, index) => (
                                <tr
                                  key={
                                    doc.noteSupportingDocumentId
                                  }
                                >
                                  <td
                                    className="approvalform-tableCol-width-1"
                                  >
                                    {index + 1}
                                  </td>
                                  <td
                                    className="approvalform-tableCol-width-3"
                                  >
                                    <span
                                      className="link-style"
                                      onClick={() => getSupportDocHyperlink(doc.supportingDocumentPath, doc.supportingDocumentFileName)

                                      }
                                      // target="_blank"
                                      style={{ wordBreak: "break-word" }}
                                    >
                                      {
                                        doc.supportingDocumentFileName
                                      }
                                      {/* </Link> */}
                                    </span>
                                  </td>
                                  {/* Bug fix - 293 - 27/03 */}
                                  <td
                                    className="approvalform-tableCol-width-3"
                                  >{doc.createdByName}</td>
                                  <td
                                    className="approvalform-tableCol-width-3"
                                  >
                                    {getdatetimeconversion(
                                      doc.createdDate
                                    )}
                                  </td>
                                </tr>
                              )
                            )}
                          </tbody>
                        </table>
                        <br />
                        {/* 01/07	eDak creator should see the reply document even if one of the recipients completes */}
                        {
                          (dakData?.edakReplyDocumentsDTO && dakData?.edakReplyDocumentsDTO?.length > 0 && dakData?.createdBy === accounts[0].username ||
                            dakData?.recipientsDTO?.some(obj => obj.recipientsMail === accounts[0].username && obj.strRecipientStatus === 'Completed')
                          )
                            ? (
                              <>
                                <p><strong>Reply Documents</strong> :</p>
                                <table className="tableStyle">
                                  <tbody>
                                    <tr>
                                      <th className="approvalform-tableCol-width-1">Serial Number</th>
                                      <th className="approvalform-tableCol-width-3">Document link</th>
                                      <th className="approvalform-tableCol-width-3">Attached By</th>
                                      <th className="approvalform-tableCol-width-3">Attached Date</th>
                                    </tr>
                                    {dakData?.edakReplyDocumentsDTO?.map((doc, index) => (
                                      <tr key={doc.dakReplyDocumentId}>
                                        <td className="approvalform-tableCol-width-1">{index + 1}</td>
                                        <td className="approvalform-tableCol-width-3">
                                          <span>
                                            <span
                                              className="link-style"
                                              onClick={() => getReplyDocHyperLink(doc.replyDocumentPath, doc.replyDocumentFileName)}
                                              style={{ wordBreak: "break-word" }}
                                            >
                                              {doc.replyDocumentFileName}
                                            </span>
                                          </span>
                                        </td>
                                        <td className="approvalform-tableCol-width-3">{doc.createdByName}</td>
                                        <td className="approvalform-tableCol-width-3">{getdatetimeconversion(doc.createdDate)}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </>
                            ) : null
                        }
                      </div>

                    </div>
                    <div className="SectionHeads row">General Section</div>
                    <div className="SectionRow row">
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Request# :
                            </Label>
                            <Input
                              value={dakData?.dakNumber || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Category :
                            </Label>
                            <Input
                              value={dakData?.strCategory || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Subject :
                            </Label>
                            <TextArea
                              rows={1}
                              value={dakData?.subject || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Department :
                            </Label>
                            <Input
                              value={dakData?.departmentName || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>

                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Requester :
                            </Label>
                            <Input
                              // value={dakData?.requesterName}
                              value={dakData?.createdByName || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Source Type :
                            </Label>
                            <Input
                              value={dakData?.strSourceType || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      {dakData?.strSourceType === "External" && (
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Movement Type :
                              </Label>
                              <Input
                                value={dakData?.strMovementType || ""}
                                // style={{ border: "none" }}
                                readOnly
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      )}

                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Request Date :
                            </Label>
                            <Input
                              value={dakData?.createdDate ? new DateObject(new Date(dakData?.createdDate)).format("DD-MMM-YYYY") : ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Document Type :
                            </Label>
                            <Input
                              value={dakData?.strDocumentType || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      {dakData?.strMovementType === "Outward" && (
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                To :
                              </Label>
                              <TextArea
                                rows={1}
                                value={dakData?.to || ""}
                                // style={{ border: "none" }}
                                readOnly
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      )}
                      {dakData?.strSourceType === "External" && (
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Name of the Agency :
                              </Label>
                              <Input
                                value={dakData?.strNameofAgency || ""}
                                // style={{ border: "none" }}
                                readOnly
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      )}
                      {/* Bug -359   otherOrganization field vaildation 09/05*/}
                      {(dakData?.strSourceType === "External" && dakData?.strNameofAgency === "Other") && (
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Other Organization :
                              </Label>
                              <TextArea
                                rows={1}

                                value={dakData?.otherOrganization || ""}
                                // style={{ border: "none" }}
                                readOnly
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      )}
                      {dakData?.strMovementType === "Inward" && (
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap">
                              <Label className="k-form-label">
                                Received Date :
                              </Label>
                              <Input
                                value={getdateconversion(dakData?.receivedDate)}
                                // style={{ border: "none" }}
                                readOnly
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      )}
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Search Keyword :
                            </Label>
                            <TextArea
                              rows={1}
                              value={dakData?.searchKeyword || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Comments :
                            </Label>
                            <TextArea
                              rows={1}
                              value={dakData?.comments || ""}
                              // style={{ border: "none" }}
                              readOnly
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                      {(dakData?.status >= 7 && dakData?.createdBy === accounts[0].username
                        // && dakData?.strMovementType === "Outward"
                      ) && (
                          <>
                            <div className="col-md-6">
                              <FieldWrapper>
                                <div className="k-form-field-wrap">
                                  <Label className="k-form-label">
                                    Close Date :
                                  </Label>
                                  <Input
                                    // format={"dd-MM-yyyy"}
                                    // placeholder="Choose a date..."
                                    // onChange={(e) => setClosedDate(e.target.value)}
                                    // min={new Date()}
                                    value={getdateconversion(dakData?.closeDate || "")}
                                    // value={new DateObject(state.meetingDate).format("DD-MM-YYYY")}
                                    readOnly
                                  />
                                </div>
                              </FieldWrapper>
                            </div>
                            {dakData?.strMovementType === "Outward" && (
                              <div className="col-md-6">
                                <FieldWrapper>
                                  <div className="k-form-field-wrap">
                                    <Label className="k-form-label">
                                      Sent Date :
                                    </Label>
                                    <Input
                                      value={getdateconversion(dakData?.sentDate || "")}
                                      readOnly
                                    />
                                  </div>
                                </FieldWrapper>
                              </div>

                            )}
                          </>)}
                      {closeBtnCondtion() &&
                        // dakData?.strMovementType === "Outward") &&
                        (
                          <>
                            <div className="col-md-6">
                              <FieldWrapper>
                                <div className="k-form-field-wrap">
                                  <Label className="k-form-label">
                                    Close Date
                                    <span className="required-asterisk"> * </span>
                                    :
                                  </Label>
                                  <DatePicker
                                    className={isCloseDateVaild ? "invalidColor" : ""}
                                    format={"dd-MM-yyyy"}
                                    placeholder="Choose a date..."
                                    onChange={(e) => {

                                      const selectedDate = new Date(e.target.value);
                                      const utcDate = new Date(Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()));

                                      setClosedDate(utcDate);
                                    }}
                                    value={closedDate}
                                  // readOnly
                                  />
                                </div>
                              </FieldWrapper>
                            </div>
                            {dakData?.strMovementType === "Outward" && (
                              <div className="col-md-6">
                                <FieldWrapper>
                                  <div className="k-form-field-wrap">
                                    <Label className="k-form-label">
                                      Sent Date
                                      <span className="required-asterisk"> * </span>
                                      :
                                    </Label>
                                    <DatePicker
                                      format={"dd-MM-yyyy"}
                                      placeholder="Choose a date..."
                                      onChange={(e) => {
                                        const selectedDate = new Date(e.target.value);
                                        const utcDate = new Date(Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()));

                                        setSentdDate(utcDate)
                                      }}
                                      value={sentDate}
                                      formatPlaceholder={"DD-MM-YYYY"}
                                      className={isSentDateVaild ? "invalidColor" : ""}
                                    />
                                  </div>
                                </FieldWrapper>
                              </div>

                            )}
                          </>)}


                    </div>
                    <div className="SectionHeads row">Reviewers Section</div>
                    <div className="SectionRow row">
                      {/* {noteData && ( */}
                      <table className="ib-forms-custom-table tableStyle">
                        <tbody>
                          <tr>
                            <th className="approvalform-tableCol-width-1">S.No</th>
                            <th className="approvalform-tableCol-width-2">Reviewer Name </th>
                            <th className="approvalform-tableCol-width-1">SR No</th>
                            <th className="approvalform-tableCol-width-2">Designation</th>
                            <th className="approvalform-tableCol-width-2">Status </th>
                            <th className="approvalform-tableCol-width-3">Action Date </th>
                          </tr>
                          {dakData?.daksApproversDTO?.map(
                            (obj, index) =>
                              obj.edakApproverType === enumObj?.approverType?.find((obj) => obj.dValue === "Reviewer").id && (
                                <tr key={obj.approverEmail}
                                >
                                  <td className="approvalform-tableCol-width-1">{index + 1}</td>
                                  <td className="approvalform-tableCol-width-2">
                                    {obj.approverEmailName}
                                  </td>
                                  <td className="approvalform-tableCol-width-1">{obj.srNo}</td>

                                  <td className="approvalform-tableCol-width-2">{obj.designation}</td>
                                  <td className="approvalform-tableCol-width-2">
                                    <span className={`k-icon k-font-icon ${renderApproverIcon(obj.edakApproverStatus)}  allIconsforPrimary-btnStatusIcon`}></span>
                                    {obj.strEdakApproverStatus}
                                  </td>
                                  <td className="approvalform-tableCol-width-2">
                                    {
                                      (obj.edakApproverStatus === enumObj?.approverStatus?.find(obj => obj.dValue === "Waiting").id ||
                                        obj.edakApproverStatus === enumObj?.approverStatus?.find(obj => obj.dValue === "Pending").id) ? ""
                                        :
                                        getdatetimeconversion(
                                          obj.modifiedDate
                                        )}
                                  </td>
                                </tr>
                              )
                          )}
                        </tbody>
                      </table>

                    </div>
                    <div className="SectionHeads row">Approvers Section</div>
                    <div className="SectionRow row">
                      <table className="ib-forms-custom-table tableStyle">
                        <tbody></tbody>{" "}
                        <tr>
                          {/* Bug fix - 294 - 27/03 */}
                          <th className="approvalform-tableCol-width-1">S.No</th>
                          <th className="approvalform-tableCol-width-2">Approver Name </th>
                          <th className="approvalform-tableCol-width-1">SR No</th>
                          <th className="approvalform-tableCol-width-2">Designation</th>
                          <th className="approvalform-tableCol-width-2">Status </th>
                          <th className="approvalform-tableCol-width-2">Action Date </th>
                        </tr>
                        {dakData?.daksApproversDTO?.map(
                          (obj, index) =>
                            obj.edakApproverType === enumObj?.approverType?.find((obj) => obj.dValue === "Approver").id
                            && (
                              <tr key={obj.approverEmail}
                              >
                                <td className="approvalform-tableCol-width-1">{index + 1}</td>
                                <td className="approvalform-tableCol-width-2">
                                  {obj.approverEmailName}
                                </td>
                                <td className="approvalform-tableCol-width-1">{obj.srNo}</td>
                                <td className="approvalform-tableCol-width-2">{obj.designation}</td>
                                <td className="approvalform-tableCol-width-2">
                                  {/* <span className={`k-icon k-font-icon ${renderApproverIcon(obj.edakApproverStatus)} cursor allIconsforPrimary-btn`}></span> */}
                                  <span className={`k-icon k-font-icon ${renderApproverIcon(obj.edakApproverStatus)}  allIconsforPrimary-btnStatusIcon`}></span>
                                  {/* allIconsforPrimary-btnStatusIcon */}
                                  {obj.strEdakApproverStatus}
                                </td>
                                <td className="approvalform-tableCol-width-2">
                                  {
                                    (obj.edakApproverStatus === enumObj?.approverStatus?.find(obj => obj.dValue === "Waiting").id ||
                                      obj.edakApproverStatus === enumObj?.approverStatus?.find(obj => obj.dValue === "Pending").id) ? ""
                                      :
                                      getdatetimeconversion(
                                        obj.modifiedDate
                                      )}
                                </td>
                              </tr>
                            )
                        )}
                      </table>
                    </div>


                    <div className="SectionHeads row">Directions Section</div>
                    {approverChecking() && (
                      <div className="SectionRow row">
                        <div className="col">
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Comments :<span className="required-asterisk">*</span>
                            </Label>
                            <TextArea
                              className={isDirectionCmtVaild ? "invalidColor" : ""}
                              onChange={handleDirectionsComments}
                              value={directionsComments}
                              rows={3}
                            />
                          </div>
                        </div>
                      </div>

                    )}

                    <div className="SectionRow row">
                      <table className="tableStyle">
                        <thead>
                          <tr>
                            <th className="approvalform-tableCol-width-2">Serial Number</th>
                            <th className="approvalform-tableCol-width-5">Comments</th>
                            <th className="approvalform-tableCol-width-3">Comments By </th>
                          </tr>
                        </thead>
                        <tbody>
                          {dakData?.directionsDTO?.map((obj, index) => <tr>
                            <td className="approvalform-tableCol-width-2">{index + 1}</td>
                            <td className="approvalform-tableCol-width-5">{obj.comments}</td>
                            <td className="approvalform-tableCol-width-3">{obj.commentsByName}</td>
                          </tr>)}
                        </tbody>
                      </table>

                    </div>

                    {approverChecking() && (
                      <>
                        <div className="SectionHeads row">Comments Section</div>
                        {/* Bug -348 06/05 */}
                        <div className={`CommentsSectionRow row `}
                          style={{ border: isReturnValidtion ? "1px solid red" : "1px solid lightgrey" }}>
                          <table className="ib-forms-custom-table tableStyle">
                            <thead>
                              <tr>
                                <th className="approvalform-tableCol-width-1">Page#</th>
                                <th className="approvalform-tableCol-width-1">Doc Reference</th>
                                <th className="approvalform-tableCol-width-6">Comments</th>
                                <th className="approvalform-tableCol-width-2">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td className="approvalform-tableCol-width-1">
                                  <div onKeyDown={(e) => e.stopPropagation()}>
                                    <input
                                      className="general-comments-pageNo"
                                      type="text"
                                      name="PageNo"
                                      value={generalcmtInfoobj.PageNo}
                                      onChange={handelGenralComments}
                                    />
                                  </div>
                                </td>
                                <td className="approvalform-tableCol-width-1">
                                  <div onKeyDown={(e) => e.stopPropagation()}>
                                    <input
                                      className="general-comments-DocRef"
                                      name="DocRef"
                                      value={generalcmtInfoobj.DocRef}
                                      onChange={handelGenralComments}
                                    />
                                  </div>
                                </td>
                                <td className="approvalform-tableCol-width-6">
                                  {/* <div> */}
                                  <div onKeyDown={(e) => e.stopPropagation()} style={{ marginTop: " 6px" }}>
                                    <textarea
                                      name="Comments"
                                      className="general-comments-Comments"
                                      row={1}
                                      value={
                                        generalcmtInfoobj.Comments
                                      }
                                      onChange={
                                        handelGenralComments
                                      }
                                    ></textarea>
                                  </div>
                                </td>
                                <td className="approvalform-tableCol-width-2">
                                  <Button
                                    className="formBtnColor"
                                    onClick={handelAddCmts}
                                  >
                                    <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                    Add comments
                                  </Button>
                                </td>
                              </tr>
                              {generalcmtforAllCmt?.map(
                                (obj, index) => (
                                  <tr key={index}>
                                    <td className="approvalform-tableCol-width-1">
                                      {obj.isEdit ? (
                                        <div onKeyDown={(e) => e.stopPropagation()}>
                                          <input
                                            type="text"
                                            className="general-comments-pageNo"
                                            value={obj.PageNo}
                                            name="PageNo"
                                            id={index}
                                            onChange={
                                              handelGenralCommentsEdit
                                            }
                                          />
                                        </div>
                                      ) : (
                                        obj.PageNo
                                      )}
                                    </td>
                                    <td className="approvalform-tableCol-width-1">
                                      {obj.isEdit ? (
                                        <div onKeyDown={(e) => e.stopPropagation()}>
                                          <input
                                            type="text"
                                            className="general-comments-DocRef"
                                            value={obj.DocRef}
                                            name="DocRef"
                                            id={index}
                                            onChange={
                                              handelGenralCommentsEdit
                                            }
                                          />
                                        </div>
                                      ) : (
                                        obj.DocRef
                                      )}
                                    </td>
                                    <td className="approvalform-tableCol-width-6">
                                      {obj.isEdit ? (
                                        <div onKeyDown={(e) => e.stopPropagation()}>
                                          <textarea
                                            value={obj.Comments}
                                            className="general-comments-Comments"
                                            name="Comments"
                                            id={index}
                                            onChange={
                                              handelGenralCommentsEdit
                                            }
                                          ></textarea>
                                        </div>
                                      ) : (
                                        obj.Comments
                                      )}
                                    </td>
                                    <td className="approvalform-tableCol-width-1">
                                      {
                                        obj.isEdit ?
                                          <Button
                                            className="formBtnColor"
                                            onClick={() =>
                                              handleGeneraleditedcommentsSave(index)
                                            }
                                          >
                                            <span className="k-icon k-font-icon k-i-save cursor allIconsforPrimary-btn"></span>
                                            Save
                                          </Button> : <div className="eDak-comments-btn">

                                            <Button
                                              onClick={() =>
                                                handelDeleteCmt(index)
                                              }
                                            >
                                              <span className="k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>
                                              Delete
                                            </Button>
                                            <Button
                                              onClick={() =>
                                                handelingEdit(index)
                                              }
                                            >
                                              <span className="k-icon k-font-icon k-i-edit cursor allIconsforPrimary-btn"></span>
                                              Edit
                                            </Button>
                                          </div>
                                      }
                                    </td>
                                  </tr>
                                )
                              )}
                            </tbody>
                          </table>

                        </div>
                      </>
                    )}

                    <div className="SectionHeads row">Comments Log</div>
                    <div className="SectionRow row">
                      <table className="ib-forms-custom-table tableStyle">
                        <tbody>

                          <tr>
                            <th className="approvalform-tableCol-width-1">Page#</th>
                            <th className="approvalform-tableCol-width-1">Doc Reference</th>
                            <th className="approvalform-tableCol-width-5">Comments</th>
                            <th className="approvalform-tableCol-width-3">Comment By</th>
                          </tr>
                          {dakData?.edakComments?.map(
                            (comment) => (

                              <tr
                                key={
                                  comment.edakApproverId
                                }
                              >
                                <td className="approvalform-tableCol-width-1">{comment.pageNumber}</td>
                                <td className="approvalform-tableCol-width-1">
                                  {comment.docReferrence}
                                </td>
                                <td className="approvalform-tableCol-width-5">{comment.comments}</td>
                                <td className="approvalform-tableCol-width-3">{comment.commentsByName}</td>
                              </tr>
                            )
                          )}
                          {generalcmtforAllCmt?.map(
                            (obj, index) => (
                              !obj.isEdit && (<tr key={index}>
                                <td className="approvalform-tableCol-width-1">{obj.PageNo}</td>
                                <td className="approvalform-tableCol-width-1">{obj.DocRef}</td>
                                <td className="approvalform-tableCol-width-5">{obj.Comments}</td>
                                <td className="approvalform-tableCol-width-3">
                                  {accounts[0].name}
                                </td>
                              </tr>)
                            )
                          )}
                        </tbody>
                      </table>
                    </div>
                    {approverChecking() && (
                      <>
                        <div className="SectionHeads row">Attach Supporting Documents</div>
                        <div className="SectionRow row">
                          <div className="col">
                            <span className="k-form-label">
                              Attach Supporting Documents
                            </span>
                            <div className="Attachemntfileinfo-ind">
                              <input
                                type="file"
                                id="multiDoc"
                                multiple
                                onChange={multipleDocUpload}
                                style={{ width: "107px" }}
                              />
                              <div>
                                <span
                                  style={{ color: "red", fontSize: "10px" }}
                                >
                                  {
                                    supportingDocError
                                  }
                                </span>
                              </div>
                            </div>
                            {supportDocfilesInfo?.map((obj, ind) => (
                              <div
                                className="Attachemntfileinfo-ind"
                                key={ind}
                              >
                                <span className="attachemntIconInfoConationer">
                                  <span className="AttchemntIconWraper">
                                    {/* Assuming you have different icons for different file types */}
                                    <SvgIcon
                                      icon={getFileIcon(
                                        obj.supportingDocumentFileName
                                      )}
                                      size="xxlarge"
                                    />
                                    <span className="attachemnrt-warningifoConatiner">
                                      <div className="attachemnrt-warningifo-fileinfo">
                                        {
                                          obj.supportingDocumentFileName
                                        }
                                      </div>
                                      <span
                                        style={{
                                          color: "red",
                                          fontSize: "10px",
                                        }}
                                      >
                                        {
                                          supportDocWarning[
                                            obj
                                              .supportingDocumentFileName
                                          ]?.warningMsg
                                        }
                                      </span>
                                    </span>
                                  </span>
                                  <span
                                    className="AttchemntIconWraperCancel"
                                    onClick={() =>
                                      onRemoveMultiAttachment(
                                        ind
                                      )
                                    }
                                  >
                                    X
                                  </span>
                                </span>
                              </div>
                            ))}
                            <div
                              style={{
                                textAlign: "right",
                                color: "green",
                              }}
                            >
                              Allowed Formats (pdf,doc,docx,xlsx only) Upto 25MB max.
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {
                      (dakData?.strSourceType === "External" && dakData?.strMovementType === "Outward") ? null :
                        <>
                          <div className="SectionHeads row">Recipients Section</div>

                          <div className="SectionRow row">
                            {recepientChecking() && (
                              <div className="row" style={{ marginBottom: "10px" }}>
                                <div className="col-md-6">
                                  {/* <FieldWrapper> */}
                                  <div className="k-form-field-wrap">
                                    <Label className="k-form-label">
                                      Action :
                                    </Label>
                                    <div className="eDak-action-radio-btn">
                                      <div>
                                        <RadioButton
                                          name="actionBtn"
                                          value="Complete"
                                          checked={recipientsActionType === "Complete"}
                                          label="Complete"
                                          onChange={handleActionType}
                                        />
                                      </div>
                                      <div>
                                        <RadioButton
                                          name="actionBtn"
                                          value="Forward"
                                          checked={recipientsActionType === "Forward"}
                                          label="Forward"
                                          onChange={handleActionType}
                                        />
                                      </div>

                                    </div>


                                  </div>
                                  {/* </FieldWrapper> */}
                                </div>
                                <>
                                  {recipientsActionType === "Complete" && (<>
                                    <div className="col-md-6">
                                      {/* <FieldWrapper> */}
                                      <div className="k-form-field-wrap">
                                        <Label className="k-form-label">
                                          Completion Date  <span className="required-asterisk"> * </span> :

                                        </Label>

                                        <DatePicker
                                          format={"dd-MM-yyyy"}
                                          placeholder="Choose a date..."
                                          onChange={onSelectedCompletionDate}
                                          // valid={isVaildCompliationDate}
                                          className={`${isVaildCompliationDate ? "invalidColor" : ""}`}
                                          // className="invalidColor"
                                          value={completionDate}
                                        />
                                      </div>
                                      {/* </FieldWrapper> */}
                                    </div>
                                    <div className="col-md-6">
                                      {/* <FieldWrapper> */}
                                      <div className="k-form-field-wrap">
                                        <Label className="k-form-label">
                                          Comments  <span className="required-asterisk"> * </span> :

                                        </Label>
                                        <TextArea
                                          // maxLength={max}
                                          // className="invalidColor"
                                          className={`${isVaildRecipientsComments ? "invalidColor" : ""}`}
                                          onChange={handlerecipientsComments}
                                          value={recipientsComments}
                                          rows={1}
                                        // style={{borderColor:isVaildRecipientsComments?"#f31700":""}}
                                        />
                                      </div>
                                    </div>
                                    <br />
                                    <br />
                                  </>
                                  )}
                                </>

                              </div>)}

                            <br />


                            <table className="tableStyle" style={{ width: "100%" }}>
                              <thead>
                                <tr>
                                  <th className="approvalform-tableCol-width-05"><div className="recipentDetailsSection-header">Serial Number</div></th>
                                  <th className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header">Recipients</div></th>
                                  <th className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header">Action Type</div> </th>
                                  {dakData?.recipientDetailsDTO[0]?.strDakActionType === "Other" && (
                                    <th className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header"> Other Action Type</div> </th>

                                  )}
                                  {
                                    dakData?.recipientDetailsDTO?.length > 0 && dakData?.recipientDetailsDTO[0]?.strDakActionType !== "Information" && (
                                      <>
                                        <th className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header">Target/Follow Up Date</div></th>
                                        <th className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header">Completion Date</div></th>
                                      </>
                                    )
                                  }
                                  {dakData?.recipientDetailsDTO?.length > 0 && dakData?.recipientDetailsDTO[0]?.strDakActionType === "Information" && (


                                    <th className="approvalform-tableCol-width-15"><div className="recipentDetailsSection-header">Acknowledgement Date</div></th>
                                  )}
                                  {dakData?.recipientDetailsDTO?.length > 0 && dakData?.recipientDetailsDTO[0]?.strDakActionType !== "Information" && (
                                    <th className="approvalform-tableCol-width-2"><div className="recipentDetailsSection-header">Comments</div></th>
                                  )}
                                  <th className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header">Status</div> </th>
                                  <th className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header">Submitted  Date </div></th>
                                </tr>
                              </thead>
                              <tbody>{
                                dakData?.recipientsDTO?.map((obj, index) =>
                                  <tr key={obj.recipientId}>
                                    <td className="approvalform-tableCol-width-05">{index + 1}</td>
                                    <td className="approvalform-tableCol-width-1">{obj.recipientsMailName}</td>
                                    <td className="approvalform-tableCol-width-1">{dakData?.recipientDetailsDTO[0]?.strDakActionType || ""}</td>
                                    {dakData?.recipientDetailsDTO[0]?.strDakActionType === "Other" && (
                                      <td className="approvalform-tableCol-width-1"><div className="recipentDetailsSection-header"> {dakData?.recipientDetailsDTO[0]?.otherActionType || ""}</div> </td>

                                    )}
                                    {dakData?.recipientDetailsDTO?.length > 0 && dakData?.recipientDetailsDTO[0]?.strDakActionType !== "Information" && (
                                      <>
                                        <td className="approvalform-tableCol-width-1">{dakData?.recipientDetailsDTO[0]?.strDakActionType === "Follow-up" ? getdateconversion(dakData?.recipientDetailsDTO[0]?.followUpDate || "") : getdateconversion(dakData?.recipientDetailsDTO[0]?.targetDate || "")}</td>
                                        <td className="approvalform-tableCol-width-1">{getdateconversion(obj.completionDate || "")}</td>
                                      </>
                                    )}
                                    {dakData?.recipientDetailsDTO?.length > 0 && dakData?.recipientDetailsDTO[0]?.strDakActionType === "Information" && (


                                      <td className="approvalform-tableCol-width-15">{getdateconversion(dakData?.acknowledgedDate || "")}</td>
                                    )}
                                    {dakData?.recipientDetailsDTO?.length > 0 && dakData?.recipientDetailsDTO[0]?.strDakActionType !== "Information" && (
                                      <td className="approvalform-tableCol-width-2">{obj.recipientComment || ""}</td>
                                    )}

                                    <td className="approvalform-tableCol-width-1">
                                      {/* <span className={`k-icon k-font-icon ${renderRecipentrIcon(obj.recipientStatus)} cursor allIconsforPrimary-btn`}></span> */}
                                      <span className={`k-icon k-font-icon ${renderRecipentrIcon(obj.recipientStatus)}  allIconsforPrimary-btnStatusIcon`}></span>
                                      {/* allIconsforPrimary-btnStatusIcon */}
                                      {obj.strRecipientStatus || ""} </td>
                                    <td className="approvalform-tableCol-width-1">{(obj.recipientStatus === 4 || obj.recipientStatus === 3) ? getdatetimeconversion(obj.modifiedDate) : ""}</td>
                                  </tr>
                                )

                              }</tbody>

                            </table>


                          </div>
                        </>

                    }
                    {recepientChecking() && (
                      <>
                        <div className="SectionHeads row">Attach Reply Documents</div>
                        <div className="SectionRow row">
                          <div className="col">
                            <span className="k-form-label">
                              Attach Reply Documents
                            </span>
                            <div className="Attachemntfileinfo-ind">
                              <input
                                type="file"
                                id="attachReplyDoc"
                                multiple
                                onChange={addAttchReplyDoc}
                                style={{ width: "107px" }}
                              />
                            </div>
                            {attachReplyDocfilesInfo?.map((obj, ind) => (
                              <div
                                className="Attachemntfileinfo-ind"
                                key={ind}
                              >
                                <span className="attachemntIconInfoConationer">
                                  <span className="AttchemntIconWraper">
                                    {/* Assuming you have different icons for different file types */}
                                    <SvgIcon
                                      icon={getFileIcon(
                                        obj.supportingDocumentFileName
                                      )}
                                      size="xxlarge"
                                    />
                                    <span className="attachemnrt-warningifoConatiner">
                                      <div className="attachemnrt-warningifo-fileinfo">
                                        {
                                          obj.supportingDocumentFileName
                                        }
                                      </div>
                                      <span
                                        style={{
                                          color: "red",
                                          fontSize: "10px",
                                        }}
                                      >
                                        {
                                          attachReplyDocWarning[
                                            obj
                                              .supportingDocumentFileName
                                          ]?.warningMsg
                                        }
                                      </span>
                                    </span>
                                  </span>
                                  <span
                                    className="AttchemntIconWraperCancel"
                                    onClick={() =>
                                      onRemoveAttachReplyDoc(
                                        ind
                                      )
                                    }
                                  >
                                    X
                                  </span>
                                </span>
                              </div>
                            ))}
                            <div
                              style={{
                                textAlign: "right",
                                color: "green",
                              }}
                            >
                              Allowed Formats (pdf,doc,docx,xlsx only) Upto 5MB max.
                            </div>
                          </div>
                        </div></>

                    )}

                    <div className="SectionHeads row">Workflow Log</div>
                    <div className="SectionRow row">
                      <table className="ib-forms-custom-table tableStyle">
                        <tbody>
                          {" "}
                          <tr>
                            <th className="approvalform-tableCol-width-4">Action</th>
                            <th className="approvalform-tableCol-width-3">Action By</th>
                            <th className="approvalform-tableCol-width-3">Action Date</th>
                          </tr>
                          {dakData?.dakWorkflowLogsDTO?.map(
                            (obj, index) => (
                              <tr>
                                <td className="approvalform-tableCol-width-4">
                                  {obj.action}
                                </td>
                                {/* Bug fix - 293 - 27/03 */}
                                <td className="approvalform-tableCol-width-3">
                                  {obj.actionByName}
                                </td>
                                <td className="approvalform-tableCol-width-3">
                                  {getdatetimeconversion(
                                    obj.modifiedDate
                                  )}
                                </td>
                              </tr>
                            )
                          )}
                        </tbody>{" "}
                      </table>
                    </div>
                  </FormElement>
                )} />
            </div>

          </fieldset>
        </div>
      </div>
      <div className="approvalAction-foreNoteForm-contaioner">
        <div>
          {approverChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={approvlfunction} themeColor="success">
                <span className="k-icon k-font-icon  k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>
                Approve
              </Button>
            </span>
          )}
          {approverChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={rejectfunctuin} themeColor="error">
                <span className="k-icon k-font-icon  k-i-track-changes-reject cursor allIconsforPrimary-btn"></span>
                Reject
              </Button>
            </span>
          )}

        </div>
        <div>
          {approverChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={returnfunction} className="formBtnColor">
                <span className="k-icon k-font-icon  k-i-undo cursor allIconsforPrimary-btn"></span>
                Return
              </Button>
            </span>
          )}
          {/* Completed */}
          {recepientChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={onClickComplete} className="formBtnColor">
                <span className="k-icon k-font-icon k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>
                Complete
              </Button>
            </span>

          )}

          {closeBtnCondtion() && (
            <span className="eNote-ApprovalButton">
              <Button className="formBtnColor" onClick={onClickCloseEdak}>

                <span className="k-icon k-font-icon k-i-close-outline k-i-x-outline cursor allIconsforPrimary-btn"></span>
                Close e-Dak
              </Button>
            </span>

          )}
          {closeBtnCondtion() && (
            <span className="eNote-ApprovalButton">
              <Button className="formBtnColor" onClick={onclickReturnEdak}>

                <span className="k-icon k-font-icon  k-i-undo cursor allIconsforPrimary-btn"></span>
                Return e-Dak
              </Button>
            </span>

          )}

          {dakData &&
            (dakData?.status === 2 || (dakData?.status === 4 && dakData?.recipientsDTO?.length > 0)) && // need to add recoipent also 
            dakData.createdBy === accounts[0].username && (
              <span className="eNote-ApprovalButton">
                <Button className="formBtnColor" onClick={onClickChangeApprover}>
                  <span className="k-icon k-font-icon  	k-i-user cursor allIconsforPrimary-btn"></span>
                  Change Approver
                </Button>
              </span>
            )}

          <span className="eNote-ApprovalButton">
            <Button onClick={redirectHomePage}>
              <span className="k-icon k-font-icon  k-i-x-circle cursor allIconsforPrimary-btn"></span>
              Exit</Button>
          </span>
        </div>
      </div>
      <Footer />

      {isLoading && <PageLoader />}
      {validationErrors && (
        <Dialog
          title={<CustomSuccussTitleBar />}
          onClose={handleClosevalidationDialog}
        >
          <p className="cstDailogValidmsg">
            <div style={customStyles.dialogAlignment}>
              <p style={customStyles.dialogPara}>Please fill up all the mandatory fields</p>
              <ul style={customStyles.dialogUl}>
                {errorMessages.map((message, index) => (
                  <li style={customStyles.dialogList} key={index}>{message}</li>
                ))}
              </ul>
              {/* Removed note -06/05 */}
              {/*  <p>
                <strong>Note:</strong> Invalid files are not allowed
              </p> */}
            </div>
          </p>
          <DialogActionsBar>
            <Button
              onClick={handleClosevalidationDialog}
              className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
            >
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}

      {dialogOpen && (
        <Dialog
          title={<CustomConfirmationTitleBar />}
          onClose={toggleDailogForConfirmation}
        >
          <p
            style={{
              margin: "25px",
              textAlign: "center",
              width: "500px",
              fontWeight: 500,
            }}
          >
            {confirmDailogObj.Confirmtext}
          </p>
          <p
            style={{
              margin: "25px",
              textAlign: "center",
              width: "500px",
            }}
          >
            {confirmDailogObj.Description}
          </p>

          {/* {isCurrentATRCreator && selectedAssigneeUsersinfo?.length === 0 && actionBtn === "Approve" && ( */}


          {/* )} */}

          <DialogActionsBar>
            <Button className="formBtnColor" onClick={onCofiormation}>
              <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
              Confirm
            </Button>

            <Button onClick={toggleDailogForConfirmation}>
              <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
              Cancel</Button>
          </DialogActionsBar>
        </Dialog>
      )}

      {dialogSuccess && (
        <Dialog title={<CustomSuccussTitleBar />} onClose={redirectHomePage}>
          <p
            style={{
              margin: "25px",
              textAlign: "center",
              width: "500px",
            }}
          >
            {successMsg}
          </p>
          <DialogActionsBar>
            <Button className="notifyDailogOkBtn" onClick={redirectHomePage}>
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {dialogFailure && (
        <Dialog
          title={<CustomSuccussTitleBar />}
          onClose={() => setDialogFailure(false)}
        >
          <p
            style={{
              margin: "25px",
              textAlign: "center",
              width: "500px",
            }}
          >
            Something went wrong please try again.
          </p>
          <DialogActionsBar>
            <Button
              className="notifyDailogOkBtn"
              onClick={() => setDialogFailure(false)}
            >
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}

      {changeapprovervisible && (
        <Dialog title={<CustomSuccussTitleBar />} onClose={() => setChangeApproverVisible(false)}>
          <p
            style={{
              margin: "25px",
              textAlign: "center",
              width: "500px",
            }}
          >
            The Approver/Reviewer/Recipient has been updated
            successfully.
          </p>
          <DialogActionsBar>
            <Button onClick={handleCloseDialog} className="notifyDailogOkBtn">
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {/* dialog for validation */}
      {userComboValidationDialog && (
        <Dialog title={<CustomSuccussTitleBar />}
          onClose={() => setUserComboValidationDialog(false)}>
          <p
            style={{
              margin: "25px",
              textAlign: "center",
              width: "500px",
            }}
          >
            {userNotifyInfo}
          </p>
          <DialogActionsBar>
            <Button
              onClick={oncloseUseNotify}
              className="notifyDailogOkBtn"
            >
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {/* add refer and change approver */}
      {dialogForRefereeAndChangeApprover && (<Dialog
        title={<CustomTitleBar />}
        onClose={() => setDialogForRefereeAndChangeApprover(false)}
      >
        {recipientsActionType === "Forward" && (<>
          <label className="addReferee-label-ChangeApprover-label">Select Forward user
            <span className="required-asterisk">*</span>
            <MultiColumnComboBox
              data={orgEmployees
              }
              filterable={true}
              columns={orgUsersPplPickerColumnMapping}
              value={forwardUser === null ? null : forwardUser.displayName}
              onFilterChange={onFillterALLUser}
              onChange={onSelectedForwardUser}
              style={{
                width: "100%",
                marginRight: "5px"
              }}
              placeholder="Select User..."
            />
          </label>


        </>)}
        {actionBtn === "ChangeApprover" && (<>
          <label className="addReferee-label-ChangeApprover-label">Select Approver
            <span className="required-asterisk">*</span>
            <DropDownList
              /* data={dakData?.daksApproversDTO?.map(x =>{
                  if(x.edakApproverStatus ===2 || x.edakApproverStatus ===1){
                      return x.approverEmailName
                  }
              })} */
              data={approverDetailsDTO?.map(obj => obj.approverEmailName)}
              value={selectedCurrentApprover}
              onChange={(e) =>
                setSelectedCurrentApprover(e.target.value)
              }
            // onChange={handelSelectedDepartment}
            />
          </label>
          <br />
          <br />
          <label className="addReferee-label-ChangeApprover-label"> Change approver
            <span className="required-asterisk">*</span>
            <MultiColumnComboBox
              data={orgEmployees
              }
              filterable={true}
              columns={orgUsersPplPickerColumnMapping}
              value={changeApprovercombovalue === null ? null : changeApprovercombovalue.displayName}
              onFilterChange={onFillterALLUser}
              onChange={handleChangeApproverCombo}
              style={{
                width: "100%",
                marginRight: "5px"
              }}
              placeholder="Change Approver..."
            />
          </label>

        </>)}
        <DialogActionsBar>
          {recipientsActionType === "Forward" ?
            <Button
              className="formBtnColor"
              onClick={onClickForward}
            >
              <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
              Forward
            </Button> :
            <Button
              className="formBtnColor"
              onClick={onSubmitforChangeApproverInfo}>
              <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
              Submit
            </Button>
          }
          <Button
            onClick={() => setDialogForRefereeAndChangeApprover(false)}>
            <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
            Cancel
          </Button>
        </DialogActionsBar>
      </Dialog>
      )
      }
      {/* Commemted for rollback passscode -  26-06 */}
      {/* passcode verification dialog*/}
      {passcodeVerification && (
        <Dialog title="Passcode Verification" onClose={handlepasscodeClose}>
          <form className="form-container" style={customStyles.dialogTextStyle}>
            <label>
              Enter your passcode for verification:
              <div className="passcode-input-wrapper">
                <input
                  type={isPasscodeVisible ? 'text' : 'password'}
                  value={passcode}
                  onChange={handlePasscodeChange}
                  className="passcode-input"
                  maxLength="6"
                  pattern="\d*"
                  title="Please enter 6-characters, Combination of Alphabets and Numbers"
                  inputMode="numeric"
                />
                <span
                  className="eye-icon-view"
                  onClick={() => setIsPasscodeVisible(!isPasscodeVisible)}
                >
                  {isPasscodeVisible ? <img alt="view" src={view} /> : <img alt="hide" src={hide} />}
                </span>
              </div>
            </label>
            <div>
              {error && <span className='error'>{error}</span>}
            </div>
          </form>
          <DialogActionsBar>
            <Button
              className="formBtnColor"
              onClick={passcodeVerificationFunction}>
              <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
              Verify
            </Button>
            <Button
              onClick={handlepasscodeClose}>
              <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
              Cancel
            </Button>

          </DialogActionsBar>
        </Dialog>
      )}
      {/* Valid passcode dialog*/}
      {validPasscode && (
        <Dialog title="Passcode Verification" onClose={() => setValidPasscode(false)}>
          <div style={customStyles.dialogStyle}>
            <p>{validMsg}</p>
          </div>
          <DialogActionsBar>
            <Button
              className="formBtnColor"
              onClick={handleRedirectToPasscode}>
              <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
              Create Passcode
            </Button>
            <Button
              onClick={() => setValidPasscode(false)}>
              <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
              Cancel
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
    </div >
  );
}

// Customized system styles can be inserted into a div elements
const customStyles = {
  childProps: { overflow: 'hidden', textOverflow: 'ellipsis', flexGrow: 1 },
  dialogList: { paddingBottom: '5px' },
  dialogPara: { marginBottom: '5px', fontWeight: 'bold' },
  dialogUl: { padding: '2% 3%' },
  dialogAlignment: { textAlign: 'left' },
  dialogStyle: { margin: "25px", textAlign: "center", width: "500px" },
  dialogTextStyle: { margin: "25px", textAlign: "center", width: "500px", fontWeight: 500 },
  attachmentHint: { textAlign: "right", color: "green" },
  attachmentFileWidth: { width: "100px" },
  attachmentWarning: { color: "red", fontSize: "10px" },
  approvalContentStyle: { display: "flex", justifyContent: "right", margin: "5px" },
  multiComboBox: { marginBottom: "8px", paddingLeft: "0px" },
  approverText: { width: "300px", marginRight: "5px" },
  departmentBorder: { border: "none" }
}