import React, { useState, useEffect } from "react";
// Import Kendo Components
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import { getter } from "@progress/kendo-react-common";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
import { orderBy } from "@progress/kendo-data-query";
import { Button } from "@progress/kendo-react-buttons";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import { CSVLink } from "react-csv";
// Import External Libraries
import { useMsal, useAccount } from "@azure/msal-react";
import { Link } from "react-router-dom";
import { useParams } from "react-router";
import DateObject from "react-date-object";
// Import components
import { ColumnMenu } from "./custom-cells";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Sidebar } from "../components/sidebar";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { PageLoader } from "../components/pageLoader";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";
// Import CSS styles
import "../styles/datagridpage.css";
import "../styles/forms.css";

const initialSort = [
  {
    field: "modifiedDate",//dakId
    dir: "desc",
  },
];
const DATA_ITEM_KEY = "dakId";
const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};

const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};

const Views = () => {

  const idGetter = getter(DATA_ITEM_KEY);
  const { id } = useParams();
  const [filterValue, setFilterValue] = useState("");
  const [filteredData, setFilteredData] = useState();
  const [currentSelectedState, setCurrentSelectedState] = useState({});
  const [dataState, setDataState] = useState(initialDataState);
  const [data, setData] = useState(filteredData);
  const [apiData, setApiData] = useState([]);
  const [dataResult, setDataResult] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentHeading, setCurrentHeading] = useState();
  const [selectedView, setSelectedView] = useState("");
  const { accounts,instance } = useMsal();
  const account = useAccount(accounts[0] || {});

  // to get the dropdown data and switch condition for views to display the data
  const getRequestByStatus = async(dakId) => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    //get enum objects
    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
    });
    const enumsObj = await dropdowns.json();

    switch (dakId) {
      case "All Requests":
        fetchDataByAllStatus(0, API_ENDPOINTS.eDak_GetRequestsRoleBased, accessToken);
        setSelectedView(dakId);
        break;
      case "Draft Requests":
        fetchDataDraftStatus(enumsObj.status.find((x) => x.dValue === "Draft").id, API_ENDPOINTS.eDak_GetRequestsRoleBased, accessToken);
        setSelectedView(dakId);
        break; 
      case "In Progress":
        fetchDataByAllPendingStatus(enumsObj.status.find((x) => x.dValue === "In Progress").id, API_ENDPOINTS.eDak_GetRequestsRoleBased, accessToken);
        setSelectedView(dakId);
        break; 
      case "Closed":
        fetchDataByAllClosedStatus(enumsObj.status.find((x) => x.dValue === "Closed").id, API_ENDPOINTS.eDak_GetRequestsRoleBased, accessToken);
        setSelectedView(dakId);
        break;
      case "Pending for close":
        fetchDataByPendingForCloseStatus(enumsObj.status.find((x) => x.dValue === "Rejected").id, API_ENDPOINTS.eDak_GetRequestsRoleBased, accessToken);
        setSelectedView(dakId);
        break;
      default:
        fetchDataByPendingForCloseStatus(0, API_ENDPOINTS.eDak_GetRequestsRoleBased, accessToken);
        setSelectedView("All Requests");
        return 0;
    }
  };

  const switchdakId = async (id) => {
    setCurrentHeading(id);
    setIsLoading(true);
    getRequestByStatus(id);
  }
  useEffect(() => {
    switchdakId(id); // Set the default dakId
  }, [id]);

  const fetchDataByAllStatus = async (status, endPoint, accessToken) => {
    setFilterValue('');
    try {
      const response = 
        await fetch(`${API_BASE_URL}${API_ENDPOINTS.eDak_GetAllRequest}`,
        {
          method: "POST",
          body: JSON.stringify({
            createdBy: accounts[0].username,
          }),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        });
  
      if (response.ok) {
        const apiOutput = await response.json();
  
        const resData = apiOutput?.viewList;
        const apiData = orderBy(resData, [{ field: "dakId", dir: "desc" }]);
        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const fetchDataByAllPendingStatus = async (status, endPoint, accessToken) => {
    setFilterValue('');
    try {
      const response = 
        await fetch(`${API_BASE_URL}${API_ENDPOINTS.eDak_GetAllProgress}`,
        {
          method: "POST",
          body: JSON.stringify({
            createdBy: accounts[0].username,
          }),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        });
  
      if (response.ok) {
        const apiOutput = await response.json();
        
        const resData = apiOutput?.viewList;
        const apiData = orderBy(resData, [{ field: "dakId", dir: "desc" }]);
        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const fetchDataDraftStatus = async (status, endPoint, accessToken) => {
    setFilterValue('');
    try {
      const response = 
        await fetch(`${API_BASE_URL}${API_ENDPOINTS.Get_Draft_Requests}`,
        {
          method: "POST",
          body: JSON.stringify({
            createdBy: accounts[0].username,
          }),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        });
  
      if (response.ok) {
        const apiOutput = await response.json();
        
        const resData = apiOutput?.viewList;
        const apiData = orderBy(resData, [{ field: "dakId", dir: "desc" }]);
        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const fetchDataByAllClosedStatus = async (status, endPoint, accessToken) => {
    setFilterValue('');
    try {
      const response = 
        await fetch(`${API_BASE_URL}${API_ENDPOINTS.eDak_GetClosed}`,
        {
          method: "POST",
          body: JSON.stringify({
            createdBy: accounts[0].username,
          }),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        });
  
      if (response.ok) {
        const apiOutput = await response.json();
        const resData = apiOutput?.viewList;
        const apiData = orderBy(resData, [{ field: "dakId", dir: "desc" }]);
        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const fetchDataByPendingForCloseStatus = async (status, endPoint, accessToken) => {
    setFilterValue('');

    try {
      const response = 
        await fetch(`${API_BASE_URL}${API_ENDPOINTS.eDak_GetAllPendingForClose}`,
        {
          method: "POST",
          body: JSON.stringify({
            createdBy: accounts[0].username,
          }),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        });
  
      if (response.ok) {
        const apiOutput = await response.json();
        const resData = apiOutput?.viewList;
        const apiData = orderBy(resData, [{ field: "dakId", dir: "desc" }]);
        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiData.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );
  const dataStateChange = (event) => {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );
  const setSelectedValue = (data) => {
    let newData = data.map((item) => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items),
        };
      } else {
        return {
          ...item,
          ["selected"]: currentSelectedState[idGetter(item)],
        };
      }
    });
    return newData;
  };
  const newData = setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: [],
  });

  const onHeaderSelectionChange = React.useCallback(
    (event) => {
      const checkboxElement = event.syntheticEvent.target;
      const checked = checkboxElement.checked;

      // Check if data is defined and an array
      const newSelectedState = {};
      data.forEach((item) => {
        newSelectedState[idGetter(item)] = checked;
      });

      setCurrentSelectedState(newSelectedState);

      const newData = data.map((item) => ({
        ...item,
        [SELECTED_FIELD]: checked,
      }));

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);
    },
    [data, dataState]
  );

  const onSelectionChange = (event) => {
    const selectedProductId = event.dataItem.dakId;

    const newData = data.map((item) => {
      if (item.dakId === selectedProductId) {
        item.selected = !item.selected;
      }
      return item;
    });

    setCurrentSelectedState((prevState) => ({
      ...prevState,
      [selectedProductId]: !prevState[selectedProductId],
    }));

    const newDataResult = processWithGroups(newData, dataState);
    setDataResult(newDataResult);
  };

  const getNumberOfItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfItems(item.items);
      } else {
        count++;
      }
    });
    return count;
  };

  const getNumberOfSelectedItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfSelectedItems(item.items);
      } else {
        count = count + (item.selected === true ? 1 : 0);
      }
    });
    return count;
  };

  const checkHeaderSelectionValue = () => {
    let selectedItems = getNumberOfSelectedItems(newData);
    return newData.length > 0 && selectedItems == getNumberOfItems(newData);
  };

  let _pdfExport;
  const exportExcel = () => {
    _export.save();
  };

  let _export;
  const exportPDF = () => {
    _pdfExport.save();
  };

  const exportCSVHeader = (id) => {

    let hdrColumn;

    switch (id) {
      case "Closed":
        hdrColumn = [
          { key: "dakNumber", label: "Dak#" },
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key : "subject", label: "Subject" },
          { key: "strStatus", label: "Status" },
          { key: "createdDate", label: "Created Date" },
          { key: "modifiedDate", label: "Modified Date" },
        ];
        break;
      // case "Noted Notes":
      //   hdrColumn = [
      //     { key: "dakNumber", label: "Note#" },
      //     { key: "createdByName", label: "Requester" },
      //     { key: "departmentName", label: "Department" },
      //     { key: "subject", label: "Subject" },
      //     { key: "strStatus", label: "Status" },
      //     { key: "createdDate", label: "Created Date" },
      //     { key: "modifiedDate", label: "Modified Date" },
      //   ];
      //   break;
        case "All Requests":
          hdrColumn = [
            { key: "dakNumber", label: "Dak#" },
            { key: "createdByName", label: "Requester" },
            { key: "departmentName", label: "Department" },
            { key: "subject", label: "Subject" },
            { key: "strStatus", label: "Status" },
            // { key: "currentActionerName", label: "Current Approver" },
            { key: "modifiedDate", label: "Modified Date" },
            { key: "createdDate", label: "Created Date" },
          ];
        break;
        case "In Progress":
          hdrColumn = [
            { key: "dakNumber", label: "Dak#" },
            { key: "createdByName", label: "Requester" },
            { key: "departmentName", label: "Department" },
            { key: "subject", label: "Subject" },
            { key: "strStatus", label: "Status" },
            // { key: "currentActionerName", label: "Current Approver" },
            { key: "modifiedDate", label: "Modified Date" },
            { key: "createdDate", label: "Created Date" },
          ];
          break;
          case "Pending for close":
            hdrColumn = [
              { key: "dakNumber", label: "Dak#" },
              { key: "createdByName", label: "Requester" },
              { key: "departmentName", label: "Department" },
              { key: "subject", label: "Subject" },
              { key: "strStatus", label: "Status" },
              // { key: "currentActionerName", label: "Current Approver" },
              { key: "modifiedDate", label: "Modified Date" },
              { key: "createdDate", label: "Created Date" },
            ];
            break;
      default:
        hdrColumn = [
          { key: "dakNumber", label: "Dak" },
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          { key: "strStatus", label: "Status" },
          // { key: "currentActionerName", label: "Current Approver" },
          { key: "modifiedDate", label: "Modified Date" },
          { key: "createdDate", label: "Created Date" },
        ];
    }
    return hdrColumn;
  }

  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    let columnsConfig = [];

    switch (id) {
      case "Closed":
        columnsConfig = [
          { field: "dakNumber", title: "Dak#" },
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "subject", title: "Subject" },
          { field: "createdDate", title: "Created Date" },
          { field: "modifiedDate", title: "Modified Date" },
        ];
        break;
      // case "Noted Notes":
      //   columnsConfig = [
      //     { field: "dakNumber", title: "Dak#" },
      //     { field: "createdByName", title: "Requester" },
      //     { field: "departmentName", title: "Department" },
      //     { field: "subject", title: "Subject" },
      //     { field: "createdDate", title: "Created Date" },
      //     { field: "modifiedDate", title: "Modified Date" },
      //   ];
      //   break;
       
        case "All Requests":
          columnsConfig = [
            { field: "dakNumber", title: "Dak#" },
            { field: "createdByName", title: "Requester" },
            { field: "departmentName", title: "Department" },
            { field: "subject", title: "Subject" },
            { field: "strStatus", title: "Status" },
            // { field: "currentActionerName", title: "Current Approver" },
            { field: "modifiedDate", title: "Modified Date" },
            { field: "createdDate", title: "Created Date" },
          ];
        break;
        case "In Progress":
          columnsConfig = [
            { field: "dakNumber", title: "Dak#" },
            { field: "createdByName", title: "Requester" },
            { field: "departmentName", title: "Department" },
            { field: "subject", title: "Subject" },
            { field: "strStatus", title: "Status" },
            // { field: "currentActionerName", title: "Current Approver" },
            { field: "modifiedDate", title: "Modified Date" },
            { field: "createdDate", title: "Created Date" },
          ];
          break;
          case "Pending for close":
            columnsConfig = [
              { field: "dakNumber", title: "Dak#" },
              { field: "createdByName", title: "Requester" },
              { field: "departmentName", title: "Department" },
              { field: "subject", title: "Subject" },
              { field: "strStatus", title: "Status" },
              // { field: "currentActionerName", title: "Current Approver" },
              { field: "modifiedDate", title: "Modified Date" },
              { field: "createdDate", title: "Created Date" },
            ];
            break;
      default:
        columnsConfig = [
          { field: "dakNumber", title: "Dak#" },
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "subject", title: "Subject" },
          { field: "strStatus", title: "Status" },
          // { field: "currentActionerName", title: "Current Approver" },
          { field: "modifiedDate", title: "Modified Date" },
          { field: "createdDate", title: "Created Date" },
        ];
    }

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "dakNumber" ? (
            <td>
              <Link
                style={customStyles.columnColor}
                to={
                  ((props.dataItem["status"] === 1 ||
                  props.dataItem["status"] === 3)
                   &&
                  props.dataItem["createdBy"] === accounts[0].username)
                    ? `/eDakform/${props.dataItem["dakId"]}`
                    : `/eDakViewForm/${props.dataItem["dakId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {column.title.includes("Date")
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A") //seconds hand removed
                : props.dataItem[column.field]
                ? props.dataItem[column.field]
                : ""}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  return (
    <div>
      <Navbar header="IB Smart Office - eDak" />
      <Sidebar />
      <div className="container cstGridContainer datagridpage">
        <div className="SectionHeads row mobileSectionHeads">{currentHeading}</div>
        {/* Add a section for displaying headings and allow the user to switch between them*/}
        {isLoading ? (
          <PageLoader />
        ) : (
          <Grid
            className="cstGridStyles"
            // pageable={{ pageSizes: true }}
            pageable={{ pageSizes: [5, 10, 15, 20] }}
            data={dataResult}
            sortable={true}
            total={resultState.total}
            onDataStateChange={dataStateChange}
            {...dataState}
            onExpandChange={onExpandChange}
            expandField="expanded"
            dataItemKey={DATA_ITEM_KEY}
            size={"small"}
            resizable={true}
          >
            <GridToolbar>
              <Input
                value={filterValue}
                onChange={onFilterChange}
                style={customStyles.filterStyle}
                placeholder="Search in all columns..."
              />
              <div className="export-btns-container">
                <Button style={customStyles.exportCSV}>
                  <CSVLink
                    filename={`eDak-${selectedView.replace(
                      / /g,
                      ""
                    )}${new DateObject(new Date()).format("DDMMYYYYhhmmss")}`}
                    data={filteredData.map((x) => ({...x, modifiedDate: new DateObject( new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm A"), //seconds hand removed 
                    createdDate: new DateObject( new Date(x.createdDate) ).format("DD-MMM-YYYY hh:mm A"),}))}
                    headers={exportCSVHeader(currentHeading)}
                  >
                    Export CSV
                  </CSVLink>
                </Button>
              </div>
            </GridToolbar>
            {renderColumnsWithData(dataResult)}
          </Grid>
        )}
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};

export default Views;

const customStyles = {
  exportCSV:{ marginLeft: "5px" },
  filterStyle:{border: "2px solid #ccc",boxShadow: "inset 0px 0px 0.5px 0px rgba(0,0,0,0.0.1)",width: "170px",height: "30px",marginRight: "10px"},
  columnColor: { color: "red" }
}
