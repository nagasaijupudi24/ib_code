import React, { useState, useEffect } from 'react';
// Import Kendo Components
import { getter } from '@progress/kendo-react-common';
import { process } from '@progress/kendo-data-query';
import { Input } from '@progress/kendo-react-inputs';
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { Form, FormElement, FieldWrapper } from '@progress/kendo-react-form';
import { Label } from "@progress/kendo-react-labels";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { CSVLink } from "react-csv";
import { Button } from '@progress/kendo-react-buttons';
import { Grid, GridColumn as Column, GridToolbar } from '@progress/kendo-react-grid';
import { setGroupIds } from '@progress/kendo-react-data-tools';
import { MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
import { Dialog, DialogActionsBar } from '@progress/kendo-react-dialogs';
// Import Kendo icon Components
import { SvgIcon } from "@progress/kendo-react-common";
import { infoCircleIcon } from '@progress/kendo-svg-icons';
import { xIcon } from "@progress/kendo-svg-icons";
// Import External Libraries
import { Link } from 'react-router-dom';
import { useMsal, useAccount } from "@azure/msal-react";
import DateObject from 'react-date-object';
// Import components
import Navbar from '../components/navbar.jsx';
import { Sidebar } from '../components/sidebar.jsx';
import Footer from '../components/footer.jsx';
import { API_BASE_URL, API_ENDPOINTS } from '../config.js';
import { PageLoader } from "../components/pageLoader.jsx";
import { getAccessToken } from "../App.js";
import { loginRequest } from "../config.js";
import { API_COMMON_HEADERS } from '../config.js';
import { ColumnMenu } from './custom-cells.jsx';
// Import CSS styles
import "../styles/datagridpage.css";
import "../styles/responsiveDesign.css";

const CustomDialogTitleBar = () => {
  return (
    <div
      className="custom-title">
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};

//Added this function due to loading impact users will be filtered on search box enter - 25/03
const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",
  },
  {
    field: "srNo",
    header: "SR No",
    width: "120px",
  },
];
// mobile view responsive
const mobileColumns = [
  {
    field: "displayName",
    header: "Person Name",
    width: "100px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "100px",
  },
  {
    field: "srNo",
    header: "SR No",
    width: "70px",
  },
];
const DATA_ITEM_KEY = 'id';
const initialDataState = {
  take: 10,
  skip: 0,
  group: []
};
const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group
  });
  return newDataState;
};

export const SearcheDak = () => {

  // Value render clears the value in field when we click on close icon in dropdown
  const valueRender = (element, value, fieldName) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
     if(fieldName ==="SType"){
      setSearchSourceType("")
     }
     if(fieldName === "MType"){
      setSearchMovementType("");
     }
     if(fieldName === "DType"){
      setSearchDocumenttype("");
     }
     if(fieldName ==="Status"){
      setSearcheDakStatus("")
     }
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} style={{
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        flexGrow: 1
      }}>
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props,
    }, children);
  };
  // change -13/05  clear  department Value 
  const valueRenderDepartment = (element, value) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      setSearchDepartment("");
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} style={{
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        flexGrow: 1
      }}>
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props
    }, children);
  };
  const idGetter = getter('id');
  const [filterValue, setFilterValue] = useState('');
  const [filteredData, setFilteredData] = useState([]);
  const [currentSelectedState, setCurrentSelectedState] = useState({});
  const [dataState, setDataState] = useState(initialDataState);
  const [dataResult, setDataResult] = useState(process(filteredData, dataState));
  const [data, setData] = useState(filteredData);
  const [apiData, setApiData] = useState([]);
  const [eDakstatus, setEdakStatus] = useState([]);
  const [searcheDakstatue, setSearcheDakStatus] = useState('');
  const [searcheDak, setSearcheDak] = useState('');
  const [searchDepartment, setSearchDepartment] = useState('')
  const [selectedFromDate, setSelectedFromDate] = useState(null);
  const [selectedToDate, setSelectedToDate] = useState(null);
  const [selectedYear, setSelectedYear] = useState('');
  const [searchText, setSearchText] = useState('');
  const [searchSubject, setSearchSubject] = useState('');
  const [searchRequester, setSearchRequester] = useState('');
  const [showNotification, setShowNotification] = useState(false);
  const [showNotificationMsg, setShowNotificationMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [enumsObj, setEnumsObj] = useState(false);
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [sourceType, setsourceType] = useState([]);
  const [searchSourceType, setSearchSourceType] = useState("");
  const [MovementType, setMovementType] = useState([]);
  const [searchMovementType, setSearchMovementType] = useState("");
  const [DocumentType, setDocumenttype] = useState([]);
  const [searchDocumentType, setSearchDocumenttype] = useState("");
  const [departmentList, setDepartmentList] = useState([]);
  const isMobile = window.innerWidth <= 768;
  const delay = 100
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      try {
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

        //get enum objects
        const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
        });

        const dropdownslist = await dropdowns.json();
        getDepartmentList();
        setEnumsObj(dropdownslist);
        setsourceType(dropdownslist.sourceType);
        setMovementType(dropdownslist.movementType);
        setDocumenttype(dropdownslist.DocumentType);
        setEdakStatus(dropdownslist.DaksSearchStatus);
        setIsLoading(false)
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);


  // Change 13/05 API call for department list
  const getDepartmentList = async () => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const obj = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_Department_List}`
      , {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }
    );
    const departmentDetailsList = await obj.json();
    setDepartmentList(departmentDetailsList)
    console.log(departmentDetailsList, "departmentDetailsList");


  }

  // const onFilterChange = (ev) => {
  //   let value = ev.value;
  //   setFilterValue(value);

  //   if (!value) {
  //     setFilteredData(apiData);
  //     setDataResult(process(apiData, (dataState) => ({ ...dataState, total: apiData.length })));
  //   } else {
  //     let newData = apiData.filter((item) => {
  //       for (const property in item) {
  //         if (
  //           item[property] &&
  //           typeof item[property] === 'string' && // Check if property is a string
  //           item[property].toString().toLocaleLowerCase().includes(value.toLocaleLowerCase())
  //         ) {
  //           return true;
  //         }
  //         if (
  //           item[property] &&
  //           item[property].toLocaleDateString && 
  //           typeof item[property].toLocaleDateString === 'function' && // Check if property has toLocaleDateString method
  //           item[property].toLocaleDateString().includes(value)
  //         ) {
  //           return true;
  //         }
  //       }
  //       return false;
  //     });

  //     let clearedPagerDataState = {
  //       ...dataState,
  //       take: 10,
  //       skip: 0,
  //     };
  //     let processedData = process(newData, clearedPagerDataState);
  //     setDataResult(processedData);
  //     setDataState({ ...clearedPagerDataState, total: newData.length });
  //     setData(newData);
  //   }
  // };
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };
  const [resultState, setResultState] = useState(processWithGroups(apiData.map(item => ({
    ...item,
    ['selected']: currentSelectedState[idGetter(item)]
  })), initialDataState));

  const dataStateChange = event => {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };

  const onExpandChange = React.useCallback(event => {
    const newData = [...dataResult.data];
    const item = event.dataItem;
    if (item.groupId) {
      const targetGroup = newData.find(d => d.groupId === item.groupId);
      if (targetGroup) {
        targetGroup.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData
        });
      }
    } else {
      item.expanded = event.value;
      setDataResult({
        ...dataResult,
        data: newData
      });
    }
  }, [dataResult]);

  // const setSelectedValue = data => {
  //   let newData = data.map(item => {
  //     if (item.items) {
  //       return {
  //         ...item,
  //         items: setSelectedValue(item.items)
  //       };
  //     } else {
  //       return {
  //         ...item,
  //         ['selected']: currentSelectedState[idGetter(item)]
  //       };
  //     }
  //   });
  //   return newData;
  // };

  // const newData = setExpandedState({
  //   data: setSelectedValue(resultState.data),
  //   collapsedIds: []
  // });

  // const getNumberOfItems = data => {
  //   let count = 0;
  //   data.forEach(item => {
  //     if (item.items) {
  //       count = count + getNumberOfItems(item.items);
  //     } else {
  //       count++;
  //     }
  //   });
  //   return count;
  // };

  // const getNumberOfSelectedItems = data => {
  //   let count = 0;
  //   data.forEach(item => {
  //     if (item.items) {
  //       count = count + getNumberOfSelectedItems(item.items);
  //     } else {
  //       count = count + (item.selected == true ? 1 : 0);
  //     }
  //   });
  //   return count;
  // };

  const exportCSVHeader = () => {
    return [
      { key: 'dakNumber', label: 'Letter#' },
      { key: 'subject', label: 'Subject' },
      { key: 'strMovementType', label: 'Movement Type' },
      { key: 'actionTypeName', label: 'Action Type' },
      { key: 'followUpDate || targetDate', label: 'Followup/Target Date' },
      { key: 'strDaksStatus', label: 'Status' },
      { key: 'acknowledgedDate', label: 'Acknowledged Date' },
      { key: 'closeDate', label: 'Completed Date' },
    ];
  }

  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }
    const columnsConfig = [
      { field: 'dakNumber', title: 'Letter#', },
      { field: 'subject', title: 'Subject' },
      { field: 'strMovementType', title: 'Movement Type' },
      { field: 'actionTypeName', title: 'Action Type' },
      { field: 'followUpDate', title: 'Followup/Target Date' },
      { field: 'strDaksStatus', title: 'Status' },
      { field: 'acknowledgedDate', title: 'Acknowledged Date' },
      { field: 'closeDate', title: 'Completed Date' },
    ];


    // return columnsConfig.map((column) => (
    //   <Column
    //   key={column.field}
    //   field={column.field}
    //   title={column.title}
    //   cell={(props) =>

    //     column.field === "dakNumber" ? (
    //       <td>
    //         <Link
    //           target='_blank'
    //           style={customStyles.columnColor}
    //           to={
    //             (props.dataItem["strDaksStatus"] === "Draft" ||
    //               props.dataItem["strDaksStatus"] === "Returned") &&
    //               props.dataItem["createdBy"] === accounts[0].username
    //               ? `/eDakform/${props.dataItem["dakId"]}`
    //               : `/eDakviewform/${props.dataItem["dakId"]}`
    //           }
    //         >
    //           {props.dataItem[column.field]}
    //         </Link>
    //       </td>
    //     ) : (
    //       <td>
    //         {column.title.includes("Date") && props.dataItem[column.field]
    //           ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm:ss A")
    //           : props.dataItem[column.field]
    //             ? props.dataItem[column.field]
    //             : ""}
    //       </td>
    //     )
    //   }
    //   columnMenu={ColumnMenu}
    // />
    // ));
    // bug 357 ==> Follow up date and target date is not updated
    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "dakNumber" ? (
            <td>
              <Link
                target='_blank'
                style={customStyles.columnColor}
                to={
                  (props.dataItem["strDaksStatus"] === "Draft" ||
                    props.dataItem["strDaksStatus"] === "Returned") &&
                    props.dataItem["createdBy"] === accounts[0].username
                    ? `/eDakform/${props.dataItem["dakId"]}`
                    : `/eDakviewform/${props.dataItem["dakId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {column.title.includes("Date") && props.dataItem[column.field]
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A") //Remove seconds hand
                : column.field === "followUpDate" && props.dataItem[column.field]
                  ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A")//Remove seconds hand
                  : column.field === "followUpDate" && !props.dataItem[column.field] && props.dataItem["targetDate"]
                    ? new DateObject(new Date(props.dataItem["targetDate"])).format("DD-MMM-YYYY hh:mm A")//Remove seconds hand
                    : props.dataItem[column.field]
                      ? props.dataItem[column.field]
                      : ""}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));

  };

  /* Search Functionality */

  const handleSearch = async () => {
    if (
      searcheDak === "" &&
      (searchRequester === "" || searchRequester === null) &&
      searchDepartment === "" &&
      searchText === "" &&
      selectedFromDate === null &&
      selectedToDate === null &&
      selectedYear === "" &&
      searcheDakstatue === "" &&
      searchSubject === "" &&
      searchDocumentType === "" &&
      searchMovementType === "" &&
      searchSourceType === ""
    ) {
      setShowNotification(true);
      setShowNotificationMsg(
        "Please fill atleast any one of the field to search."
      );
      return;
    }
    setIsLoading(true);
    try {
      const params = {
        "dakNumber": searcheDak || null,
        "createdBy": searchRequester.userPrincipalName || null,
        "departmentName": searchDepartment || null,
        "searchKeyword": searchText || null,
        "fromDate": selectedFromDate ? new DateObject(new Date(selectedFromDate)).format("DD-MM-YYYY") : null,
        "ToDate": selectedToDate ? new DateObject(new Date(selectedToDate)).format("DD-MM-YYYY") : null,
        "status": searcheDakstatue ? enumsObj.DaksSearchStatus.find(x => x.dValue === searcheDakstatue).id : 0,
        "subject": searchSubject || null,
        "sourceType": searchSourceType ? enumsObj.sourceType.find(x => x.dValue === searchSourceType).id : 0,
        "movementType": searchMovementType ? enumsObj.movementType.find(x => x.dValue === searchMovementType).id : 0,
        "documentType": searchDocumentType ? enumsObj.DocumentType.find(x => x.dValue === searchDocumentType).id : 0,
      }
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      await fetch(`${API_BASE_URL}${API_ENDPOINTS.eDak_SearchDaks}`, {
        method: 'POST',
        body: JSON.stringify(params),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }).then(response => {
        return response.json();
      }).then(data => {
        setIsLoading(false);
        const apiRespData = data;
        setApiData(apiRespData);
        const newDataResult = process(apiRespData, dataState);
        setDataResult(newDataResult);
        setDataState({ ...dataState, total: apiRespData.length });
        setFilteredData(apiRespData); // Update filteredData after other state updates

      })
    } catch (error) {
      console.error('Error fetching data:', error);
      setIsLoading(false)
    }
  };

  const handleClear = () => {
    setFilterValue('');
    setFilteredData([]);
    setApiData([]);
    setDataResult(process([], initialDataState)); // Reset data state
    setSearcheDak('');
    setSearchDepartment('');
    setSearchText('');
    setSelectedFromDate(null);
    setSelectedToDate(null);
    setSearchRequester({ department: "", displayName: "", jobTitle: "", userPrincipalName: "" });
    setSearchSubject('');
    setSelectedYear(null);
    setSearcheDakStatus('');
    setSearchMovementType('')
    setSearchSourceType('')
    setSearchDocumenttype('')
  };
  /* Search Requester and Approver */
  const [data1, setData1] = useState([]);

  //filter the users dropdown data
  const filterChange = async (event) => {
    if (event.filter.value.length >= 4) {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            return { department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName }
          });
          setData1(orgUsers);
        })
        .catch((err) => {
          setData1([]);
          console.log(err);
        });
    }
  };

  return (
    <div>
      <Navbar />
      <Sidebar />
      <div className="container datagridpage searchNoteContainer">
        <div className="SectionHeads row mobileSectionHeads">Search Parameters</div>
        <div className="container datagridpage" style={customStyles.dataGridPage}>
          <Form
            id="searchForm"
            render={() => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="SectionRow row">
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Letter#:</Label>
                          <Input
                            name="Dak#"
                            value={searcheDak}
                            onChange={(e) => setSearcheDak(e.target.value)}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Requester:</Label>
                          <MultiColumnComboBox
                            name="Requester"
                            data={data1}
                            filterable={true}
                            // columns={orgUsersPplPickerColumnMapping}
                            columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                            style={{ width: isMobile ? "100%" : "100%" }} 
                            onFilterChange={filterChange}
                            value={searchRequester.displayName}
                            onChange={(e) => e.value === null ? setSearchRequester({ department: "", displayName: "", jobTitle: "", userPrincipalName: "" }) : setSearchRequester(e.value)}
                            placeholder="Search Requester..."
                          />
                          <span className='cstUserSearchMsg'>(Please enter minimum 4 characters to find the user)</span>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Department:</Label>
                          <Input
                            name="Department"
                            value={searchDepartment}
                            defaultValue=""
                            onChange={(e) =>
                              setSearchDepartment(e.target.value)
                            }
                          />

                          {/* <DropDownList
                            data={departmentList.map((x) => x.departmentName)}
                            // defaultItem={"Select"}
                            onChange={(e) =>
                              setSearchDepartment(e.target.value)
                            }
                            value={searchDepartment}
                            defaultValue=""
                            name="DepartMent"
                            // required={true}
                            valueRender={element => valueRenderDepartment(element, searchDepartment)}
                          /> */}
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Search Text:</Label>
                          <Input
                            name="search"
                            value={searchText}
                            onChange={(e) => setSearchText(e.target.value)}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">From Date:</Label>
                          <DatePicker
                            max={new Date()}
                            placeholder="From Date..."
                            onChange={(event) =>
                              setSelectedFromDate(event.target.value)
                            }
                            format={"dd-MM-yyyy"}
                            value={selectedFromDate}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">To Date:</Label>
                          <DatePicker
                            min={new Date(selectedFromDate)}
                            max={new Date()}
                            placeholder="To Date..."
                            onChange={(event) =>
                              setSelectedToDate(event.target.value)
                            }
                            format={"dd-MM-yyyy"}
                            value={selectedToDate}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Status:</Label>
                          <DropDownList
                            data={eDakstatus.map((x) => x.dValue)}
                            value={searcheDakstatue}
                            onChange={(e) =>
                              setSearcheDakStatus(e.target.value)
                            }
                            valueRender={element => valueRender(element, searcheDakstatue, 'Status')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Subject:</Label>
                          <Input
                            name="Subject"
                            value={searchSubject}
                            onChange={(e) => setSearchSubject(e.target.value)}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Source Type:</Label>
                          <DropDownList
                            data={sourceType.map((x) => x.dValue)}
                            value={searchSourceType}
                            onChange={(e) => setSearchSourceType(e.target.value)}
                            valueRender={element => valueRender(element, searchSourceType, 'SType')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Movement Type:</Label>
                          <DropDownList
                            data={MovementType.map((x) => x.dValue)}
                            value={searchMovementType}
                            onChange={(event) =>
                              setSearchMovementType(event.target.value)
                            }
                            valueRender={element => valueRender(element, searchMovementType, 'MType')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Document Type:</Label>
                          <DropDownList
                            data={DocumentType.map((x) => x.dValue)}
                            value={searchDocumentType}
                            onChange={(event) =>
                              setSearchDocumenttype(event.target.value)
                            }
                            valueRender={element => valueRender(element, searchDocumentType, 'DType')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                  </div>
                </fieldset>
                <div className="FormButtonsContainer k-form-buttons">
                  <Button className="searchNoteBtns" onClick={handleSearch}>
                    <span className="k-icon-xs k-icon k-font-icon  k-i-search cursor searchBtnStyles"></span>
                    Search
                  </Button>
                  <Button onClick={handleClear}>
                    <span className="k-icon-sm k-icon k-font-icon  k-i-reset-sm cursor searchBtnStyles"></span>
                    Clear
                  </Button>
                </div>
              </FormElement>
            )}
          />
        </div>
        <div className="SectionHeads row" style={customStyles.header}>
          Search Results
        </div>
        {isLoading ? (
          <PageLoader />
        ) : (
          <Grid
            style={customStyles.grid}
            // pageable={{ pageSizes: true }}
            pageable={{ pageSizes: [5, 10, 15, 20] }}
            data={dataResult}
            sortable={true}
            total={resultState.total}
            onDataStateChange={dataStateChange}
            {...dataState}
            onExpandChange={onExpandChange}
            expandField="expanded"
            dataItemKey={DATA_ITEM_KEY}
            size={"small"}
            resizable={true}
          >
            <GridToolbar>
              <Input
                value={filterValue}
                onChange={onFilterChange}
                style={customStyles.gridToolbar}
                placeholder="Search in all columns..."
              />{" "}
              <div className="export-btns-container">

                <Button style={customStyles.exportCSV}>
                  <CSVLink
                    filename={`eDak-SearchResult-${new DateObject(
                      new Date()
                    ).format("DDMMYYYY")}`}
                    data={filteredData}
                    headers={exportCSVHeader()}
                  >
                    Export CSV
                  </CSVLink>
                </Button>
              </div>
            </GridToolbar>
            {renderColumnsWithData(dataResult)}
          </Grid>
        )}
      </div>
      {showNotification && (
        <Dialog
          title={<CustomDialogTitleBar />}
          onClose={() => setShowNotification(false)}
        >
          <p style={customStyles.notificationDialog}>
            {showNotificationMsg}
          </p>
          <DialogActionsBar>
            <Button
              className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
              onClick={() => setShowNotification(false)}
            >
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};

// Customized system styles can be inserted into a div elements
const customStyles = {
  notificationDialog: { margin: "25px", textAlign: "center", width: "500px", fontWeight: 500 },
  gridToolbar: { border: "2px solid #ccc", boxShadow: "inset 0px 0px 0.5px 0px rgba(0,0,0,0.0.1)", width: "170px", height: "30px", marginRight: "10px" },
  grid: { height: "550px", bottom: "30px", marginLeft: "auto", marginRight: "auto" },
  header: { marginBottom: "40px" },
  dataGridPage: { marginTop: "10px" }, columnColor: { color: "red" }, exportCSV: { marginLeft: "5px" }
}