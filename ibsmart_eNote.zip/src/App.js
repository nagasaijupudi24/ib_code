import { useEffect,createContext, useContext, useState } from "react";
// import external components 
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useIsAuthenticated,
} from "@azure/msal-react";
import * as Msal from "msal";
import { useMsalAuthentication } from "@azure/msal-react";
import { InteractionType } from "@azure/msal-browser";
import { useMsal, useAccount } from '@azure/msal-react';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import internal components and pages
import { Landingpage } from "./pages/landingpage";
import { ENoteHome } from "./pages/eNoteHome.jsx";
import { ENoteNewForm } from "./pages/eNoteNewForm.jsx";
import { ENoteViewForm } from "./pages/eNoteViewForm.jsx";
import { ENoteAtrworkflowform } from "./pages/eNoteAtrworkflowform.jsx";
import { msalConfig } from "./config.js";
import { SearchNotes } from "./pages/searchnotes.jsx";
import { ENotePasscode } from "./pages/eNotePasscode.jsx"
import Views from "./pages/eNoteViews.jsx";
import ATRViews from "./pages/ATRViews.jsx";
import PageNotFound from "./pages/404page.jsx";
import AdminDashBoardChartReports from "./pages/DashbaordReportforAdmin.jsx";
// Initialize MSAL application object
const userAgentApplication = new Msal.UserAgentApplication(msalConfig);
const request = {
  scopes: ['User.Read', 'User.ReadBasic.All', 'email'],
};

// Function to get access token
export const getAccessToken = async (loginRequest, instance) => {
  try {
    const response = await instance.acquireTokenSilent(loginRequest);
    return response.accessToken;
  } catch (error) {
    console.error("Failed to get access token:", error);
    throw new Error("Failed to get access token");
  }
}
const TabContext = createContext();

export const useTabContext = () => useContext(TabContext);
function App() {
  const isAuthenticated = useIsAuthenticated();
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [activeTab, setActiveTab] = useState('My Notes'); // Default active tab
  const [passcodenaviagate, setPasscodeNaviage] = useState('New'); // Default passcode page redirect
  const [passcodeData, setPasscodeData] = useState(null);
  // Added for page redirect to my peding notes after any action
  const setTab = (tabName) => {
    setActiveTab(tabName);
  };
  // Added for page redirect to view page after creating passcode --> Kavya(23/07)
  const setPasscodeNavigate = (pageName) => {
    setPasscodeNaviage(pageName);
  }

  // Auto redirect to login
  useMsalAuthentication(InteractionType.Redirect);

  useEffect(() => {
    async function getTokenSilently() {
      const tokenRequest = {
        // scopes: ['User.Read', 'User.ReadBasic.All'],
        // loginHint: accounts[0].username,
        account,
      };

      await instance.acquireTokenSilent(tokenRequest);
      // dispatch({ type: AuthActions.SET_TOKEN, payload: res.accessToken });
      // dispatch({ type: AuthActions.SET_CLAIMS, payload: accounts[0].username });
    }
    if (isAuthenticated && inProgress === 'none') {
      getTokenSilently();
    }
  }, [isAuthenticated]);

  return (
    <div className="App">
      <AuthenticatedTemplate>
        {/* <ENoteHome> */}
        <TabContext.Provider value={{ activeTab, setTab, setPasscodeNavigate, passcodenaviagate, passcodeData, setPasscodeData }}>
        <Router>
          <Routes>
            <Route path="/" element={<ENoteHome />} />
            <Route path="/datagridpage" element={<ENoteHome />} />
            <Route path="/searchnotes" element={<SearchNotes />} />
            <Route path="/enoteform/:id" element={<ENoteNewForm />} />
            <Route path="/enoteviewform/:id" element={<ENoteViewForm />} />
            <Route path="/views/:id" element={<Views />} />
            <Route path="/atrviews/:id" element={<ATRViews />} />
            <Route
              path="/eNoteAtrworkflowform/:id"
              element={<ENoteAtrworkflowform />}
            />
            <Route
              path="/dashBoardReports"
              element={<AdminDashBoardChartReports />}
            />
             <Route path="/enotepasscode" element={<ENotePasscode />} /> 
            <Route path="*"  element={<PageNotFound />}/>
          </Routes>
        </Router>
        </TabContext.Provider>
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
      <TabContext.Provider value={{ activeTab, setTab, setPasscodeNavigate, passcodenaviagate, passcodeData, setPasscodeData  }}>
        <Router>
          <Routes>
            <Route path="/" element={<Landingpage />} />
             {/* Commented because when ever we are opening direct link in new tab first it is displaying 404 page not found */}
            {/* <Route path="*" element={<PageNotFound />}/> */}
          </Routes>
        </Router>
        {/* </ENoteHome> */}
        </TabContext.Provider>
      </UnauthenticatedTemplate>
    </div>
  );
}
export default App;
