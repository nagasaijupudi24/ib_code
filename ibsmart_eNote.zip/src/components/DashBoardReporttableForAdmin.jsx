import React, { useState, useEffect } from "react";
// import kendo components
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
import { getter } from "@progress/kendo-react-common";
import { orderBy } from "@progress/kendo-data-query";
// import external components
import { useMsal, useAccount } from "@azure/msal-react";
import DateObject from "react-date-object";
// import internal components and pages
import { API_BASE_URL, API_ENDPOINTS, loginRequest, API_COMMON_HEADERS } from "../config";
import { ColumnMenu } from "../pages/custom-cells";
import { PageLoader } from "./pageLoader";
import { getAccessToken } from "../App";
// import css styles
import "../styles/datagridpage.css";
import "../styles/forms.css";

const initialSort = [
  {
    field: "modifiedDate",//noteId
    dir: "desc",
  },
];
const DATA_ITEM_KEY = "noteId";
// const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};

const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};
const AdminDashboardGrid = (props) => {
  const idGetter = getter(DATA_ITEM_KEY);
  const [filterValue, setFilterValue] = React.useState("");
  const [filteredData, setFilteredData] = React.useState();
  const [currentSelectedState, setCurrentSelectedState] = React.useState({});
  const [dataState, setDataState] = React.useState(initialDataState);
  const [data, setData] = React.useState(filteredData);
  const [apiData, setApiData] = React.useState([]);
  const [dataResult, setDateGrid] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});

  useEffect(() => {
if(props.departmentName){
    fetchApiData();
}
  }, [props]);
 
  const fetchApiData = async () => {
    setFilterValue('');
    if(props.departmentName){
      const Params = {
        "Department": (props.departmentName).replace(/&/g, "%26"),
        "fromDate": props.fromDate ? new DateObject(new Date(props.fromDate)).format("DD-MM-YYYY") : null,
        "ToDate":props.toDate ? new DateObject(new Date(props.toDate)).format("DD-MM-YYYY") : null,
    };
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account}, instance);
      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_DeatilsForPending}?Department=${Params.Department}&fromDate=${Params.fromDate}&ToDate=${Params.ToDate}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        }
      );

      if (response.ok) {
        const apiOutput = await response.json();
        const resData = apiOutput?.map((x, ind) => ({ ...x, SerialNo: ind + 1 }));
        const apiData = orderBy(resData, initialSort);
        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDateGrid(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDateGrid(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  }
  };

  // handle filter change
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);
    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);
      // }

      const newDataResult = processWithGroups(newData, dataState);
      setDateGrid(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDateGrid(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiData.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );

  // Handle dataState change
  const dataStateChange = (event) => {
    setDateGrid(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };

  // Handle onExpand Change
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDateGrid({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDateGrid({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );
  const setSelectedValue = (data) => {
    let newData = data.map((item) => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items),
        };
      } else {
        return {
          ...item,
          ["selected"]: currentSelectedState[idGetter(item)],
        };
      }
    });
    return newData;
  };
  const newData = setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: [],
  });

/*   const onHeaderSelectionChange = React.useCallback(
    (event) => {
      const checkboxElement = event.syntheticEvent.target;
      const checked = checkboxElement.checked;

      // Check if data is defined and an array
      // if (Array.isArray(data)) {
      const newSelectedState = {};
      data.forEach((item) => {
        newSelectedState[idGetter(item)] = checked;
      });

      setCurrentSelectedState(newSelectedState);

      const newData = data.map((item) => ({
        ...item,
        [SELECTED_FIELD]: checked,
      }));

      const newDataResult = processWithGroups(newData, dataState);
      setDateGrid(newDataResult);
      // }
    },
    [data, dataState]
  );
 */
 
  // const onSelectionChange = (event) => {
  //   const selectedProductId = event.dataItem.noteId;

  //   const newData = data.map((item) => {
  //     if (item.noteId === selectedProductId) {
  //       item.selected = !item.selected;
  //     }
  //     return item;
  //   });

  //   setCurrentSelectedState((prevState) => ({
  //     ...prevState,
  //     [selectedProductId]: !prevState[selectedProductId],
  //   }));

  //   const newDataResult = processWithGroups(newData, dataState);
  //   setDateGrid(newDataResult);
  // };
 
  // // Handle get NumberOfItems
  // const getNumberOfItems = (data) => {
  //   let count = 0;
  //   data.forEach((item) => {
  //     if (item.items) {
  //       count = count + getNumberOfItems(item.items);
  //     } else {
  //       count++;
  //     }
  //   });
  //   return count;
  // };

  // // Handle get NumberOfSelectedItems
  // const getNumberOfSelectedItems = (data) => {
  //   let count = 0;
  //   data.forEach((item) => {
  //     if (item.items) {
  //       count = count + getNumberOfSelectedItems(item.items);
  //     } else {
  //       count = count + (item.selected === true ? 1 : 0);
  //     }
  //   });
  //   return count;
  // };


 /*  const checkHeaderSelectionValue = () => {
    let selectedItems = getNumberOfSelectedItems(newData);
    return newData.length > 0 && selectedItems == getNumberOfItems(newData);
  }; */

/*   let _pdfExport;
  const exportExcel = () => {
    _export.save();
  };

  let _export;
  const exportPDF = () => {
    _pdfExport.save();
  };

  const exportCSVHeader = (id) => {

    let hdrColumn;

    switch (id) {
      case "All Approved":
        hdrColumn = [
          { key: "noteNumber", label: "Note#" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          { key: "createdDate", label: "Created Date" },
          // Bug fix - 298 - 27/03
          { key: "modifiedDate", label: "Modified Date" },
        ];
        break;
      case "Noted Notes":
        hdrColumn = [
          { key: "noteNumber", label: "Note#" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          { key: "createdDate", label: "Created Date" },
          // Bug fix - 298 - 27/03
          { key: "modifiedDate", label: "Modified Date" },
        ];
        break;
      case "All Requests":
        hdrColumn = [
          { key: "noteNumber", label: "Note Number" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          // Bug fix - 293 - 27/03
          { key: "currentActionerName", label: "Current Approver" },
          { key: "strNoteStatus", label: "Status" },
          { key: "modifiedDate", label: "Modified Date" },
          { key: "createdDate", label: "Created Date" },
        ];
        break;
      default:
        hdrColumn = [
          { key: "noteNumber", label: "Note Number" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          // Bug fix - 293 - 27/03
          { key: "currentActionerName", label: "Current Approver" },
          { key: "finalApprover", label: "Final Approver" },
          { key: "modifiedDate", label: "Modified Date" },
          { key: "createdDate", label: "Created Date" },
        ];
    }
    return hdrColumn;
  } */

    // Handle render ColumnsWithData
  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }
    let columnsConfig = [];
    columnsConfig = [
      { field: "SerialNo", title: "Sl.No", minWidth: 15, },
      { field: "currentActionerName", title: "Pending with", minWidth: 30, },
      { field: "designation", title: "Designation ", minWidth:25},
      { field: "srNo", title: "SrNo", minWidth: 20, },
      { field: "count", title: "Count", minWidth:10 },
    ];
    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        columnMenu={ColumnMenu}
      />
    ));
  };

  return (
    <div>
   
      {isLoading ? (
        <PageLoader />
      ) : (
        <Grid
          className="cstGridStylesForAdmin"
          pageable={{ pageSizes: true }}
          data={dataResult}
          sortable={true}
          total={resultState.total}
          onDataStateChange={dataStateChange}
          {...dataState}
          onExpandChange={onExpandChange}
          expandField="expanded"
          dataItemKey={DATA_ITEM_KEY}
          size={"small"}
          resizable={true}
        >
          <GridToolbar>
            <Input
              value={filterValue}
              onChange={onFilterChange}
              className="searchCSS"
              placeholder="Search in all columns..."
            />
            <div className="export-btns-container">
            </div>
          </GridToolbar>
          {renderColumnsWithData(dataResult)}
        </Grid>
      )}
    </div>
  );
};
export default AdminDashboardGrid;
