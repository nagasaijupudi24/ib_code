import * as React from 'react';
import '../styles/footer.css'

// import linkedin from '../../src/assets/linkedin.svg';
// import twitter from '../../src/assets/twitter.svg';
// import face from '../../src/assets/face.svg';
// import insta from '../../src/assets/insta.svg';
const Footer = () => {
    return (
        <footer className='ibFooter'>
            <div className='container ibFooter'>
                <p className='copyRight'> © 2024  copyright Indian Bank </p>
                <div className='ibFooterimages'>
                {/* <img alt="IB image" src={linkedin} />
                <img alt="IB image" src={twitter} />
                <img alt="IB image" src={face} />
                <img alt="IB image" src={insta} /> */}
                </div>
            </div>
        </footer>
    )
}
export default Footer;