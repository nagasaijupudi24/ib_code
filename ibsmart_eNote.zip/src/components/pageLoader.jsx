import * as React from "react";
import "../styles/footer.css";
import { Loader } from "@progress/kendo-react-indicators";

export const PageLoader = () => {
  const [pageLoadingtype] = React.useState("converging-spinner");
  const [pageLoadingColor] = React.useState("info");

  return (
    <div className="overlayLoader">
      <Loader
        size="large"
        type={pageLoadingtype}
        themeColor={pageLoadingColor}
      />
    </div>
  );
};