export const categories = ["MD and CEO", "Executive Director", "Chief Vigilance Officer", "Chief General Manager", "General Manager", "Field General Manager", "Deputy General Manager", "Zonal Manager", "Assistant General Manager", "Deputy Zonal Manager", "Chief Manager", "Retail Asset Pilot Central Credit committee", "Department Head"];
export const natureofnote = ["Sanction", "Approval", "Information", "Ratification"];
export const natureofapprsanc = ["Administrative", "Capital / Revenue Expenditure"];
export const notetype = ["Financial", "Non-Financial"];
export const typeoffinancial = ["Administrative", "Capital Expenditure", "Revenue Expenditure"];
export const purpose = ["Fresh/Enhancement/Takeover", "Others", "Review / Renewal", "Sanction Modification / Miscellaneous requests"];
export const purpose1 = ["Note with deviation / remarks / observations", "Note without any deviations"]