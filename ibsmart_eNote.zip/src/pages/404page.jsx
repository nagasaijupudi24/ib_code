import React from "react";
const PageNotFound = () => {
  return (
    <div>
      <div className="container404">
        <h4 className="centerAlign404">404 - Page Not Found</h4>
      </div>
    </div>
  );
};

export default PageNotFound;