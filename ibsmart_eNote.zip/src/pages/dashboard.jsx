import React, { useEffect, useState } from "react";
// import kendo componnets
import { getter } from "@progress/kendo-react-common";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import { Button } from "@progress/kendo-react-buttons";
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
// import external components
import { CSVLink } from "react-csv";
import { Link } from "react-router-dom";
import { useMsal } from "@azure/msal-react";
import DateObject from "react-date-object";
// import internal components
import { ColumnMenu } from "./custom-cells";
import { fetchNoteData } from "./apiService";
// import css styles
import "../styles/passcode.css";

const DATA_ITEM_KEY = "id";
const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};
const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};
export const Dashboard = ({ apiOutput, selectedView }) => {
  const { accounts } = useMsal();
  const idGetter = getter("id");
  const [filterValue, setFilterValue] = useState("");
  const [filteredData, setFilteredData] = useState(apiOutput);
  const [currentSelectedState, setCurrentSelectedState] = useState({});
  const [dataState, setDataState] = useState(initialDataState);
  const [dataResult, setDataResult] = useState(
    process(filteredData, dataState)
  );
  const [data, setData] = useState(filteredData);
  const [apiData, setApiData] = useState([]);
  useEffect(() => {
    setApiData(apiOutput);
    setFilteredData(apiOutput);

    let processedData = process(apiOutput, initialDataState);
    setDataResult(processedData);
    setDataState({ ...dataState, total: apiOutput.length });
    setFilterValue("");
  }, [apiOutput]);

  // filter data based on search text for all columns 
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      setFilteredData(apiData);
      setDataResult(
        process(apiData, (dataState) => ({
          ...dataState,
          total: apiData.length,
        }))
      );
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLocaleLowerCase()
              .includes(value.toLocaleLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...dataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiOutput.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );

  // Grid dataStateChange handler
  const dataStateChange = (event) => {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };

  // Grid Expand chnage handler
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );

  // Grid setSelectedValue handler
  const setSelectedValue = (data) => {
    let newData = data.map((item) => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items),
        };
      } else {
        return {
          ...item,
          ["selected"]: currentSelectedState[idGetter(item)],
        };
      }
    });
    return newData;
  };

  const newData = setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: [],
  });

  // Grid get number of items 
  const getNumberOfItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfItems(item.items);
      } else {
        count++;
      }
    });
    return count;
  };

  // Grid get number of selected  items 
  const getNumberOfSelectedItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfSelectedItems(item.items);
      } else {
        count = count + (item.selected == true ? 1 : 0);
      }
    });
    return count;
  };


  // CSV column headers 
  const exportCSVHeader = () => {
    return [
      { key: "noteNumber", label: "Note ID" },
      { key: "createdByName", label: "Requester" },
      { key: "departmentName", label: "Department" },
      { key: "subject", label: "Subject" },
      { key: "strNoteStatus", label: "Status" },
      { key: "lastActioner", label: "Previous Approver" },
      { key: "finalApprover", label: "Final Approver" },
      { key: "modifiedDate", label: "Modified Date" },
      { key: "createdDate", label: "Created Date" }
    ];
  }

  // Based on Data column with will render
  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    const columnsConfig = [
      { field: "noteNumber", title: "Note ID" },
      { field: "createdByName", title: "Requester" },
      { field: "departmentName", title: "Department" },
      { field: "subject", title: "Subject" },
      { field: "strNoteStatus", title: "Status" },
      { field: "lastActioner", title: "Previous Approver" },
      { field: "finalApprover", title: "Final Approver" },
      { field: "modifiedDate", title: "Modified Date" },
      { field: "createdDate", title: "Created Date" }
    ];

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "noteNumber" ? (
            <td>
              <Link
                style={{ color: "red" }}
                to={
                  (props.dataItem["status"] === 1 ||
                    props.dataItem["status"] === 4 ||
                    props.dataItem["status"] === 8) &&
                    props.dataItem["createdBy"] === accounts[0]?.username
                    ? `/enoteform/${props.dataItem["noteId"]}`
                    : `/enoteviewform/${props.dataItem["noteId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {column.title.includes("Date")
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A") //removed seconds hand
                : props.dataItem[column.field]}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  //  Grid Header cell handler
  const onHeaderCellClick = (event) => {
    const clickedColumn = event.column;
    if (clickedColumn.field === "noteId") {
      // Extract noteId from the clicked column
      const noteId = clickedColumn.dataItem.noteId;
      // Fetch data based on the noteId
      fetchNoteData(noteId);
    }
  };
 
  return (
    <div>
      {/* Conditionally render the link for All Approved */}

      <Grid
        className="cstGridlandPgStyles"
        onHeaderCellClick={onHeaderCellClick}
        pageable={{ pageSizes: true }}
        data={dataResult}
        sortable={true}
        total={resultState.total}
        onDataStateChange={dataStateChange}
        {...dataState}
        onExpandChange={onExpandChange}
        expandField="expanded"
        dataItemKey={DATA_ITEM_KEY}
        selectedField={SELECTED_FIELD}
        size={"small"}
        resizable={true}
      >
        <GridToolbar>
          <Input
            value={filterValue}
            onChange={onFilterChange}
            className="searchCSS"
            placeholder="Search in all columns..."
          />
          <div className="export-btns-container">
            <Button style={{ marginLeft: "5px" }}>
              <CSVLink
                filename={`eNote-${selectedView.replace(
                  / /g,
                  ""
                )}${new DateObject(new Date()).format("DD-MMM-YYYY hh:mm A")}`}
                data={filteredData.map((x) => ({
                  ...x,
                  modifiedDate: new DateObject(new Date(x.modifiedDate)).format(
                    "DD-MMM-YYYY hh:mm A"
                  ),
                  createdDate: new DateObject(new Date(x.createdDate)).format(
                    "DD-MMM-YYYY hh:mm A"
                  ),
                }))}
                headers={exportCSVHeader()}
              >
                Export CSV
              </CSVLink>
            </Button>
          </div>
        </GridToolbar>
        {renderColumnsWithData(dataResult)}
      </Grid>
    </div>
  );
};