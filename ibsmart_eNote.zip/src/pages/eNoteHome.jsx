import React, { useState, useEffect } from "react";
// import kendo componets
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { Button } from "@progress/kendo-react-buttons";
import { orderBy } from "@progress/kendo-data-query";
// import external componnets
import DateObject from "react-date-object";
import { useMsal, useAccount } from "@azure/msal-react";
// import internal componnets
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Dashboard } from "./dashboard";
import { Sidebar } from "../components/sidebar";
import { PageLoader } from "../components/pageLoader";
import { getAccessToken,useTabContext } from "../App";
import { API_COMMON_HEADERS,loginRequest, API_BASE_URL, API_ENDPOINTS } from "../config";
import { ChartContainer } from "../components/enoteChartInfo";
// import styles
import "../styles/datagridpage.css";
const initialSort = [
  {
    field: "modifiedDate",
    dir: "desc",
  }
];
export const ENoteHome = () => {

  const { instance, accounts } = useMsal();
  const { activeTab } = useTabContext();
  const [activeButton, setActiveButton] = useState(activeTab);
  const [myPendingNotes, setMyPendingNotes] = useState(0);
  const [myRecommendedReferredNotes, setMyRecommendedReferredNotes] = useState(0);
  const [myReturnedNotes, setmyReturnedNotes] = useState(0);
  const [myApprovedNotes, setmyApprovedNotes] = useState(0);
  const [myEDMDNotes, setmyEDMDNotes] = useState(0);
  const [apiOutput, setapiOutput] = React.useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSecretary, setIsSecretary] = useState(true);
  const [selectedView, setSelectedView] = useState("");
  const [apiOutputforChart, setApiOutputforChart] = useState([]);
  const [myNotes, setMyNotes] = useState(0);
  const account = useAccount(accounts[0] || {});
  const [isMobileView, setIsMobileView] = useState(window.innerWidth <= 768);
  const [selectedOption, setSelectedOption] = useState(null);

  useEffect(() => {
    // on load call chartData API
    handleButtonClick(activeTab);
    // on Load fetch findIsSecratary API
    findIsSecratary();

    const initialOption = options.find(option => option.value === activeTab);
    setSelectedOption(initialOption);

    const handleResize = () => {
      setIsMobileView(window.innerWidth <= 1105);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };

  }, []);

  // get data for charts 
  const fetchDataForcharts = async (endPoint, accessToken) => {
    // custom colors 
    const colorCodes = [
      "#7731a3", // Deep Purple
      "rgb(254, 215, 76)", // Yellow
      "#ba3294", // Purple
      "rgb(78, 185, 167)", // Turquoise
      "#d92b2b", // Red
      "rgb(12, 77, 162)", // Blue
      "#4dc313", // Green
      "#1e6bb5", // Dark Blue
      "rgb(255, 165, 0)" // Orange
    ];

    try {
      const response = await fetch(
        `${API_BASE_URL}${endPoint}?userEmailId=${accounts[0].username}`,
        {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        }
      );

      if (response.ok) {
        let noteCount = 0;
        setIsLoading(false);
        const apiOutput = await response.json();
        // adding color property to Response. adding custom colors dynamically
        // change 20/04 conacting status and count
        apiOutput.lstNoteChart = apiOutput.lstNoteChart?.map((obj, index) => { return { ...obj, color: colorCodes[index], status: `${obj.status}: ${obj.count}` } });
        // adding color property to Response. adding custom colors dynamically
        // change 20/04 conacting status and count
        apiOutput.lstNatureofNoteStatusCount = apiOutput.lstNatureofNoteStatusCount?.map((obj, index) => { return { ...obj, color: colorCodes[index], status: `${obj.status}: ${obj.count}` } })
        apiOutput.lstNoteChart?.map(obj => {
          noteCount = noteCount + obj.count
        });
        setMyNotes(noteCount);
        setApiOutputforChart(apiOutput);
      }
    }
    catch {
      console.log("err")
    }
  }

  // Based on button text API will call
  const handleButtonClick = async (buttonText) => {
    setActiveButton(buttonText);
    setIsLoading(true);
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
    });
    const enumsObject = await dropdowns.json();

    switch (buttonText) {
      case "My Pending Notes":
        fetchApiData(API_ENDPOINTS.eNote_GetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Pending").id, buttonText, accessToken);
        break;
      case "My Recommended/Referred Notes":
        fetchApiData(API_ENDPOINTS.eNote_GetRefferedNoteList, enumsObject.ReferrerStatus.find((x) => x.dValue === "Pending").id, buttonText, accessToken);
        break;
      case "My Returned Notes":
        fetchApiData(API_ENDPOINTS.eNote_GetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Returned").id, buttonText, accessToken);
        break;
      case "My Approved Notes":
        fetchApiData(API_ENDPOINTS.eNote_GetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Approved").id, buttonText, accessToken);
        break;
      case "My Notes":
        fetchDataForcharts(API_ENDPOINTS.eNote_GetNoteChartData, accessToken);
        break;
      case "ED/MD Notes":
        fetchApiData(API_ENDPOINTS.eNote_GetEDMDNoteList, 0, buttonText, accessToken);
        break;
      default:
        fetchApiData(API_ENDPOINTS.eNote_GetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Pending").id, "My Pending Notes", accessToken);
        break;
    }
  };

  // checking if login user is Secratary or not.if login user is Secratary displaying ED/MD btn 
  const findIsSecratary = async () => {
    setIsLoading(true);
    const accessToken = await getAccessToken({
      ...loginRequest,
      account,
    }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eNote_findIsloginUserSecretary}`,
      {
        method: "POST",
        body: JSON.stringify({ SecretaryEmail: accounts[0].username }),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      }
    )
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        setIsSecretary(data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
    setIsLoading(false);
  };

  // Based on button  click  this function will call 
  const fetchApiData = async (apiEndpoint, Status, buttonText, accessToken) => {
    setSelectedView(buttonText);

    try {
      const response = await fetch(`${API_BASE_URL}${apiEndpoint}`, {
        method: "POST",
        body: JSON.stringify({
          status: Status,
          createdBy: accounts[0].username,
        }),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      });

      if (response.ok) {
        const apiData = await response.json();
        if (apiData.pendingNoteList) {
          let resData = apiData.pendingNoteList;
          const ordData = orderBy(resData, initialSort);
          // converting date object for  modifieddate and createdDate
          const apiCstData = ordData.map(x => ({ ...x, modifiedDate: new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"), createdDate: new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A") }));
          setapiOutput(apiCstData);
          // based on button text  store  the total count of Response 
          switch (buttonText) {
            case "My Pending Notes":
              setMyPendingNotes(apiData.pendingNoteList.length);
              break;
            case "My Recommended/Referred Notes":
              setMyRecommendedReferredNotes(apiData.pendingNoteList.length);
              break;
            case "My Returned Notes":
              setmyReturnedNotes(apiData.pendingNoteList.length);
              break;
            case "My Approved Notes":
              setmyApprovedNotes(apiData.pendingNoteList.length);
              break;
            case "ED/MD Notes":
              setmyEDMDNotes(apiData.pendingNoteList.length);
              break;
            // Add more cases for other buttons if needed
            default:
              break;
          }
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    setIsLoading(false);
  };
  const options = [
    { text: "My Notes", value: "My Notes" },
    { text: "My Pending Notes", value: "My Pending Notes" },
    { text: "My Recommended/Referred Notes", value: "My Recommended/Referred Notes" },
    { text: "My Returned Notes", value: "My Returned Notes" },
    { text: "My Approved Notes", value: "My Approved Notes" },
  ];

  if (isSecretary) {
    options.push({ text: "ED/MD Notes", value: "ED/MD Notes" });
  }

  // Handle select change
  const handleSelect = (event) => {
    const selectedValue = event.target.value;
    setSelectedOption(options.find(option => option.value === selectedValue));
    setSelectedOption(selectedValue);
    handleButtonClick(selectedValue?.value);
  };

  // Handle rebder dropdown
  const renderDropdown = () => (
    <DropDownList
      className="landing_Page_Dropdown"
      data={options}
      value={selectedOption}
      textField="text"
      dataItemKey="value"
      onChange={handleSelect}
      defaultItem={{ text: "Select an option", value: null }}
    />
  );

  // 
  const renderButtons = () => (
    <div className="row landingPgTopBtnRow">
      <Button className="landingPgTopBtn"
        style={{ width: isSecretary ? "16%" : "18%", background: activeButton === "My Notes" ? "#034ea1" : "", color: activeButton === "My Notes" ? "#ffff" : "" }}
        onClick={() => handleButtonClick("My Notes")}
      >
        My Notes
        {activeButton === "My Notes" && (<span className="landingPgTopBtncontent">{myNotes}</span>)}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Pending Notes" ? "#034ea1" : "",
          color: activeButton === "My Pending Notes" ? "#ffff" : "#333333",

        }}
        onClick={() => handleButtonClick("My Pending Notes")}
      >
        My Pending Notes
        {activeButton === "My Pending Notes" && (
          <span className="landingPgTopBtncontent">
            {myPendingNotes}
          </span>
        )}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Recommended/Referred Notes" ? "#034ea1" : "",
          color: activeButton === "My Recommended/Referred Notes" ? "#ffff" : "",

        }}
        onClick={() => handleButtonClick("My Recommended/Referred Notes")}
      >
        My Recommended/Referred Notes
        {activeButton === "My Recommended/Referred Notes" && (
          <span className="landingPgTopBtncontent">
            {myRecommendedReferredNotes}
          </span>
        )}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Returned Notes" ? "#034ea1" : "",
          color: activeButton === "My Returned Notes" ? "#ffff" : "",

        }}
        onClick={() => handleButtonClick("My Returned Notes")}
      >
        My Returned Notes
        {activeButton === "My Returned Notes" && (
          <span className="landingPgTopBtncontent" >
            {myReturnedNotes}
          </span>
        )}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Approved Notes" ? "#034ea1" : "",
          color: activeButton === "My Approved Notes" ? "#ffff" : "",

        }}
        onClick={() => handleButtonClick("My Approved Notes")}
      >
        My Approved Notes
        {activeButton === "My Approved Notes" && (<span className="landingPgTopBtncontent">{myApprovedNotes}</span>)}
      </Button>
      {isSecretary && <Button className="landingPgTopBtn"
        style={{ width: isSecretary ? "16%" : "18%", background: activeButton === "ED/MD Notes" ? "#034ea1" : "", color: activeButton === "ED/MD Notes" ? "#ffff" : "" }}
        onClick={() => handleButtonClick("ED/MD Notes")}
      >
        ED/MD Notes
        {activeButton === "ED/MD Notes" && (<span className="landingPgTopBtncontent">{myEDMDNotes}</span>)}
      </Button>}
    </div>
  );
  // const renderButtonsCarousel = () => (
  //   <Carousel
  //     showThumbs={false}
  //     showStatus={false}
  //     infiniteLoop
  //     emulateTouch
  //     swipeable
  //     className="button-carousel"
  //     centerSlidePercentage={50}
  //   >
  //     <div>
  //       <Button className="landingPgTopBtn"
  //         style={{ width: "85%", height:"70px", background: activeButton === "My Notes" ? "#034ea1" : "", color: activeButton === "My Notes" ? "#ffff" : "" }}
  //         onClick={() => handleButtonClick("My Notes")}
  //       >
  //         My Notes
  //         {activeButton === "My Notes" && (<span className="landingPgTopBtncontent">{myNotes}</span>)}
  //       </Button>
  //     </div>
  //     <div>
  //       <Button className="landingPgTopBtn"
  //         style={{ width: "85%", height:"70px", background: activeButton === "My Pending Notes" ? "#034ea1" : "", color: activeButton === "My Pending Notes" ? "#ffff" : "" }}
  //         onClick={() => handleButtonClick("My Pending Notes")}
  //       >
  //         My Pending Notes
  //         {activeButton === "My Pending Notes" && (<span className="landingPgTopBtncontent">{myPendingNotes}</span>)}
  //       </Button>
  //     </div>
  //     <Button className="landingPgTopBtn"
  //       style={{
  //         width: isSecretary ? "85%" : "18%",
  //         height:"70px",
  //         background: activeButton === "My Recommended/Referred Notes" ? "#034ea1" : "",
  //         color: activeButton === "My Recommended/Referred Notes" ? "#ffff" : "",

  //       }}
  //       onClick={() => handleButtonClick("My Recommended/Referred Notes")}
  //     >
  //       My Recommended/Referred Notes
  //       {activeButton === "My Recommended/Referred Notes" && (
  //         <span className="landingPgTopBtncontent">
  //           {myRecommendedReferredNotes}
  //         </span>
  //       )}
  //     </Button>
  //     <Button className="landingPgTopBtn"
  //       style={{
  //         width: isSecretary ? "85%" : "18%", height:"70px",
  //         background: activeButton === "My Returned Notes" ? "#034ea1" : "",
  //         color: activeButton === "My Returned Notes" ? "#ffff" : "",

  //       }}
  //       onClick={() => handleButtonClick("My Returned Notes")}
  //     >
  //       My Returned Notes
  //       {activeButton === "My Returned Notes" && (
  //         <span className="landingPgTopBtncontent" >
  //           {myReturnedNotes}
  //         </span>
  //       )}
  //     </Button>
  //     <Button className="landingPgTopBtn"
  //       style={{
  //         width: isSecretary ? "85%" : "18%", height:"70px",
  //         background: activeButton === "My Approved Notes" ? "#034ea1" : "",
  //         color: activeButton === "My Approved Notes" ? "#ffff" : "",

  //       }}
  //       onClick={() => handleButtonClick("My Approved Notes")}
  //     >
  //       My Approved Notes
  //       {activeButton === "My Approved Notes" && (<span className="landingPgTopBtncontent">{myApprovedNotes}</span>)}
  //     </Button>
  //     {isSecretary && <Button className="landingPgTopBtn"
  //       style={{ width: isSecretary ? "85%" : "18%", height:"70px", background: activeButton === "ED/MD Notes" ? "#034ea1" : "", color: activeButton === "ED/MD Notes" ? "#ffff" : "" }}
  //       onClick={() => handleButtonClick("ED/MD Notes")}
  //     >
  //       ED/MD Notes
  //       {activeButton === "ED/MD Notes" && (<span className="landingPgTopBtncontent">{myEDMDNotes}</span>)}
  //     </Button>}
  //   </Carousel>
  // );

  return (
    <div>
      <Navbar header="IB Smart Office - eNote" />
      {/* Task 319--showing the menus at first time--12/04--RK */}
      <Sidebar defaultOpenComponent={true} />
      <div className="container datagridpage">
        <div className="datagridPghdrBtns">
          <div className="row landingPgTopBtnRow">
            {/* <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background: activeButton === "My Notes" ? "#034ea1" : "",
                color: activeButton === "My Notes" ? "#ffff" : "",
                // Mobile View responsive added
                ...(window.innerWidth <= 768 && {
                  width: "100%",
                }),
                ...(window.innerWidth > 768 && window.innerWidth <= 1024 && {
                  width: "16%", // Adjust this percentage based on your tablet view requirement
                }),
              }}
              onClick={() => handleButtonClick("My Notes")}
            >
              My Notes
              {activeButton === "My Notes" && (<span className="landingPgTopBtncontent">{myNotes}</span>)}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background: activeButton === "My Pending Notes" ? "#034ea1" : "",
                color: activeButton === "My Pending Notes" ? "#ffff" : "#333333",
                // Mobile View responsive added
                ...(window.innerWidth <= 768 && {
                  width: "100%",
                }),
                ...(window.innerWidth > 768 && window.innerWidth <= 1024 && {
                  width: "15%", // Adjust this percentage based on your tablet view requirement
                }),
              }}
              onClick={() => handleButtonClick("My Pending Notes")}
            >
              My Pending Notes
              {activeButton === "My Pending Notes" && (
                <span className="landingPgTopBtncontent">
                  {myPendingNotes}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background: activeButton === "My Recommended/Referred Notes" ? "#034ea1" : "",
                color: activeButton === "My Recommended/Referred Notes" ? "#ffff" : "",
                // Mobile View responsive added
                ...(window.innerWidth <= 768 && {
                  width: "100%",
                }),
                ...(window.innerWidth > 768 && window.innerWidth <= 1024 && {
                  width: "25%", // Adjust this percentage based on your tablet view requirement
                }),
              }}
              onClick={() => handleButtonClick("My Recommended/Referred Notes")}
            >
              My Recommended/Referred Notes
              {activeButton === "My Recommended/Referred Notes" && (
                <span className="landingPgTopBtncontent">
                  {myRecommendedReferredNotes}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background: activeButton === "My Returned Notes" ? "#034ea1" : "",
                color: activeButton === "My Returned Notes" ? "#ffff" : "",
                // Mobile View responsive added
                ...(window.innerWidth <= 768 && {
                  width: "100%",
                }),
                ...(window.innerWidth > 768 && window.innerWidth <= 1024 && {
                  width: "15%", // Adjust this percentage based on your tablet view requirement
                }),
              }}
              onClick={() => handleButtonClick("My Returned Notes")}
            >
              My Returned Notes
              {activeButton === "My Returned Notes" && (
                <span className="landingPgTopBtncontent" >
                  {myReturnedNotes}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background: activeButton === "My Approved Notes" ? "#034ea1" : "",
                color: activeButton === "My Approved Notes" ? "#ffff" : "",
                // Mobile View responsive added
                ...(window.innerWidth <= 768 && {
                  width: "100%",
                }),
                ...(window.innerWidth > 768 && window.innerWidth <= 1024 && {
                  width: "15%", // Adjust this percentage based on your tablet view requirement
                }),
              }}
              onClick={() => handleButtonClick("My Approved Notes")}
            >
              My Approved Notes
              {activeButton === "My Approved Notes" && (<span className="landingPgTopBtncontent">{myApprovedNotes}</span>)}
            </Button>

            {isSecretary && <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background: activeButton === "ED/MD Notes" ? "#034ea1" : "",
                color: activeButton === "ED/MD Notes" ? "#ffff" : "",
                // Mobile View responsive added
                ...(window.innerWidth <= 768 && {
                  width: "100%",
                }),
                ...(window.innerWidth > 768 && window.innerWidth <= 1024 && {
                  width: "15%",marginTop: "10px" // Adjust this percentage based on your tablet view requirement
                }),
              }}
              onClick={() => handleButtonClick("ED/MD Notes")}
            >
              ED/MD Notes
              {activeButton === "ED/MD Notes" && (
                <span className="landingPgTopBtncontent" >
                  {myEDMDNotes}
                </span>
              )}
            </Button>} */}
            {isMobileView ? renderDropdown() : renderButtons()}
          </div>
        </div>
        {isLoading ?
          <PageLoader /> :
          activeButton === "My Notes" ?
            <ChartContainer apiOutput={apiOutputforChart} /> :
            <Dashboard apiOutput={apiOutput} selectedView={selectedView} />
        }
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};