import React, { useState, useEffect } from "react";
// import kendo components
import {Form, FormElement, FieldWrapper, Field} from "@progress/kendo-react-form";
import { Input, TextArea} from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { Button } from "@progress/kendo-react-buttons";
import { Label, Hint } from "@progress/kendo-react-labels";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
// import kendo icons
import { SvgIcon } from "@progress/kendo-react-common";
import { infoCircleIcon } from "@progress/kendo-svg-icons";
import {
  filePdfIcon,
  fileWordIcon,
  fileImageIcon,
  fileTxtIcon,
  fileDataIcon,
  fileIcon,
  xIcon,
} from "@progress/kendo-svg-icons";
// import external components
import { useNavigate } from "react-router-dom";
import { Link, useParams } from "react-router-dom";
import { useMsal, useAccount } from "@azure/msal-react";
import DateObject from "react-date-object";
import Clock from 'react-live-clock';
// import internal components
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Sidebar } from "../components/sidebar";
import { TableDraggableRows } from "../components/tableDragRows";
import { PageLoader } from "../components/pageLoader";
import { API_BASE_URL, API_ENDPOINTS,loginRequest,API_COMMON_HEADERS } from "../config";
import { getAccessToken ,useTabContext} from "../App";
import useAutosave from "../hooks/useAutoSave.hook";
// Mobile responsive css and css styles
import "../styles/responsiveDesign.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/forms.css";

const CustomDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};

const CustomConfirmDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span> Confirmation
    </div>
  );
};

const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",
  },
  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "120px",
  },
];

// mobile view responsive
const mobileColumns = [
  {
    field: "displayName",
    header: "Person Name",
    width: "100px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "100px",
  },
  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "70px",
  },
];
export const ReorderContext = React.createContext({
  reorder: () => { },
  dragStart: () => { },
});

export const ENoteNewForm = () => {
  
  const valueRender = (element, value, fieldName) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      setState(prevState => ({
        ...prevState,
        [fieldName]: '', // Clear the value of the specified field
      }));
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} className="_valueRender">
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props
    }, children);
  };

  // change -13/05  clear  department Value 
  /* const valueRenderDepartment = (element, value) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      setSelectedDepartment(null);
      //  change 16/05  on clear of department approver and reviwers need to clear 
      setUserDepertment('');
      setNoteApproverData([]);
      setNoteReviewerData([])
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} className="_valueRender">
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props
    }, children);
  }; */

  const  {setTab} =useTabContext();
  // const [inputValue, setInputValue] = useState('');
  const navigate = useNavigate();
  const [noteto, setNoteTo] = useState([]);
  const [natureofnote, setNatureOfNote] = useState([]);
  const [notetype, setNoteTypeData] = useState([]);
  const [fintype, setFinType] = useState([]);
  const [natureofapprsanc, setNatureofApprSanc] = useState([]);
  const [noteapproverData, setNoteApproverData] = useState([]);
  const [notereviewerData, setNoteReviewerData] = useState([]);
  const [noteComments, setNoteComments] = useState([]);
  const [showNatureOfApprSanc, setShowNatureOfApprSanc] = useState(false);
  const [showTypeOfFinNote, setshowTypeOfFinNote] = useState(false);
  const [showAmount, setshowAmount] = useState(false);
  const [showPurpose, setshowPurpose] = useState(false);
  const [showPurpose1, setshowPurpose1] = useState(false);
  const [showPurpose2, setshowPurpose2] = useState(false);
  // const [value] = useState("");
  const [departmentError] = useState("");
  const [noteBorderColor, setNoteBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  // Commented for department select dropdown
  // const [departmentBorderColor, setDepartmentBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const urlParam = useParams();
  const [noteId] = useState(urlParam.id);
  const [draftId, setDraftId] = useState(noteId === "new" ? 0 : noteId);
  const [redirectTo] = useState("/datagridpage");
  const [allOrgUsers, setAllOrgUsers] = useState([]);

  const [searchBorderColor, setSearchBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [subjectBorderColor, setSubjectBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [natureofapprsancBorderColor, setNatureofapprsancBorderColor] =
    useState("rgba(0, 0, 0, 0.12)");
  const [notetypeBorderColor, setNotetypeBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [typeoffinBorderColor, setTypeOfFinBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [amountBorderColor, setAmountBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [natureofnoteBorderColor, setNatureOfNoteBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [purposeBorderColor, setPurposeBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [purposeOthersBorderColor, setPurposeOthersBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );

  const [purpose1BorderColor, setPurpose1BorderColor] = useState("");
  const [purpose2BorderColor, setPurpose2BorderColor] = useState("");
  // const [approverEmailsList] = useState();
  // const [approveremailsObject, setApproverEmailsObject] = useState([]);
  const [selectedReveiwer, setSelectedReviewer] = useState(null);
  const [combovalueApprover, setComboValueApprover] = useState(null);
  const [visible, setVisible] = React.useState(false);
  const [visibleCancelCfrm, setVisibleCancelCfrm] = React.useState(false);
  const [alertvisible, setAlertVisible] = useState(false);
  const [visiblesave, setVisibleSave] = React.useState(false);
  const [validationErrors, setValidationErrors] = React.useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [isSecretaryExist, setisSecretaryExist] = useState(false);
  const [showNotification, setShowNotification] = React.useState(false);
  const [notificationMsg, setNotificationMsg] = React.useState(false);
  const [enumsObj, setEnumsObj] = React.useState(null);
  const [isNewForm] = React.useState(noteId === "new");
  const [amount, setAmount] = React.useState("");
  const [purpose, setPurpose] = React.useState("");
  const [purposeOthers, setPurposeOthers] = React.useState("");
  const [drpOptPurposeApproval, setDrpOptPurposeApproval] = React.useState([]);
  const [drpOptPurposeInformation, setDrpOptPurposeInformation] = React.useState([]);
  const [supportingDocError, setSupportingError] = useState("");
  const [notepath,setNotePath] = useState(null);
  const [wordPath,setWordPath] = useState(null)
  const max = 250;
  const isMobile = window.innerWidth <= 768;
  const [state, setState] = useState({
    Department: "",
    NoteTo: "",
    Subject: "",
    NatureOfNote: "",
    NatureOfApprSanc: "",
    NoteType: "",
    TypeOfFinNote: "",
    Amount: "",
    Search: "",
    Purpose: "",
    PurposeApproval: "",
    PurposeInformation: "",
    notePdfPath: "",
    noteWordPath: "",
    supportingdocument: "",
    createdBy: "",
    status: "",
    statusMsg: "",
    createdDate: ""
  });
  const [filesInfo, SetFileinfo] = useState([]);
  const [wordandPdfWarring, SetWordPDFInfowarring] = useState({
    PDFInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
    },
    wordInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
    },
  });

  const [supportDocWarning, SetSupportDocWarning] = useState({});
  const { instance, accounts } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [userDepartment, setUserDepertment] = useState("");
  const [userDesignation, setUserDesignation] = useState("");
  const [isSaveAndSubmitActionCompleted, setisSaveAndSubmitActionCompleted] = useState(false);
  // Commented for department select dropdown
  // const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [departmentList, setDepartmentList] = useState([]);

  useEffect(() => {
    setIsLoading(true);
    getUserDepartment();
  }, []);

  //Get login users department and designation
  const getUserDepartment = async () => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const obj = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetailsByPrincipalName(accounts[0].username)}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }
      );
      const departmentDetails = await obj.json();
      // Commentted UserDepartment State in onload
      setUserDepertment(departmentDetails[0].department);
      setUserDesignation(departmentDetails[0].jobTitle);

      // await getDefaultConfigData(departmentDetails[0].department);
      await getDefaultConfigData(departmentDetails[0].department);
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  };

  // Change 13/05 API call for department list
  const getDepartmentList = async () => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const obj = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_Departments_List}`
      , {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }
    );
    const departmentDetailsList = await obj.json();
    setDepartmentList(departmentDetailsList)
  }

  //Find secretary exists for the added Approvers/Reviewers
  const findSecrateries = async (apprObj, userDepartment) => {
    let param = apprObj.map((x) => ({
      approverType: x.approverType,
      approverEmail: x.approverEmail,
    }));
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    let secretaryExists = false;
    if (userDepartment) {
      try {
        await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eNote_GetNoteSecretaryofApprover}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify({ noteApproversMasterlst: param, departmentName: userDepartment }),
          }
        )
          .then((response) => {
            return response.json();
          })
          .then((data) => {
            setisSecretaryExist(data.secretaryExist);
            secretaryExists = data.secretaryExist;
          });
      } catch (error) {
        console.error("Error fetching data from API:", error);
      }
    }
    return secretaryExists;
  };

  /* get defalutApprovers on change of department 
  Change 16/05 on change department this function will call */

  // const getDefaultConfigApprovers = async (userDepartment) => {
  //   // if (isNewForm) {
  //   const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
  //   const approverresponse = await fetch(
  //     `${API_BASE_URL}${API_ENDPOINTS.eNote_GetNoteApprovers(userDepartment)}`, {
  //     method: "GET",
  //     headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
  //   }
  //   );

  //   const reviewerresponse = await fetch(
  //     `${API_BASE_URL}${API_ENDPOINTS.eNote_GetNoteReviewer(userDepartment)}`, {
  //     method: "GET",
  //     headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
  //   }
  //   );

  //   const noteapprover = await approverresponse.json();
  //   const notereviewer = await reviewerresponse.json();
  //   if (noteapprover) {
  //     setNoteApproverData(noteapprover);
  //     await findSecrateries(noteapprover, userDepartment);
  //   }
  //   if (notereviewer)
  //     setNoteReviewerData(notereviewer);

  // }

  //Get all the dropdowns and pre configured data
  const getDefaultConfigData = async (userDepartment) => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      //get enum objects
      const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      });
      const dropdownslist = await dropdowns.json();
      getDepartmentList();
      setEnumsObj(dropdownslist);
      setNoteTo(dropdownslist.noteTo);
      setNatureOfNote(dropdownslist.natureofNote);
      setNoteTypeData(dropdownslist.noteType);
      setFinType(dropdownslist.financialType);
      setNatureofApprSanc(dropdownslist.natureOfApprovalOrSanction);
      setDrpOptPurposeApproval(dropdownslist.PurposeonApproval);
      setDrpOptPurposeInformation(dropdownslist.PurposeonInformation);

      if (!(isNewForm)) {
        await fetcheNotedetails(userDepartment, dropdownslist.PurposeonApproval);
      }
      setIsLoading(false);


      //Removed this function due to loading impact users will be filtered on search box enter - 22/03
      /*const orgUsers = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_UserDetails}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
        });
  
        const orgMembers = await orgUsers.json();
        const reConstructArr = orgMembers.map(x=>{
          return {department:x.department === null?"NA":x.department,displayName:x.displayName === null?"NA":x.displayName,jobTitle:x.jobTitle === null?"NA":x.jobTitle,userPrincipalName:x.userPrincipalName}
        });
  
        setOrgEmployees(reConstructArr);

      setApproverEmailsObject(reConstructArr);*/

      // Comment get default approvers on onload in feature we will roll back 

       if (isNewForm) {
         const approverresponse = await fetch(
           `${API_BASE_URL}${API_ENDPOINTS.eNote_GetNoteApprovers(userDepartment)}`, {
           method: "GET",
           headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
         }
         );
 
         const reviewerresponse = await fetch(
           `${API_BASE_URL}${API_ENDPOINTS.eNote_GetNoteReviewer(userDepartment)}`, {
           method: "GET",
           headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
         }
         );
 
         const noteapprover = await approverresponse.json();
         const notereviewer = await reviewerresponse.json();
         if (noteapprover) {
           setNoteApproverData(noteapprover);
           await findSecrateries(noteapprover, userDepartment);
         }
         if (notereviewer)
           setNoteReviewerData(notereviewer);
 
         setIsLoading(false);
       } 

    } catch (error) {
      console.error("Error fetching data:", error);
      setIsLoading(false);
    }
  };

  //Get eNote data for Edit form on load
  const fetcheNotedetails = async (userDepartment, purposeApprovalDrpOpt) => {
    setIsLoading(true);
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eNote_GetGeneralDetails}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify({ noteId: noteId }),
        }
      );
      if (!response.ok) {
        // Handle error, for example set an error state
        console.error("Error fetching data:", response.statusText);
        return;
      }
      const data = await response.json();
    

      setState({
        ...data,
        status: data.status,
        NoteTo: data.strNoteTo,
        Amount: data.amount || "",
        NatureOfNote: data.strNatureofNote === "0" ? "" : data.strNatureofNote,
        Subject: data.subject || "",
        NatureOfApprSanc: data.strNatureOfApprovalOrSanction === "0" ? "" : data.strNatureOfApprovalOrSanction,
        NoteType: data.strNoteType === "0" ? "" : data.strNoteType,
        FinancialType: data.strFinancialType === "0" ? "" : data.strFinancialType,
        TypeOfFinNote: data.strFinancialType === "0" ? "" : data.strFinancialType,
        Search: data.searchKeyword || "",
        Purpose: data.purpose || "",
        PurposeApproval: data.purpose === "0" ? "" : data.purpose,
        PurposeInformation: data.purpose === "0" ? "" : data.purpose,
        NotePdfFileName: data.purpose === "0" ? "" : data.purpose,
        NotePdfPath: data.notePdfPath || "",
        supportingdocument: data.noteSupportingDocumentsDTO || "",
        noteApproversDTO: data.noteApproversDTO || "",
        createdBy: data.createdBy,
        statusMsg: data.strNoteStatus,
        createdDate: new DateObject(new Date(data.createdDate)).format("DD-MMM-YYYY hh:mm A") //seconds hand was removed 
      });
      // Commenetd for department select dropdown
      // setSelectedDepartment(data?.departmentName ? data?.departmentName : null);
      // Change  16/05
      setUserDepertment(data?.departmentName ? data?.departmentName : "");
      setAmount(data.amount);

      if (data.strNatureofNote === "Approval" && purposeApprovalDrpOpt.find(x => (x.dValue === data.purpose)) === undefined) {
        setPurpose("Others");
        setPurposeOthers(data.purpose);
      } else {
        setPurpose(data.purpose);
      }
      setNoteComments(data.noteApproverCommentsDTO);
      setShowNatureOfApprSanc(data.strNatureofNote === "Sanction" || data.strNatureofNote === "Approval");
      setshowPurpose(data.strNatureofNote === "Sanction" || data.strNatureofNote === "Ratification");
      setshowPurpose1(data.strNatureofNote === "Approval");
      setshowPurpose2(data.strNatureofNote === "Information");
      setshowTypeOfFinNote(data.strNoteType === "Financial");
      setshowAmount(data.strNoteType === "Financial");


      SetWordPDFInfowarring({
        PDFInfo: {
          fileName: data?.notePdfFileName,
          warningMsg: "",
          filePath: data?.notePdfPath,
          isValid: (data?.notePdfFileName === "" || data?.notePdfFileName === null) ? false : true
        },
        wordInfo: {
          fileName: data?.noteWordFileName,
          warningMsg: "",
          filePath: data?.noteWordPath,
          isValid: (data?.noteWordFileName === "" || data?.noteWordFileName === null) ? false : true
        },
      });
      setNotePath(data?.notePdfPath);
      setWordPath(data?.noteWordPath);
      SetFileinfo(data?.noteSupportingDocumentsDTO);
      const fetchNoteApprover = data.noteApproversDTO?.filter((obj) => obj.approverType === 2);
      if (fetchNoteApprover?.length > 0) {
        await findSecrateries(fetchNoteApprover, data?.departmentName ? data?.departmentName : "");
      }
      setNoteApproverData(fetchNoteApprover);

      setNoteReviewerData(
        data.noteApproversDTO?.filter((obj) => obj.approverType === 1)
      );
    } catch (error) {
      console.error("Error fetching data:", error.message);
    }
    setIsLoading(false);
  };

  // Delete Approvers from Approvers/Reviewers table
  const deletereviewer = (data) => {
    if (data && data.approverType === 1) {
      const updatedData = notereviewerData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      setNoteReviewerData(updatedData)
    }
    if (data && data.approverType === 2) {
      const updatedData = noteapproverData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      setNoteApproverData(updatedData)
    }

  }

  //  Approvers orderChange from Approvers/Reviewers table   
  const orderChange = (data) => {
    if (data.some(obj => obj.approverType === 1)) {
      setNoteReviewerData(data)
    }
    if (data.some(obj => obj.approverType === 2)) {
      setNoteApproverData(data);
    }
  }

  // Autosave functionaites  is implemented here
  useAutosave(() => {
    if (!isSaveAndSubmitActionCompleted && isNewForm) {
      handleAutoSave();
    }
  }, 3 * 60 * 1000);

  /* -------------------Form fields handlers START ---------------------- */
  /* Data Handles */
  const handleNote = (event) => {
    setState((prevState) => ({ ...prevState, NoteTo: event.target.value }));
    setNoteBorderColor("");
  };

  // Change -13/05 added dropdown for department user will select department name 
/*   const handleSelectedDepartment = (event) => {
    setSelectedDepartment(event.target.value);

    // on departmet change  call getDefaultConfigApprovers function and update userDepartment
    setUserDepertment(event.target.value);
    getDefaultConfigApprovers(event.target.value)
    setDepartmentBorderColor("");
  } */

  //  handle subject change
  const handleSubjectChange = (event) => {
    setState((prevState) => ({ ...prevState, Subject: event.target.value }));
    setSubjectBorderColor("");
  };

  // handle  nature of note change
  const handleNatureOfNoteChange = (event) => {
    setState((prevState) => ({ ...prevState, NatureOfNote: event.target.value }));
    setNatureOfNoteBorderColor("");
    const selectedValue = event.target.value;
    if (selectedValue === "Sanction" || selectedValue === "Ratification")
      setState((prevState) => ({ ...prevState, PurposeApproval: "", PurposeInformation: "", NatureOfApprSanc: "" }));

    if (selectedValue === "Approval")
      setState((prevState) => ({ ...prevState, Purpose: "", PurposeInformation: "", NatureOfApprSanc: "" }));

    if (selectedValue === "Information")
      setState((prevState) => ({ ...prevState, PurposeApproval: "", Purpose: "", NatureOfApprSanc: "" }));

    setShowNatureOfApprSanc(selectedValue === "Sanction" || selectedValue === "Approval");
    setshowPurpose(selectedValue === "Sanction" || selectedValue === "Ratification");
    setshowPurpose1(selectedValue === "Approval");
    setshowPurpose2(selectedValue === "Information");

    setPurpose('');
    setPurposeOthers('');
  };

  // handle  Natureb Of ApprSanc Change
  const handleNatureOfApprSancChange = (event) => {
    setState((prevState) => ({ ...prevState, NatureOfApprSanc: event.target.value }));
    setNatureofapprsancBorderColor("");
  };

  // handle NoteType change
  const handleNoteType = (event) => {
    setState((prevState) => ({ ...prevState, NoteType: event.target.value }));

    if (!(event.target.value === "Financial"))
      setState((prevState) => ({ ...prevState, TypeOfFinNote: "", Amount: 0 }));
    setNotetypeBorderColor("");
    setshowTypeOfFinNote(event.target.value === "Financial");
    setshowAmount(event.target.value === "Financial");
  };

  // handle  Type Of Financial
  const handleTypeOfFin = (event) => {
    setState((prevState) => ({ ...prevState, TypeOfFinNote: event.target.value }));
    setTypeOfFinBorderColor("");
  };

  // handle amoount change
  const handleAmount = (event) => {
    // Bug fix - 297 - 27/03
    // Change - Adding decimals - 05/04 - RK 

    if (/^\d*\.?\d{0,2}$/.test(event.target.value)) {
      // if(/^\d*$/.test(event.target.value)){
      setState((prevState) => ({ ...prevState, Amount: event.target.value }));
      setAmount(event.target.value);
      setAmountBorderColor("");
    }
  };

  // handle search change
  const handleSearchChange = (event) => {
    setState((prevState) => ({ ...prevState, Search: event.target.value }));
    setSearchBorderColor("");
  };

  //handle  purpose change
  const handlePurpose = (event) => {
    setState((prevState) => ({ ...prevState, Purpose: event.target.value }));
    setPurpose(event.target.value);
    setPurposeBorderColor("");
  };

  // handle Purpose Info Others change
  const handlePurposeInfoOthers = (event) => {
    setPurposeOthers(event.target.value);
    setPurposeOthersBorderColor("");
  };

  //  handle Purpose Approval change
  const handlePurposeApproval = (event) => {
    setState((prevState) => ({ ...prevState, PurposeApproval: event.target.value }));
    // setPurposeApproval(event.target.value);
    setPurpose(event.target.value);
    setPurposeOthers('');
    setPurpose1BorderColor("");
  };

  // handle Purpose Information change
  const handlePurposeInformation = (event) => {
    setState((prevState) => ({ ...prevState, PurposeInformation: event.target.value }));
    // setPurposeInformation(event.target.value);
    setPurpose(event.target.value);
    setPurpose2BorderColor("");
  };
  /* -------------------Form fields handlers END ---------------------- */


  /* Form mandatory fields and file validation handler */
  const validateForm = (isApproverValid, isReviewerValid) => {
    const errors = {};
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    //commented for department select dropdwon
    // if (!userDepartment) {
    //   errors["Depertment"] = "Department";
    //   setDepartmentBorderColor("#f31700");
    // } else {
    //   setDepartmentBorderColor("");
    // }
    if (!state.NoteTo) {
      errors["NoteTo"] = "NoteTo";
      setNoteBorderColor("#f31700");
    } else {
      setNoteBorderColor("");
    }

    if (!state.Subject.trim()) {
      errors["Subject"] = "Subject";
      setSubjectBorderColor("#f31700");
    } else {
      setSubjectBorderColor("");
    }

    if (!state.NatureOfNote) {
      errors["NatureOfNote"] = "Nature Of Note";
      setNatureOfNoteBorderColor("#f31700");
    } else {
      setNatureOfNoteBorderColor("");
    }

    if (showNatureOfApprSanc && !state.NatureOfApprSanc) {
      errors["NatureOfApprSanc"] =
        "Nature Of Appr/Sanc";
      setNatureofapprsancBorderColor("#f31700");
    } else {
      setNatureofapprsancBorderColor("");
    }

    if (!state.NoteType) {
      errors["NoteType"] = "Note Type";
      setNotetypeBorderColor("#f31700");
    } else {
      setNotetypeBorderColor("");
    }

    if (showTypeOfFinNote && !state.TypeOfFinNote) {
      errors["TypeOfFinNote"] =
        "Type of Financial Note";
      setTypeOfFinBorderColor("#f31700");
    } else {
      setTypeOfFinBorderColor("");
    }

    if (showAmount && !amount) {
      errors["Amount"] = "Amount";
      setAmountBorderColor("#f31700");
    } else {
      setAmountBorderColor("");
    }

    // Bug fix - 297 - 27/03
    if (showAmount && Number(amount) <= 0) {
      errors["Amount"] = "Amount";
      setAmountBorderColor("#f31700");
    } else {
      setAmountBorderColor("");
    }

    if (!state.Search.trim()) {
      errors["Search"] = "Search Text";
      setSearchBorderColor("#f31700");
    } else {
      setSearchBorderColor("");
    }

    if (showPurpose && !purpose.trim()) {
      errors["Purpose"] = "Purpose";
      setPurposeBorderColor("#f31700");
    } else {
      setPurposeBorderColor("");
    }

    if (showPurpose1 && !purpose) {
      errors["Purpose1"] = "Purpose";
      setPurpose1BorderColor("#f31700");
    } else {
      setPurpose1BorderColor("");
    }

    if (showPurpose2 && !purpose) {
      errors["Purpose2"] = "Purpose";
      setPurpose2BorderColor("#f31700");
    } else {
      setPurpose2BorderColor("");
    }

    if (showPurpose1 && purpose === "Others" && !purposeOthers.trim()) {
      errors["Purpose2"] = "Others";
      setPurposeOthersBorderColor("#f31700");
    } else {
      setPurposeOthersBorderColor("");
    }

    if (noteapproverData.length === 0) {
      errors["Approvers"] = "Please select atleast one Approver to submit request"
    }

    if (isApproverValid || isReviewerValid) {
      errors["Login user"] = "Login user cannont be part of Approvers/Reviewers."
    }

    if ((wordandPdfWarring?.PDFInfo.fileName === null || wordandPdfWarring?.PDFInfo.fileName === "" || wordandPdfWarring?.PDFInfo.isValid === false)) {
      errors["PDFInfo"] = "Please select Valid Pdf File";
    }

    if (noteapproverData.length > 0 && isSecretaryExist && (wordandPdfWarring?.wordInfo.fileName === "" || wordandPdfWarring?.wordInfo.fileName === null || wordandPdfWarring?.wordInfo.isValid === false)) {
      errors["wordDocInfo"] = "Please select Valid Word Doc File";
    }

    if (Object.keys(supportDocWarning).length > 0 || totalFileSize > 26214400) {
      if (Object.keys(supportDocWarning).length > 0) {
        errors["Supporting Documents"] = "Please select vaild files";
      }
      if (totalFileSize > 26214400) {
        errors["Supporting DocumentsMaxSize"] = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";

      }

    }
    if (Object.keys(errors).length > 0) {
      const errorMessagesArray = Object.values(errors);
      setErrorMessages(errorMessagesArray);
      setValidationErrors(true);
    }
    return errors;
  };


  /* Auto save Form Data */
  const handleAutoSave = async () => {
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    // }
    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });

    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      const updatedNoteReviewerData = notereviewerData.map((item, ind) => ({
        ...item,
        strApproverStatus: ind === 0 ? "Pending" : "Waiting",
      }));

      const updatedNoteApproverData = noteapproverData.map((item, ind) => ({
        ...item,
        strApproverStatus:
          notereviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
      }));
      // Added for base 64 split params ---> Kavya(18-07)
      const base64PDFParams = wordandPdfWarring.PDFInfo.filePath;
      const base64WordParams = wordandPdfWarring.wordInfo.filePath || {};// added base 64 parts for word doc
     
      // noteId:draftId,
      const params = {
        noteId: draftId || 0,
        noteFor: enumsObj.noteFor.find(x => x.dValue === "Regular").id,
        status: enumsObj.NoteStatus.find(x => x.dValue === "Draft").id,
        departmentId: userDepartment ? departmentList.find(obj => obj.departmentName === userDepartment).departmentId : 0,
        // departmentName: userDepartment,
        //  Change 13/05 
        departmentName: userDepartment,
        noteTo: state.NoteTo ? noteto.find(x => (x.dValue === state.NoteTo)).id : null,
        subject: state.Subject,
        designation: userDesignation,
        natureofNote: state.NatureOfNote ? natureofnote.find(x => (x.dValue === state.NatureOfNote)).id : 0,
        natureOfApprovalOrSanction: state.NatureOfApprSanc ? natureofapprsanc.find(x => (x.dValue === state.NatureOfApprSanc)).id : 0,
        noteType: state.NoteType ? notetype.find(x => (x.dValue === state.NoteType)).id : 0,
        financialType: state.TypeOfFinNote ? fintype.find(x => (x.dValue === state.TypeOfFinNote)).id : 0,
        amount: amount ? amount : 0,
        createdBy: accounts[0].username,
        modifiedBy: accounts[0].username,
        noteSupportingDocumentsDTO: totalFileSize > 26214400 ? [] : fileupdated,//filesInfo,
        noteApproversDTO: [
          ...updatedNoteReviewerData,
          ...updatedNoteApproverData,
        ],
        autosave: true,
        searchKeyword: state.Search,
        Purpose: (showPurpose1 && purpose === "Others") ? purposeOthers : purpose,
        // Purpose: purpose ||  purposeApproval || purposeInformation,
        // Added for base 64 split params ---> Kavya(18-07)
        NotePdfPathPart1: base64PDFParams.part1,
        NotePdfPathPart2: base64PDFParams.part2,
        NotePdfPathPart3: base64PDFParams.part3,
        NotePdfPathPart4: base64PDFParams.part4,
        NotePdfPathPart5: base64PDFParams.part5,
        NotePdfPathPart6: base64PDFParams.part6,
        NotePdfPathPart7: base64PDFParams.part7,
        NotePdfPathPart8: base64PDFParams.part8,
        NotePdfPathPart9: base64PDFParams.part9,
        NotePdfPathPart10: base64PDFParams.part10,
        NoteWordPathPart1: base64WordParams.part1,
        NoteWordPathPart2: base64WordParams.part2,
        NoteWordPathPart3: base64WordParams.part3,
        NoteWordPathPart4: base64WordParams.part4,
        NoteWordPathPart5: base64WordParams.part5,
        NoteWordPathPart6: base64WordParams.part6,
        NoteWordPathPart7: base64WordParams.part7,
        NoteWordPathPart8: base64WordParams.part8,
        NoteWordPathPart9: base64WordParams.part9,
        NoteWordPathPart10: base64WordParams.part10,
        // NotePdfPath: (wordandPdfWarring?.PDFInfo.fileName && wordandPdfWarring?.PDFInfo.isValid === false) ? null : wordandPdfWarring.PDFInfo.filePath,
        NotePdfFileName: (wordandPdfWarring?.PDFInfo.fileName && wordandPdfWarring?.PDFInfo.isValid === false) ? null : wordandPdfWarring.PDFInfo.fileName,
        // NoteWordPath: (isSecretaryExist && (wordandPdfWarring?.wordInfo.fileName && wordandPdfWarring?.wordInfo.isValid === false)) ? null : wordandPdfWarring.wordInfo.filePath || null,
        NoteWordFileName: (isSecretaryExist && (wordandPdfWarring?.wordInfo.fileName && wordandPdfWarring?.wordInfo.isValid === false)) ? null : wordandPdfWarring.wordInfo.fileName || null,
      };
      // if(isNewForm && !isSaveAndSubmitActionCompleted){
      await fetch(
        `${API_BASE_URL}${draftId === 0 ? API_ENDPOINTS.eNote_AddNote : API_ENDPOINTS.eNote_EditNote}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      ).then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Success") {
          setDraftId(res.noteId);
        } else {
          console.log("Something went wrong please try again.");
        }
        setIsLoading(false);

      }).catch((err) => {
        console.log(err, "errr");
      });
    } catch {
      console.log("rere")
    }
  };

  //It helps to cancel the note 
  const onCancelNote = async () => {
    setIsLoading(true);
    setVisibleCancelCfrm(false);
    let params = {
      noteId: noteId,
      createdBy: accounts[0].username,
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    await fetch(`${API_BASE_URL}${API_ENDPOINTS.eNote_CancelNote}`, {
      method: "POST",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(params),
    })
      .then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Success") {
          setSuccessMessage("The request for cancellation has been successfull.");
          setVisibleSave(!visiblesave);
        } else {
          setShowNotification(true);
          setNotificationMsg("Something went wrong please try again.");
        }
        setIsLoading(false);
      })
      .catch((err) => {
        setShowNotification(true);
        setNotificationMsg("Something went wrong please try again.");
        console.log(err);
        setIsLoading(false);
      });
  };

  /* it helps tp save or update draft data on Save as draft*/
  const handleSave = async () => {
    const errors = {};
    setIsLoading(true);
    setisSaveAndSubmitActionCompleted(true);
    let totalFileSize = 0
    let isFilesValid = true;
    filesInfo.map((x) => {
      isFilesValid = !(x.supportingDocumentFileName in supportDocWarning);
    });
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });

    if (isSecretaryExist && (wordandPdfWarring?.wordInfo.fileName && wordandPdfWarring?.wordInfo.isValid === false)) {
      errors["wordDocInfo"] = "Please select vaild file";
    }
    if (wordandPdfWarring?.PDFInfo.fileName && wordandPdfWarring?.PDFInfo.isValid === false) {
      errors["PDFInfo"] = "Please select vaild file";
    }
    if ((filesInfo.length > 0 && !isFilesValid) || totalFileSize > 26214400) {
      if (filesInfo.length > 0 && !isFilesValid) {
        errors["Supporting Documents"] = "Please select vaild files"
      }
      if (totalFileSize > 26214400) {
        errors["Supporting DocumentsMaxSize"] = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
      }
    }

    if (Object.keys(errors).length === 0) {

      try {
        const updatedNoteReviewerData = notereviewerData.map((item, ind) => ({
          ...item,
          strApproverStatus: ind === 0 ? "Pending" : "Waiting",
        }));

        const updatedNoteApproverData = noteapproverData.map((item, ind) => ({
          ...item,
          strApproverStatus:
            notereviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
        }));
        // Added for base 64 split params ---> Kavya(18-07)
        const base64PDFParams = wordandPdfWarring.PDFInfo.filePath;
        const base64WordParams = wordandPdfWarring.wordInfo.filePath || {}; // added base 64 parts for word doc

        const params = {
          noteId: isNewForm ? draftId : noteId,
          noteFor: enumsObj.noteFor.find(x => x.dValue === "Regular").id,
          status: enumsObj.NoteStatus.find(x => x.dValue === "Draft").id,
          /* departmentId: 0,
          departmentName: userDepartment, */
          // departmentId: 0, this will be roll back in future
          departmentId: userDepartment ? departmentList.find(obj => obj.departmentName === userDepartment).departmentId : 0,
          // departmentName: userDepartment,
          departmentName: userDepartment,
          noteTo: state.NoteTo ? noteto.find(x => (x.dValue === state.NoteTo)).id : null,
          subject: state.Subject,
          designation: userDesignation,
          natureofNote: state.NatureOfNote ? natureofnote.find(x => (x.dValue === state.NatureOfNote)).id : 0,
          natureOfApprovalOrSanction: state.NatureOfApprSanc ? natureofapprsanc.find(x => (x.dValue === state.NatureOfApprSanc)).id : 0,
          noteType: state.NoteType ? notetype.find(x => (x.dValue === state.NoteType)).id : 0,
          financialType: state.TypeOfFinNote ? fintype.find(x => (x.dValue === state.TypeOfFinNote)).id : 0,
          amount: amount ? amount : 0,
          createdBy: accounts[0].username,
          modifiedBy: accounts[0].username,
          noteSupportingDocumentsDTO: fileupdated, // filesInfo ,
          noteApproversDTO: [
            ...updatedNoteReviewerData,
            ...updatedNoteApproverData,
          ],
          autosave: false,
          searchKeyword: state.Search,
          Purpose: (showPurpose1 && purpose === "Others") ? purposeOthers : purpose,
          // Purpose: purpose ||  purposeApproval || purposeInformation,
          // NotePdfPath: wordandPdfWarring.PDFInfo.filePath,
          // NotePdfPath: (isNewForm ? null : wordandPdfWarring.PDFInfo.filePath === null ? notepath  : null),
          NotePdfPath: isNewForm ? null : (wordandPdfWarring.PDFInfo.filePath !== notepath ? null : notepath),
          // Added for base 64 split params ---> Kavya(18-07)
          NotePdfPathPart1: base64PDFParams.part1,
          NotePdfPathPart2: base64PDFParams.part2,
          NotePdfPathPart3: base64PDFParams.part3,
          NotePdfPathPart4: base64PDFParams.part4,
          NotePdfPathPart5: base64PDFParams.part5,
          NotePdfPathPart6: base64PDFParams.part6,
          NotePdfPathPart7: base64PDFParams.part7,
          NotePdfPathPart8: base64PDFParams.part8,
          NotePdfPathPart9: base64PDFParams.part9,
          NotePdfPathPart10: base64PDFParams.part10,
          NotePdfFileName: wordandPdfWarring.PDFInfo.fileName,
          NoteWordPathPart1: base64WordParams.part1 || null,
          NoteWordPathPart2: base64WordParams.part2 || null,
          NoteWordPathPart3: base64WordParams.part3 || null,
          NoteWordPathPart4: base64WordParams.part4 || null,
          NoteWordPathPart5: base64WordParams.part5 || null,
          NoteWordPathPart6: base64WordParams.part6 || null,
          NoteWordPathPart7: base64WordParams.part7 || null,
          NoteWordPathPart8: base64WordParams.part8 || null,
          NoteWordPathPart9: base64WordParams.part9 || null,
          NoteWordPathPart10: base64WordParams.part10 || null,
          // NoteWordPath:(isNewForm ? null : wordandPdfWarring.wordInfo.filePath === null ? wordPath : null),
          NoteWordPath: isNewForm ? null : (wordandPdfWarring.wordInfo.filePath !== wordPath ? null : wordPath),
          // NoteWordPath: wordandPdfWarring.wordInfo.filePath || null,
          NoteWordFileName: wordandPdfWarring.wordInfo.fileName || null,
        };
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
        await fetch(
          `${API_BASE_URL}${draftId === 0 ? API_ENDPOINTS.eNote_AddNote : API_ENDPOINTS.eNote_EditNote}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify(params),
          }
        ).then(response => {
          return response.json();
        }).then(data => {
          if (data.statusMessage === "Success") {
            setSuccessMessage("The request for eNote has been drafted successfull.");
            setVisibleSave(true);
          } else {
            setShowNotification(true);
            setNotificationMsg(`eNote form submission failed. 
            ${data.statusMessage}`);
          }
        }).catch(err => {
          console.error("Error submitting form:", err);
          setShowNotification(true);
          setNotificationMsg(err);
        })
      } catch (error) {
        console.error("Error submitting form:", error);
        setShowNotification(true);
        setNotificationMsg(error);
      }
    } else {
      setShowNotification(true);
      setNotificationMsg("Invalid files attached. Kindly remove the invalid files.");
    }
    setIsLoading(false);
  };
  
  /* It helps create or update note on Submit*/
  const handleSubmit = async () => {
    setIsLoading(true);
    setVisible(false);
    setisSaveAndSubmitActionCompleted(true);
    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });
    try {
      const updatedNoteReviewerData = notereviewerData.map((item, ind) => ({
        ...item,
        strApproverStatus: ind === 0 ? "Pending" : "Waiting",
      }));
      const updatedNoteApproverData = noteapproverData.map((item, ind) => ({
        ...item,
        strApproverStatus:
          notereviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
      }));
      // Added for base 64 split params ---> Kavya(18-07)
      const base64PDFParams = wordandPdfWarring.PDFInfo.filePath;
      const base64WordParams = wordandPdfWarring.wordInfo.filePath || {};
      const params = {
        noteId: isNewForm ? draftId : noteId,
        noteFor: enumsObj.noteFor.find(x => x.dValue === "Regular").id,
        status: enumsObj.NoteStatus.find(x => x.dValue === "Submitted").id,
        // departmentId: 0,
        departmentId: userDepartment ? departmentList.find(obj => obj.departmentName === userDepartment).departmentId : 0,
        // departmentName: userDepartment,
        departmentName: userDepartment,
        noteTo: state.NoteTo ? noteto.find(x => (x.dValue === state.NoteTo)).id : 0,
        subject: state.Subject,
        designation: userDesignation,
        natureofNote: state.NatureOfNote ? natureofnote.find(x => (x.dValue === state.NatureOfNote)).id : 0,
        natureOfApprovalOrSanction: state.NatureOfApprSanc ? natureofapprsanc.find(x => (x.dValue === state.NatureOfApprSanc)).id : 0,
        noteType: state.NoteType ? notetype.find(x => (x.dValue === state.NoteType)).id : 0,
        financialType: state.TypeOfFinNote ? fintype.find(x => (x.dValue === state.TypeOfFinNote)).id : 0,
        amount: amount ? amount : 0,
        createdBy: accounts[0].username,
        modifiedBy: accounts[0].username,
        noteSupportingDocumentsDTO: fileupdated,// filesInfo,
        noteApproversDTO: [
          ...updatedNoteReviewerData,
          ...updatedNoteApproverData,
        ],
        autosave: false,
        searchKeyword: state.Search,
        Purpose: (showPurpose1 && purpose === "Others") ? purposeOthers : purpose,
        // NotePdfPath: wordandPdfWarring.PDFInfo.filePath,
        NotePdfPath: isNewForm ? null : (wordandPdfWarring.PDFInfo.filePath !== notepath ? null : notepath),
        // Added for base 64 split params ---> Kavya(18-07)
        NotePdfPathPart1: base64PDFParams.part1,
        NotePdfPathPart2: base64PDFParams.part2,
        NotePdfPathPart3: base64PDFParams.part3,
        NotePdfPathPart4: base64PDFParams.part4,
        NotePdfPathPart5: base64PDFParams.part5,
        NotePdfPathPart6: base64PDFParams.part6,
        NotePdfPathPart7: base64PDFParams.part7,
        NotePdfPathPart8: base64PDFParams.part8,
        NotePdfPathPart9: base64PDFParams.part9,
        NotePdfPathPart10: base64PDFParams.part10,
        NotePdfFileName: wordandPdfWarring.PDFInfo.fileName,
        NoteWordPathPart1: base64WordParams.part1,
        NoteWordPathPart2: base64WordParams.part2,
        NoteWordPathPart3: base64WordParams.part3,
        NoteWordPathPart4: base64WordParams.part4,
        NoteWordPathPart5: base64WordParams.part5,
        NoteWordPathPart6: base64WordParams.part6,
        NoteWordPathPart7: base64WordParams.part7,
        NoteWordPathPart8: base64WordParams.part8,
        NoteWordPathPart9: base64WordParams.part9,
        NoteWordPathPart10: base64WordParams.part10,
        NoteWordPath: isNewForm ? null : (wordandPdfWarring.wordInfo.filePath !== wordPath ? null : wordPath) || null,
       
        // NoteWordPath:(isNewForm ? null : wordandPdfWarring.wordInfo.filePath),
        // NoteWordPath: wordandPdfWarring.wordInfo.filePath || null,
        NoteWordFileName: wordandPdfWarring.wordInfo.fileName || null,
      };
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      await fetch(
        `${API_BASE_URL}${(isNewForm && draftId === 0) ? API_ENDPOINTS.eNote_AddNote : API_ENDPOINTS.eNote_EditNote}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      ).then(response => {
        return response.json();
      }).then(data => {
        if (data.statusMessage === "Success") {
          console.log("Form submitted successfully!");
          setAlertVisible(true);
        } else {
          setShowNotification(true);
          setNotificationMsg(`eNote form submission failed. 
            ${data.statusMessage}`);
        }
      }).catch(err => {
        console.error(err, "Error submitting form");
        setShowNotification(true);
        setNotificationMsg(err);
      })
    } catch (error) {
      console.error("Error submitting form:", error);
      setShowNotification(true);
      setNotificationMsg(error);
    }
    setIsLoading(false);
  };

  //Submit handler helps to vlidate mandatory fields and prompt confirm dailog
  const handleOpenDialog = async () => {

    let isApproverValid = noteapproverData.find((x) => x.approverEmail === accounts[0].username) !== undefined;
    let isReviewerValid = notereviewerData.find((x) => x.approverEmail === accounts[0].username) !== undefined;

    if (!userDepartment) {
      setShowNotification(true);
      setNotificationMsg("User department cannot be blank. Please contact system administrator.");
      return;
    }
    const errors = validateForm(isApproverValid, isReviewerValid);
    // if (noteapproverData.length === 0) {
    //   setShowNotification(true);
    //   setNotificationMsg("Approvers cannot be blank. Please add approvers to submit request.");
    //   return;
    // }

    // if (isApproverValid || isReviewerValid) {
    //   setShowNotification(true);
    //   setNotificationMsg("Login user cannont be part of Approvers/Reviewers.");
    //   return;
    // }


    if (Object.keys(errors).length === 0) {
      // const documentErrors = validateDocuments();
      // if (Object.keys(documentErrors).length === 0) {
      setVisible(!visible);
      // }
    }
  };

  // handle close  dialog
  const handleCloseDialog = async () => {
    setVisible(!visible);
  };

  // handle save close 
  const handleSaveClose = async () => {
    setVisibleSave(false);
  };

  // handle close validation dialog
  const handleClosevalidationDialog = async () => {
    setValidationErrors(false);
  };

  //It helps to validate and convert to Base64 to attach documents - Word Info

//   const convertBase64Word = () => {
//     var selectedFile = document.getElementById("WordDocfile").files;
//     let cstWarningMsg = "";
//     let isValidFile = true;
//     if (selectedFile.length > 0) {
//       var fileExtension = selectedFile[0].name.split(".");
//       const fileName = selectedFile[0].name

//       if (
//         !(
//           fileName.toLowerCase().endsWith("docx") ||
//           fileName.toLowerCase().endsWith("doc" || "DOC")
//         )
//       ) {
//         cstWarningMsg = "File type not allowed";
//         isValidFile = false;
//       }
//       /* Bug -396 
//  *For Note pdf the maximum allowed size should be decreased from 25 MB to 10 MB.
//  25 mb = 26214400
//  10 mb = 10485760
//   */

//       if (selectedFile[0].size > 10485760) {
//         cstWarningMsg = "File size should not exceed more then 10 MB";
//         isValidFile = false;
//       }
//       if (checkingSpl(selectedFile[0].name)) {
//         isValidFile = false;
//         cstWarningMsg = "File name sholud not contain special characters";
//       }

//       if (isValidFile) {
//         var fileToLoad = selectedFile[0];
//         // FileReader function for read the file.
//         var fileReader = new FileReader();
//         // Onload of file read the file content
//         fileReader.onload = function (fileLoadedEvent) {
//           let base64 = fileLoadedEvent.target.result;
//           const RemovedHeaderFormBase64 = base64.split(",");
//           SetWordPDFInfowarring({
//             ...wordandPdfWarring,
//             wordInfo: {
//               fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
//               fileName: selectedFile[0].name,
//               filePath: RemovedHeaderFormBase64[1],
//               isValid: isValidFile,
//               warningMsg: cstWarningMsg
//             },
//           });
//         };
//         // Convert data to base64
//         fileReader.readAsDataURL(fileToLoad);
//       } else {
//         SetWordPDFInfowarring({
//           ...wordandPdfWarring,
//           wordInfo: {
//             fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
//             fileName: selectedFile[0].name,
//             filePath: "",
//             isValid: isValidFile,
//             warningMsg: cstWarningMsg
//           },
//         });
//       }
//     }
//   };
// Added base 64 split --> Kavya 18-07
const convertBase64Word = () => {
  var selectedFile = document.getElementById("WordDocfile").files;
  let cstWarningMsg = "";
  let isValidFile = true;
  if (selectedFile.length > 0) {
    var fileExtension = selectedFile[0].name.split(".");
    const fileName = selectedFile[0].name

    if (
      !(
        fileName.toLowerCase().endsWith("docx") ||
        fileName.toLowerCase().endsWith("doc" || "DOC")
      )
    ) {
      cstWarningMsg = "File type not allowed";
      isValidFile = false;
    }
    /* Bug -396 
*For Note pdf the maximum allowed size should be decreased from 25 MB to 10 MB.
25 mb = 26214400
10 mb = 10485760
*/

    if (selectedFile[0].size > 10485760) {
      cstWarningMsg = "File size should not exceed more then 10 MB";
      isValidFile = false;
    }
    if (checkingSpl(selectedFile[0].name)) {
      isValidFile = false;
      cstWarningMsg = "File name sholud not contain special characters";
    }

    if (isValidFile) {
      var fileToLoad = selectedFile[0];
      // FileReader function for read the file.
      var fileReader = new FileReader();
      // Onload of file read the file content
      fileReader.onload = function (fileLoadedEvent) {
        let base64 = fileLoadedEvent.target.result;
        const RemovedHeaderFormBase64 = base64.split(",")[1];

        const partLength = Math.ceil(RemovedHeaderFormBase64.length / 10);
        const parts = [];

        for (let i = 0; i < 10; i++) {
          parts.push(RemovedHeaderFormBase64.slice(i * partLength, (i + 1) * partLength));
        }
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: {
              part1: parts[0],
              part2: parts[1],
              part3: parts[2],
              part4: parts[3],
              part5: parts[4],
              part6: parts[5],
              part7: parts[6],
              part8: parts[7],
              part9: parts[8],
              part10: parts[9]
            },
            isValid: isValidFile,
            warningMsg: cstWarningMsg
          },
        });
      };
      // Convert data to base64
      fileReader.readAsDataURL(fileToLoad);
    } else {
      SetWordPDFInfowarring({
        ...wordandPdfWarring,
        wordInfo: {
          fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
          fileName: selectedFile[0].name,
          filePath: null,
          isValid: isValidFile,
          warningMsg: cstWarningMsg
        },
      });
    }
  }
};
  // Commented for base 64 split
  //It helps to validate and convert to Base64 to attach documents - PDF Info
  // const convertPDFToBase64 = () => {
  //   var selectedFile = document.getElementById("PDFDocfile").files;
  //   let cstWarningMsg = "";
  //   let isValidFile = true;
  //   if (selectedFile.length > 0) {
  //     var fileExtension = selectedFile[0].name.split(".");
  //     const fileName = selectedFile[0].name
  //     /*   if (fileExtension[fileExtension.length - 1] !== "pdf") {
  //         cstWarningMsg = "File type not allowed";
  //         isValidFile = false;
  //       } */
  //     if (!(fileName.toLowerCase().endsWith("pdf"))) {
  //       cstWarningMsg = "File type not allowed";
  //       isValidFile = false;

  //     }
  //     /* Bug -396 
  //     *For Note pdf the maximum allowed size should be decreased from 25 MB to 10 MB.
  //     25 mb = 26214400
  //     10 mb = 10485760
  //      */
  //     if (selectedFile[0].size > 10485760) {


  //       cstWarningMsg = "File size should not exceed more then 10 MB"; //Bug number -396 decre
  //       isValidFile = false;
  //     }
  //     if (checkingSpl(selectedFile[0].name)) {
  //       isValidFile = false;
  //       cstWarningMsg = "File name sholud not contain special characters";
  //     }

  //     if (isValidFile) {
  //       var fileToLoad = selectedFile[0];
  //       // FileReader function for read the file.
  //       var fileReader = new FileReader();
  //       // Onload of file read the file content
  //       fileReader.onload = function (fileLoadedEvent) {
  //         let base64 = fileLoadedEvent.target.result;
  //         const RemovedHeaderFormBase64 = base64.split(",");
  //         SetWordPDFInfowarring({
  //           ...wordandPdfWarring,
  //           PDFInfo: {
  //             fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
  //             fileName: selectedFile[0].name,
  //             filePath: RemovedHeaderFormBase64[1],
  //             isValid: isValidFile,
  //             warningMsg: cstWarningMsg
  //           },

  //         });
  //       };
  //       // Convert data to base64
  //       fileReader.readAsDataURL(fileToLoad);
  //     } else {
  //       SetWordPDFInfowarring({
  //         ...wordandPdfWarring,
  //         PDFInfo: {
  //           fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
  //           fileName: selectedFile[0].name,
  //           filePath: "",
  //           isValid: isValidFile,
  //           warningMsg: cstWarningMsg
  //         }

  //       });
  //     }
  //   }
  // };
// Added for base 64 split params ---> Kavya(18-07)
  const convertPDFToBase64 = () => {
    var selectedFile = document.getElementById("PDFDocfile").files;
    let cstWarningMsg = "";
    let isValidFile = true;
    
    if (selectedFile.length > 0) {
      var fileExtension = selectedFile[0].name.split(".");
      const fileName = selectedFile[0].name;
  
      if (!(fileName.toLowerCase().endsWith("pdf"))) {
        cstWarningMsg = "File type not allowed";
        isValidFile = false;
      }
  
      if (selectedFile[0].size > 10485760) {
        cstWarningMsg = "File size should not exceed more than 10 MB";
        isValidFile = false;
      }
  
      if (checkingSpl(selectedFile[0].name)) {
        isValidFile = false;
        cstWarningMsg = "File name should not contain special characters";
      }
  
      if (isValidFile) {
        var fileToLoad = selectedFile[0];
        var fileReader = new FileReader();
  
        fileReader.onload = function (fileLoadedEvent) {
          let base64 = fileLoadedEvent.target.result;
          const RemovedHeaderFormBase64 = base64.split(",")[1];
  
          const partLength = Math.ceil(RemovedHeaderFormBase64.length / 10);
          const parts = [];
  
          for (let i = 0; i < 10; i++) {
            parts.push(RemovedHeaderFormBase64.slice(i * partLength, (i + 1) * partLength));
          }
  
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            PDFInfo: {
              fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
              fileName: selectedFile[0].name,
              filePath: {
                part1: parts[0],
                part2: parts[1],
                part3: parts[2],
                part4: parts[3],
                part5: parts[4],
                part6: parts[5],
                part7: parts[6],
                part8: parts[7],
                part9: parts[8],
                part10: parts[9]
              },
              isValid: isValidFile,
              warningMsg: cstWarningMsg
            }
          });
        };
  
        fileReader.readAsDataURL(fileToLoad);
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          PDFInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: {},
            isValid: isValidFile,
            warningMsg: cstWarningMsg
          }
        });
      }
    }
  };
    

  //Helps to validate multiple docs - Support documents
  const checkingSpl = (test) => {
    var specialCharPattern = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;

    // Test the input string against the pattern
    return specialCharPattern.test(test);
  };

  //It helps to validate and attach documents - support documents
  const multipleDocUpload = () => {
    let isValidFile = true;
    let waringmsg = "";
    let reamingFileSize = 26214400;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
  
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.forEach(obj => 
        reamingFileSize -= obj.supportingDocumentPathLength
      );
    }

    const arrayExtension = [
      ".pdf", ".doc", ".docx", ".xlsx",
      ".PDF", ".DOC", ".DOCX", ".XLSX"
    ];
    const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
    const selectedFile = document.getElementById("multiDoc").files;
    const TempfileInfo = filesInfo;
  
    const promises = [];
    const fileCount = selectedFile.length;
  
    for (let i = 0; i < fileCount; i++) {
      const fileToLoad = selectedFile[i];
      const fileExtession = fileToLoad.name.split(".");
  
      if (!filesInfo?.some(obj => obj.supportingDocumentFileName === fileToLoad.name)) {
        if (!arrayExtension.includes(`.${fileExtession[fileExtession.length - 1]}`)) {
          isValidFile = false;
          waringmsg = "File type is not allowed";
          SetSupportDocWarning({
            ...supportDocWarning,
            [fileToLoad.name]: {
              filename: fileToLoad.name,
              isValid: true,
              warningMsg: waringmsg,
              fileExtnsion: fileExtession[fileExtession.length - 1],
            },
          });
        } else if (validname.test(fileToLoad.name)) {
          // isValidFile = false;
          waringmsg = "File name should not contain special characters";
          SetSupportDocWarning({
            ...supportDocWarning,
            [fileToLoad.name]: {
              filename: fileToLoad.name,
              isValid: true,
              warningMsg: waringmsg,
              fileExtnsion: fileExtession[fileExtession.length - 1],
            },
          });
        } else if (fileToLoad.size > reamingFileSize) {
          // isValidFile = false;
          waringmsg = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
          setSupportingError(waringmsg);
        }
      }
  
      const fileReader = new FileReader();
  
      const promise = new Promise((resolve) => {
        fileReader.onload = function (fileLoadedEvent) {
          // Added for base 64 split ---> Kavya(18-07)
          const base64 = fileLoadedEvent.target.result.split(",")[1];
          const partLength = Math.ceil(base64.length / 10);
          const parts = [];
          for (let j = 0; j < 10; j++) {
            parts.push(base64.slice(j * partLength, (j + 1) * partLength));
          }
  
          resolve({
            name: fileToLoad.name,
            parts: parts,
            size: fileToLoad.size
          });
        };
      });
  
      fileReader.readAsDataURL(fileToLoad);
      promises.push(promise);
    }
  
    Promise.all(promises)
      .then((fileDataArray) => {
        const updatedTempFileInfo = fileDataArray.reduce((acc, fileData) => {
          const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
          if (!ObjExist.includes(fileData.name)) {
            acc.push({
              noteSupportingDocumentId: 0,
              noteId: 0,
              supportingDocumentFileName: fileData.name,
              createdDate: new Date(),
              createdBy: accounts[0].username,
              modifiedDate: new Date(),
              modifiedBy: accounts[0].username,
              // Added for base 64 split params parts ---> Kavya(18-07)
              supportingDocumentPathPart1: fileData.parts[0],
              supportingDocumentPathPart2: fileData.parts[1],
              supportingDocumentPathPart3: fileData.parts[2],
              supportingDocumentPathPart4: fileData.parts[3],
              supportingDocumentPathPart5: fileData.parts[4],
              supportingDocumentPathPart6: fileData.parts[5],
              supportingDocumentPathPart7: fileData.parts[6],
              supportingDocumentPathPart8: fileData.parts[7],
              supportingDocumentPathPart9: fileData.parts[8],
              supportingDocumentPathPart10: fileData.parts[9],
              supportingDocumentPathLength: fileData.size
            });
          }
          return acc;
        }, [...TempfileInfo]);
  
        SetFileinfo(updatedTempFileInfo);
      })
      .catch((error) => {
        console.error("Error reading files:", error);
      });
  };
  
  /* Add Reviewers and Approvers Data */
  // const [data] = useState([]);
  /*   const [selectedRowId, setSelectedRowId] = useState(null);
    const [selectedRowId1, setSelectedRowId1] = useState(null); */

  /*  const handleRowClick = (id) => {
     setSelectedRowId((id === selectedRowId || selectedRowId === -1) ? null : id);
   }; */

  /*   const handleRowClick1 = (id) => {
      setSelectedRowId1((id === selectedRowId1 || selectedRowId1 === -1) ? null : id);
    }; */

  /*  const handleDelete = async (approverOrder) => {
 
     const updatedData = notereviewerData.filter(
       (row) => row.approverOrder !== approverOrder
     );
     updatedData.forEach((item, index) => {
       item.approverOrder = index + 1;
     });
     setNoteReviewerData(updatedData);
   }; */

  //Delete Approvers from Approver table
  /*   const handleDeleteApprover = async (approverOrder) => {
      const updatedData = noteapproverData.filter(
        (row) => row.approverOrder !== approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      setNoteApproverData(updatedData);
      if (updatedData?.length > 0) {
        const secretaryValChk = await findSecrateries(updatedData, userDepartment);
        if (!secretaryValChk) {
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            wordInfo: {
              fileExtension: "",
              fileName: "",
              filePath: "",
              isValid: false,
            },
          });
        }
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: "",
            fileName: "",
            filePath: "",
            isValid: false,
          },
        });
      }
    }; */

  //Helps to move up slected reviewer
  /*  const handleMoveUp = () => {
     debugger;
     if (selectedRowId) {
       const selectedIndex = notereviewerData.findIndex(
         (item) => item.approverOrder === selectedRowId
       );
       if (selectedIndex > 0) {
         const newData = [...notereviewerData];
         const temp = newData[selectedIndex];
         newData[selectedIndex] = newData[selectedIndex - 1];
         newData[selectedIndex - 1] = temp;
         newData.forEach((item, index) => {
           item.approverOrder = index + 1;
         });
         setNoteReviewerData(newData);
         setSelectedRowId(selectedRowId - 1);
       }
     }
   }; */

  //Helps to move down slected reviewer
  /* const handleMoveDown = () => {
    if (selectedRowId) {
      const selectedIndex = notereviewerData.findIndex(
        (item) => item.approverOrder === selectedRowId
      );
      if (selectedIndex !== -1 && selectedIndex < notereviewerData.length - 1) {
        const newData = [...notereviewerData];
        const temp = newData[selectedIndex];
        newData[selectedIndex] = newData[selectedIndex + 1];
        newData[selectedIndex + 1] = temp;
        newData.forEach((item, index) => {
          item.approverOrder = index + 1;
        });
        setNoteReviewerData(newData);
        setSelectedRowId(selectedRowId + 1);
      }
    }
  }; */

  //Helps to move up slected approver
  /*  const handleMoveUpapprover = () => {
     if (selectedRowId1) {
       const selectedIndex = noteapproverData.findIndex(
         (item) => item.approverOrder === selectedRowId1
       );
       if (selectedIndex > 0) {
         const newData = [...noteapproverData];
         const temp = newData[selectedIndex];
         newData[selectedIndex] = newData[selectedIndex - 1];
         newData[selectedIndex - 1] = temp;
         newData.forEach((item, index) => {
           item.approverOrder = index + 1;
         });
         setNoteApproverData(newData);
         setSelectedRowId1(selectedRowId1 - 1);
       }
     }
   }; */

  //Helps to move down slected approver
  /* const handleMoveDownapprover = () => {
    if (selectedRowId1) {
      const selectedIndex = noteapproverData.findIndex(
        (item) => item.approverOrder === selectedRowId1
      );
      if (selectedIndex !== -1 && selectedIndex < noteapproverData.length - 1) {
        const newData = [...noteapproverData];
        const temp = newData[selectedIndex];
        newData[selectedIndex] = newData[selectedIndex + 1];
        newData[selectedIndex + 1] = temp;
        newData.forEach((item, index) => {
          item.approverOrder = index + 1;
        });
        setNoteApproverData(newData);
        setSelectedRowId1(selectedRowId1 + 1);
      }
    }
  }; */

  // handle Reviewer chaange
  const handleComboChangeReviewer = (event) => {
    setSelectedReviewer(event.value);
  };

  // handle  Approver change
  const handleComboChangeApprover = (event) => {
    setComboValueApprover(event.value);
  };

  //Helps to add selected reviewer to the reviewers table
  const handleAddRow = async () => {
    if (!selectedReveiwer) {
      setShowNotification(true);
      setNotificationMsg("Please select reviewer then click on Add.");
      return;
    }

    //Removed this function due to loading impact users will be filtered on search box enter - 22/03
    // setOrgEmployees(approveremailsObject);
    let isApproverValid =
      noteapproverData.find((x) => x.approverEmail === selectedReveiwer.userPrincipalName) ===
      undefined;
    let isReviewerValid =
      notereviewerData.find((x) => x.approverEmail === selectedReveiwer.userPrincipalName) ===
      undefined;

    if (isApproverValid && isReviewerValid && selectedReveiwer.userPrincipalName !== accounts[0].username && selectedReveiwer.userPrincipalName !== state.createdBy) {
      const newRow = {
        approverType: 1,
        approverEmail: selectedReveiwer.userPrincipalName,
        approverOrder: notereviewerData.length + 1,
        approverStatus: 1,
        // Bug fix - 294 - 27/03
        srNo: selectedReveiwer.srNo,
        designation: selectedReveiwer.jobTitle,
        approverEmailName: selectedReveiwer.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
      };
      setNoteReviewerData((prevData) => [...prevData, newRow]);
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected reviewer cannont be same as existing Reviewers/Requester/CurrentActioner."
      );
    }
    setSelectedReviewer(null);
    setOrgEmployees([]);
  };

 
  const handleOpenReveiwer = () => {
    if (!selectedReveiwer) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectedReveiwer.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  const handleOpenApprover = () => {
    if (!combovalueApprover) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(combovalueApprover.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  //Helps to add selected approver to the approvers table
  const handleAddRowApprover = async () => {
    if (!combovalueApprover) {
      setShowNotification(true);
      setNotificationMsg("Please select approver then click on Add.");
      return;
    }

    //Removed this function due to loading impact users will be filtered on search box enter - 22/03
    // setOrgEmployees(approveremailsObject);
    let isApproverValid =
      noteapproverData.find((x) => x.approverEmail === combovalueApprover.userPrincipalName) ===
      undefined;
    let isReviewerValid =
      notereviewerData.find((x) => x.approverEmail === combovalueApprover.userPrincipalName) ===
      undefined;

    if (isApproverValid && isReviewerValid && combovalueApprover.userPrincipalName !== accounts[0].username && combovalueApprover.userPrincipalName !== state.createdBy) {

      const newRow = {
        approverType: 2,
        approverEmail: combovalueApprover.userPrincipalName,
        approverOrder: noteapproverData.length + 1,
        approverStatus: 1,
        // Bug fix - 294 - 27/03
        srNo: combovalueApprover.srNo,
        designation: combovalueApprover.jobTitle,
        approverEmailName: combovalueApprover.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username
      };
      setNoteApproverData((prevData) => [...prevData, newRow]);

      let upApprObj = [...noteapproverData, newRow];
      if (upApprObj?.length > 0) {
        const secretaryValChk = await findSecrateries(upApprObj, userDepartment);
        if (!secretaryValChk) {
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            wordInfo: {
              fileExtension: "",
              fileName: "",
              filePath: "",
              isValid: false,
            },
          });
        }
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: "",
            fileName: "",
            filePath: "",
            isValid: false,
          },
        });
      }
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected approver cannont be same as existing Reviewers/Requester/CurrentActioner."
      );
    }
    setComboValueApprover(null);
    setOrgEmployees([]);
  };

  //It helps to remove Word/PDF attachments
  const onRemoveAttachmentWarning = (key) => {
    if (key === "PDFInfo") {
      SetWordPDFInfowarring({
        ...wordandPdfWarring,
        PDFInfo: {
          fileExtension: "",
          fileName: "",
          warningMsg: "",
          filePath: "",
          isValid: false,
        },
        /*  wordInfo: {
           fileExtension: "",
           fileName: "",
           warningMsg: "",
           filePath: "",
           isValid: false,
         }, */
      });
    }
    if (key === "wordInfo") {
      SetWordPDFInfowarring({
        ...wordandPdfWarring,
        [key]: { fileExtension: "", fileName: "", isValid: false },
      });
    }
  };

  //Helps to attache icon based on file extension
  const getFileIcon = (filename) => {
    const fileSplit = filename.split(".");
    const extnsion = `.${fileSplit[fileSplit.length - 1]}`;
    const fileExtension = extnsion.toLowerCase();
    let fileType = fileIcon;
    if (fileExtension === ".pdf") {
      fileType = filePdfIcon;
    }
    if (fileExtension === ".doc" || fileExtension === ".docx") {
      fileType = fileWordIcon;
    }
    if (fileExtension === ".png" || fileExtension === ".jpg") {
      fileType = fileImageIcon;
    }
    if (fileExtension === ".txt") {
      fileType = fileTxtIcon;
    }
    if (fileExtension === ".xlsx") {
      fileType = fileDataIcon;
    }
    return fileType;
  };

  // remove multiple attchemnts - support documents
  const onRemoveMultiAttachment = (id) => {
    const filename = filesInfo.find((obj, index) => index === id).supportingDocumentFileName;
    delete supportDocWarning[filename];
    SetSupportDocWarning(supportDocWarning);
    // let reamingFileSize = 26214400;
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map((obj, index) => {
        if (index !== id) {
          totalFileSize = totalFileSize + obj.supportingDocumentPathLength
        }
      }

      );


      if (totalFileSize <= 26214400) {
        setSupportingError("");
      }
    }
    SetFileinfo(filesInfo.filter((obj, ind) => ind !== id));
  };

  const [orgEmployees, setOrgEmployees] = React.useState([]);

  //Helps to filter the people picker dropdown vaules

  const pplFilterMultiColumn = async (event) => {

    if (event.filter.value.length >= 4) {
      setOrgEmployees([]);
      const accessToken = await getAccessToken({
        ...loginRequest,
        account
      }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            return { ...x, department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName, srNo: x.srNo === null ? "NA" : x.srNo }
          });
          setOrgEmployees(orgUsers);
          setAllOrgUsers(orgUsers);
        })
        .catch((err) => {
          setOrgEmployees([]);
          console.log(err);
        });
    } else if(event.filter.value.length < 4){
      setOrgEmployees([]);
    }
    else {
      setOrgEmployees([]);
    }
    //Added  ----------------- 22/03 --------------------

  };

  //HTML - render
  return (
    <div>
      <Navbar header="IB Smart Office - eNote" />
      <Sidebar />
      {/* {isNewForm || (!isNewForm && ((state.status === 1 || state.status === 4 ||state.status === 8 ) && state.createdBy === accounts[0].username)) ? */}
      <div className="FormMaincontainer">
        <div className="container">
          <div className="HeaderButtonsContainer row">
            <div className="cstformHdrLeftContainer mobileTitleNewForm">
              {isNewForm ? "" : `Status: ${state.statusMsg}`}
            </div>
            <div className="cstformHdrMiddleContainer mobileTitleNewForm">
              eNote - {isNewForm ? "New" : `${state.noteId}`}
            </div>
            <div className="cstformHdrRightContainer mobileTitleNewForm">
              {isNewForm ? (
                <span>
                  Date: <Clock format={"DD-MMM-YYYY hh:mm:ss A"} ticking={true} />
                </span>
              ) : (
                `Created: ${state.createdDate}`
              )}
            </div>
          </div>
        </div>
        <div className="container mobileViewCSS">
          <Form
            render={() => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="errorMsg">All fields marked "*" are mandatory</div>
                  <div className="SectionHeads row">General Section</div>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Department:
                            <span className="required-asterisk">*</span>
                          </Label>

                           {userDepartment && (
                            <Field
                              component={Input}
                              name="Department"
                              value={state.Department}
                              // defaultValue={accounts[0].username}
                              defaultValue={userDepartment}
                              style={{ border: "none" }}
                              readOnly
                            />
                          )} 
                          {/* Removing this field  and added dropdown -13/05*/}
                          {/* <DropDownList
                            data={departmentList.map((x) => x.departmentName)}
                            // defaultItem={"Select"}
                            onChange={handleSelectedDepartment}
                            value={userDepartment}
                            name="DepartMent"
                            // required={true}
                            style={{ borderColor: departmentBorderColor }}
                            valueRender={element => valueRenderDepartment(element, userDepartment)}
                          /> */}
                        </div>
                        <div className="errorMsg">{departmentError}</div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Note To:<span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            data={noteto.map((x) => x.dValue)}
                            // defaultItem={"Select"}
                            onChange={handleNote}
                            value={state.NoteTo}
                            name="NoteTo"
                            // required={true}
                            style={{ borderColor: noteBorderColor }}
                            valueRender={element => valueRender(element, state.NoteTo, 'NoteTo')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Subject:<span className="required-asterisk">*</span>
                          </Label>
                          <TextArea
                            maxLength={max}
                            onChange={handleSubjectChange}
                            value={state.Subject}
                            rows={1}
                            style={{ borderColor: subjectBorderColor }}
                            className="mobileFieldHeight"
                          />
                          <Hint direction={"end"}>
                            {state.Subject.length} / {max}
                          </Hint>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Nature of Note:
                            <span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            name="NatureOfNote"
                            data={natureofnote.map((x) => x.dValue)}
                            // defaultItem={"Select"}
                            value={state.NatureOfNote}
                            onChange={handleNatureOfNoteChange}
                            style={{ borderColor: natureofnoteBorderColor }}
                            valueRender={element => valueRender(element, state.NatureOfNote, 'NatureOfNote')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    {showNatureOfApprSanc && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Nature of Approval/Sanction:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              name="NatureOfApprSanc"
                              value={state.NatureOfApprSanc}
                              data={natureofapprsanc.map((x) => x.dValue)}
                              // defaultItem={"Select"}
                              onChange={handleNatureOfApprSancChange}
                              style={{
                                borderColor: natureofapprsancBorderColor,
                              }}
                              valueRender={element => valueRender(element, state.NatureOfApprSanc, 'NatureOfApprSanc')}
                            />
                          </div>
                          {/* <div className="errorMsg">
                            {natureofapprsancError}
                          </div> */}
                        </FieldWrapper>
                      </div>
                    )}
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Note Type:
                            <span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            data={notetype.map((x) => x.dValue)}
                            value={state.NoteType}
                            // defaultItem={"Select"}
                            onChange={handleNoteType}
                            style={{ borderColor: notetypeBorderColor }}
                            valueRender={element => valueRender(element, state.NoteType, 'NoteType')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    {showTypeOfFinNote && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Type of Financial Note:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              data={fintype.map((x) => x.dValue)}
                              value={state.TypeOfFinNote}
                              // defaultItem={"Select"}
                              onChange={handleTypeOfFin}
                              style={{ borderColor: typeoffinBorderColor }}
                              valueRender={element => valueRender(element, state.TypeOfFinNote, 'TypeOfFinNote')}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {showAmount && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Amount:
                              <span className="required-asterisk">*</span>
                            </Label>
                            {/* Bug fix - 297 - 27/03 */}
                            {/* <NumericTextBox
                              // format="n2"
                              min={0}
                              onChange={handleAmount}
                              value={amount}
                              defaultValue={amount}
                              style={{ borderColor: amountBorderColor }}
                            /> */}
                            <Input
                              value={amount}
                              onChange={handleAmount}
                              defaultValue={amount}
                              style={{ borderColor: amountBorderColor }}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Search Text:
                            <span className="required-asterisk">*</span>
                          </Label>
                          <TextArea
                            maxLength={max}
                            // value={value}
                            value={state.Search}
                            onChange={handleSearchChange}
                            rows={1}
                            style={{ borderColor: searchBorderColor }}
                              className="mobileFieldHeight"
                          />
                          <Hint direction={"end"}>
                            {state.Search.length} / {max}
                          </Hint>
                        </div>
                      </FieldWrapper>
                    </div>
                    {showPurpose && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Purpose:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <Input
                              // component={Input}
                              value={purpose}
                              name="Purpose"
                              // defaultValue={purpose}
                              // key={state.Purpose}
                              onChange={handlePurpose}
                              style={{ borderColor: purposeBorderColor }}
                                className="mobileFieldHeight"
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {showPurpose1 && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Purpose:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              data={drpOptPurposeApproval.map((x) => x.dValue)}
                              // defaultItem={"Select"}
                              value={state.PurposeApproval}
                              onChange={handlePurposeApproval}
                              style={{ borderColor: purpose1BorderColor }}
                              valueRender={element => valueRender(element, state.PurposeApproval, 'PurposeApproval')}

                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {showPurpose2 && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Purpose:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              data={drpOptPurposeInformation.map(
                                (x) => x.dValue
                              )}
                              // defaultItem={"Select"}
                              value={state.PurposeInformation}
                              onChange={handlePurposeInformation}
                              style={{ borderColor: purpose2BorderColor }}
                              valueRender={element => valueRender(element, state.PurposeInformation, 'PurposeInformation')}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {(showPurpose1 && purpose === "Others") && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Others:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <Input
                              // component={Input}
                              value={purposeOthers}
                              name="PurposeOthers"
                              // defaultValue={purpose}
                              // key={state.Purpose}
                              onChange={handlePurposeInfoOthers}
                              style={{ borderColor: purposeOthersBorderColor }}
                                className="mobileFieldHeight"
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                  </div>

                  <div className="SectionHeads row">Approver Details</div>
                  <div className="SectionRow row">
                    <div className="_approverDetailsDiv">
                      <MultiColumnComboBox
                        data={orgEmployees}
                        filterable={true}
                        // mobile view design for dropdown
                        columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                        // columns={orgUsersPplPickerColumnMapping}
                        // textField={"displayName"}
                        value={
                          selectedReveiwer === null
                            ? null
                            : selectedReveiwer.displayName
                        }
                        // itemRender={orgUsersPplPickerItemRender}
                        onFilterChange={pplFilterMultiColumn}
                        onChange={handleComboChangeReviewer}
                        onOpen={handleOpenReveiwer}
                        style={{ width: isMobile ? "100%" : "300px",marginRight: "5px", }} // Adjust width
                        placeholder="Add Reviewer..."
                       
                      />
                      <Button onClick={handleAddRow}>
                        <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                        Add
                      </Button>
                    </div>
                    {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                    <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                    <div className="cstDisableGridScroll">
                      {/* added scroll class 24/04 */}
                      <TableDraggableRows
                        //Change - Adding SR No - 05/04 - RK 
                        srCol="SR No"
                        // Change - Adding Designation- 05/04 - RK 
                        designationCol="Designation"
                        reviewerCol="Reviewer"
                        data={notereviewerData}
                        onDelate={deletereviewer}
                        onOrderChange={orderChange} />
                    </div>
                    <div className="_reviewerDetailsDiv">
                    </div>
                    <div className="_reviewerDetailsCol">
                      <MultiColumnComboBox
                        data={orgEmployees}
                        filterable={true}
                        // columns={orgUsersPplPickerColumnMapping}
                        // mobile view design for dropdown
                        columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                        style={{ width: isMobile ? "100%" : "300px",marginRight: "5px", }} // Adjust width
                        // textField={"displayName"}
                        value={
                          combovalueApprover === null
                            ? null
                            : combovalueApprover.displayName
                        }
                        // itemRender={orgUsersPplPickerItemRender}
                        onFilterChange={pplFilterMultiColumn}
                        onChange={handleComboChangeApprover}
                        onOpen={handleOpenApprover}
                        placeholder="Add Approver..."
                      />
                      <Button onClick={handleAddRowApprover}>
                        <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                        Add</Button>
                    </div>
                    {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                    <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                    <div className="cstDisableGridScroll">
                      {/* added scroll class 24/04 */}
                      <TableDraggableRows
                        //Change - Adding SR No - 05/04 - RK 
                        srCol="SR No"
                        // Change - Adding Designation- 05/04 - RK 
                        designationCol="Designation"
                        reviewerCol="Approver"
                        data={noteapproverData}
                        onDelate={deletereviewer}
                        onOrderChange={orderChange} />
                    </div>


                    <div className="_reviewerDetailsDiv">
                    </div>
                  </div>

                  {(!isNewForm && state.status === enumsObj?.NoteStatus.find(x => x.dValue === "Returned").id) &&
                    (<div>
                      <div className="SectionHeads eNoteAtrFormHdr row">
                        Comments
                      </div>
                      <div className="SectionRow row">
                      <div className="table-responsive">
                        <table className="SectionRow cstATRFormTbl tableStyle">
                          <tr>
                            <th className="approvalform-tableCol-width-1">Page#</th>
                            <th className="approvalform-tableCol-width-1">Doc Reference</th>
                            <th className="approvalform-tableCol-width-5">Comments</th>
                            <th className="approvalform-tableCol-width-3">Comment By</th>
                          </tr>
                          {noteComments?.map((comment) => (
                            <tr key={comment.noteApproverCommentID}>
                              <td className="approvalform-tableCol-width-1">{comment.pageNumber}</td>
                              <td className="approvalform-tableCol-width-1">{comment.docReferrence}</td>
                              <td className="approvalform-tableCol-width-5">{comment.comments}</td>
                              <td className="approvalform-tableCol-width-3">{comment.createdBy}</td>
                            </tr>
                          )
                          )}
                        </table>
                      </div>
                      </div>
                    </div>
                    )}

                  <div className="SectionHeads row">File Attachments</div>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      {" "}
                      <Label className="k-form-label">
                        Note PDF<span className="required-asterisk">*</span>
                      </Label>
                      {/* <Upload batch={false} onBeforeUpload={onBeforeUpload} restrictions={{ allowedExtensions: [".pdf"], maxFileSize: 26214400, }} multiple={false} defaultFiles={[]} withCredentials={false} accept="string"  saveUrl={'https://indianbankxenciaapp.azurewebsites.net/api/ENote/AddNote'}/> */}
                      {/* //(Naren....) */}
                      <div className="Attachemntfileinfo-ind">
                        <input
                          type="file"
                          id="PDFDocfile"
                          onChange={convertPDFToBase64}
                          className="_ConvertPDFToBase64"
                        />
                      </div>
                      {wordandPdfWarring?.PDFInfo.fileName === null ||
                        wordandPdfWarring?.PDFInfo.fileName === "" ? null : (
                        <div className="Attachemntfileinfo-ind">
                          <span className="attachemntIconInfoConationer">
                            <span className="AttchemntIconWraper">
                              <SvgIcon
                                icon={getFileIcon(
                                  wordandPdfWarring?.PDFInfo.fileName
                                )}
                                size="xxlarge"
                              />
                              <span className="attachemnrt-warningifoConatiner">
                                <div className="attachemnrt-warningifo-fileinfo">
                                  {wordandPdfWarring?.PDFInfo.fileName}
                                </div>
                                <span
                                  className="inCorrectFileError"
                                >
                                  {wordandPdfWarring?.PDFInfo.warningMsg}
                                </span>
                              </span>
                            </span>
                            <span
                              className="AttchemntIconWraperCancel"
                              onClick={() =>
                                onRemoveAttachmentWarning("PDFInfo")
                              }
                            >
                              X
                            </span>
                          </span>
                        </div>
                      )}
                      <div 
                      className="_fileFormatHintMsg"
                      >
                        {/* Bug -396
                        *For Note pdf the maximum allowed size should be decreased from 25 MB to 10 MB
                         */}
                        Allowed only one PDF.Upto 10MB max.
                      </div>
                    </div>
                    {noteapproverData?.length > 0 && isSecretaryExist && (
                      <div className="col-md-6">
                        <Label className="k-form-label">
                          Word Document
                          <span className="required-asterisk">*</span>
                        </Label>
                  
                        <div className="Attachemntfileinfo-ind">
                          {" "}
                          <input
                            type="file"
                            id="WordDocfile"
                            onChange={convertBase64Word}
                            className="_ConvertPDFToBase64"
                          />
                        </div>
                        {wordandPdfWarring?.wordInfo.fileName === null ||
                          wordandPdfWarring?.wordInfo.fileName === "" ? null : (
                          <div className="Attachemntfileinfo-ind">
                            <span className="attachemntIconInfoConationer">
                              <span className="AttchemntIconWraper">
                                <SvgIcon
                                  icon={getFileIcon(
                                    wordandPdfWarring?.wordInfo.fileName
                                  )}
                                  size="xxlarge"
                                />
                                <span className="attachemnrt-warningifoConatiner">
                                  <div className="attachemnrt-warningifo-fileinfo">
                                    {wordandPdfWarring?.wordInfo.fileName}
                                  </div>
                                  <span
                                    className="inCorrectFileError"
                                  >
                                    {wordandPdfWarring?.wordInfo.warningMsg}
                                  </span>
                                </span>
                              </span>
                              <span
                                className="AttchemntIconWraperCancel"
                                onClick={() =>
                                  onRemoveAttachmentWarning("wordInfo")
                                }
                              >
                                X
                              </span>
                            </span>
                          </div>
                        )}

                        <div 
                        className="_fileFormatHintMsg"
                        >
                          Allowed only one Word.Upto 10MB max.
                        </div>
                      </div>
                    )}
                    <div className="col-md-6">
                      <Label className="k-form-label">
                        Supporting Documents
                        {/* <span className="required-asterisk">*</span> */}
                      </Label>
                      {/* multidoc controller */}
                      <div className="Attachemntfileinfo-ind">
                        <input
                          type="file"
                          id="multiDoc"
                          onChange={multipleDocUpload}
                          className="_ConvertPDFToBase64"
                        />
                        <div>
                          <span className="inCorrectFileError">
                            {
                              supportingDocError
                            }
                          </span>
                        </div>
                      </div>
                      {/*  //(Naren....) */}
                      {filesInfo?.map((obj, ind) => (
                        <div className="Attachemntfileinfo-ind" key={ind}>
                          <span className="attachemntIconInfoConationer">
                            <span className="AttchemntIconWraper">
                              {/* Assuming you have different icons for different file types */}
                              <SvgIcon
                                icon={getFileIcon(
                                  obj.supportingDocumentFileName
                                )}
                                size="xxlarge"
                              />
                              <span className="attachemnrt-warningifoConatiner">
                                <div className="attachemnrt-warningifo-fileinfo">
                                  {obj.supportingDocumentFileName}
                                </div>
                                <span className="inCorrectFileError">
                                  {
                                    supportDocWarning[
                                      obj.supportingDocumentFileName
                                    ]?.warningMsg
                                  }
                                </span>
                              </span>
                            </span>
                            <span
                              className="AttchemntIconWraperCancel"
                              onClick={() => onRemoveMultiAttachment(ind)}
                            >
                              X
                            </span>
                          </span>
                        </div>
                      ))}
                      {/* <Upload batch={false} restrictions={{ allowedExtensions: [".pdf", ".doc", ".docx", ".xlsx", ".eml"], maxFileSize: 5242880, }} multiple={true} defaultFiles={[]} withCredentials={false} accept="string" saveUrl={'https://demos.telerik.com/kendo-ui/service-v4/upload/save'} removeUrl={'https://demos.telerik.com/kendo-ui/service-v4/upload/remove'} />
                       */}
                      <div 
                      className="_fileFormatHintMsg"
                      >
                        {/* Allowed Formats (images,pdf,eml,doc,docx,xlsx only) Upto 5MB max. */}
                        {/* Bug -396 fixed  */}
                        Allowed Formats (pdf,doc,docx,xlsx only) Upto 25MB max.
                      </div>
                    </div>
                  </div>
                </fieldset>
                <div className="FormButtonsContainer k-form-buttons">
                  {(isNewForm ||
                    (!isNewForm &&
                      state.status === 1 &&
                      state.createdBy === accounts[0].username)) && (
                      <Button
                        type={"button"}
                        onClick={handleSave}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className=" k-icon-xs k-icon k-font-icon k-i-save cursor allIconsforPrimary-btn"></span>
                        <save>
                          Save as Draft
                        </save>
                      </Button>
                    )}
                  {/* {isNewForm && <Autosave interval={5000} onSave={handleAutoSave} />} */}
                  {(isNewForm ||
                    (!isNewForm &&
                      (state.status === 1 ||
                        state.status === 4 ||
                        state.status === 8) &&
                      state.createdBy === accounts[0].username)) && (
                      <Button
                        onClick={handleOpenDialog}
                        type={"submit"}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon k-i-launch cursor allIconsforPrimary-btn"></span>
                        Submit
                      </Button>
                    )}
                  {!isNewForm &&
                    state.status === 4 &&
                    state.createdBy === accounts[0].username && (
                      <span className="eNote-ApprovalButton">
                        <Button
                          onClick={() => setVisibleCancelCfrm(true)}
                          className="formBtnColor"
                        >
                          <span className="k-icon-sm k-icon k-font-icon k-i-cancel cursor allIconsforPrimary-btn"></span>
                          Cancel Note
                        </Button>
                      </span>
                    )}
                  <Link to="/datagridpage">
                    <Button
                      type={"submit"}
                      className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                    >
                      <span className="k-icon-sm k-icon k-font-icon  k-i-x-circle cursor allIconsforPrimary-btn"></span>
                      Exit
                    </Button>
                  </Link>
                </div>
                {isLoading && <PageLoader />}
                {visiblesave && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleSaveClose}
                  >
                    <p className="dialogcontent_">
                      {successMessage}
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() =>{ setTab("My Pending Notes");navigate(redirectTo);}}
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visible && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={handleCloseDialog}
                      className="dialogcontent_Refer"
                  >
                    <p className="dialogcontent_">
                      Are you sure you want to submit this request?
                    </p>
                    <p  className="dialogcontent_">
                      Please check the details filled along with attachment and
                      click on Confirm button to submit request.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                        onClick={handleSubmit}
                      >
                        {/* {isLoading ? 'Loading...' : 'Confirm'} */}
                        <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                        Confirm
                      </Button>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleCloseDialog}
                      >
                        <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visibleCancelCfrm && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={() => setVisibleCancelCfrm(false)}
                     className="dialogcontent_Refer"
                  >
                    <p className="dialogcontent_">
                      Are you sure you want to cancel this request?
                    </p>
                    <p className="dialogcontent_">
                      Please click on Confirm button to cancel request.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                        onClick={onCancelNote}
                      >
                        <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                        Confirm
                      </Button>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => setVisibleCancelCfrm(false)}
                      >
                        <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {alertvisible && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setAlertVisible(false)}
                  >
                    <p className="dialogcontent_">
                      The request for eNote has been submitted successfully.
                    </p>
                    <DialogActionsBar>
                    {/* Commented because after enote create it should redirect to my pending notes page */}
                      {/* <Link
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        to="/datagridpage"
                      > */}
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => {setTab("My Pending Notes"); navigate(redirectTo);}}
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                      {/* </Link> */}
                    </DialogActionsBar>
                  </Dialog>
                )}

                {validationErrors && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleClosevalidationDialog}
                  >
                    <p className="cstDailogValidmsg">
                      {/* Bug fix - order of validation - 05/04 - RK */}
                      <div className="_cstDialogDiv">
                        <p className="_cstDialogDivp">Please fill up all the mandatory fields</p>
                        <ul className="_cstDialogDivUl">
                          {errorMessages.map((message, index) => (
                            <li className="_cstDialogDivUlli" key={index}>{message}</li>
                          ))}
                        </ul>
                        <p>
                          <strong>Note:</strong> Invalid files are not allowed
                        </p>
                      </div>
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={handleClosevalidationDialog}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}

                {showNotification && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setShowNotification(false)}
                  >
                    <p className="dialogcontent_">
                      {notificationMsg}
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={() => setShowNotification(false)}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
              </FormElement>
            )}
          />
        </div>
      </div>
      <Footer />
    </div>
  );
};