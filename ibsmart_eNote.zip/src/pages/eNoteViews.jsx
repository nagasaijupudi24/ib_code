import React, { useState, useEffect } from "react";
// import Kendo components
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import { Link } from "react-router-dom";
import { Button } from "@progress/kendo-react-buttons";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
import { getter } from "@progress/kendo-react-common";
import { orderBy } from "@progress/kendo-data-query";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
// import external components
import { useMsal, useAccount } from "@azure/msal-react";
import { CSVLink } from "react-csv";
import DateObject from "react-date-object";
import { ColumnMenu } from "./custom-cells";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { useParams } from "react-router";
// import internal components
import { Sidebar } from "../components/sidebar";
import { API_BASE_URL, API_ENDPOINTS,loginRequest, API_COMMON_HEADERS } from "../config";
import { PageLoader } from "../components/pageLoader";
import { getAccessToken } from "../App";
// import styles
import "../styles/datagridpage.css";
import "../styles/forms.css";

const initialSort = [
  {
    field: "modifiedDate",//noteId
    dir: "desc",
  },
];
const DATA_ITEM_KEY = "noteId";
// const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};

const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};

const Views = () => {
  const idGetter = getter(DATA_ITEM_KEY);
  const { id } = useParams();
  const [filterValue, setFilterValue] = React.useState("");
  const [filteredData, setFilteredData] = React.useState();
  const [currentSelectedState, setCurrentSelectedState] = React.useState({});
  const [dataState, setDataState] = React.useState(initialDataState);
  const [data, setData] = React.useState(filteredData);
  const [apiData, setApiData] = React.useState([]);
  const [dataResult, setDataResult] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentHeading, setCurrentHeading] = useState();
  const [selectedView, setSelectedView] = useState("");
  // const [enumsObj, setEnumsObj] = React.useState(null);
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});

  const getRequestByStatus = async(noteId) => {

    const accessToken = await getAccessToken({...loginRequest, account}, instance);
    //get enum objects
    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
    });
    const enumsObj = await dropdowns.json();

    switch (noteId) {
      case "All Requests":
        fetchApiData(0, API_ENDPOINTS.eNote_GetRequestsRoleBased, accessToken);
        setSelectedView(noteId);
        break;
      case "Draft Requests":
        fetchApiData(enumsObj.NoteStatus.find((x) => x.dValue === "Draft").id, API_ENDPOINTS.eNote_GetRequestsRoleBased, accessToken);
        setSelectedView(noteId);
        break;
      case "In Progress":
        fetchApiData(enumsObj.NoteStatus.find((x) => x.dValue === "Pending").id, API_ENDPOINTS.eNote_GetRequestsRoleBased, accessToken);
        setSelectedView(noteId);
        break; 
      case "All Approved":
        fetchApiData(enumsObj.NoteStatus.find((x) => x.dValue === "Approved").id, API_ENDPOINTS.eNote_GetRequestsRoleBased, accessToken);
        setSelectedView(noteId);
        break;
      case "All Rejected":
        fetchApiData(enumsObj.NoteStatus.find((x) => x.dValue === "Rejected").id, API_ENDPOINTS.eNote_GetRequestsRoleBased, accessToken);
        setSelectedView(noteId);
        break;
      case "Noted Notes":
        fetchApiData("noted", API_ENDPOINTS.eNote_GetNotedNoteRequests, accessToken);
        setSelectedView(noteId);
        break;
      default:
        fetchApiData(0, API_ENDPOINTS.eNote_GetRequestsRoleBased, accessToken);
        setSelectedView("All Requests");
        return 0;
    }
  };

  const switchNoteId = async (id) => {
    setCurrentHeading(id);
    setIsLoading(true);
    getRequestByStatus(id);
    // fetchApiData(getNoteStatusId(id));
  }
  useEffect(() => {
    switchNoteId(id); // Set the default noteId
  }, [id]);

  const fetchApiData = async (status,endPoint, accessToken) => {

    setFilterValue('');
    const params = status === "noted"?{CreatedBy: accounts[0].username}:{Status: status, CreatedBy: accounts[0].username};
    try {
      const response = await fetch(
        `${API_BASE_URL}${endPoint}`,
        {
          method: "POST",
          body: JSON.stringify(params),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
        }
      );

      if (response.ok) {
        const apiOutput = await response.json();
        const resData = apiOutput.pendingNoteList;
        const apiData = orderBy(resData, initialSort);

        // Bug fix - 300 - 27/03
        // const apiData = upObj.map(x=>({...x,modifiedDate:new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"),createdDate:new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A")}));

        /*let apiData = formatData.map((dataItem) =>
          Object.assign(
            {
              selected: false,
            },
            dataItem
          )
        );*/

        // console.log(apiData);

        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);
      // }

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      // setFilteredData(newData);
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiData.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );
  const dataStateChange = (event) => {
    // if (event.dataState && filteredData) {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
    // }
  };
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );
  // const setSelectedValue = (data) => {
  //   let newData = data.map((item) => {
  //     if (item.items) {
  //       return {
  //         ...item,
  //         items: setSelectedValue(item.items),
  //       };
  //     } else {
  //       return {
  //         ...item,
  //         ["selected"]: currentSelectedState[idGetter(item)],
  //       };
  //     }
  //   });
  //   return newData;
  // };
  // const newData = setExpandedState({
  //   data: setSelectedValue(resultState.data),
  //   collapsedIds: [],
  // });

  // console.log(newData)
  // const onHeaderSelectionChange = React.useCallback(
  //   (event) => {
  //     const checkboxElement = event.syntheticEvent.target;
  //     const checked = checkboxElement.checked;

  //     // Check if data is defined and an array
  //     // if (Array.isArray(data)) {
  //     const newSelectedState = {};
  //     data.forEach((item) => {
  //       newSelectedState[idGetter(item)] = checked;
  //     });

  //     setCurrentSelectedState(newSelectedState);

  //     const newData = data.map((item) => ({
  //       ...item,
  //       [SELECTED_FIELD]: checked,
  //     }));

  //     const newDataResult = processWithGroups(newData, dataState);
  //     setDataResult(newDataResult);
  //     // }
  //   },
  //   [data, dataState]
  // );

  // const onSelectionChange = (event) => {
  //   // if (event && event.dataItem && data) {
  //   const selectedProductId = event.dataItem.noteId;

  //   const newData = data.map((item) => {
  //     if (item.noteId === selectedProductId) {
  //       item.selected = !item.selected;
  //     }
  //     return item;
  //   });

  //   setCurrentSelectedState((prevState) => ({
  //     ...prevState,
  //     [selectedProductId]: !prevState[selectedProductId],
  //   }));

  //   const newDataResult = processWithGroups(newData, dataState);
  //   setDataResult(newDataResult);
  //   // }
  // };

  // const getNumberOfItems = (data) => {
  //   let count = 0;
  //   data.forEach((item) => {
  //     if (item.items) {
  //       count = count + getNumberOfItems(item.items);
  //     } else {
  //       count++;
  //     }
  //   });
  //   return count;
  // };

  // const getNumberOfSelectedItems = (data) => {
  //   let count = 0;
  //   data.forEach((item) => {
  //     if (item.items) {
  //       count = count + getNumberOfSelectedItems(item.items);
  //     } else {
  //       count = count + (item.selected === true ? 1 : 0);
  //     }
  //   });
  //   return count;
  // };

  // const checkHeaderSelectionValue = () => {
  //   let selectedItems = getNumberOfSelectedItems(newData);
  //   return newData.length > 0 && selectedItems == getNumberOfItems(newData);
  // };

  // let _pdfExport;
  // const exportExcel = () => {
  //   _export.save();
  // };

  // let _export;
  // const exportPDF = () => {
  //   _pdfExport.save();
  // };

  const exportCSVHeader = (id) => {

    let hdrColumn;

    switch (id) {
      case "All Approved":
        hdrColumn = [
          { key: "noteNumber", label: "Note#" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key : "subject", label: "Subject" },
          { key: "createdDate", label: "Created Date" },
          // Bug fix - 298 - 27/03
          { key: "modifiedDate", label: "Modified Date" },
        ];
        break;
      case "Noted Notes":
        hdrColumn = [
          { key: "noteNumber", label: "Note#" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          { key: "createdDate", label: "Created Date" },
          // Bug fix - 298 - 27/03
          { key: "modifiedDate", label: "Modified Date" },
        ];
        break;
        case "All Requests":
          hdrColumn = [
            { key: "noteNumber", label: "Note Number" },
            // Bug fix - 293 - 27/03
            { key: "createdByName", label: "Requester" },
            { key: "departmentName", label: "Department" },
            { key: "subject", label: "Subject" },
            // Bug fix - 293 - 27/03
            { key: "currentActionerName", label: "Current Approver" },
            { key: "strNoteStatus", label: "Status" },
            { key: "modifiedDate", label: "Modified Date" },
            { key: "createdDate", label: "Created Date" },
          ];
        break;
      default:
        hdrColumn = [
          { key: "noteNumber", label: "Note Number" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          // Bug fix - 293 - 27/03
          { key: "currentActionerName", label: "Current Approver" },
          { key: "finalApprover", label: "Final Approver" },
          { key: "modifiedDate", label: "Modified Date" },
          { key: "createdDate", label: "Created Date" },
        ];
    }
    return hdrColumn;
  }

  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    let columnsConfig = [];

    console.log(id);

    switch (id) {
      case "All Approved":
        columnsConfig = [
          { field: "noteNumber", title: "Note#" },
          // Bug fix - 293 - 27/03
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "subject", title: "Subject" },
          { field: "createdDate", title: "Created Date" },
          // Bug fix - 298 - 27/03
          { field: "modifiedDate", title: "Modified Date" },
        ];
        break;
      case "Noted Notes":
        columnsConfig = [
          { field: "noteNumber", title: "Note#" },
          // Bug fix - 293 - 27/03
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "subject", title: "Subject" },
          { field: "createdDate", title: "Created Date" },
          // Bug fix - 298 - 27/03
          { field: "modifiedDate", title: "Modified Date" },
        ];
        break;
        case "All Requests":
          columnsConfig = [
            { field: "noteNumber", title: "Note Number" },
            // Bug fix - 293 - 27/03
            { field: "createdByName", title: "Requester" },
            { field: "departmentName", title: "Department" },
            { field: "subject", title: "Subject" },
            // Bug fix - 293 - 27/03
            { field: "currentActionerName", title: "Current Approver" },
            { field: "strNoteStatus", title: "Status" },
            { field: "modifiedDate", title: "Modified Date" },
            { field: "createdDate", title: "Created Date" },
          ];
        break;
      default:
        columnsConfig = [
          { field: "noteNumber", title: "Note Number" },
          // Bug fix - 293 - 27/03
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "subject", title: "Subject" },
          // Bug fix - 293 - 27/03
          { field: "currentActionerName", title: "Current Approver" },
          { field: "finalApprover", title: "Final Approver" },
          { field: "modifiedDate", title: "Modified Date" },
          { field: "createdDate", title: "Created Date" },
        ];
    }


    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "noteNumber" ? (
            <td>
              <Link
                style={{ color: "red" }}
                to={
                  (props.dataItem["status"] === 1 ||
                    props.dataItem["status"] === 4 ||
                    props.dataItem["status"] === 8) &&
                  props.dataItem["createdBy"] === accounts[0].username
                    ? `/enoteform/${props.dataItem["noteId"]}`
                    : `/enoteviewform/${props.dataItem["noteId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {/* Bug fix - 300 - 27/03 */}
              {column.title.includes("Date")
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A") //Removed seconds hand
                : props.dataItem[column.field]}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  return (
    <div>
      <Navbar header="IB Smart Office - eNote" />
      <Sidebar />
      <div className="container cstGridContainer datagridpage">
        <div className="SectionHeads row mobileSectionHeads">{currentHeading}</div>
        {/* Add a section for displaying headings and allow the user to switch between them*/}
        {isLoading ? (
          <PageLoader />
        ) : (
          <Grid
            className="cstGridStyles"
            pageable={{ pageSizes: true }}
            data={dataResult}
            sortable={true}
            total={resultState.total}
            onDataStateChange={dataStateChange}
            {...dataState}
            onExpandChange={onExpandChange}
            expandField="expanded"
            dataItemKey={DATA_ITEM_KEY}
            /* selectedField={SELECTED_FIELD}
            onHeaderSelectionChange={onHeaderSelectionChange}
            onSelectionChange={onSelectionChange} */
            // groupable={true}
            size={"small"}
            resizable={true}
          >
            <GridToolbar>
              <Input
                value={filterValue}
                onChange={onFilterChange}
                className='searchCSS'
                placeholder="Search in all columns..."
              />
              <div className="export-btns-container">
                <Button style={{ marginLeft: "5px" }}>
                  <CSVLink
                    filename={`eNote-${selectedView.replace(
                      / /g,
                      ""
                    )}${new DateObject(new Date()).format("DDMMYYYYhhmmss")}`}
                    // Bug fix - 300 - 27/03
                    data={filteredData.map((x) => ({...x, modifiedDate: new DateObject( new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm A"), //Removed seconds hand
                    createdDate: new DateObject( new Date(x.createdDate) ).format("DD-MMM-YYYY hh:mm A"),}))}
                    headers={exportCSVHeader(currentHeading)}
                  >
                    Export CSV
                  </CSVLink>
                </Button>
              </div>
            </GridToolbar>

            {/* <Column
              filterable={false}
              field={SELECTED_FIELD}
              width={50}
              headerSelectionValue={checkHeaderSelectionValue()}
            /> */}

            {renderColumnsWithData(dataResult)}
          </Grid>
        )}
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};

export default Views;