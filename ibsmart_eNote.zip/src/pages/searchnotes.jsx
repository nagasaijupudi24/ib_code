import React, { useState, useEffect } from 'react';
// Kendo components
import { getter } from '@progress/kendo-react-common';
import { process } from '@progress/kendo-data-query';
import { Input } from '@progress/kendo-react-inputs';
import { Button } from '@progress/kendo-react-buttons';
import { Grid, GridColumn as Column, GridToolbar } from '@progress/kendo-react-grid';
import { setGroupIds, setExpandedState } from '@progress/kendo-react-data-tools';
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { Form, FormElement, FieldWrapper } from '@progress/kendo-react-form';
import { Label } from "@progress/kendo-react-labels";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { Dialog, DialogActionsBar } from '@progress/kendo-react-dialogs';
import { MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
// import kendo icons
import { SvgIcon } from "@progress/kendo-react-common";
import { infoCircleIcon } from '@progress/kendo-svg-icons';
import { xIcon } from "@progress/kendo-svg-icons";
// import external components
import { Link } from 'react-router-dom';
import { CSVLink } from "react-csv";
import DateObject from 'react-date-object';
import { useMsal, useAccount } from "@azure/msal-react";
// import internal components
import Navbar from '../components/navbar.jsx';
import { Sidebar } from '../components/sidebar.jsx';
import Footer from '../components/footer.jsx';
import { API_BASE_URL, API_ENDPOINTS, loginRequest, API_COMMON_HEADERS } from '../config';
import { getAccessToken } from "../App";
import { PageLoader } from "../components/pageLoader";
import { ColumnMenu } from './custom-cells.jsx';
// import style css
import "../styles/datagridpage.css";
import "../styles/forms.css";

const CustomDialogTitleBar = () => {
  return (
    <div className="custom-title">
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};

//Added this function due to loading impact users will be filtered on search box enter - 25/03
const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",
  },
  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "120px",
  },
];
// mobile view responsive
const mobileColumns = [
  {
    field: "displayName",
    header: "Person Name",
    width: "100px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "100px",
  },
  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "70px",
  },
];

const DATA_ITEM_KEY = 'id';
const initialDataState = {
  take: 10,
  skip: 0,
  group: []
};
const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group
  });
  return newDataState;
};

export const SearchNotes = () => {
  const valueRender = (element, value, fieldName) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      if (fieldName === "NoteType") {
        setSearchNoteType("")
      }
      if (fieldName === "Status") {
        setSearchNoteStatus("");
      }
      if (fieldName === "FinType") {
        setSearchFinType("");
      }
      if (fieldName === "FY") {
        setSelectedYear('');
      }
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1}  className='_valueRender'>
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props
    }, children);
  };
  // change -13/05  clear  department Value 
  const valueRenderDepartment = (element, value) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      setSearchDepartment("");
      //  change 16/05  on clear of department approver and reviwers need to clear 
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} className='_valueRender'>
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props
    }, children);
  };
  const idGetter = getter('id');
  const [filterValue, setFilterValue] = useState('');
  const [filteredData, setFilteredData] = useState([]);
  const [currentSelectedState] = useState({});
  const [dataState, setDataState] = useState(initialDataState);
  const [dataResult, setDataResult] = useState(process(filteredData, dataState));
  const [apiData, setApiData] = useState([]);
  const [notestatus, setNoteStatus] = useState([]);
  const [searchNotestatus, setSearchNoteStatus] = useState('');
  const [notetype, setNoteTypeData] = useState([]);
  const [fintype, setFinType] = useState([]);
  const [searchTextNote, setSearchTextNote] = useState('');
  const [searchDepartment, setSearchDepartment] = useState('')
  const [selectedFromDate, setSelectedFromDate] = useState(null);
  const [selectedToDate, setSelectedToDate] = useState(null);
  const [selectedYear, setSelectedYear] = useState('');
  const [searchText, setSearchText] = useState('');
  const [searchSubject, setSearchSubject] = useState('');
  const [searchFinType, setSearchFinType] = useState('');
  const [searchNoteType, setSearchNoteType] = useState('');
  const [searchRequester, setSearchRequester] = useState('');
  const [searchApprover, setSearchApprover] = useState('')
  const [showNotification, setShowNotification] = useState(false);
  const [showNotificationMsg, setShowNotificationMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [enumsObj, setEnumsObj] = useState(false);
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [departmentList, setDepartmentList] = useState([]);
  const isMobile = window.innerWidth <= 768;

  // const delay = 100
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      try {
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

        //get enum objects
        const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
        });

        //Removed this function due to loading impact users will be filtered on search box enter - 25/03
        /*const emailUsers = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_UserDetails}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        });
        const approverEmails = await emailUsers.json();
        const approverEmailsList = approverEmails.map(approver => approver.userPrincipalName);
        setEmailsObject(approverEmailsList)
        setMembers(approverEmailsList)
        setData2(approverEmailsList)*/

        const dropdownslist = await dropdowns.json();
        getDepartmentList();
        setNoteTypeData(dropdownslist.SearchNoteType);
        setFinType(dropdownslist.SearchFinancial);
        setNoteStatus(dropdownslist.SearchStatus);
        setEnumsObj(dropdownslist);
        setIsLoading(false)
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  // get dempartments list 
  const getDepartmentList = async () => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const obj = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_Departments_List}`
      , {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }
    );
    const departmentDetailsList = await obj.json();
    setDepartmentList(departmentDetailsList)
  }

  //Handle on filter change
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      setFilteredData(apiData);
      setDataResult(process(apiData, (dataState) => ({ ...dataState, total: apiData.length })));
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property].toString().toLocaleLowerCase().includes(value.toLocaleLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      }
      );

      // setFilteredData(newData);
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      // setData(newData);
    }
  };

  // const [resultState, setResultState] = React.useState(processWithGroups(apiData.map(item => ({
  const [resultState] = React.useState(processWithGroups(apiData.map(item => ({
    ...item,
    // ['selected']: currentSelectedState[idGetter(item)]
    'selected': currentSelectedState[idGetter(item)]
  })), initialDataState));
  const dataStateChange = event => {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };

  const onExpandChange = React.useCallback(event => {
    const newData = [...dataResult.data];
    const item = event.dataItem;
    if (item.groupId) {
      const targetGroup = newData.find(d => d.groupId === item.groupId);
      if (targetGroup) {
        targetGroup.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData
        });
      }
    } else {
      item.expanded = event.value;
      setDataResult({
        ...dataResult,
        data: newData
      });
    }
  }, [dataResult]);

  // Handle selected Value change
  const setSelectedValue = data => {
    let newData = data.map(item => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items)
        };
      } else {
        return {
          ...item,
          // ['selected']: currentSelectedState[idGetter(item)]
          'selected': currentSelectedState[idGetter(item)]
        };
      }
    });
    return newData;
  };
  // const newData = 
  setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: []
  });

  // Handle export CSV headers
  const exportCSVHeader = () => {
    return [
      { key: 'noteNumber', label: 'Note#' },
      // Bug fix - 293 - 27/03
      { key: 'createdBy', label: 'Requester' },
      { key: 'departmentName', label: 'Department' },
      { key: 'subject', label: 'Subject' },
      { key: 'strNoteStatus', label: 'Status' },
      // Bug fix - 293 - 27/03
      { key: 'currentActioner', label: 'Current Approver' },
      { key: 'modifiedBy', label: 'Last Approver' },
      { key: 'modifiedDate', label: 'Modified Date' },
      { key: 'createdDate', label: 'Created Date' },
    ];
  }

  // Handle  render columns with data
  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    const columnsConfig = [
      { field: 'noteNumber', title: 'Note#' },
      // Bug fix - 293 - 27/03
      { field: 'createdBy', title: 'Requester' },
      { field: 'departmentName', title: 'Department' },
      { field: 'subject', title: 'Subject' },
      { field: 'strNoteStatus', title: 'Status' },
      // Bug fix - 293 - 27/03
      { field: 'currentActioner', title: 'Current Approver' },
      { field: 'modifiedBy', title: 'Last Approver' },
      { field: 'modifiedDate', title: 'Modified Date' },
      { field: 'createdDate', title: 'Created Date' },
    ];

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "noteNumber" ? (
            <td>
              <Link
                target='_blank'
                style={{ color: "red" }}
                to={
                  (props.dataItem["strNoteStatus"] === "Draft" ||
                    props.dataItem["strNoteStatus"] === "Returned" ||
                    props.dataItem["strNoteStatus"] === "Called Back") &&
                    props.dataItem["createdBy"] === accounts[0].username
                    ? `/enoteform/${props.dataItem["noteId"]}`
                    : `/enoteviewform/${props.dataItem["noteId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {/* Bug fix - 300 - 27/03 */}
              {column.title.includes("Date")
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A") // removing seconds hand
                : props.dataItem[column.field]}
              {/* {props.dataItem[column.field]} */}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  /* To get the financial year viz in 2024-2025 format */
  const getRecentFinancialYears = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = 0; i < 5; i++) {
      const startYear = currentYear - i;
      const endYear = startYear + 1; // Increment startYear by 1 to get the endYear
      // const endYearShort = endYear.toString().slice(2); // Get the last two digits of the year
      years.push({ text: `${startYear}-${endYear}`, value: startYear });
    }
    return years;
  };
  const financialYears = getRecentFinancialYears();

  /* Search Functionality */
  // const todayDate = new Date();

  // Commented for null parameters --> Kavya (22/08)
  // const handleSearch = async () => {

  //   if (
  //     searchTextNote === "" &&
  //     (searchRequester === "" || searchRequester === null) &&
  //     searchDepartment === "" &&
  //     searchText === "" &&
  //     selectedFromDate === null &&
  //     selectedToDate === null &&
  //     selectedYear === "" &&
  //     searchNotestatus === "" &&
  //     searchSubject === "" &&
  //     searchFinType === "" &&
  //     (searchApprover === "" || searchApprover === null) &&
  //     searchNoteType === ""

  //   ) {
  //     setShowNotification(true);
  //     setShowNotificationMsg(
  //       "Please fill atleast any one of the field to search."
  //     );
  //     return;
  //   }

  //   setIsLoading(true);

  //   try {
  //     const financialyear = selectedYear ? selectedYear.text : null;

  //     const params = {
  //       "noteNumber": searchTextNote || null,
  //       "createdBy": searchRequester.userPrincipalName || null,
  //       "departmentName": searchDepartment || null,
  //       "searchKeyword": searchText || null,
  //       "fromDate": selectedFromDate ? new DateObject(new Date(selectedFromDate)).format("DD-MM-YYYY") : null,
  //       "toDate": selectedToDate ? new DateObject(new Date(selectedToDate)).format("DD-MM-YYYY") : null,
  //       "status": searchNotestatus ? enumsObj.SearchStatus.find(x => x.dValue === searchNotestatus).id : 0,
  //       "subject": searchSubject || null,
  //       "financialType": searchFinType ? enumsObj.SearchFinancial.find(x => x.dValue === searchFinType).id : 0,
  //       "fy": financialyear || null,
  //       "approverEmail": searchApprover.userPrincipalName || null,
  //       "natureofNote": searchNoteType ? enumsObj.SearchNoteType.find(x => x.dValue === searchNoteType).id : 0
  //     }

  //     const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

  //     await fetch(`${API_BASE_URL}${API_ENDPOINTS.eNote_SearchNotes}`, {
  //       method: 'POST',
  //       body: JSON.stringify(params),
  //       headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
  //     }).then(response => {
  //       return response.json();
  //     }).then(data => {
  //       setIsLoading(false);
  //       // Bug fix - 300 - 27/03
  //       // const apiRespData = data.map(x => ({ ...x, modifiedDate: new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"), createdDate: new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A") }));
  //       const apiRespData = data;

  //       setFilteredData(apiRespData);
  //       setApiData(apiRespData);
  //       const newDataResult = process(apiRespData, dataState);
  //       setDataResult(newDataResult);
  //       setDataState({ ...dataState, total: apiRespData.length });
  //     })
  //   } catch (error) {
  //     console.error('Error fetching data:', error);
  //     setIsLoading(false)
  //   }
  // };
  const handleSearch = async () => {
    if (
      searchTextNote === "" &&
      (searchRequester === "" || searchRequester === null) &&
      searchDepartment === "" &&
      searchText === "" &&
      selectedFromDate === null &&
      selectedToDate === null &&
      selectedYear === "" &&
      searchNotestatus === "" &&
      searchSubject === "" &&
      searchFinType === "" &&
      (searchApprover === "" || searchApprover === null) &&
      searchNoteType === ""
    ) {
      setShowNotification(true);
      setShowNotificationMsg("Please fill at least any one of the fields to search.");
      return;
    }
  
    setIsLoading(true);
  
    try {
      const financialyear = selectedYear ? selectedYear.text : null;
  
      // Create an object with all possible fields
      let params = {
        "noteNumber": searchTextNote || null,
        "createdBy": searchRequester?.userPrincipalName || null,
        "departmentName": searchDepartment || null,
        "searchKeyword": searchText || null,
        "fromDate": selectedFromDate ? new DateObject(new Date(selectedFromDate)).format("DD-MM-YYYY") : null,
        "toDate": selectedToDate ? new DateObject(new Date(selectedToDate)).format("DD-MM-YYYY") : null,
        "status": searchNotestatus ? enumsObj.SearchStatus.find(x => x.dValue === searchNotestatus).id : 0,
        "subject": searchSubject || null,
        "financialType": searchFinType ? enumsObj.SearchFinancial.find(x => x.dValue === searchFinType).id : 0,
        "fy": financialyear || null,
        "approverEmail": searchApprover?.userPrincipalName || null,
        "natureofNote": searchNoteType ? enumsObj.SearchNoteType.find(x => x.dValue === searchNoteType).id : 0
      };
  
      // Set default values for financialType, status, and natureofNote if they are 0
      if (!params.financialType) {
        params.financialType = 0;
      }
      if (!params.status) {
        params.status = 0;
      }
      if (!params.natureofNote) {
        params.natureofNote = 0;
      }
  
      // Remove other fields that are null or empty strings
      params = Object.fromEntries(
        Object.entries(params).filter(
          ([key, value]) =>
            value !== null && value !== "" && (value !== 0 || ["financialType", "status", "natureofNote"].includes(key))
        )
      );
  
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
  
      await fetch(`${API_BASE_URL}${API_ENDPOINTS.eNote_SearchNotes}`, {
        method: 'POST',
        body: JSON.stringify(params),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }).then(response => response.json())
        .then(data => {
          setIsLoading(false);
          const apiRespData = data;
  
          setFilteredData(apiRespData);
          setApiData(apiRespData);
          const newDataResult = process(apiRespData, dataState);
          setDataResult(newDataResult);
          setDataState({ ...dataState, total: apiRespData.length });
        });
    } catch (error) {
      console.error('Error fetching data:', error);
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setFilterValue('');
    setFilteredData([]);
    setApiData([]);
    setDataResult(process([], initialDataState)); // Reset data state
    setSearchTextNote('');
    setSearchDepartment('');
    setSearchText('');
    setSelectedFromDate(null);
    setSelectedToDate(null);
    setSearchRequester({ department: "", displayName: "", jobTitle: "", userPrincipalName: "" });
    setSearchSubject('');
    setSelectedYear(null);
    setSearchNoteStatus('');
    setSearchApprover({ department: "", displayName: "", jobTitle: "", userPrincipalName: "" })
    setSearchFinType('')
    setSearchNoteType('')
  };
  /* Search Requester and Approver */
  const [members, setMembers] = useState([]);

  //filter the users dropdown data
  const filterChange = async (event) => {

    //Removed this function due to loading impact users will be filtered on search box enter - 25/03
    /*clearTimeout(timeout.current);
    timeout.current = setTimeout(() => {
      setMembers(filterData(event.filter));
      setLoading(false);
    }, delay);
    setLoading(true);*/

    //Added  ----------------- 25/03 --------------------
    if (event.filter.value.length >= 4) {
      const accessToken = await getAccessToken({
        ...loginRequest,
        account
      }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            // Change - Adding SR No - 05/04 - Venkat
            return { ...x, department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName }
          });
          setMembers(orgUsers);
        })
        .catch((err) => {
          setMembers([]);
          console.log(err);
        });
    }
    //Added  ----------------- 25/03 --------------------
  };

  return (
    <div>
      <Navbar />
      <Sidebar />
      <div className="container datagridpage searchNoteContainer">
        <div className="SectionHeads row mobileSectionHeads">Search Parameters</div>
        <div className="container ">
          <Form
            id="searchForm"
            render={() => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="SectionRow row">
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Note#:</Label>
                          <Input
                            name="Note#"
                            value={searchTextNote}
                            onChange={(e) => setSearchTextNote(e.target.value)}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Requester:</Label>
                          {/* Replaced with new component due to loading impact users will be filtered on search box enter - 25/03 */}
                          <MultiColumnComboBox
                            name="Requester"
                            data={members}
                            filterable={true}
                            className='testt'
                            // Commented for mobile responsive
                            // columns={orgUsersPplPickerColumnMapping}
                            columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                            style={{ width: isMobile ? "100%" : "100%" }} // Adjust width
                            onFilterChange={filterChange}
                            value={searchRequester.displayName}
                            onChange={(e) => e.value === null ? setSearchRequester({ department: "", displayName: "", jobTitle: "", userPrincipalName: "" }) : setSearchRequester(e.value)}
                            placeholder="Search Requester..."
                          />
                          <span className='cstUserSearchMsg'>(Please enter minimum 4 characters to find the user)</span>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Department:</Label>
                          {/*  <Input
                            // component={Input}
                            name="Department"
                            value={searchDepartment}
                            // defaultValue={accounts[0].username}
                            defaultValue=""
                            onChange={(e) =>
                              setSearchDepartment(e.target.value)
                            }
                          /> */}
                          {/* Bug -376 fix */}
                          <DropDownList
                            data={departmentList.map((x) => x.departmentName)}
                            // defaultItem={"Select"}
                            onChange={(e) =>
                              setSearchDepartment(e.target.value)
                            }
                            value={searchDepartment}
                            // value={selectedDepartment}
                            name="Department"
                            valueRender={element => valueRenderDepartment(element, searchDepartment)}
                          />
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Search Text:</Label>
                          <Input
                            name="search"
                            value={searchText}
                            onChange={(e) => setSearchText(e.target.value)}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">From Date:</Label>
                          <DatePicker
                            max={new Date()}
                            placeholder="From Date..."
                            onChange={(event) =>
                              setSelectedFromDate(event.target.value)
                            }
                            format={"dd-MM-yyyy"}
                            value={selectedFromDate}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">To Date:</Label>
                          <DatePicker
                            min={new Date(selectedFromDate)}
                            max={new Date()}
                            placeholder="To Date..."
                            onChange={(event) =>
                              setSelectedToDate(event.target.value)
                            }
                            format={"dd-MM-yyyy"}
                            value={selectedToDate}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Status:</Label>
                          <DropDownList
                            data={notestatus.map((x) => x.dValue)}
                            value={searchNotestatus}
                            onChange={(e) =>
                              setSearchNoteStatus(e.target.value)
                            }
                            valueRender={element => valueRender(element, searchNotestatus, "Status")}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Subject:</Label>
                          <Input
                            name="Subject"
                            value={searchSubject}
                            onChange={(e) => setSearchSubject(e.target.value)}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Financial:</Label>
                          <DropDownList
                            data={fintype.map((x) => x.dValue)}
                            value={searchFinType}
                            onChange={(e) => setSearchFinType(e.target.value)}
                            valueRender={element => valueRender(element, searchFinType, "FinType")}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">FY:</Label>
                          <DropDownList
                            data={financialYears}
                            textField="text"
                            dataItemKey="text"
                            value={selectedYear}
                            onChange={(event) =>
                              setSelectedYear(event.target.value)
                            }
                            valueRender={element => valueRender(element, selectedYear, "FY")}
                          />
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Approver:</Label>
                          {/* Replaced with new component due to loading impact users will be filtered on search box enter - 25/03 */}
                          <MultiColumnComboBox
                            name="Approver"
                            data={members}
                            filterable={true}
                            columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                             className="responsive-multicolumn"
                            // Commented for responsive design
                            // columns={orgUsersPplPickerColumnMapping}
                            style={{ width: isMobile ? "100%" : "100%", }} // Adjust width
                            onFilterChange={filterChange}
                            value={searchApprover.displayName}
                            onChange={(e) => e.value === null ? setSearchApprover({ department: "", displayName: "", jobTitle: "", userPrincipalName: "" }) : setSearchApprover(e.value)}
                            placeholder="Search Approver..."
                          />
                          <span className='cstUserSearchMsg'>(Please enter minimum 4 characters to find the user)</span>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-4">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Note Type:</Label>
                          <DropDownList
                            data={notetype.map((x) => x.dValue)}
                            value={searchNoteType}
                            onChange={(e) => setSearchNoteType(e.target.value)}
                            valueRender={element => valueRender(element, searchNoteType, "NoteType")}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                  </div>
                </fieldset>
                <div className="FormButtonsContainer k-form-buttons">
                  <Button className="searchNoteBtns" onClick={handleSearch}>
                    <span className="k-icon-xs k-icon k-font-icon  k-i-search cursor searchBtnStyles"></span>
                    Search
                  </Button>
                  <Button onClick={handleClear}>
                    <span className="k-icon-sm k-icon k-font-icon  k-i-reset-sm cursor searchBtnStyles"></span>
                    Clear
                  </Button>
                </div>
              </FormElement>
            )}
          />
        </div>
        <div className="SectionHeads row" style={{ marginBottom: "40px" }}>
          Search Results
        </div>
        {isLoading ? (
          <PageLoader />
        ) : (
          <Grid
            // Added mobile view responsive 
            className='cstGridStyles searchMobileView'
            pageable={{ pageSizes: true }}
            data={dataResult}
            sortable={true}
            total={resultState.total}
            onDataStateChange={dataStateChange}
            {...dataState}
            onExpandChange={onExpandChange}
            expandField="expanded"
            dataItemKey={DATA_ITEM_KEY}
            size={"small"}
            resizable={true}
          >
            <GridToolbar>
              <Input
                value={filterValue}
                onChange={onFilterChange}
                className='searchCSS'
                placeholder="Search in all columns..."
              />{" "}
              <div className="export-btns-container">
                <Button style={{ marginLeft: "5px" }}>
                  <CSVLink
                    filename={`eNote-SearchResult-${new DateObject(
                      new Date()
                    ).format("DDMMYYYYhhmmss")}`}
                    // Bug fix - 300 - 27/03
                    data={filteredData.map((x) => ({ ...x, modifiedDate: new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"), createdDate: new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A"), }))}
                    headers={exportCSVHeader()}
                  >
                    Export CSV
                  </CSVLink>
                </Button>
              </div>
            </GridToolbar>
            {renderColumnsWithData(dataResult)}
          </Grid>
        )}
      </div>
      {showNotification && (
        <Dialog
          title={<CustomDialogTitleBar />}
          onClose={() => setShowNotification(false)}
        >
          <p className='dialogcontent_' >
            {showNotificationMsg}
          </p>
          <DialogActionsBar>
            <Button
              className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
              onClick={() => setShowNotification(false)}
            >
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};