const {override} = require('customize-cra');
const cspHtmlWebpackPlugin = require("csp-html-webpack-plugin");

const cspConfigPolicy = {
    'default-src': "'self'",
    'base-uri': "'self'",
    'style-src': ["'self'"],
    'script-src': ["'self'"],
    'img-src': ["'self' data:"],
    'connect-src': [process.env.REACT_APP_APIBase_URL, "https://login.microsoftonline.com"],
    'font-src': ["'self'"],
    'frame-src': ["'self'"],
    'media-src': ["'self'"]
};

function addCspHtmlWebpackPlugin(config) {
    // if(process.env.REACT_APP_Home_URL) {
        // config.plugins.push(new cspHtmlWebpackPlugin(cspConfigPolicy));
    // }

    return config;
}

module.exports = {
    webpack: override(addCspHtmlWebpackPlugin),
};