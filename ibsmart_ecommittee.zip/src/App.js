import { useEffect,createContext, useContext, useState } from "react";
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import { ECommitteeHome } from "./pages/eCommitteeHome.jsx";
import { ECommitteeNewForm } from "./pages/eCommitteeNoteForm.jsx";
import { ECommitteeViewForm } from "./pages/eCommitteeViewForm.jsx";
import { BoardNoteForm } from "./pages/boardNoteForm.jsx";
import { BoardViewForm } from "./pages/boardViewForm.jsx";
import { ECommitteeMeetingsNewForm } from "./pages/eCommitteeMeetingForm.jsx";
import { ECommitteeMeetingsViewForm } from "./pages/eCommitteeMeetingViewForm.jsx";
import Views from "./pages/eCommitteeViews.jsx";
import ATRViews from "./pages/ATRViews.jsx";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useIsAuthenticated,
} from "@azure/msal-react";
import { SearchNotes } from "./pages/searchnotes.jsx";
import { useMsalAuthentication } from "@azure/msal-react";
import { InteractionType } from "@azure/msal-browser";
import MeetingViews from "./pages/eCommitteeMeetingViews.jsx";
import { useMsal, useAccount } from "@azure/msal-react";
import { ECommitteeAtrForm } from "./pages/eCommitteeAtrform.jsx";
import PageNotFound from "./pages/404page.jsx";
import AdminDashBoardChartReports from "./pages/dashBoardReportChartsforAdmin.jsx";

import { ECommitteePasscode } from "./pages/eCommitteePasscode.jsx"
// Function to get access token
export const getAccessToken = async (loginRequest, instance) => {
  try {
    const response = await instance.acquireTokenSilent(loginRequest);
    return response.accessToken;
  } catch (error) {
    console.error("Failed to get access token:", error);
    throw new Error("Failed to get access token");
  }
}
const TabContext = createContext();

export const useTabContext = () => useContext(TabContext);
function App() {
  const isAuthenticated = useIsAuthenticated();
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [activeTab, setActiveTab] = useState('My Notes'); // Default active tab
  const [passcodenaviagate, setPasscodeNaviage] = useState('New'); // Default passcode page redirect

  // Added for page redirect to my peding notes after any action
  const setTab = (tabName) => {
    setActiveTab(tabName);
  };
  // Added for page redirect to view page after creating passcode --> Kavya(23/07)
  const setPasscodeNavigate = (pageName) => {
    setPasscodeNaviage(pageName);
  }
  // Auto redirect to login
  useMsalAuthentication(InteractionType.Redirect);

  useEffect(() => {
    async function getTokenSilently() {
      const tokenRequest = {
        // scopes: ['User.Read', 'User.ReadBasic.All'],
        // loginHint: accounts[0].username,
        account,
      };

      await instance.acquireTokenSilent(tokenRequest);
      // dispatch({ type: AuthActions.SET_TOKEN, payload: res.accessToken });
      // dispatch({ type: AuthActions.SET_CLAIMS, payload: accounts[0].username });
    }
    if (isAuthenticated && inProgress === 'none') {
      getTokenSilently();
    }
  }, [isAuthenticated]);

  return (
    <div className="App">
      {/* {isAuthenticated ? ( */}
        <AuthenticatedTemplate>
        <TabContext.Provider value={{ activeTab, setTab, setPasscodeNavigate, passcodenaviagate }}>
          <Router>
            <Routes>
              <Route path="/"  element={<ECommitteeHome />} />
              <Route path="/ecommittehome" element={<ECommitteeHome />} />
              <Route path="/searchnotes" element={<SearchNotes />} />
              <Route path="/ecommitteenote/:id" element={<ECommitteeNewForm />} />
              <Route path="/ecommitteeviewform/:id" element={<ECommitteeViewForm />} />
              <Route path="/boardnoteform/:id" element={<BoardNoteForm />} />
              <Route path="/boardnoteviewform/:id" element={<BoardViewForm />} />
              <Route path="/ecommitteemeetingform/:id" element={<ECommitteeMeetingsNewForm />} />
              <Route path="/ecommitteemeetingviewform/:id" element={<ECommitteeMeetingsViewForm />} />
              <Route path="/views/:id" element={<Views />} />
              <Route path="/meetingviews/:id" element={<MeetingViews />} />
              <Route path="/atrviews/:id" element={<ATRViews />} />
              <Route path="/DashBoardReports" element={<AdminDashBoardChartReports />} />
              <Route
                path="/ecommitteeatrform/:id"
                element={<ECommitteeAtrForm />}
              />
              <Route path="/ecommitteepasscode" element={<ECommitteePasscode />} /> 
              <Route path="*" element={<PageNotFound />}/>
            </Routes>
          </Router>
          </TabContext.Provider>
        </AuthenticatedTemplate>
        <UnauthenticatedTemplate>
        <TabContext.Provider value={{ activeTab, setTab, setPasscodeNavigate, passcodenaviagate }}>
          <Router>
            <Routes>
              <Route path="/" element={<ECommitteeHome />} />
              {/* <Route path="*" element={<PageNotFound />}/> */}
            </Routes>
          </Router>
          </TabContext.Provider>
        </UnauthenticatedTemplate>
    </div>
  );
}

export default App;