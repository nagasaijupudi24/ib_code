import * as React from "react";
import {
    Chart,
    ChartLegend,
    ChartSeries,
    ChartSeriesItem,
    ChartTitle,
    ChartTooltip,
} from "@progress/kendo-react-charts";
// Import External Libraries
import "hammerjs";
// Import CSS styles
import "bootstrap/dist/css/bootstrap.min.css";
// Display the category value when it hover on chart
const tooltipRender = props => {
    if (props.point) {
        const {
            category,
            value
        } = props.point;
        return <span>{String(category)}</span>;
    }
};
export const ChartContainer = (props) => {
    const [state, setState] = React.useState({})
    React.useEffect(() => {
        setState(props.apiOutput)
    }, [props]);
    return (
        <div className="custom-committeeNote-charts-container">
            {state ? props.committeeType === "Committee Meeting" ?
                <div className="row">
                    <div className="col-lg-6 col-md-12 col-sm-12 custom-pie-chart-seperateline">
                        <div className="enote-chartContainer">
                            <Chart>
                                <ChartTitle text="Status" />
                                <ChartLegend position="right" />
                                <ChartSeries>
                                    <ChartSeriesItem
                                        type="pie"
                                        data={state.lstCommitteeMeetingChart}
                                        field="count"
                                        categoryField="status"
                                        tooltip={{
                                            visible: true,
                                        }}
                                    />
                                </ChartSeries>
                                <ChartTooltip opacity={1} visible={true} render={tooltipRender} />
                            </Chart>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-12 col-sm-12 ">
                        <div className="enote-chartContainer">
                            <Chart>
                                <ChartTitle text="Committee name" />
                                <ChartLegend position="right" />
                                <ChartSeries>
                                    <ChartSeriesItem
                                        type="donut"
                                        data={state.lstCommitteeMeetingNameCount}//lstCommitteeMeetingNameCount
                                        field="count"
                                        categoryField="status"
                                        autoFit
                                        tooltip={{
                                            visible: true,
                                        }}
                                    />
                                </ChartSeries>
                                <ChartTooltip opacity={1} visible={true} render={tooltipRender} />
                            </Chart>
                        </div>
                    </div>
                </div>
                :
                <div className="row">
                    <div className="col-lg-6 col-md-12 col-sm-12  custom-pie-chart-seperateline">
                        <div className="enote-chartContainer">
                            <Chart>
                                <ChartTitle text="Status" />
                                <ChartLegend position="right" />
                                <ChartSeries>
                                    <ChartSeriesItem
                                        type="pie"
                                        data={props.committeeType === "Committee Note" ? state.lstCommitteeChart : state.lstBoardChart}

                                        field="count"
                                        categoryField="status"
                                        tooltip={{
                                            visible: true,
                                        }}
                                    />
                                </ChartSeries>
                                <ChartTooltip opacity={1} visible={true} render={tooltipRender} />
                            </Chart>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-12 col-sm-12 ">
                        <div className="enote-chartContainer">
                            <Chart>
                                <ChartTitle text="Nature of Notes Created" />
                                <ChartLegend position="right" />
                                <ChartSeries>
                                    <ChartSeriesItem
                                        type="donut"
                                        data={props.committeeType === "Committee Note" ? state.lstCommitteeNatureofNoteStatusCount : state.lstBoardNatureofNoteStatusCount
                                        }
                                        field="count"
                                        categoryField="status"
                                        tooltip={{
                                            visible: true,
                                        }}
                                    />
                                </ChartSeries>
                                <ChartTooltip opacity={1} visible={true} render={tooltipRender} />
                            </Chart>
                        </div>
                    </div>
                </div>
                :
                <div>
                    <span>
                        No data is available.
                    </span>
                </div>}
        </div>
    )
}
