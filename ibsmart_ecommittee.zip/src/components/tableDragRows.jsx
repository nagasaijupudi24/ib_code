import * as React from "react";
import { useContext, useState, useRef, useEffect  } from "react";
// Import Kendo Components
import { Grid, GridColumn as Column } from "@progress/kendo-react-grid";
// commented for drag and drop functionality because of iphone scroll issue
// import { DragAndDrop } from "@progress/kendo-react-common";
// import { DraggableRow } from "../resources/draggable-row";
// import { DragHandleCell } from "../resources/drag-handle-cell";
import { Button } from "@progress/kendo-react-buttons";
// import kendo icons 
import { SvgIcon } from '@progress/kendo-react-common';
import { reorderIcon } from '@progress/kendo-svg-icons';
// import internal components
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { getAccessToken } from "../App";
import { loginRequest, API_COMMON_HEADERS } from "../config";
import { useMsal, useAccount } from "@azure/msal-react";
// Import CSS styles
import "../styles/forms.css";
import "../styles/responsiveDesign.css";

const ReorderContext = React.createContext({
  reorder: (dataItem) => {},
  dragStart: (dataItem) => {},
});

// Drag and Drop Cell for Table Rows in Approvers/Reviewers table mobile view and iphone view
// const DragCell = (props) => {
//   const currentContext = useContext(ReorderContext);
//   const touchMoveRef = useRef(null);

//   // Handle drag start for mouse events
//   const handleDragStart = (e) => {
//     currentContext.dragStart(props.dataItem);
//     e.dataTransfer.setData('dragging', '');
//   };

//   // Handle touch start for mobile devices
//   const handleTouchStart = () => {
//     currentContext.dragStart(props.dataItem);

//     // Add the touchmove listener dynamically when dragging starts
//     touchMoveRef.current = handleTouchMove;
//     window.addEventListener('touchmove', touchMoveRef.current, { passive: false });
//   };

//   // Handle touch move for mobile devices
//   const handleTouchMove = (e) => {
//     const touch = e.touches[0];
//     const target = document.elementFromPoint(touch.clientX, touch.clientY);
//     if (target && target.closest('tr')) {
//       const row = target.closest('tr');
//       const index = row.rowIndex - 1; // Subtract 1 for the header row
//       currentContext.reorder(props.dataItem, index);
//     }
//     e.preventDefault();
//   };

//   // Clean up the touchmove listener when touch ends
//   const handleTouchEnd = () => {
//     window.removeEventListener('touchmove', touchMoveRef.current);
//   };

//   useEffect(() => {
//     // Attach touchend listener to cleanup after drag is complete
//     window.addEventListener('touchend', handleTouchEnd);
//     return () => {
//       window.removeEventListener('touchend', handleTouchEnd);
//       window.removeEventListener('touchmove', touchMoveRef.current);
//     };
//   }, []);

//   return (
//     <td
//       onDragOver={(e) => e.preventDefault()}
//       onDrop={(e) => {
//         currentContext.reorder(props.dataItem);
//         e.preventDefault();
//       }}
//       onTouchStart={handleTouchStart}
//     >
//       <span
//         draggable={true}
//         style={{ cursor: 'move' }}
//         onDragStart={handleDragStart}
//       >
//         <SvgIcon icon={reorderIcon} />
//       </span>
//     </td>
//   );
// };
// Drag and drop cell for Table Rows in Approvers/Reviewers table mobile view and iphone view
const DragCell = (props) => {
  const currentContext = useContext(ReorderContext);
  const touchMoveRef = useRef(null);

  // Handle drag start for mouse events
  const handleDragStart = (e) => {
    currentContext.dragStart(props.dataItem);
    e.dataTransfer.setData('dragging', '');
  };

  // Handle touch start for mobile devices
  const handleTouchStart = () => {
    currentContext.dragStart(props.dataItem);

    // Add the touchmove listener dynamically when dragging starts
    touchMoveRef.current = handleTouchMove;
    window.addEventListener('touchmove', touchMoveRef.current, { passive: false });
  };

  // Handle touch move for mobile devices
  const handleTouchMove = (e) => {
    const touch = e.touches[0];
    const target = document.elementFromPoint(touch.clientX, touch.clientY);
    if (target && target.closest('tr')) {
      const row = target.closest('tr');
      const index = row.rowIndex - 1; // Subtract 1 for the header row
      currentContext.reorder(props.dataItem, index);
    }
    e.preventDefault();
  };

  // Clean up the touchmove listener when touch ends
  const handleTouchEnd = () => {
    window.removeEventListener('touchmove', touchMoveRef.current);
  };

  useEffect(() => {
    // Attach touchend listener to cleanup after drag is complete
    window.addEventListener('touchend', handleTouchEnd);
    return () => {
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('touchmove', touchMoveRef.current);
    };
  }, []);

  return (
    <td
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        currentContext.reorder(props.dataItem);
        e.preventDefault();
      }}
      onTouchStart={handleTouchStart}
    >
      <span
        draggable={true}
        style={{ cursor: 'move' }}
        onDragStart={handleDragStart}
      >
        <SvgIcon icon={reorderIcon} />
      </span>
    </td>
  );
};

//It helps to Drag And Drop Approvers from Approvers/Reviewers table
export const TableDraggableRows = (props) => {
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const {
    typeOfTable,
    srCol,
    designationCol,
    field,
    formType,
    typeOfTable1,
    committeefield,
    Department,
    NoteLink,
    Departmentfield,
    NoteLinkfield,
    getpdflink,
    onedit,
    isNewForm,
    meetingOver,
    isReturned,
  } = props;
  const [gridData, setGridData] = useState(props.data);
  const [gridHeight, setGridHeight] = useState("auto");

  const [activeItem, setActiveItem] = React.useState(null);
  React.useEffect(() => {
    setGridData(props.data);
  }, [props]);

  //  Update Date
  const updatedDate = (current) => {
    const updatedRow = gridData.filter((obj, index) => index !== current);
    props.onDelate(gridData.find((obj, ind) => ind === current));
    setGridData(updatedRow);
  };

  /* 
      Bug no - 22/07 open pdf file in new tab 
      * add New function for open pdf 
  */
  const downloadBase64PDFFile = async (path) => {
    // console.log(path, "path");
    // let pdfLink = ""
    const accessToken = await getAccessToken(
      { ...loginRequest, account },
      instance
    );
    const parmas = {
      supportingDocumentPath: path,
    };
    const notePDFINfo = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: {
          ...API_COMMON_HEADERS,
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(parmas),
      }
    );
    const pdfDetails = await notePDFINfo?.text();
    if (pdfDetails !== "File Not Available!") {
      // console.log(pdfDetails);
      const byteCharacters = atob(pdfDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: "application/pdf" });
      // pdfLink = window.URL.createObjectURL(blob)
      window.open(window.URL.createObjectURL(blob));
    }
  };

  // const reorder = (dataItem, direction) => {
  //   if (activeItem === dataItem) {
  //     return;
  //   }
  //   let reorderedData = gridData.slice();
  //   let prevIndex = reorderedData.findIndex((p) => p === activeItem);
  //   let nextIndex =
  //     reorderedData.findIndex((p) => p === dataItem) +
  //     (direction === "before" ? -1 : 0);
  //   reorderedData.splice(prevIndex, 1);
  //   reorderedData.splice(nextIndex, 0, activeItem || reorderedData[0]);
  //   setGridData(
  //     reorderedData.map((obj, ind) => {
  //       return { ...obj, approverOrder: ind + 1 };
  //     })
  //   );
  //   props.onOrderChange(
  //     reorderedData.map((obj, ind) => {
  //       return { ...obj, approverOrder: ind + 1 };
  //     })
  //   );
  // };

  // const reorder = (dataItem, targetIndex = null) => {
  //   if (activeItem === dataItem) {
  //     return;
  //   }
  //   const reorderedData = [...gridData];
  //   const prevIndex = reorderedData.findIndex(p => p === activeItem);
  //   if (targetIndex === null) {
  //     targetIndex = reorderedData.findIndex(p => p === dataItem);
  //   }

  //   if (prevIndex > -1 && targetIndex > -1) {
  //     reorderedData.splice(prevIndex, 1); // Remove the item from its original position
  //     reorderedData.splice(targetIndex, 0, activeItem); // Insert the item at the new position
  //     setGridData(reorderedData);
  //   }
  // };

  const reorder = (dataItem, targetIndex = null) => {
    if (activeItem === dataItem) {
      return;
    }
  
    // Create a copy of the grid data to avoid mutating state directly
    let reorderedData = [...gridData];
    
    // Find the previous index of the active item
    const prevIndex = reorderedData.findIndex(p => p === activeItem);
    
    // If targetIndex is not provided, find it based on dataItem
    if (targetIndex === null) {
      targetIndex = reorderedData.findIndex(p => p === dataItem);
    }
  
    if (prevIndex > -1 && targetIndex > -1) {
      // Remove the active item from its original position
      reorderedData.splice(prevIndex, 1);
      
      // Insert the active item at the new target position
      reorderedData.splice(targetIndex, 0, activeItem);
  
      // Update the approverOrder for each item based on the new order
      const updatedData = reorderedData.map((obj, ind) => ({
        ...obj,
        approverOrder: ind + 1,
      }));
  
      // Update the grid data with the reordered items
      setGridData(updatedData);
  
      // Notify the parent component about the order change if needed
      if (props.onOrderChange) {
        props.onOrderChange(updatedData);
      }
    }
  };

  const dragStart = (dataItem) => {
    setActiveItem(dataItem);
  };
  return (
    <ReorderContext.Provider
      value={{
        reorder: reorder,
        dragStart: dragStart,
      }}
    >
      {/* <DragAndDrop> */}
      <div style={{overflowX:"auto",overflowY: "auto !important",maxHeight:"100vh" }}>
          <Grid scrollable
            style={{ height: gridHeight }}
            data={gridData}
            dataItemKey={"noteApproverMasterId"}
            // rowRender={(row, rowProps) => (
            //   <DraggableRow elementProps={row.props} {...rowProps} />
            // )}
            rowClassName={(index) => (index % 2 === 0 ? "even-row" : "odd-row")}
          >
            {formType !== "committeemeeting" &&
              formType !== "committeemeetingnotes" && (
                <Column title="" width="50%" cell={DragCell} />
              )}
              {/* commented for iphone scroll issue */}
            {/* <Column title=""  width="50%"  cell={DragHandleCell} /> */}
            {formType !== "committeemeetingnotes" && (
              <Column
                title="S.No"
                width="100"
                cell={(props) => {
                  return <td>{props.dataIndex + 1}</td>;
                }}
              />
            )}
            {/* Change - Adding SR No - 05/04 - RK  */}

            {/*  Change - Adding Designation- 05/04 - RK  */}
            <Column field={field} title={typeOfTable} />
            {formType !== "committeemeetingnotes" && (
              <Column field="srNo" title={srCol}  className='mobile_responsive_dragTable'/>
            )}
            {formType !== "committeemeeting" &&
              formType !== "committeeform" && (
                <Column field={committeefield} title={typeOfTable1}  className='mobile_responsive_dragTable'/>
              )}
            {formType !== "committeemeeting" &&
              formType !== "committeeform" && (
                <Column field={Departmentfield} title={Department}  className='mobile_responsive_dragTable'/>
              )}
            {formType !== "committeemeetingnotes" && (
              <Column field="designation" title={designationCol} className='mobile_responsive_dragTable'/>
            )}

            {formType !== "committeemeeting" &&
              formType !== "committeeform" && (
                <Column
                  field={NoteLinkfield}
                  title={NoteLink}
                  cell={(props) => {
                    return (
                      <td>
                        {/* Bug no -  updated column render using custom link 22/07 naren */}
                        <span
                          className="link-style"
                          onClick={() =>
                            downloadBase64PDFFile(props.dataItem[NoteLinkfield])
                          }
                          style={{ wordBreak: "break-word" }}
                        >
                          {props.dataItem[NoteLinkfield]}
                        </span>
                      </td>
                    );
                  }}
                />
              )}

            <Column
              width="120%"
              cell={(props) => {
                return (
                  <td>
                    {formType !== "committeemeetingnotes" && (
                      <Button
                        onClick={() => {
                          updatedDate(props?.dataIndex);
                        }}
                      >
                        <span className="k-icon-sm k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>
                        Delete
                      </Button>
                    )}
                    {formType !== "committeemeeting" &&
                      formType !== "committeeform" &&
                      (isNewForm || meetingOver) && (
                        <Button
                          onClick={() => {
                            updatedDate(props?.dataIndex);
                          }}
                        >
                          <span className="k-icon-sm k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>
                          Delete
                        </Button>
                      )}
                    {formType !== "committeemeeting" &&
                      formType !== "committeeform" &&
                      (!(isNewForm || meetingOver) || isReturned) && (
                        <Button onClick={() => onedit(props.dataIndex)}>
                          <span className="k-icon k-font-icon k-i-edit cursor allIconsforPrimary-btn"></span>
                          Edit
                        </Button>
                      )}
                  </td>
                );
              }}
              title="Action"
            />
          </Grid>
        </div>
      {/* </DragAndDrop> */}
    </ReorderContext.Provider>
  );
};