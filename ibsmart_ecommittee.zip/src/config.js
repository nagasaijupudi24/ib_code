/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { LogLevel } from "@azure/msal-browser";

/**
 * Configuration object to be passed to MSAL instance on creation. 
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md 
 */
// "Instance": "https://login.microsoftonline.com/",
// "Domain": "xencia.com",
// "TenantId": "75f2a99b-01fd-48f2-ac60-d4a7a44fd0cc",
// "ClientId": "e77908ab-8705-4f9a-b103-515ef6f69535",
// "ClientSecret": "Ayl8Q~VPcbGTe53TrrkiBiOkKAErJDweV8t6GcAK",
// "CallbackPath": "/signin-oidc",
// "Scopes": "access_as_user"

export const msalConfig = {
  auth: {
    /*clientId: "b3fc558c-f399-4d3b-aa6c-ac70624e07a8",
    authority: "https://login.microsoftonline.com/75f2a99b-01fd-48f2-ac60-d4a7a44fd0cc",
    redirectUri: "https://inb-ecom.xencia.com",*/

    clientId: process.env.REACT_APP_ClientId,
    authority: process.env.REACT_APP_Authority,
    redirectUri: process.env.REACT_APP_eCommittee_URL,

    /*clientId: "ab1333a0-e6bc-4ba8-b67b-4f4378b37e7e",
    authority: "https://login.microsoftonline.com/19e8abd9-a4ec-4a12-a8e7-ad170593e0b2",
    // redirectUri: "https://smartofficeDev-ecommittee.indianbank.in",
    redirectUri: "https://smartofficeuat-ecommittee.indianbank.in",*/

    // clientId: "e77908ab-8705-4f9a-b103-515ef6f69535",
    // clientId: "73c2abaa-f13a-415c-aa1a-7cce420f85b0",
    // redirectUri: "https://inb.xencia.com",
    // redirectUri: "http://localhost:3000",
    // redirectUri: "https://20.55.197.131"
  },
  cache: {
    cacheLocation: "sessionStorage", // This configures where your cache will be stored
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  },

  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            // console.error(message);
            return;
          case LogLevel.Info:
            // console.info(message);
            return;
          case LogLevel.Verbose:
            // console.debug(message);
            return;
          case LogLevel.Warning:
            // console.warn(message);
            return;
          default:
            return;
        }
      },
    },
  },
};

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit: 
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */
export const loginRequest = {
  // scopes: ['https://graph.microsoft.com/User.Read'],
  // AUD: "api://b3fc558c-f399-4d3b-aa6c-ac70624e07a8",
  scopes: [process.env.REACT_APP_Scopes],
  // scopes: ["api://ab1333a0-e6bc-4ba8-b67b-4f4378b37e7e/IBSmartOfficeScope"],
  // scopes: ["api://b3fc558c-f399-4d3b-aa6c-ac70624e07a8/User.Read"],
  // scopes: ["https://graph.microsoft.com/User.Read"],
  // loginHint: ""
  // loginHint: "admin@M365x70282966.onmicrosoft.com" // or your login hint if needed
};

export const API_COMMON_HEADERS = {
  "Content-type": "application/json; charset=UTF-8",
  "Access-Control-Allow-Origin":process.env.REACT_APP_eCommittee_URL
}

/**
 * Add here the scopes to request when obtaining an access token for MS Graph API. For more information, see:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md
 */
export const graphConfig = {
    graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
};

// IB Dev
/*export const API_BASE_URL = "https://smartofficeDev-api.indianbank.in";
export const IB_Domain_URL = "https://smartofficeDev.indianbank.in";
export const IB_eNoteDomain_URL = "https://smartofficeDev-enote.indianbank.in";
export const IB_eCommitteeDomain_URL = "https://smartofficeDev-ecommittee.indianbank.in";*/

// IB UAT
/*export const API_BASE_URL = "https://smartofficeuat-api.indianbank.in";
export const IB_Domain_URL = "https://smartofficeuat.indianbank.in";
export const IB_eNoteDomain_URL = "https://smartofficeuat-enote.indianbank.in";
export const IB_eCommitteeDomain_URL = "https://smartofficeuat-ecommittee.indianbank.in";*/

export const API_BASE_URL = process.env.REACT_APP_APIBase_URL;
export const IB_Domain_URL = process.env.REACT_APP_Home_URL;
export const IB_eNoteDomain_URL = process.env.REACT_APP_eNote_URL;
export const IB_eCommitteeDomain_URL = process.env.REACT_APP_eCommittee_URL;
export const IB_eDakDomain_URL = process.env.REACT_APP_eDak_URL;

/*export const API_BASE_URL = "https://inb-api.xencia.com";
export const IB_Domain_URL = "https://inb.xencia.com";
export const IB_eNoteDomain_URL = "https://inb-enote.xencia.com";
export const IB_eCommitteeDomain_URL = "https://inb-ecom.xencia.com";*/

// export const API_BASE_URL = "https://inb-api.xencia.com";
// export const API_BASE_URL = "http://localhost:8081";
// export const API_BASE_URL = "https://indianbankxenciaapp.azurewebsites.net";

export const API_ENDPOINTS = {
  GET_DROPDOWNDATA: "/api/ECommittee/getDropdownData",
  GET_UserDetailsByPrincipalName: (username) => `/api/Azure/GetUserDetailsByPrincipalName?userPrincipalName=${username}`,
  GET_UserDetails: "/api/Azure/GetUserDetailsGraphALL",

  /*ATR_GetRequest: "/api/ATRStatus/Atrs",
  ATR_GetAllRequests: "/api/ATRStatus/GetAtrsStatusBaseAll",
  ATR_GetRequestsByStatus: "/api/ATRStatus/GetAtrsStatusBase",
  ATR_AssigneeAction: "/api/ATRStatus/AtrStatusUpdate",
  ATR_RequesterAction: "/api/ATRStatus/AtrStatusUpdateFromRequester",*/

  ATR_GetRequest: "/api/CommitteeATR/Atrs",
  ATR_GetAllRequests: "/api/CommitteeATR/GetAtrsStatusBaseAll",
  ATR_GetRequestsByStatus: "/api/CommitteeATR/GetAtrsStatusBase",
  ATR_AssigneeAction: "/api/CommitteeATR/AtrStatusUpdate",
  ATR_RequesterAction: "/api/CommitteeATR/AtrStatusUpdateFromRequester",
  
  /*eCommittee_GetRequests: "/api/NavigationMenu/getNoteListCommittee",
  eCommittee_GetNotedNoteRequests: "/api/NavigationMenu/getNotedNoteListCommittee",
  eCommittee_LandingPageGetRequests: "/api/ECommittee/getCommitteeList",
  eCommittee_GetRefferedNoteList:"/api/ECommittee/getRefferedCommitteeList",
  eCommittee_GetEDMDNoteList: "/api/ECommittee/getEDMDCommitteeList",
  eCommittee_SearchNotes:"api/Search/SearchNotes",
  eCommittee_findIsloginUserSecretary: "/api/NoteSecretary/IdentifySecretary",
  eCommittee_GetNoteSecretaryofApprover:"/api/NoteApproversMaster/GetNoteSecretaryfromApprover",
  Board_GetNoteSecretaryofApprover:"/api/NoteApproversMaster/GetNoteSecretaryfromApprover",
  eCommittee_GetNoteApprovers: (department) => `/api/NoteApproversMaster/getNoteApprovers/?department=${encodeURIComponent(department)}`,
  eCommittee_GetNoteReviewer: (department) => `/api/NoteApproversMaster/getNoteReviewer/?department=${encodeURIComponent(department)}`,
  eCommittee_AddNote: "/api/ECommittee/AddCommittee",
  eCommittee_EditNote:"/api/ECommittee/EditCommittees",
  eCommitte_GetGeneralDetails: "/api/ECommittee/getECommitteeGeneralDetails",*/

  eCommittee_GetRequests: "/api/CommitteeNavigationMenu/getNoteListCommittee",
  eCommittee_GetNotedNoteRequests: "/api/CommitteeNavigationMenu/getNotedNoteListCommittee",
  eCommittee_LandingPageGetRequests: "/api/ECommittee/getCommitteeList",
  eCommittee_GetRefferedNoteList:"/api/ECommittee/getRefferedCommitteeList",
  eCommittee_GetEDMDNoteList: "/api/ECommittee/getEDMDCommitteeList",
  GET_CommitteeChartData:"/api/CommitteeChartInfo/getCommitteeChartInfo",
  eCommittee_SearchNotes:"/api/BoardSearch/SearchNotes",
  eCommittee_findIsloginUserSecretary: "/api/CommitteeNoteSecretary/IdentifySecretary",
  eCommittee_GetNoteSecretaryofApprover:"/api/CommitteeNoteApproversMaster/GetNoteSecretaryfromApprover",
  Board_GetNoteSecretaryofApprover:"/api/CommitteeNoteApproversMaster/GetNoteSecretaryfromApprover",
  eCommittee_GetNoteApprovers: (department) => `/api/CommitteeNoteApproversMaster/getNoteApprovers/?department=${encodeURIComponent(department)}`,
  eCommittee_GetNoteReviewer: (department) => `/api/CommitteeNoteApproversMaster/getNoteReviewer/?department=${encodeURIComponent(department)}`,
  eCommittee_AddNote: "/api/ECommittee/AddCommittee",
  eCommittee_EditNote:"/api/ECommittee/EditCommittees",
  eCommitte_GetGeneralDetails: "/api/ECommittee/getECommitteeGeneralDetails",  

  /*eCommitte_ChangeApprover:"/api/ENote/ChangeApprover",
  eCommitte_GetNoteSecretary:"/api/NoteSecretary/GetNoteSecretary",
  eCommitte_CallBackNote:"/api/ENote/CallBackNote",
  eCommittee_CancelNote:"/api/ENote/CancelNote",
  eCommitte_NoteApproverStatusChange:"/api/ENote/NoteApproverStausChange",
  eCommitte_UpdateNoteReferresStatus:"/api/NoteReferre/UpdateNoteReferrerStatus",
  eCommitte_InserNoteSecretary:"/api/NoteSecretary/InsertNoteSecretary",
  eCommitte_AddNoteMarkedInformation:"/api/NoteMarkedInformation/AddNoteMarkedInformation",
  eCommitte_GetATRCreators:"/api/ATRCreators/getATRCreators",
  eCommitte_GetATRAssignees:"/api/ATRAssignees/getATRAssignees",*/

  eCommitte_ChangeApprover:"/api/ECommittee/ChangeApprover",
  eCommitte_GetNoteSecretary:"/api/CommitteeNoteSecretary/GetNoteSecretary",
  eCommitte_CallBackNote:"/api/ECommittee/CallBackNote",
  eCommittee_CancelNote:"/api/ECommittee/CancelNote",
  eCommitte_NoteApproverStatusChange:"/api/ECommittee/NoteApproverStausChange",
  eCommitte_UpdateNoteReferresStatus:"/api/CommitteeNoteReferre/UpdateNoteReferrerStatus",
  eCommitte_InserNoteSecretary:"/api/CommitteeNoteSecretary/InsertNoteSecretary",
  eCommitte_AddNoteMarkedInformation:"/api/CommitteeNoteMarkedInformation/AddNoteMarkedInformation",
  eCommitte_GetATRCreators:"/api/CommitteeATR/getATRCreators",
  eCommitte_GetATRAssignees:"/api/CommitteeATR/getATRAssignees",

  Board_AddNote: "/api/EBoard/AddBoard",
  Board_EditNote: "/api/EBoard/EditBoard",

  Board_GetNoteApprovers: (department) => `/api/CommitteeNoteApproversMaster/getNoteApprovers/?department=${encodeURIComponent(department)}`,
  Board_GetNoteReviewer: (department) => `/api/CommitteeNoteApproversMaster/getNoteReviewer/?department=${encodeURIComponent(department)}`,
  Board_GetGeneralDetails:"/api/ECommittee/getECommitteeGeneralDetails",
  Board_ChangeApprover: "/api/ECommittee/ChangeApprover",
  Board_GetNoteSecretary: "/api/CommitteeNoteSecretary/GetNoteSecretary",
  Board_CallBackNote: "/api/ECommittee/CallBackNote",
  Board_CancelNote: "/api/ECommittee/CancelNote",
  Board_NoteApproverStatusChange: "/api/ECommittee/NoteApproverStausChange",
  Board_UpdateNoteReferresStatus: "/api/CommitteeNoteReferre/UpdateNoteReferrerStatus",
  Board_InserNoteSecretary: "/api/CommitteeNoteSecretary/InsertNoteSecretary",
  Board_AddNoteMarkedInformation:"/api/CommitteeNoteMarkedInformation/AddNoteMarkedInformation",
  Board_GetATRCreators: "/api/CommitteeATR/getATRCreators",
  Board_GetATRAssignees: "/api/CommitteeATR/getATRAssignees",


  eCommittee_GetMeetingList:"/api/ECommittee/getCommitteeListForMeeting",
  eCommittee_GetMeetingGeneralDetails:"/api/CommitteeMeeting/GetCommitteeMeetingGeneralDetails",
  eCommittee_CreateMeeting:"/api/CommitteeMeeting/CreateMeeting",
  eCommittee_PublishMeeting:"/api/CommitteeMeeting/PublishMeeting",

  MeetingView_UnMappedRecords:"/api/CommitteeMeeting/getCommitteeUnmappedList",
  MeetingView_AllInProgress:"/api/CommitteeMeeting/getInProgressCommitteeMeetingList",
  MeetingView_MyPending:"/api/CommitteeMeeting/getMyPendingCommitteeMeetingList",
  MeetingView_MyApproved:"/api/CommitteeMeeting/getMyApprovedCommitteeMeetingList",
  MeetingView_AllApproved:"/api/CommitteeMeeting/getAllApprovedCommitteeMeetingList",

  eCommitteeMeetting_GetGeneralDetails:"/api/CommitteeMeeting/GetCommitteeMeetingGeneralDetails",
  eCommitteeMeetting_CommitteeMeetingStatusChange:"/api/CommitteeMeeting/CommitteeMeetingStatusChange",
  GET_CommitteeMeetingList:"/api/ECommittee/getCommitteeListForMeeting",
  GET_CommitteeMeetingGeneralDetails:"/api/CommitteeMeeting/GetCommitteeMeetingGeneralDetails",
  eCommittee_PublishMOM:"/api/CommitteeMeeting/CommitteeMeetingMOMPublish",
  eCommittee_MeetingOver:"/api/CommitteeMeeting/CommitteeMeetingStatusChange",
  eCommittee_Meetting_chairmanApprove:"/api/CommitteeMeeting/CommitteeMeetingChairmanApproval",
  eCommitteeMeeting_GetChairmanConvenor: "/api/CommitteeMeeting/GetChairmanConvenor",
  Find_Super_Dept_Admin: (username) => `/api/Department/FindAdminorDepartmentAdmin?userPrincipalName=${username}`,
  Search_UserDetails: (username) => `/api/Azure/GetUserDetailsByStartChar?userPrincipalName=${username}`,

  GET_ReportPowerBi:"/api/CommitteeChartInfo/GetReportPowerBi",
  GET_ReportPowerBiPending:"/api/CommitteeChartInfo/GetReportPowerBiPending",
  GET_AdminType:"/api/Admin/GetAdminType",
  GET_Departments:"/api/ECommittee/getDepartments",
  Get_ATRReport:"/api/CommitteeChartInfo/GetATRReport",

  GET_Departments_List:"/api/ECommittee/getDepartments",
  GET_CommitteeNamesList:"/api/CommitteeMeeting/getECommitteeConvernerDetails",
  eCommittee_GetCommitteMembers:"/api/CommitteeMeetingApproversMaster/getCommitteeMeetingApproversMaster",

  GET_SupportingDoc:"/api/Ecommittee/getEnoteGeneralDetailsSupportDoc",
  GET_NotePdf:"/api/Ecommittee/getEnoteGeneralDetailsNotePdf",
  GET_WordDoc:"/api/Ecommittee/getEnoteGeneralDetailsWordPdf",
  GET_ATRSupportingDoc:"/api/CommitteeATR/getSupportFilesAtrs",
  GET_Base64:`/api/ENote/GetBase64`,

  eCommittee_AddPasscode: "/api/NotePasscode/AddPasscode",
  eCommittee_VerifyPasscode: "/api/NotePasscode/VerifyPasscode",
  eCommittee_SendOTP:"/api/NotePasscode/SendOTP",
  eCommittee_VerifyUserPasscode :  (username) => `/api/NotePasscode/PasscodeAvailability?userPrincipalName=${username}`,
  GET_Base64PDF: `/api/ECommittee/getECommitteePDFBase64`,
};