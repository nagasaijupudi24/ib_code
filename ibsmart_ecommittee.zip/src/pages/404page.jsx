import React from "react";
// import Navbar from "../components/navbar";
// import { Sidebar } from "../components/sidebar"; 
// import Footer from "../components/footer";
import "../styles/forms.css";
import { useNavigate } from "react-router-dom";


const PageNotFound = () => {
    const navigate = useNavigate();

    return (
      <div>
        {/* <Navbar header="IB Smart Office - eNote" />
        <Sidebar /> */}
        <div className="container404">
        {/* <span className="centerAlign404 icon404 k-icon k-font-icon  k-i-windows cursor allIconsforPrimary-btn"></span> */}
          <h4 className="centerAlign404">404 - Page Not Found</h4>
          {/* <Button
            className="notifyDailogOkBtn centerAlign404 k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
            onClick={() => navigate(process.env.REACT_APP_eNote_URL)}
          >
            <span className="k-icon k-font-icon  k-i-undo cursor allIconsforPrimary-btn"></span>
            Go back to home
          </Button> */}
        </div>
        {/* <div className="footer404">
          <Footer></Footer>
        </div> */}
      </div>
    );
};
 
export default PageNotFound;