import React, { useState, useEffect } from "react";

import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Label } from "@progress/kendo-react-labels";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import {  DropDownList } from "@progress/kendo-react-dropdowns";
import { useMsal, useAccount } from "@azure/msal-react";
import { Sidebar } from "../components/sidebar";
import DateObject from "react-date-object";
import "../styles/datagridpage.css";
import "../styles/forms.css";
import { API_BASE_URL, API_ENDPOINTS ,loginRequest,API_COMMON_HEADERS} from "../config";
import { PageLoader } from "../components/pageLoader";
import { getAccessToken } from "../App";
import AdminDashboardGrid from "../components/DashBoardReporttableForAdmin";
import {
    Chart,
    ChartSeries,
    ChartSeriesItem,
    ChartTitle,
    ChartTooltip,
    // SeriesClickEvent
} from "@progress/kendo-react-charts";
import "hammerjs";
import "bootstrap/dist/css/bootstrap.min.css";

/* const labelContent = (props) => {
    let formatedNumber = Number(props.value).toLocaleString(undefined, {
        // style: "percent",
        // minimumFractionDigits: 2,
    });
    return `${formatedNumber}`;
    // return `${props.dataItem.status} : ${formatedNumber}`;
}; */

// Handle tooltip render
const tooltipRender = props => {
    if (props.point) {
        const {
            category,
            value
        } = props.point;
        return <span>{String(category)}</span>;
    }
};

const defaultDate = new Date();
defaultDate.setMonth(3); // April is month 3 (zero-based index)
defaultDate.setDate(1);
const noteType = ["Committee Note", "Board Note"];

const AdminDashBoardChartReports = () => {
    const [dataResult, setDataResult] = useState([]);
    const [atrdataResult, setATRDataResult] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const { accounts, instance } = useMsal();
    const account = useAccount(accounts[0] || {});
    const [fromDate, setFormDate] = useState(defaultDate);
    const [toDate, setToDate] = useState(new Date());
    const [selectedDepartment, setSelectedDepartment] = useState("");
    const [getDepartment, setGetDepartment] = useState([]);
    const [isSuperAdmin, setIsSuperAdmin] = useState(false);
    const [selectedNoteType, setSelectedNoteType] = useState("Committee Note")

    useEffect(() => {
        GetDepartments()
        getUserDepartment();
    }, []);

    useEffect(() => {
        getAdminType();
        // getUserDepartment()
        fetchApiData();
        fetchApiDataATR();
    }, [fromDate, toDate, selectedDepartment, selectedNoteType]);

    // Handle get departments 
    const GetDepartments = async () => {
        try {
            const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

            const obj = await fetch(
                `${API_BASE_URL}${API_ENDPOINTS.GET_Departments}`, {
                method: "GET",
                headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
            }
            );
            const dep = await obj.json();

            setGetDepartment(dep);
        } catch (err) {
            console.log(err)
        }
    }

    // Handle get current user department
    const getUserDepartment = async () => {
        try {
            const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

            const obj = await fetch(
                `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetailsByPrincipalName(accounts[0].username)}`, {
                method: "GET",
                headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
            }
            );
            const departmentDetails = await obj.json();

            setSelectedDepartment(departmentDetails[0].department);
        } catch (error) {
            console.error("Error fetching user details:", error);
        }
        setIsLoading(false)
    };

    // Handle get admin type
    const getAdminType = async () => {
        try {
            const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

            const obj = await fetch(
                `${API_BASE_URL}${API_ENDPOINTS.GET_AdminType}?userPrincipalName=${accounts[0].username}`, {
                method: "GET",
                headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
            }
            )
            const adminType = await obj.text();
            setIsSuperAdmin(adminType === "Super Admin");
        } catch (err) {
            console.log(err)
        }
    }

    // Handle get power bi reports data
    const fetchApiData = async () => {
        const colorCodes = [
            "#7731a3", // Deep Purple
            "rgb(254, 215, 76)", // Yellow
            "#ba3294", // Purple
            "rgb(78, 185, 167)", // Turquoise
            "#d92b2b", // Red
            "rgb(12, 77, 162)", // Blue
            "#4dc313", // Green
            "#1e6bb5", // Dark Blue
            "rgb(255, 165, 0)" // Orange
        ];

        if (fromDate && toDate && selectedDepartment) {
            try {
                const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
                const Params = {
                    "Department": selectedDepartment.replace(/&/g, "%26"),
                    "fromDate": fromDate ? new DateObject(new Date(fromDate)).format("DD-MM-YYYY") : null,
                    "ToDate": toDate ? new DateObject(new Date(toDate)).format("DD-MM-YYYY") : null,
                }
                const obj = await fetch(
                    `${API_BASE_URL}${API_ENDPOINTS.GET_ReportPowerBi}?Department=${Params.Department}&fromDate=${Params.fromDate}&ToDate=${Params.ToDate}`, {
                    method: "GET",
                    headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
                }
                );
                const res = await obj.json();
                if (res) {
                    const filterAPiData = selectedNoteType === "Committee Note" ? res.lstCommitteeChart?.map((obj, index) => { return { ...obj, color: colorCodes[index],status:`${obj.status}: ${obj.count}` } }) :
                        res.lstBoardChart?.map((obj, index) => { return { ...obj, color: colorCodes[index],status:`${obj.status}: ${obj.count}` } })
                    // res.lstCommitteeChart=res.lstCommitteeChart?.map((obj, index) => { return { ...obj, color: colorCodes[index] } })
                    // res.lstNatureofNoteStatusCount = res.lstNatureofNoteStatusCount?.map((obj, index) => { return { ...obj, color: colorCodes[index] } })
                    setDataResult(filterAPiData);
                }
            }
            catch (err) {
                console.log(err)
            }
        }
    }

    // Handle get ATR reports data
    const fetchApiDataATR = async () => {
        const colorCodes = [
            "#7731a3", // Deep Purple
            "rgb(254, 215, 76)", // Yellow
            "#ba3294", // Purple
            "rgb(78, 185, 167)", // Turquoise
            "#d92b2b", // Red
            "rgb(12, 77, 162)", // Blue
            "#4dc313", // Green
            "#1e6bb5", // Dark Blue
            "rgb(255, 165, 0)" // Orange
        ];

        if (fromDate && toDate && selectedDepartment) {
            try {
                const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
                const Params = {
                    "Department": selectedDepartment.replace(/&/g, "%26"),
                    "fromDate": fromDate ? new DateObject(new Date(fromDate)).format("DD-MM-YYYY") : null,
                    "ToDate": toDate ? new DateObject(new Date(toDate)).format("DD-MM-YYYY") : null,
                }
                const obj = await fetch(
                    `${API_BASE_URL}${API_ENDPOINTS.Get_ATRReport}?Department=${Params.Department}&fromDate=${Params.fromDate}&ToDate=${Params.ToDate}`, {
                    method: "GET",
                    headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
                }
                );
                const res = await obj.json();
                if (res) {
                    const filterAPiData = selectedNoteType === "Committee Note" ? res.lstCommitteeChart?.map((obj, index) => { return { ...obj, color: colorCodes[index],status:`${obj.status}: ${obj.count}` } }) :
                        res.lstBoardChart?.map((obj, index) => { return { ...obj, color: colorCodes[index],status:`${obj.status}: ${obj.count}` } })
                    // res.lstCommitteeChart=res.lstCommitteeChart?.map((obj, index) => { return { ...obj, color: colorCodes[index] } })
                    // res.lstNatureofNoteStatusCount = res.lstNatureofNoteStatusCount?.map((obj, index) => { return { ...obj, color: colorCodes[index] } })
                    setATRDataResult(filterAPiData)
                }

            }
            catch (err) {
                console.log(err)
            }
        }
    }

    // Handle selected from date change
    const handelSelectedFromDate = (e) => {
        setFormDate(e.target.value);
        // fetchApiData(e.target.value,today,selectedDepartment);
    }

    // Handle selected to date change
    const handelSelectedToDate = (e) => {
        setToDate(e.target.value);
        // fetchApiData(fromDate,e.target.value,selectedDepartment);
    }

    /*  const handelSelectedDepartment=(e)=>{
        console.log(e)
        setGetDepartment(e.target.value);
        // fetchApiData(fromDate,toDate,e.target.value,);
     } */
    return (
        <div>
            <Navbar header="IB Smart Office - eCommittee" />
            <Sidebar />
            <div className="container cstGridContainer datagridpage ">
                <div className="SectionHeads row mobileSectionHeads">Dashboard Reports</div>
                <div className="row mobileDashboardLayout">
                    {/* <div className="col-md-6"> */}
                    <div className="col-md-3">
                        <Label className="k-form-label" style={{fontSize:"14px"}}>From Date:</Label>
                        <DatePicker
                            // defaultValue={null}
                            max={new Date()}
                            placeholder="From Date..."
                            onChange={handelSelectedFromDate}
                            // onChange={(event) => setFormDate(event.target.value)}
                            format={"dd-MM-yyyy"}
                            value={fromDate}
                        />

                    </div>
                    <div className="col-md-3">
                        <Label className="k-form-label" style={{fontSize:"14px"}}>To Date:</Label>
                        <DatePicker
                            // defaultValue={null}
                            // max={new Date()}
                            min={new Date(fromDate)}
                            max={new Date()}
                            placeholder="To Date..."
                            onChange={handelSelectedToDate}
                            format={"dd-MM-yyyy"}
                            value={toDate}
                        />
                    </div>
                    {isSuperAdmin && (
                        <div className="col-md-3">
                            <Label className="k-form-label" style={{fontSize:"14px"}} >Select Department:</Label>
                            <DropDownList
                                data={getDepartment?.map(x => x.departmentName)}
                                value={selectedDepartment}
                                onChange={(e) =>
                                    setSelectedDepartment(e.target.value)
                                }
                            // onChange={handelSelectedDepartment}
                            />
                        </div>
                    )}
                    <div className="col-md-3">
                        <Label className="k-form-label" style={{fontSize:"14px"}}>Select Note Type:</Label>
                        <DropDownList
                            data={noteType}
                            value={selectedNoteType}
                            onChange={(e) =>
                                setSelectedNoteType(e.target.value)
                            }
                        />
                    </div>
                </div>
                {/* Add a section for displaying headings and allow the user to switch between them*/}
                {isLoading ? (
                    <PageLoader />
                ) : (
                    <>
                    <div className="SectionRowForPowerBIReports row">
                        <div className="col-md-6 custom-pie-chart-seperateline ">
                            <div className="row">
                                <div className="enote-chartContainer">
                                    <Chart>
                                        <ChartTitle text={`${selectedNoteType}s - status`} color="#7731a3"/>
                                        <ChartSeries>
                                            <ChartSeriesItem
                                                type="pie"
                                                data={dataResult}
                                                field="count"
                                                categoryField="status"
                                                tooltip={{
                                                    visible: true,
                                                }}
                                
                                            />

                                        </ChartSeries>
                                        <ChartTooltip opacity={1} visible={true} render={tooltipRender} />
                                    </Chart>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <Chart>
                                <ChartTitle text={`${selectedNoteType}s ATR - status`} color="#7731a3" />
                                <ChartSeries>
                                    <ChartSeriesItem
                                        type="pie"
                                        data={atrdataResult}
                                        field="count"
                                        categoryField="status"
                                        tooltip={{
                                            visible: true,
                                        }}
                                     

                                    />

                                </ChartSeries>
                                <ChartTooltip opacity={1} visible={true} render={tooltipRender} />
                            </Chart>
                            {/* <AdminDashboardGrid departmentName={selectedDepartment} noteType={selectedNoteType} /> */}
                        </div>
                    </div>
                    <div className="SectionHeadsDashBoard row">{`${selectedNoteType}s - Pending With`}</div>
                    <div className="row">
                        <div className="col">
                        <AdminDashboardGrid 
                        departmentName={selectedDepartment} 
                        noteType={selectedNoteType} 
                        fromDate={fromDate}
                        toDate={toDate}/>

                        </div>
                    </div>
                    </>
                )
                }

            </div>
            <div className="pgFooterContainer">
                <Footer />
            </div>
        </div>
    );
};

export default AdminDashBoardChartReports;
