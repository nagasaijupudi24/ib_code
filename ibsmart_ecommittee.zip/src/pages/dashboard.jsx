import React, { useEffect } from "react";
import { getter } from "@progress/kendo-react-common";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import { CSVLink } from "react-csv";
import { Button } from "@progress/kendo-react-buttons";
import {
  ColumnMenu
} from "./custom-cells";
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
import { fetchNoteData } from "./apiService";
import { Link } from "react-router-dom";
import { useMsal, useAccount } from "@azure/msal-react";
import DateObject from "react-date-object";

const DATA_ITEM_KEY = "id";
const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};
const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};
export const Dashboard = ({ apiOutput, selectedView, enumObj }) => {
  const { accounts } = useMsal();
  const account = useAccount(accounts[0] || {});
  const idGetter = getter("id");
  const [filterValue, setFilterValue] = React.useState("");
  const [filteredData, setFilteredData] = React.useState(apiOutput);
  const [currentSelectedState, setCurrentSelectedState] = React.useState({});
  const [dataState, setDataState] = React.useState(initialDataState);
  const [dataResult, setDataResult] = React.useState(
    process(filteredData, dataState)
  );
  const [data, setData] = React.useState(filteredData);
  const [apiData, setApiData] = React.useState([]);

  useEffect(() => {

    setApiData(apiOutput);
    setFilteredData(apiOutput);
    let processedData = process(apiOutput, initialDataState);
    setDataResult(processedData);
    setDataState({ ...dataState, total: apiOutput.length });
    setFilterValue("");
  }, [apiOutput]);

  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      setFilteredData(apiData);
      setDataResult(
        process(apiData, (dataState) => ({
          ...dataState,
          total: apiData.length,
        }))
      );
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLocaleLowerCase()
              .includes(value.toLocaleLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      let clearedPagerDataState = {
        ...dataState,
        take: 8,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState(clearedPagerDataState);
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiOutput.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );
  const dataStateChange = (event) => {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );
  const setSelectedValue = (data) => {
    let newData = data.map((item) => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items),
        };
      } else {
        return {
          ...item,
          ["selected"]: currentSelectedState[idGetter(item)],
        };
      }
    });
    return newData;
  };
  const newData = setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: [],
  });

  // console.log(newData)
/*   const onHeaderSelectionChange = React.useCallback(
    (event) => {
      const checkboxElement = event.syntheticEvent.target;
      const checked = checkboxElement.checked;
      const newSelectedState = {};
      data.forEach((item) => {
        newSelectedState[idGetter(item)] = checked;
      });
      setCurrentSelectedState(newSelectedState);
      const newData = data.map((item) => ({
        ...item,
        [SELECTED_FIELD]: checked,
      }));
      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);
    },
    [data, dataState]
  );

  const onSelectionChange = (event) => {
    const selectedProductId = event.dataItem.id;
    const newData = data.map((item) => {
      if (item.id === selectedProductId) {
        item.selected = !item.selected;
      }
      return item;
    });
    setCurrentSelectedState((prevState) => ({
      ...prevState,
      [selectedProductId]: !prevState[selectedProductId],
    }));
    const newDataResult = processWithGroups(newData, dataState);
    setDataResult(newDataResult);
  }; */
/*   const getNumberOfItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfItems(item.items);
      } else {
        count++;
      }
    });
    return count;
  };
  const getNumberOfSelectedItems = (data) => {
    let count = 0;
    data.forEach((item) => {
      if (item.items) {
        count = count + getNumberOfSelectedItems(item.items);
      } else {
        count = count + (item.selected == true ? 1 : 0);
      }
    });
    return count;
  };
 */
 /*  const checkHeaderSelectionValue = () => {
    let selectedItems = getNumberOfSelectedItems(newData);
    return newData.length > 0 && selectedItems == getNumberOfItems(newData);
  };
  let _pdfExport;
  const exportExcel = () => {
    _export.save();
  };
  let _export;
  const exportPDF = () => {
    _pdfExport.save();
  };
 */
  // Handle expost CSV header
  const exportCSVHeader = () => {
    return [
      { key: "noteNumber", label: "Note ID" },
      // Bug fix - 293 - 27/03
      { key: "createdByName", label: "Requester" },
      { key: "departmentName", label: "Department" },
      { key: "committeeName", label: "Board/Committee Name" },
      { key: "subject", label: "Subject" },
      { key: "strNoteStatus", label: "Status" },
      { key: "lastActioner", label: "Previous Approver" },
      { key: "finalApprover", label: "Final Approver" },
      { key: "modifiedDate", label: "Modified Date" },
      { key: "createdDate", label: "Created Date" }
    ];
  }

  // Handle render column with data
  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    const columnsConfig = [
      { field: "noteNumber", title: "Note ID" },
      // Bug fix - 293 - 27/03
      { field: "createdByName", title: "Requester" },
      { field: "departmentName", title: "Department" },
      { field: "committeeName", title: "Board/Committee Name" },
      { field: "subject", title: "Subject" },
      { field: "strNoteStatus", title: "Status" },
      { field: "lastActioner", title: "Previous Approver" },
      { field: "finalApprover", title: "Final Approver" },
      { field: "modifiedDate", title: "Modified Date" },
      { field: "createdDate", title: "Created Date" },
    ];

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "noteNumber" ? (
            <td>
              <Link
                style={{ color: "red" }}
                to={
                  (props.dataItem["status"] === enumObj.NoteStatus.find((x) => x.dValue === "Draft").id ||
                  props.dataItem["status"] === enumObj.NoteStatus.find((x) => x.dValue === "Returned").id ||
                  props.dataItem["status"] === enumObj.NoteStatus.find((x) => x.dValue === "Called Back").id) &&
                  props.dataItem["createdBy"] === accounts[0].username
                    ? `${(props.dataItem["noteFor"] === enumObj.noteFor.find((x) => x.dValue === "Committee").id)?"/ecommitteenote/":"/boardnoteform/"}${props.dataItem["noteId"]}`
                    : `${(props.dataItem["noteFor"] === enumObj.noteFor.find((x) => x.dValue === "Committee").id)?"/ecommitteeviewform/":"/boardnoteviewform/"}${props.dataItem["noteId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {/* Bug fix - 300 - 27/03 */}
              {column.title.includes("Date")
              // Change 23/05 seconds Removed 
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A")
                : (column.field === "committeeName" && props.dataItem["noteFor"] === enumObj.noteFor.find((x) => x.dValue === "Board").id)?props.dataItem['boardCommitteeName']:props.dataItem[column.field]}
               {/* {column.title === "Board/Committee Name" && props.dataItem["noteFor"] === enumObj.noteFor.find((x) => x.dValue === "Board").id?props.dataItem['boardCommitteeName']:props.dataItem[column.field]} */}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  // Handle onHeader cell click
  const onHeaderCellClick = (event) => {
    const clickedColumn = event.column;
    if (clickedColumn.field === "noteId") {
      // Extract noteId from the clicked column
      const noteId = clickedColumn.dataItem.noteId;

      // Fetch data based on the noteId
      fetchNoteData(noteId);
    }
  };
  return (
    <div>
      <Grid
        className="cstGridlandPgStyles"
        onHeaderCellClick={onHeaderCellClick}
        pageable={{ pageSizes: true }}
        data={dataResult}
        sortable={true}
        total={resultState.total}
        onDataStateChange={dataStateChange}
        {...dataState}
        onExpandChange={onExpandChange}
        expandField="expanded"
        dataItemKey={DATA_ITEM_KEY}
        selectedField={SELECTED_FIELD}
        /*onHeaderSelectionChange={onHeaderSelectionChange} 
        onSelectionChange={onSelectionChange}*/
        groupable={true}
        size={"small"}
        resizable={true}
      >
        <GridToolbar>
          <Input
            value={filterValue}
            onChange={onFilterChange}
            style={{
              border: "2px solid #ccc",
              boxShadow: "inset 0px 0px 0.5px 0px rgba(0,0,0,0.0.1)",
              width: "170px",
              height: "30px",
              marginRight: "10px",
            }}
            placeholder="Search in all columns..."
          />
          <div className="export-btns-container">
            {/* <Button onClick={exportExcel}>Export to Excel</Button> */}
            {/* <Button onClick={exportPDF}>Export to PDF</Button> */}
            <Button style={{ marginLeft: "5px" }}>
              <CSVLink
                filename={`eCommittee-${selectedView.replace(
                  / /g,
                  ""
                )}${new DateObject(new Date()).format("DDMMYYYYhhmmss")}`}
                // Bug fix - 300 - 27/03
                // Change 23/05 Seconds hand was Removed
                data={filteredData.map((x) => ({...x, modifiedDate: new DateObject( new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm A"),
                createdDate: new DateObject( new Date(x.createdDate) ).format("DD-MMM-YYYY hh:mm A"),}))}
                headers={exportCSVHeader()}
              >
                Export CSV
              </CSVLink>
            </Button>
          </div>
        </GridToolbar>
        {/* <Column 
        filterable={false} 
        field={SELECTED_FIELD} 
        width={50} 
        headerSelectionValue={checkHeaderSelectionValue()} /> */}
        {renderColumnsWithData(dataResult)}
      </Grid>
    </div>
  );
};
