import React, { useState, useEffect } from "react";
import "../styles/datagridpage.css";
import "../styles/responsiveDesign.css";
import { Button } from "@progress/kendo-react-buttons";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Dashboard } from "./dashboard";
import { Sidebar } from "../components/sidebar";
import { useMsal, useAccount } from "@azure/msal-react";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { PageLoader } from "../components/pageLoader";
import { orderBy } from "@progress/kendo-data-query";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { ChartContainer } from "../components/ChartInfo";
import { useTabContext } from "../App";

const initialSort = [
  {
    field: "modifiedDate",
    dir: "desc",
  },
];

export const ECommitteeHome = () => {
  const { accounts, instance } = useMsal();
  const {activeTab} = useTabContext();
  const account = useAccount(accounts[0] || {});
  // const [activeButton, setActiveButton] = useState("My Notes");
  const [activeButton, setActiveButton] = useState(activeTab);
  const [myPendingNotes, setMyPendingNotes] = useState(0);
  const [myRecommendedReferredNotes, setMyRecommendedReferredNotes] = useState(0);
  const [myReturnedNotes, setmyReturnedNotes] = useState(0);
  const [myApprovedNotes, setmyApprovedNotes] = useState(0);
  const [myEDMDNotes, setmyEDMDNotes] = useState(0);
  const [apiOutput, setapiOutput] = React.useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSecretary, setIsSecretary] = useState(true);
  const [selectedView, setSelectedView] = useState("");
  const [enumObj, setEnumObj] = useState();
  const [selectedCommitteeType, setSelectedCommitteeType] = useState("Committee Note");
  const [chartInfo, setChartInfo] = useState();
  const [committeeTypeOptions] = useState(["Committee Note", "Board Note", "Committee Meeting"]);
  const [myNotes, setMyNotes] = useState(0);
  const [isMobileView, setIsMobileView] = useState(window.innerWidth <= 768);
  const [selectedOption, setSelectedOption] = useState(null);

  useEffect(() => {
    findIsSecratary();
    // handleButtonClick("My Notes");
    handleButtonClick(activeTab);

    const initialOption = options.find(option => option.value === activeTab);
    setSelectedOption(initialOption);

    const handleResize = () => {
      setIsMobileView(window.innerWidth <= 1105);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };

  }, []);

  const options = [
    { text: "My Notes", value: "My Notes" },
    { text: "My Pending Notes", value: "My Pending Notes" },
    { text: "My Recommended/Referred Notes", value: "My Recommended/Referred Notes" },
    { text: "My Returned Notes", value: "My Returned Notes" },
    { text: "My Approved Notes", value: "My Approved Notes" },
  ];

  if (isSecretary) {
    options.push({ text: "ED/MD Notes", value: "ED/MD Notes" });
  }

  const handleSelect = (event) => {
    const selectedValue = event.target.value;
    console.log(selectedValue,"selectedValue");
    
    setSelectedOption(options.find(option => option.value === selectedValue));
    // selectedValue
    setSelectedOption(selectedValue);
    handleButtonClick(selectedValue?.value);
  };

  // Handle dropdown for landing page option
  const renderDropdown = () => (
    <DropDownList
      className="landing_Page_Dropdown"
      data={options}
      value={selectedOption}
      textField="text"
      dataItemKey="value"
      onChange={handleSelect}
      defaultItem={{ text: "Select an option", value: null }}
    />
  );

  // Handle render buttons
  const renderButtons = () => (
    <div className="row landingPgTopBtnRow">
      <Button className="landingPgTopBtn"
        style={{ width: isSecretary ? "16%" : "18%", background: activeButton === "My Notes" ? "#034ea1" : "", color: activeButton === "My Notes" ? "#ffff" : "" }}
        onClick={() => handleButtonClick("My Notes")}
      >
        My Notes
        {activeButton === "My Notes" && (<span className="landingPgTopBtncontent">{myNotes}</span>)}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Pending Notes" ? "#034ea1" : "",
          color: activeButton === "My Pending Notes" ? "#ffff" : "#333333",

        }}
        onClick={() => handleButtonClick("My Pending Notes")}
      >
        My Pending Notes
        {activeButton === "My Pending Notes" && (
          <span className="landingPgTopBtncontent">
            {myPendingNotes}
          </span>
        )}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Recommended/Referred Notes" ? "#034ea1" : "",
          color: activeButton === "My Recommended/Referred Notes" ? "#ffff" : "",

        }}
        onClick={() => handleButtonClick("My Recommended/Referred Notes")}
      >
        My Recommended/Referred Notes
        {activeButton === "My Recommended/Referred Notes" && (
          <span className="landingPgTopBtncontent">
            {myRecommendedReferredNotes}
          </span>
        )}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Returned Notes" ? "#034ea1" : "",
          color: activeButton === "My Returned Notes" ? "#ffff" : "",

        }}
        onClick={() => handleButtonClick("My Returned Notes")}
      >
        My Returned Notes
        {activeButton === "My Returned Notes" && (
          <span className="landingPgTopBtncontent" >
            {myReturnedNotes}
          </span>
        )}
      </Button>
      <Button className="landingPgTopBtn"
        style={{
          width: isSecretary ? "16%" : "18%",
          background: activeButton === "My Approved Notes" ? "#034ea1" : "",
          color: activeButton === "My Approved Notes" ? "#ffff" : "",

        }}
        onClick={() => handleButtonClick("My Approved Notes")}
      >
        My Approved Notes
        {activeButton === "My Approved Notes" && (<span className="landingPgTopBtncontent">{myApprovedNotes}</span>)}
      </Button>
      {isSecretary && <Button className="landingPgTopBtn"
        style={{ width: isSecretary ? "16%" : "18%", background: activeButton === "ED/MD Notes" ? "#034ea1" : "", color: activeButton === "ED/MD Notes" ? "#ffff" : "" }}
        onClick={() => handleButtonClick("ED/MD Notes")}
      >
        ED/MD Notes
        {activeButton === "ED/MD Notes" && (<span className="landingPgTopBtncontent">{myEDMDNotes}</span>)}
      </Button>}
    </div>
  );

// Handle btn click
  const handleButtonClick = async (buttonText) => {
    setActiveButton(buttonText);
    setSelectedCommitteeType("Committee Note")
    setIsLoading(true);

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
    });

    const enumsObject = await dropdowns.json();
    setEnumObj(enumsObject);
    switch (buttonText) {
      case "My Pending Notes":
        fetchApiData(API_ENDPOINTS.eCommittee_LandingPageGetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Pending").id, buttonText);
        break;
      case "My Recommended/Referred Notes":
        fetchApiData(API_ENDPOINTS.eCommittee_GetRefferedNoteList, 0, buttonText);
        break;
      case "My Returned Notes":
        fetchApiData(API_ENDPOINTS.eCommittee_LandingPageGetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Returned").id, buttonText);
        break;
      case "My Approved Notes":
        fetchApiData(API_ENDPOINTS.eCommittee_LandingPageGetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Approved").id, buttonText);
        break;
      case "ED/MD Notes":
        fetchApiData(API_ENDPOINTS.eCommittee_GetEDMDNoteList, 0, buttonText);
        break;
      case "My Notes":
        fetchApiDataForChart(API_ENDPOINTS.GET_CommitteeChartData);
        break;
      default:
        fetchApiData(API_ENDPOINTS.eCommittee_LandingPageGetRequests, enumsObject.NoteStatus.find((x) => x.dValue === "Pending").id, "My Pending Notes");
        break;
    }
  };

  // Handle find secratary
  const findIsSecratary = async () => {
    setIsLoading(true);

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eCommittee_findIsloginUserSecretary}`,
      {
        method: "POST",
        body: JSON.stringify({ SecretaryEmail: accounts[0].username }),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      }
    )
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        setIsSecretary(data);
        // console.log(data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
    setIsLoading(false);
  };

  // get charts info
  const fetchApiDataForChart = async (apiEndpoint) => {
    const colorCodes = [
      "#7731a3", // Deep Purple
      "rgb(254, 215, 76)", // Yellow
      "#ba3294", // Purple
      "rgb(78, 185, 167)", // Turquoise
      "#d92b2b", // Red
      "rgb(12, 77, 162)", // Blue
      "#4dc313", // Green
      "#1e6bb5", // Dark Blue
      "rgb(255, 165, 0)", // Orange
      "#d92b2b"
    ];
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(`${API_BASE_URL}${apiEndpoint}?userEmailId=${accounts[0].username}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      });

      if (response.ok) {
        let committeeNote = 0;
        setIsLoading(false);
        const apiData = await response.json();
        if (apiData) {
          apiData.lstCommitteeMeetingChart = apiData.lstCommitteeMeetingChart?.map((obj, ind) => { return { ...obj, color: colorCodes[ind],status:`${obj.status}: ${obj.count}` } });
          apiData.lstCommitteeChart = apiData.lstCommitteeChart?.map((obj, ind) => { return { ...obj, color: colorCodes[ind],status:`${obj.status}: ${obj.count}` } });
          apiData.lstBoardChart = apiData.lstBoardChart?.map((obj, ind) => { return { ...obj, color: colorCodes[ind],status:`${obj.status}: ${obj.count}` } });
          apiData.lstCommitteeNatureofNoteStatusCount = apiData.lstCommitteeNatureofNoteStatusCount?.map((obj, ind) => { return { ...obj, color: colorCodes[ind],status:`${obj.status}: ${obj.count}` } });
          apiData.lstBoardNatureofNoteStatusCount = apiData.lstBoardNatureofNoteStatusCount?.map((obj, ind) => { return { ...obj, color: colorCodes[ind],status:`${obj.status}: ${obj.count}` } });
          apiData.lstCommitteeMeetingNameCount = apiData.lstCommitteeMeetingNameCount?.map((obj, ind) => { return { ...obj, color: colorCodes[Math.floor(Math.random() * colorCodes.length)],status:`${obj.status}: ${obj.count}`} });
          //  initially taking count for committee note
          apiData.lstCommitteeChart?.map(obj => {
            committeeNote = committeeNote + obj.count
          })
          setMyNotes(committeeNote);
          setChartInfo(apiData);
        }
      }
    } catch {
      setIsLoading(false);
      console.log("err")
    }
  }

  // Handle get data
  const fetchApiData = async (apiEndpoint, Status, buttonText) => {
    setSelectedView(buttonText);
    let params;

    if (buttonText === "ED/MD Notes" || buttonText === "My Recommended/Referred Notes") {
      params = { CreatedBy: accounts[0].username }
    } else {
      params = { Status: Status, CreatedBy: accounts[0].username }
    }
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(`${API_BASE_URL}${apiEndpoint}`, {
        method: "POST",
        body: JSON.stringify(params),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      });

      if (response.ok) {
        const apiData = await response.json();
        // console.log(apiData, "Resposne data");

        // const dataArray = Array.isArray(apiData) ? apiData : [apiData];
        if (apiData.pendingNoteList) {
          let resData = apiData.pendingNoteList;
          const apiCstData = orderBy(resData, initialSort);
          // Bug fix - 300 - 27/03
          // const apiCstData = upData.map(x=>({...x,modifiedDate:new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"),createdDate:new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A")}));

          setapiOutput(apiCstData);
          switch (buttonText) {
            case "My Pending Notes":
              setMyPendingNotes(apiData.pendingNoteList.length);
              break;
            case "My Recommended/Referred Notes":
              setMyRecommendedReferredNotes(apiData.pendingNoteList.length);
              break;
            case "My Returned Notes":
              setmyReturnedNotes(apiData.pendingNoteList.length);
              break;
            case "My Approved Notes":
              setmyApprovedNotes(apiData.pendingNoteList.length);
              break;
            case "ED/MD Notes":
              setmyEDMDNotes(apiData.pendingNoteList.length);
              break;
            // Add more cases for other buttons if needed
            default:
              break;
          }
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    setIsLoading(false);
  };

  // committee note dropdown Change for chart
  const onChangeForChartType = (e) => {
    let noteCount = 0
    if (e.target.value === committeeTypeOptions[0]) {
      chartInfo.lstCommitteeChart?.map(obj => {
        noteCount = noteCount + obj.count
      })
    }
    if (e.target.value === committeeTypeOptions[1]) {
      chartInfo.lstBoardChart?.map(obj => {
        noteCount = noteCount + obj.count
      })
    }
    if (e.target.value === committeeTypeOptions[2]) {
      chartInfo.lstCommitteeMeetingChart?.map(obj => {
        noteCount = noteCount + obj.count
      })
    }
    setMyNotes(noteCount);
    setSelectedCommitteeType(e.target.value);
  }

  return (
    <div>
      <Navbar header="IB Smart Office - eNote" />
    {/* Task 319--showing the menus at first time--12/04--RK */}
      <Sidebar defaultOpenComponent={true}/>
      <div className="container datagridpage">
        <div className="datagridPghdrBtns">
          <div className="row dataGridContainer" >
            {/* <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background:
                  activeButton === "My Notes" ? "#034ea1" : "",
                color:
                  activeButton === "My Notes" ? "#ffff" : "#333333",
              }}
              onClick={() => handleButtonClick("My Notes")}
            >
              My Notes
              {activeButton === "My Notes" && (
                <span className="landingPgTopBtncontent">
                  {myNotes}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background:
                  activeButton === "My Pending Notes" ? "#034ea1" : "",
                color:
                  activeButton === "My Pending Notes" ? "#ffff" : "#333333",
              }}
              onClick={() => handleButtonClick("My Pending Notes")}
            >
              My Pending Notes
              {activeButton === "My Pending Notes" && (
                <span className="landingPgTopBtncontent">
                  {myPendingNotes}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background:
                  activeButton === "My Recommended/Referred Notes"
                    ? "#034ea1"
                    : "",
                color:
                  activeButton === "My Recommended/Referred Notes"
                    ? "#ffff"
                    : "",
              }}
              onClick={() => handleButtonClick("My Recommended/Referred Notes")}
            >
              My Recommended/Referred Notes
              {activeButton === "My Recommended/Referred Notes" && (
                <span className="landingPgTopBtncontent">
                  {myRecommendedReferredNotes}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background:
                  activeButton === "My Returned Notes" ? "#034ea1" : "",
                color: activeButton === "My Returned Notes" ? "#ffff" : "",
              }}
              onClick={() => handleButtonClick("My Returned Notes")}
            >
              My Returned Notes
              {activeButton === "My Returned Notes" && (
                <span className="landingPgTopBtncontent" >
                  {myReturnedNotes}
                </span>
              )}
            </Button>
            <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "18%" : "23%",
                background:
                  activeButton === "My Approved Notes" ? "#034ea1" : "",
                color: activeButton === "My Approved Notes" ? "#ffff" : "",
              }}
              onClick={() => handleButtonClick("My Approved Notes")}
            >
              My Approved Notes
              {activeButton === "My Approved Notes" && (<span className="landingPgTopBtncontent">{myApprovedNotes}</span>)}
            </Button>
            {isSecretary && <Button className="landingPgTopBtn"
              style={{
                width: isSecretary ? "16%" : "18%",
                background: activeButton === "ED/MD Notes" ? "#034ea1" : "",
                color: activeButton === "ED/MD Notes" ? "#ffff" : "",
              }}
              onClick={() => handleButtonClick("ED/MD Notes")}
            >
              ED/MD Notes
              {activeButton === "ED/MD Notes" && (
                <span className="landingPgTopBtncontent" >
                  {myEDMDNotes}
                </span>
              )}
            </Button>} */}
            {isMobileView ? renderDropdown() : renderButtons()}
          </div>
        </div>
        {activeButton === "My Notes" && (
          <div className="row ">
            <div className="custom-dropdown-for-committeeNote-charts">
              <label className="mobileSelectNote"> Select Note Type : </label>
              <DropDownList
                data={committeeTypeOptions}
                value={selectedCommitteeType}
                // defaultValue={1}
                onChange={onChangeForChartType}
                className="custom-dropdown-for-committeeNote-charts-dropdownWidth"
                // style={{
                //   width: "300px",
                //   // float:"right"
                // }}
              >
              </DropDownList>
            </div>

          </div>
        )}
        {isLoading ? <PageLoader /> : activeButton === "My Notes" ? <ChartContainer apiOutput={chartInfo} committeeType={selectedCommitteeType} />
          : <Dashboard apiOutput={apiOutput} selectedView={selectedView} enumObj={enumObj} />}
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};