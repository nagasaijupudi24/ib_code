import React, { useState, useEffect } from "react";
import {
  Field,
  Form,
  FormElement,
  FieldWrapper,
} from "@progress/kendo-react-form";
import { Input, TextArea } from "@progress/kendo-react-inputs";
import { DatePicker } from "@progress/kendo-react-dateinputs";
import { DropDownList, MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
import { Button } from "@progress/kendo-react-buttons";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Sidebar } from "../components/sidebar";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/forms.css";
import { Label } from "@progress/kendo-react-labels";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { xIcon, infoCircleIcon } from "@progress/kendo-svg-icons";
import { Link, useParams } from "react-router-dom";
import { useMsal, useAccount } from "@azure/msal-react";
import { SvgIcon } from "@progress/kendo-react-common";
import { TableDraggableRows } from "../components/tableDragRows";
import { filterBy } from "@progress/kendo-data-query";
import { PageLoader } from "../components/pageLoader";
import { useNavigate } from "react-router-dom";
import { API_BASE_URL, API_ENDPOINTS ,loginRequest,API_COMMON_HEADERS} from "../config";
import Clock from 'react-live-clock';
import { getAccessToken } from "../App";
import DateObject from "react-date-object";
import { orderBy } from "@progress/kendo-data-query";
import { Editor, EditorTools, EditorUtils } from "@progress/kendo-react-editor";

const {
  Bold,
  Italic,
  Underline,
  Subscript,
  Superscript,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Indent,
  Outdent,
  OrderedList,
  UnorderedList,
  Undo,
  Redo,
  FontSize,
  FontName,
  FormatBlock,
} = EditorTools;

const CustomDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};

const CustomDialogAddMOM = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <span className="k-icon k-font-icon k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>{" "}
      Add MOM
    </div>
  );
};

const CustomConfirmDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span>{" "}
      Confirmation
    </div>
  );
};
const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",
  },

  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "120px",
  },
];

// mobile view responsive
const mobileColumns = [
  {
    field: "displayName",
    header: "Person Name",
    width: "100px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "100px",
  },
  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "70px",
  },
];
const noteRecordsPickerColumnMapping = [
  {
    field: "committeeName",
    header: "Committee Name",
    width: "200px",
  },
  {
    field: "noteNumber",
    header: "Note Number",
    width: "180px",
  },
  {
    field: "departmentName",
    header: "Department",
    width: "180px",
  },
];
const mobileNoteRecordsPickerColumnMapping = [
  {
    field: "committeeName",
    header: "Committee Name",
    width: "120px",
  },
  {
    field: "noteNumber",
    header: "Note Number",
    width: "120px",
  },
  {
    field: "departmentName",
    header: "Department",
    width: "200px",
  },
];

export const ECommitteeMeetingsNewForm = () => {
  const valueRender = (element, value, fieldName) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      setState(prevState => ({
        ...prevState,
        [fieldName]: '', // Clear the value of the specified field
      }));
      if(fieldName==="committeeName"){
      setCommitteMeetingsNotes([]);
      setCommiteeGuestMembersData([]);
      setCommiteeMembersData([]);
      }
    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} style={{
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        flexGrow: 1
      }}>
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, {
      ...element.props
    }, children);
  };
  const navigate = useNavigate();
  const [committeeMembersData, setCommiteeMembersData] = useState([]);
  const [committeeGuestMembersData, setCommiteeGuestMembersData] = useState([]);
  const [committeeMeetingsNotes, setCommitteMeetingsNotes] = useState([]);
  const [showSuccessmsg, setShowSuccessmsg] = useState(false);
  const [successmsg, setSuccessmsg] = useState("");
  const [showConfirmDailog, setShowConfirmDailog] = useState(false);
  const [confirmDailogObj, setConfirmDailogObj] = React.useState({
    Confirmtext: "",
    Description: "",
  });
  const [selectedAction, setSelectedAction] = useState("");
  // const [committeeMeetingsComments, setCommitteeMeetingsComments] = useState([]);
  // const [committeeMeetings, setCommitteMeetings] = useState([]);
  const [committeeName, setCommitteeName] = useState([]);
  // const [noteapproverData, setNoteApproverData] = useState([]);
  // const [notereviewerData, setNoteReviewerData] = useState([]);
  // const [value, setValue] = useState("");
  const [departmentError] = useState("");
  const [redirectTo] = useState("/meetingviews/All%20In-progress%20Committee%20Meeting%20Records");
  const [isLoading, setIsLoading] = useState(false);
  const [committeeNameBorderColor, setCommitteeNameBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [convenerBorderColor, setConvenerBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [chairmanBorderColor, setChairmanBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [meetingDateBorderColor, setMeetingDateBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [meetingSubjectBorderColor, setMeetingSubjectBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [meetingModeBorderColor, setMeetingModeBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [meetingLinkBorderColor, setMeetingLinkBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  // const [emailsObject, setEmailsObject] = useState([]);
  const [approverEmailsList] = useState();
  // const [committeeMeetingList, setCommitteeMeetingList] = useState();
  const [committeeMeetingsObject, setCommitteeMeetingsObject] = useState([]);
  const [selectedCommitteeNote, setSelectedCommitteeNote] = useState(null);
  const [selectedCommitteeMember, setSelectedReviewer] = useState(null);
  const [committeeGuestMember, setcommitteeGuestMember] = useState(null);
  const [commentsData, setCommentsData] = useState([]);
  const [workflowLog, setWorkflowLog] = useState([]);
  const [validationErrors, setValidationErrors] = React.useState(false);
  // const [isSecretaryExist, setisSecretaryExist] = useState(false);
  const [showNotification, setShowNotification] = React.useState(false);
  const [notificationMsg, setNotificationMsg] = React.useState(false);
  const [enumsObj, setEnumsObj] = React.useState(null);
  const noteId = useParams();
  const [isNewForm] = React.useState(noteId.id === "new");
  const [meetingOver, setMeetingOver] = useState(false);
  // const [publishMeeting, setPublishMeeting] = useState(true);
  const [publishMom, setPublishMom] = useState(false);
  const [momVisible, setMomVisible] = useState(false);
  const [momData, setMomData] = useState({});
  const [commentText, setCommentText] = useState('');
  const editor = React.createRef();
  const [innerValue, setInnerValue] = React.useState("");
  const [isReturned, setIsReturned] = useState(false);
  const [publishMeetingValidationDialog, setPublishMeetingValidationDialog] = useState(false);
  const [isMeetingPublished, setIsMeetingPublished] = useState(false);
  const max = 250;
  const [state, setState] = useState({
    meetingId: "To be genererated",
    committeeMeetingId: "",
    committeeName: "",
    // convenerDepartment: "",
    // chairman: "",
    meetingDate: new Date(),
    meetingSubject: "",
    meetingMode: "",
    meetingLink: "",
    committeeMembers: [],
    committeeGuestMembers: [],
    committeeMeetings: [],
    selectedNoteRecords: [],
    createdBy: ""
  });

  const delay = 100;
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [userDepartment, setGetDepertment] = useState("");
  const [userDesignation, setUserDesignation] = useState("");
  const [convenerDepartment, setConvenerDepartment] = useState("")
  const [chairman, setChairman] = useState("");
  const [chairmanName, setChairmanName] = useState("");
  const [allOrgUsers, setAllOrgUsers] = useState([]);
  const isMobile = window.innerWidth <= 768;

  useEffect(() => {
    setIsLoading(true);
    getUserDepartment();
    // if ((isNewForm)) {
    // getDefaultConfigData();
    // }

  }, []);

  // Handle get user department
  const getUserDepartment = async () => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const obj = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetailsByPrincipalName(
          accounts[0].username
        )}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      }
      );
      const departmentDetails = await obj.json();
      setGetDepertment(departmentDetails[0].department);
      setUserDesignation(departmentDetails[0].jobTitle);
      getDefaultConfigData(departmentDetails[0].department);
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  };

  // Handle get default config data
  const getDefaultConfigData = async (userDepartment) => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);


      //Removed this function due to loading impact users will be filtered on search box enter - 22/03
      /*const orgUsers = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetails}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      }
      );
      const orgMembers = await orgUsers.json();
      const reConstructArr = orgMembers.map(x => {
        return { department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName }
      });

      setOrgEmployees(reConstructArr);
      setApproverEmailsObject(reConstructArr); */

      const dropdowns = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      }
      );
      const dropdownslist = await dropdowns.json();
      setEnumsObj(dropdownslist);
      // console.log(dropdownslist, "dropdown");



      /* const meetingsList = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_CommitteeMeetingList}`, {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ "CreatedBy": accounts[0].username }),
      }
      );
      const committeeMeetings = await meetingsList.json(); */
      const committeeNameList = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_CommitteeNamesList}`, {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ "Convener": accounts[0].username }),
      }
      );
      const configuredCommitteeNames = await committeeNameList.json();
      setCommitteeName(configuredCommitteeNames);

      /*    const reConstructArray = committeeMeetings.map((x) => {
           return {
             committeeName: x.committeeName === null ? "NA" : x.committeeName,
             noteNumber: x.noteNumber === null ? "NA" : x.noteNumber,
             departmentName: x.departmentName === null ? "NA" : x.departmentName,
             notePdfPath: x.notePdfPath === null ? "NA" : x.notePdfPath,
             noteId: x.noteId === null ? "NA" : x.noteId,
             userPrincipalName: x.userPrincipalName,
             notePdfBase64: x.notePdfBase64 === null ? null : x.notePdfBase64,
           };
         });
         setNoteRecords(orderBy(reConstructArray, [{ field: "noteNumber", dir: "asc" }]));
         setCommitteeMeetingsObject(reConstructArray); */

      if ((!isNewForm)) {
        fetchCommitteeMeetingdetails(dropdownslist);
      } else {
        setIsLoading(false);
      }

      // setCommitteMeetings(committeeMeetings)
      // console.log(committeeMeetings, "meetingslist")
    } catch (error) {
      console.error("Error fetching user details:", error);
      setIsLoading(false);
    }
  };

  // Handle get committee meeting details
  const fetchCommitteeMeetingdetails = async (enumObj) => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_CommitteeMeetingGeneralDetails}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify({ committeeMeetingId: noteId.id }),
        }
      );

      if (!response.ok) {
        // Handle error, for example set an error state
        console.error("Error fetching data:", response.statusText);
        return;
      }

      const data = await response.json();
      // console.log(data.strMeetingStatus, "strstatus")
      setState({
        ...data,
        meetingId: data.meetingNumber,
        committeeName: data.committeeName,
        meetingDate: new Date(),
        meetingSubject: data.meetingSubject,
        meetingMode: data.meetingMode === 1 ? "Teams" : data.meetingMode === 2 ? "WebEx" : null,
        meetingLink: data.meetingLink,
        // committeeMembersData: data.committeeMeetingMembersDTO,
        // committeeGuestMembersData: data.committeeMeetingGuestMembersDTO,
        // committeeMeetingsNotes: data.committeeMeetingNoteDTO,
        // committeeMeetingsComments:data.committeeMeetingMemberCommentsDTO,
        strMeetingStatus: data.strMeetingStatus,
        convener: data.convener,
        chairman: data.chairman,
        convenerDepartment: data.departmentName,
      });
      setIsMeetingPublished(data.meetingStatus === enumObj?.CommitteeMeetingStatus.find(x => x.dValue === "Published").id);
      setMeetingOver(data.meetingStatus < enumObj?.CommitteeMeetingStatus.find(x => x.dValue === "Meeting Over").id && data.createdBy === accounts[0].username);
      setIsReturned(data.meetingStatus === enumObj?.CommitteeMeetingStatus.find(x => x.dValue === "Returned").id && data.createdBy === accounts[0].username);
      setPublishMom(data.meetingStatus === enumObj?.CommitteeMeetingStatus.find(x => x.dValue === "Meeting Over").id && data.createdBy === accounts[0].username);
      setChairman(data.chairman);
      // 01/04 issue 
      setChairmanName(data.chairmanName)
      setConvenerDepartment(data.departmentName);
      setWorkflowLog(data.committeeMeetingWorkflowLogsDTO);
      setCommentsData(data.committeeMeetingMemberCommentsDTO);
      setCommiteeMembersData(data.committeeMeetingMembersDTO?.filter(obj => obj.memberEmail !== data.chairman));
      setCommiteeGuestMembersData(data.committeeMeetingGuestMembersDTO);
      setCommitteMeetingsNotes(data.committeeMeetingNoteDTO.map(note => { return { ...note, mom: note.mom === null ? "" : note.mom } }));

      // setCommiteeMembersData(data.committeeMeetingMembersDTO);
      // setCommiteeGuestMembersData(data.committeeMeetingGuestMembersDTO?.filter(obj=>obj.memberEmail !==data.chairman))
      // setCommiteeMembersData(data.committeeMeetingMembersDTO)
      // setCommiteeGuestMembersData(data.committeeMeetingGuestMembersDTO)
      // setCommitteeMeetingsComments(data.committeeMeetingsComments)
      // const fetchNoteApprover = data.noteApproversDTO?.filter((obj) => obj.approverType === 2);
      // setNoteApproverData(fetchNoteApprover);
      // setNoteReviewerData(
      //   data.noteApproversDTO?.filter((obj) => obj.approverType === 1)
      // );
      // getDefaultConfigData();

    } catch (error) {
      console.error("Error fetching data:", error.message);
    }
    setIsLoading(false);
  };

/*   // Delete Approvers from Approvers/Reviewers table
  const deletereviewer = (data) => {
    console.log(data, "data")
    if (data && data.approverType === 1) {
      const updatedData = committeeMembersData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      setCommiteeMembersData(updatedData)
    }
    if (data && data.approverType === 2) {
      const updatedData = committeeGuestMembersData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      setCommiteeGuestMembersData(updatedData)
    }
    //delete for commiteemeetingnotes added--12/04--RK
    if (data) {
      //helps to restore note records object
      setCommitteeMeetingsObject([...committeeMeetingsObject, committeeMeetingsNotes.find(x => x.noteId === data.noteId)]);
      setNoteRecords(orderBy([...committeeMeetingsObject, committeeMeetingsNotes.find(x => x.noteId === data.noteId)], [{ field: "noteNumber", dir: "asc" }]));
      const updatedData = committeeMeetingsNotes.filter(
        (row) => row.noteId !== data.noteId
      );
      updatedData.forEach((item, index) => {
        item.noteId = index + 1;
      });
      setCommitteMeetingsNotes(updatedData);
    }
  } */



  /* Data Handles */
  const handleCommitteeName = async (event) => {
    let committeemembers = []
    const selectedCommitteeName = event.target.value;
    setState((prevState) => ({ ...prevState, committeeName: event.target.value }));
    setCommitteeNameBorderColor("");
    setChairmanBorderColor("");
    setConvenerBorderColor("");

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    try {
      // const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const convenorResponse = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommitteeMeeting_GetChairmanConvenor}`, {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ "CommitteeName": selectedCommitteeName }),
      }
      );
      if (selectedCommitteeName) {
        setCommitteMeetingsNotes([]);
        setCommiteeGuestMembersData([]);
       
        const committeeId = committeeName.find(obj => obj.committeeName === selectedCommitteeName).committeeId;
        try {
          const defalutMembers = await fetch(
            `${API_BASE_URL}${API_ENDPOINTS.eCommittee_GetCommitteMembers}?CommitteeId=${committeeId}`, {
            method: "GET",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            // body: JSON.stringify({ "CommitteeName": selectedCommitteeName }),
          }
          )
          const mebmers = await defalutMembers.json();

          committeemembers = mebmers.map((obj, ind) => { return { ...obj, committeeMeetingMemberId: ind + 1, memberEmail: obj.approverEmail, memberEmailName: obj.approverEmailName } });
        }
        catch (error) {
          console.error("Error fetching convenor data:", error);
          // Handle errors
        }
        const convenorData = await convenorResponse.json();
        setConvenerDepartment(convenorData.convenerDepartment);
        setChairman(convenorData.chairman);
        setChairmanName(convenorData.chairmanName)
        setCommiteeMembersData(committeemembers?.filter(obj => obj.memberEmail !== convenorData.chairman));
        await getCommitteeNotesList(selectedCommitteeName,accessToken);

      }



      // Handle convenorData as needed, such as setting it in state
    } catch (error) {
      console.error("Error fetching convenor data:", error);
      // Handle errors
    }

  };
  
  // get committeenotealist 
  const getCommitteeNotesList=async (selectedCommitteeName,accessToken)=>{
    const meetingsList = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_CommitteeMeetingList}`, {
      method: "POST",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify({
        "CreatedBy": accounts[0].username,

        CommitteeName: selectedCommitteeName
      }),
    }
    );
    const committeeMeetings = await meetingsList.json();
    const reConstructArray = committeeMeetings.map((x) => {
      return {
        committeeName: x.committeeName === null ? "NA" : x.committeeName,
        noteNumber: x.noteNumber === null ? "NA" : x.noteNumber,
        departmentName: x.departmentName === null ? "NA" : x.departmentName,
        notePdfPath: x.notePdfPath === null ? "NA" : x.notePdfPath,
        noteId: x.noteId === null ? "NA" : x.noteId,
        userPrincipalName: x.userPrincipalName,
        // notePdfPath: x.notePdfPath === null ? null : x.notePdfPath,
      };
    });
    setNoteRecords(orderBy(reConstructArray, [{ field: "noteNumber", dir: "asc" }]));
    setCommitteeMeetingsObject(reConstructArray);

  }

  // Handle meeting date change 
  const handleOnChangeMeetingDate = (event) => {
    setState((prevState) => ({ ...prevState, meetingDate: event.target.value }));
    setMeetingDateBorderColor('');
  };
  const handleMeetingSubject = (event) => {
    setState((prevState) => ({ ...prevState, meetingSubject: event.target.value }));
    setMeetingSubjectBorderColor("");
  };
  const handleMeetingMode = (event) => {
    setState((prevState) => ({ ...prevState, meetingMode: event.target.value }));
    setMeetingModeBorderColor("");
  };
  const handleMeetingLink = (event) => {
    setState((prevState) => ({ ...prevState, meetingLink: event.target.value }));
    setMeetingLinkBorderColor("");
  };


  /* Form Validation */
  const validateForm = () => {
    const errors = {};
    if (!state.committeeName) {
      errors["committeeName"] = "Committee Name";
      setCommitteeNameBorderColor("#f31700");
    } else {
      setCommitteeNameBorderColor("");
    }
    if (!convenerDepartment) {
      errors["Convener"] = "Convenor Department";
      setConvenerBorderColor("#f31700");
    } else {
      setConvenerBorderColor("");

    }
    if (!chairman) {
      errors["Chairman"] = "Chairman";
      setChairmanBorderColor("#f31700");
    } else {
      setChairmanBorderColor("");

    }
    if (!state.meetingDate) {
      errors["MeetingDate"] = "Meeting Date";
      setMeetingDateBorderColor("#f31700");
    } else {
      setMeetingDateBorderColor("");
    }
    if (!state.meetingSubject.trim()) {
      errors["MeetingSubject"] = "Meeting Subject";
      setMeetingSubjectBorderColor("#f31700");
    } else {
      setMeetingSubjectBorderColor("");
    }
    if (!state.meetingMode) {
      errors["MeetingMode"] = "Meeting Mode";
      setMeetingModeBorderColor("#f31700");
    } else {
      setMeetingModeBorderColor("");
    }
    if (!state.meetingLink.trim()) {
      errors["MeetingLink"] = "Meeting Link";
      setMeetingLinkBorderColor("#f31700");
    } else {
      setMeetingLinkBorderColor("");
    }
    if (committeeMembersData.length === 0) {
      errors["committeeMeetingMembers"] = "Input Committee Meeting Members.";
      // setNotificationMsg("Please input CommitteeMeetingMembers");
    }
    if (committeeMeetingsNotes.length === 0) {
      errors["committeeMeetingNotes"] = "Input Committee Meeting Notes.";
      // setNotificationMsg("Please input CommitteeMeetingMembers");
    }
    // if (committeeGuestMembersData.length === 0) {
    //   errors["committeeGuestMembers"] = "Input CommitteeMeetingguestMembers."
    // }

    if (Object.keys(errors).length > 0) {
      setValidationErrors(true);
    }
    return errors;
  };

  // Handle confirm action
  const handleConfirmAction = () => {

    switch (selectedAction) {
      case 'Create':
        handleCreateMeeting();
        break;
      case 'Publish':
        handlePublishMeeting();
        break;
      case 'MeetingOver':
        handleMeetingOver();
        break;
      case 'PublishMeetingMiinutes':
        handlePublishMeetingMinutes();
        break;
      case 'ReturnBack':
        handleReturnBack();
        break;
      default:
        break;
    };
    setShowConfirmDailog(false);
  }

  // Handle create btn click
  const handleCreateBtnClick = () => {
    const errors = validateForm();
    setIsLoading(true);
    if (Object.keys(errors).length === 0) {
      setConfirmDailogObj({
        Confirmtext: "Are you sure you want to Create this meeting?",
        Description: "Please check the details filled and click on Confirm button to Create meeting.",
      });
      setSelectedAction("Create");
      setShowConfirmDailog(true);
    }
    else {
      let errorMessage = "<div style='font-weight: bold;padding-bottom:2%'>Please fill up all the mandatory fields</div>";


      Object.values(errors).forEach(error => {
        errorMessage += `<li style='padding-bottom:2%'>${error}</li>`;
      });

      errorMessage += "</ul>";

      // Update notification message with specific error details
      setShowNotification(true);
      setNotificationMsg(errorMessage);
    }

    // else {
    //   setShowNotification(true);
    //   setNotificationMsg("Please fill up all the mandatory fields");
    // }
    setIsLoading(false);
  }

  // Handle on click publish btn
  const handlePublishBtnClick = async () => {
    const errors = validateForm();
    setIsLoading(true);
    if (Object.keys(errors).length === 0) {
      setConfirmDailogObj({
        Confirmtext: "Are you sure you want to Publish this meeting?",
        Description: "Please check the details filled and click on Confirm button to Publish meeting.",
      });
      setSelectedAction("Publish");
      setShowConfirmDailog(true);
    }
    else {
      let errorMessage = "<div style='font-weight: bold;padding-bottom:2%'>Please fill up all the mandatory fields</div>";


      Object.values(errors).forEach(error => {
        errorMessage += `<li style='padding-bottom:2%'>${error}</li>`;
      });

      errorMessage += "</ul>";

      // Update notification message with specific error details
      setShowNotification(true);
      setNotificationMsg(errorMessage);
    }
    // else {
    //   setShowNotification(true);
    //   setNotificationMsg("Please fill up all the mandatory fields");
    // }
    setIsLoading(false);
  };

  // Handle on click meeting over btn 
  const handleMeetingOverBtnClick = () => {
    if (!isMeetingPublished) {
      setPublishMeetingValidationDialog(true)
    } else {
      setShowConfirmDailog(true);
      setConfirmDailogObj({
        Confirmtext: "Are you sure you want to submit meeting over?",
        Description: "Please check the details filled and click on Confirm button to submit meeting over.",
      });
      setSelectedAction("MeetingOver");
    }
  }

  // Handle on click publish mom btn 
  const handlePublishMOMbtnClick = () => {

    // const upNotes = committeeMeetingsNotes.map(x=> {return {...x,mom:x.mom===null?"":x.mom}});
    let isValid = committeeMeetingsNotes.some(note => note.mom === "");

    if (isValid) {
      setNotificationMsg(
        "MOM cannot be blank, Please add MOM for all the listed Notes."
      );
      setShowNotification(true);
    } else {
      setShowConfirmDailog(true);
      setConfirmDailogObj({
        Confirmtext: "Are you sure you want to Publish MOM?",
        Description:
          "Please check the details filled and click on Confirm button to Publish MOM.",
      });
      setSelectedAction("PublishMeetingMiinutes");
    }
  }

  // Handle on click return back
  const handleReturnBackBtnclick = () => {
    // const regex = /(<([^>]+)>)/gi;

    let isValid = committeeMeetingsNotes.some(note => note.mom === "");

    if (isValid) {
      setNotificationMsg(
        "MOM cannot be blank, Please add MOM for all the listed Notes."
      );
      setShowNotification(true);
    } else {
      setShowConfirmDailog(true);
      setConfirmDailogObj({
        Confirmtext: "Are you sure you want to Return back meeting?",
        Description:
          "Please check the details filled and click on Confirm button to Return back meeting.",
      });
      setSelectedAction("ReturnBack");
    }
  };

  /* Creates Meeting */
  const handleCreateMeeting = async () => {
    setIsLoading(true);
    /*const errors = validateForm();
    console.log(Object.keys(errors), "Form Validation");
    if (Object.keys(errors).length === 0) {*/
    // const meetingLinkHTML = `<a href="${state.meetingLink}" target="_blank">${state.meetingLink}</a>`
    /*const updatedCommitteeMembersData = committeeMembersData.map(x => ({
      ...x,
      approvalStatus: enumsObj.ATRStatusEnum.find(x => x.dValue === "Pending").id
    }));
    console.log(updatedCommitteeMembersData, "approvalstatus");*/
    try {
      const params =
      {
        // noteTo: noteto.find(x => (x.dValue === state.NoteTo)).id,
        // "meetingNumber": "CM-002",
        "committeeName": state.committeeName,
        "committeeId": enumsObj?.committeeName.find(x => x.dValue === state.committeeName).id,
        // "departmentId": 4,
        "meetingDate": state.meetingDate,
        "meetingSubject": state.meetingSubject,
        "departmentName": userDepartment,
        "meetingMode": enumsObj?.MeetingMode.find(x => x.dValue === state.meetingMode).id,
        "meetingLink": state.meetingLink,
        "meetingStatus": enumsObj.CommitteeMeetingStatus.find(x => x.dValue === "Created").id,
        "createdBy": accounts[0].username,
        "modifiedBy": accounts[0].username,
        // "approvalStatus": 1,
        "committeeMeetingMembersDTO": committeeMembersData,
        // "committeeMeetingMembersDTO": [...committeeMembersData],
        "committeeMeetingGuestMembersDTO": committeeGuestMembersData,
        "committeeMeetingNoteDTO": committeeMeetingsNotes
      }
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_CreateMeeting}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      );
      if (response.ok) {
        setSuccessmsg("Meeting has been created successfully!");
        setShowSuccessmsg(true);
      } else {
        setShowNotification(true);
        setNotificationMsg("Error Creating Meeting:", response.statusText);
      }
    } catch (error) {
      console.error("Error Creating Meeting:", error);
      setShowNotification(true);
      setNotificationMsg(error);
    }
    // } else {
    //   setShowNotification(true);
    //   setNotificationMsg("Please fill up all the mandatory fields");
    // }
    setIsLoading(false);
  };

  /* Publish Meeting */
  const handlePublishMeeting = async () => {
    setIsLoading(true);
    const errors = validateForm();
    if (Object.keys(errors).length === 0) {
      try {

        const params =
        {
          // noteTo: noteto.find(x => (x.dValue === state.NoteTo)).id,
          // "meetingNumber": "CM-002",
          // "committeeName": state.committeeName,
          // "departmentId": 4,

          "committeeMeetingId": isNewForm ? 0 : state.committeeMeetingId,
          "committeeId": enumsObj?.committeeName.find(x => x.dValue === state.committeeName).id,
          "meetingDate": state.meetingDate,
          "meetingSubject": state.meetingSubject,
          "departmentName": userDepartment,
          "meetingMode": enumsObj?.MeetingMode.find(x => x.dValue === state.meetingMode).id,
          "meetingLink": state.meetingLink,
          "meetingStatus": enumsObj.CommitteeMeetingStatus.find(x => x.dValue === "Published").id,
          "createdBy": accounts[0].username,
          "modifiedBy": accounts[0].username,
          "committeeMeetingMembersDTO": committeeMembersData,
          "committeeMeetingGuestMembersDTO": committeeGuestMembersData,
          "committeeMeetingNoteDTO": committeeMeetingsNotes
        }

        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

        const response = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eCommittee_PublishMeeting}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify(params),
          }
        );
        if (response.ok) {
          // setVisiblePublishMeeting(!visiblePublishMeeting);
          setSuccessmsg("Meeting has been published successfully!");
          setShowSuccessmsg(true);
        } else {
          setShowNotification(true);
          setNotificationMsg("Error Publishing Meeting:", response.statusText);
        }
      } catch (error) {
        console.error("Error Creating Meeting:", error);
        setShowNotification(true);
        setNotificationMsg(error);
      }
    } else {
      setShowNotification(true);
      setNotificationMsg("Please fill up all the mandatory fields.");
    }
    setIsLoading(false);
  };

  /* Meeting Over */
  const handleMeetingOver = async () => {
    setIsLoading(true);
    try {
      const params =
      {

        "CommitteeMeetingId": state.committeeMeetingId,
        "CreatedBy": accounts[0].username,
        "committeeName": state.committeeName,
        "MeetingStatus": enumsObj.CommitteeMeetingStatus.find(x => x.dValue === "Meeting Over").id,
        "strMeetingDate": new DateObject(new Date(state.meetingDate)).format('DD/MM/YYYY'),
        "meetingSubject": state.meetingSubject,
        "meetingMode": enumsObj?.MeetingMode.find(x => x.dValue === state.meetingMode).id,
        "meetingLink": state.meetingLink,
        "committeeMeetingMembersDTO": committeeMembersData,
        "committeeMeetingNoteDTO": committeeMeetingsNotes
      };
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_MeetingOver}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      ).then(response => {
        return response.json();
      }).then(data => {
        setSuccessmsg("Meeting over has been submitted successfully!");
        setShowSuccessmsg(true);
      }).catch(err => {
        setShowNotification(true);
        setNotificationMsg("Error while meeting over", err.toString());
      })
    }
    catch (error) {
      // console.error("Error in MeetingOver:", error);
      setShowNotification(true);
      setNotificationMsg("Error while meeting over", error.toString());
    }
    setIsLoading(false);
  }

  /* Publish Meeting Minutes */
  const handlePublishMeetingMinutes = async () => {
    setIsLoading(true);

    try {
      const params =
      {
        "CommitteeMeetingId": state.committeeMeetingId,
        "CreatedBy": state.createdBy,
        "CommitteeMeetingNoteDTO": [...committeeMeetingsNotes]
      }
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_PublishMOM}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      );
      if (response.ok) {
        setSuccessmsg("Meeting minutes has been published successfully!");
        setShowSuccessmsg(true);
      }
    }
    catch (error) {
      console.error("Error in Meeting Over:", error);
      setShowNotification(true);
      setNotificationMsg("Error in Publishing meeting Minutes:", error);
    }
    setIsLoading(false);
  }

  /*  Return Back */
  const handleReturnBack = async () => {
    setIsLoading(true);
    try {

      /*const updatedCommitteeMembersData = committeeMembersData.map(x => ({
        ...x,
        approvalStatus: enumsObj.CommitteeMeetingStatus.find(x => x.dValue === "Pending Approval").id, strApprovalStatus:"Pending Approval"
      }));*/
      // console.log(updatedCommitteeMembersData, "approvalstatus");

      const params = {
        // "CommitteeMeetingMemberId": committeeMembersData.find(x => x.memberEmail === accounts[0].username).committeeMeetingMemberId,
        "CommitteeMeetingId": state.committeeMeetingId,
        "CreatedBy": accounts[0].username,
        "MeetingStatus": enumsObj.CommitteeMeetingStatus.find(x => x.dValue === "Pending Approval").id,
        // "CommitteeMeetingMemberCommentsDTO": commentsData,
        "CommitteeMeetingNoteDTO": committeeMeetingsNotes,
        // "committeeMeetingMembersDTO": updatedCommitteeMembersData,
      };

      // console.log(JSON.stringify(params), "Returned Back");

      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_MeetingOver}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      ).then(response => {
        return response.json();
      }).then(data => {
        // console.log(data);
        setSuccessmsg("Return back has been successful!");
        setShowSuccessmsg(true);
      })

      setIsLoading(false);
    }
    catch (error) {
      // console.error("Error in MeetingOver:", error);
      setShowNotification(true);
      setNotificationMsg("Error in Return back:", error);
    }
  }

  /* Add CommitteeMembers and CommitteeGuestMembers Data */
  const [data] = useState([]);
  const [selectedRowId, setSelectedRowId] = useState(null);

//  Handle delete function
  const handleDelete = async (selectedMember) => {
    const updatedData = committeeMembersData.filter(
      (row) => row.committeeMeetingMemberId !== selectedMember.committeeMeetingMemberId
    );
    // updatedData.forEach((item, index) => {
    //   item.approverOrder = index + 1;
    // });
    setCommiteeMembersData(updatedData);
  };

  // Handle delete committe guest
  const handleDeleteCommitteeGuest = async (selectedMember) => {
    const updatedData = committeeGuestMembersData.filter(
      (row) => row.committeeMeetingMemberId !== selectedMember.committeeMeetingMemberId
    );
    // updatedData.forEach((item, index) => {
    //   item.approverOrder = index + 1;
    // });
    setCommiteeGuestMembersData(updatedData);
    // if (selectedRowId1 === approverOrder) {
    //   setSelectedRowId1(null);
    // }
  };

  // Handle  delete committee notes
  const handleDeleteCommitteeNotes = async (noteId) => {

    //helps to restore note records object
    setCommitteeMeetingsObject([...committeeMeetingsObject, committeeMeetingsNotes.find(x => x.noteId === noteId.noteId)]);
    setNoteRecords(orderBy([...committeeMeetingsObject, committeeMeetingsNotes.find(x => x.noteId === noteId.noteId)], [{ field: "noteNumber", dir: "asc" }]));

    const updatedData = committeeMeetingsNotes.filter(
      (row) => row.noteId !== noteId.noteId
    );
    updatedData.forEach((item, index) => {
      item.approverOrder = index + 1;
    });
    setCommitteMeetingsNotes(updatedData);
    // if (selectedRowId === approverOrder) {
    //   setSelectedRowId(null);
    // }
  };

  // Handle edit committee notes
  const handleEditCommitteeNotes = async (index) => {
    // Find the row with the given approverOrder and set its MOM data
    const selectedRow = committeeMeetingsNotes[index];
    // console.log(selectedRow, "rrr")
    if (selectedRow) {
      setSelectedRowId(index);
      // Get MOM data for the selected row from the selectedRow object
      const rowMomData = selectedRow.mom || ''; // Assuming 'mom' is the field name for MOM data
      setInnerValue(rowMomData);
      setMomData(rowMomData);
      setMomVisible(true);
      setState((prevState) => ({
        ...prevState,
        draftResolution: rowMomData,
      }));
    }

  };

  //Handle editor value change 
  const changeEditorValue = async (e) => {
    const view = editor.current.view;
    setInnerValue(EditorUtils.getHtml(view.state));
    // if (contentWithoutPTags !== '') {
    setState(prevState => ({
      ...prevState,
      draftResolution: EditorUtils.getHtml(view.state),
    }));

  };

  // Handle add mom
  const handleAddMom = () => {
    // console.log(state.draftResolution, "draftmom")
    const htmlContent = state.draftResolution
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');
    const contentWithoutPTags = doc.body.textContent.trim();
    // if(contentWithoutPTags ===""){

    // }else{
    if (selectedRowId !== null) {
      const updatedMeetingsNotes = [...committeeMeetingsNotes];
      updatedMeetingsNotes[selectedRowId] = {
        ...updatedMeetingsNotes[selectedRowId],
        // mom: momData.toString()
        mom: contentWithoutPTags !== "" ? state.draftResolution : ""
      };
      // console.log("Updated Meetings Notes:", updatedMeetingsNotes);
      setCommitteMeetingsNotes(updatedMeetingsNotes);
      setMomVisible(false);
    }
    // }
  };

  //Handle close mom dialog
  const handleCloseMom = async () => {
    setMomVisible(false)
  }

  // Handle change member
  const handleComboChangeMember = (event) => {
    setSelectedReviewer(event.value);
  };

  // Handle change guest member
  const handleComboChangeApprover = (event) => {
    setcommitteeGuestMember(event.value);
  };

  //Handle note records change
  const handleComboChangeNoteRecords = (event) => {
    setSelectedCommitteeNote(event.value);
  };

  // Handle open committee member dropdown options
  const handleOpenCommitteeMember = () => {
    if (!selectedCommitteeMember) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectedCommitteeMember.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  // Handle open committee guest member options
  const handleOpenGuestMember = () => {
    if (!committeeGuestMember) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(committeeGuestMember.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  // Handle open committee notes 
  const handleOpencommittenote = () => {
    if (!selectedCommitteeNote) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectedCommitteeNote.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  // Handle add  member in row
  const handleAddRow = async () => {
    if (!selectedCommitteeMember) {
      setShowNotification(true);
      setNotificationMsg("Please select Member then click on Add.");
      return;
    }
    if (!state.committeeName) {
      setShowNotification(true);
      setNotificationMsg("Please select committee name to Add committee members.");
      return;
    }


    //Removed this function due to loading impact users will be filtered on search box enter - 22/03
    // setOrgEmployees(approveremailsObject);

    const isMemberValid =
      committeeMembersData.find((x) => x.memberEmail === selectedCommitteeMember.userPrincipalName) ===
      undefined;
    const isGuestValid =
      committeeGuestMembersData.find((x) => x.memberEmail === selectedCommitteeMember.userPrincipalName) ===
      undefined;
    // const isChairmanExists = committeeMembersData.some((x) => x.isChairman === true);
    // const isChairmanExists = committeeMembersData.some((x) => x.isChairman === true &&selectedCommitteeMember.userPrincipalName ===x.memberEmail);
    // console.log(isChairmanExists,"chairman")

    if (selectedCommitteeMember.userPrincipalName !== chairman && isMemberValid && isGuestValid && selectedCommitteeMember.userPrincipalName !== accounts[0].username && selectedCommitteeMember.userPrincipalName !== state.createdBy) {
      const newRow = {
        // id: notereviewerData.length + 1,
        meetingId: 1,
        approverType: 1,
        memberEmail: selectedCommitteeMember.userPrincipalName,
        memberEmailName: selectedCommitteeMember.displayName,
        committeeMeetingMemberId: committeeMembersData.length + 1,
        approverStatus: 1,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
        // Bug - 294 - 27/03
        srNo: selectedCommitteeMember.srNo,
        designation: selectedCommitteeMember.jobTitle,
        // approverOrder: notereviewerData.length + 1,
        // selectedComboValue: combovalue,
      };
      // console.log(newRow);
      // setNoteReviewerData([...notereviewerData, newRow]);
      setCommiteeMembersData((prevData) => [...prevData, newRow]);
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected member cannont be same as existing Member/Convenor/Chairman."
      );
    }
    setSelectedReviewer(null);
    setOrgEmployees([]);
  };

  //  Handle add guest member in row 
  const handleAddRowGuest = async () => {
    if (!committeeGuestMember) {
      setShowNotification(true);
      setNotificationMsg("Please select Guest member then click on Add.");
      return;
    }
    if (!state.committeeName) {
      setShowNotification(true);
      setNotificationMsg("Please select committee name to Add committee members.");
      return;
    }

    //Removed this function due to loading impact users will be filtered on search box enter - 22/03
    // setOrgEmployees(approveremailsObject);

    const isGstMemberValid =
      committeeMembersData.find((x) => x.memberEmail === committeeGuestMember.userPrincipalName) ===
      undefined;
    const isGstGuestValid =
      committeeGuestMembersData.find((x) => x.memberEmail === committeeGuestMember.userPrincipalName) ===
      undefined;
    // let isChairman = committeeMembersData.find((x) => x.isChairman === false)

    /*const isMemberInCommittee = committeeMembersData.some(
      (member) => member.memberEmail === committeeGuestMember
    );*/

    /*if (isMemberInCommittee) {
      setShowNotification(true);
      setNotificationMsg("The selected member already exists in the committee.");
      return;
    }*/
    if (committeeGuestMember.userPrincipalName !== chairman && isGstMemberValid && isGstGuestValid && committeeGuestMember.userPrincipalName !== accounts[0].username && committeeGuestMember.userPrincipalName !== state.createdBy) {
      // let isApproverValid = true;

      const newRow = {
        meetingId: 1,
        approverType: 2,
        memberEmail: committeeGuestMember.userPrincipalName,
        memberEmailName: committeeGuestMember.displayName,
        srNo: committeeGuestMember.srNo,
        designation: committeeGuestMember.jobTitle,
        committeeMeetingMemberId: committeeGuestMembersData.length + 1,
        approverStatus: 1,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
        // approverOrder: noteapproverData.length + 1,
        // selectedComboValue: committeeGuestMember,
      };
      // setNoteApproverData([...noteapproverData, newRow]);
      setCommiteeGuestMembersData((prevData) => [...prevData, newRow]);
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected member cannont be same as existing Member/Convenor/Chairman."
      );
    }
    setcommitteeGuestMember(null);
    setOrgEmployees([]);
  };

  const [noteRecords, setNoteRecords] = React.useState();

  //Handle add note recoards row 
  const handleAddRowNoteRecords = async () => {
    if (!selectedCommitteeNote) {
      setShowNotification(true);
      setNotificationMsg("Please select Note then click on Add.");
      return;
    }

    // if (committeeMeetingsNotes.some(x=>selectedCommitteeNote.noteId === x.noteId)) {
    //   setShowNotification(true);
    //   setNotificationMsg("This note is selected already. Please select another Note.");
    //   return;
    // }
    setNoteRecords(orderBy(committeeMeetingsObject.filter(x => x.noteId !== selectedCommitteeNote.noteId), [{ field: "noteNumber", dir: "asc" }]));
    setCommitteeMeetingsObject(committeeMeetingsObject.filter(x => x.noteId !== selectedCommitteeNote.noteId));
    // if (selectedCommitteeNote) {
    //   const selectedMeeting = committeeMeetings.find(meeting => meeting.noteNumber === selectedCommitteeNote);
    //   console.log(selectedMeeting, "ttt")
    // console.log(selectedCommitteeNote, "selectedCommitteeNote")
    if (selectedCommitteeNote) {
      const newRow = {
        noteId: selectedCommitteeNote.noteId,
        mom: "",
        noteNumber: selectedCommitteeNote.noteNumber,
        committeeName: selectedCommitteeNote.committeeName,
        departmentName: selectedCommitteeNote.departmentName,
        notePdfPath: selectedCommitteeNote.notePdfPath,
        approverOrder: committeeMeetingsNotes.length + 1,
        // notePdfBase64:onChangegetpdflink(selectedCommitteeNote.notePdfPath,selectedCommitteeNote.notePdfBase64)
        // notePdfBase64: selectedCommitteeNote.notePdfBase64 || null
      };
      // setCommitteMeetingsNotes([...committeeMeetingsNotes,newRow])
      setCommitteMeetingsNotes((prevData) => [...prevData, newRow]);

      // }
    }
    //  else {
    //   setShowNotification(true);
    //   setNotificationMsg(
    //     "The selected member cannont be same as existing Member."
    //   );
    // }
    setSelectedCommitteeNote(null);
    setOrgEmployees([]);
  };
  const [loading, setLoading] = React.useState(false);
  const timeout = React.useRef();
  const [orgEmployees, setOrgEmployees] = React.useState(approverEmailsList);

  //Helps to filter the people picker dropdown vaules
  const pplFilterMultiColumn = async (event) => {
    //Added  ----------------- 22/03 --------------------
    if (event.filter.value.length >= 4) {
      // const accessToken = await getAccessToken({...loginRequest,loginHint: accounts[0].username});
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            return { ...x, department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName, srNo: x.srNo === null ? "NA" : x.srNo }
          });
          setOrgEmployees(orgUsers);
          setAllOrgUsers(orgUsers)
        })
        .catch((err) => {
          setOrgEmployees([]);
          console.log(err);
        });
    }
    else {
      setOrgEmployees([]);
    }

    //Added  ----------------- 22/03 --------------------
  }

  //Helps to filter the people picker dropdown vaules
  const noteDataFilterMultiColumn = (event) => {
    let enteredVal = event.filter.value;
    const filteredObj = committeeMeetingsObject.filter((x, i) => {
      return (
        x["committeeName"].toLowerCase().includes(enteredVal.toLowerCase()) ||
        x["noteNumber"].toLowerCase().includes(enteredVal.toLowerCase()) ||
        x["departmentName"].toLowerCase().includes(enteredVal.toLowerCase())
      );
    });
    setNoteRecords(orderBy(filteredObj, [{ field: "noteNumber", dir: "asc" }]));
  }

  const currentDate = new Date();
  const month = (currentDate.getMonth() + 1).toString().padStart(2, "0");
  const day = currentDate.getDate().toString().padStart(2, "0");
  const year = currentDate.getFullYear().toString();
  const formattedDate = `${day}-${month}-${year}`;
  /* To Add Comments */
  /* const handleComments = (e) => {
    setCommentText(e.target.value)
  };
  const handelAddCmts = () => {
    const newComment = {
      Comments: commentText,
      CommentedBy: state.convener,

    };
    // console.log(newComment, "com")
    setCommentsData([...commentsData, newComment]);
    // setCommentText('');
  } */

//handle download pdf file 
  const downloadBase64PDFFile = async (path) => {
    // console.log(path, "path");
        let pdfLink = ""
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const parmas = {
      supportingDocumentPath: path
    }
    const notePDFINfo = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)

      }
    );
    const pdfDetails = await notePDFINfo?.text();
    if (pdfDetails !== "File Not Available!") {
      // console.log(pdfDetails);
      const byteCharacters = atob(pdfDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      // Commented for pdf open new file --> Kavya (06-08)
      // pdfLink = window.URL.createObjectURL(blob)
      // window.open(window.URL.createObjectURL(blob))
      // setPdfLink(window.URL.createObjectURL(blob))
      const url = URL.createObjectURL(blob);
  
      // Create a link element
      const link = document.createElement('a');
      link.href = url;
      link.download = path; // specify the filename
      document.body.appendChild(link);
      link.click();
  
      // Clean up
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
    console.log(pdfLink,"pdfLink");
    // return pdfLink;
  }

  // // cret
  // const onChangegetpdflink = (path, base64Data) => {
  //   let pdfLink = ""
  //   if (path !== null && base64Data !== null) {
  //     const byteCharacters = atob(base64Data);
  //     const byteNumbers = new Array(byteCharacters.length);
  //     for (let i = 0; i < byteCharacters.length; i++) {
  //       byteNumbers[i] = byteCharacters.charCodeAt(i);
  //     }
  //     const byteArray = new Uint8Array(byteNumbers);
  //     // Create a Blob object
  //     const blob = new Blob([byteArray], { type: `application/pdf` });
  //     pdfLink = window.URL.createObjectURL(blob)
  //   }
  //   return pdfLink;
  // }
  return (
    <div>
      <Navbar header="IB Smart Office - eCommittee" />
      <Sidebar />
      <div className="FormMaincontainer">
        <div className="container">
       
          <div className="HeaderButtonsContainer row">
            {isNewForm ? (
              <div className="col-md-4"></div>
            ) : (
              <div className="col-md-4 formHeaderTilesStatus mobileTitleNewForm">
                {isNewForm ? "New" : `Status: ${state.strMeetingStatus}`}
              </div>
            )}
            <div className="col-md-4 formHeaderTilesTitle mobileTitleNewForm">
              eCommittee Meeting - {isNewForm ? "New" : state.meetingId}
            </div>
            <div className="col-md-4 formHeaderTilesDate mobileTitleNewForm">
              {isNewForm ? (
                <>
                  {" "}
                  Date: {new DateObject(new Date()).format("DD-MMM-YYYY")}{" "}
                  <Clock format={"hh:mm:ss A"} ticking={true} />
                </>
              ) : (
                <>
                  {` Created: ${new DateObject(state.createdDate).format(
                    "DD-MMM-YYYY hh:mm A"
                  )}`}
                </>
              )}
            </div>
            {/* <div>{currentTime.toLocaleTimeString('en', { hour: 'numeric', hour12: true, minute: 'numeric' })}</div> */}
          </div>
          {/* <div className="FormHead">eNote Committee Meetings {isNewForm ? "New" : "View"} Form</div> */}
        </div>

        <div className="container">
          {(isNewForm || meetingOver) && <div className="errorMsg">All fields marked "*" are mandatory</div>}
          <div className="SectionHeads row">General Section</div>
          <Form
            render={() => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Meeting ID:
                            {/* <span className="required-asterisk">*</span> */}
                          </Label>

                          <Field
                            component={Input}
                            name="MeetingId"
                            defaultValue={state.meetingId}
                            key={state.meetingId}
                            className="input-field-readonly"
                            readOnly={true}
                          />
                        </div>
                        <div className="errorMsg">{departmentError}</div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Committee Name :
                            {isNewForm && <span className="required-asterisk">*</span>}
                          </Label>
                          {isNewForm && (
                            <DropDownList
                              data={committeeName.map((x) => x.committeeName)}
                              // defaultItem={"Select"}
                              onChange={handleCommitteeName}
                              value={state.committeeName}
                              name="CommitteeName"
                              // readOnly={!isNewForm}
                              // required={true}
                              style={{ borderColor: committeeNameBorderColor }}
                              valueRender={element => valueRender(element, state.committeeName, 'committeeName')}
                            />
                          )}
                          {!isNewForm && <Field
                            component={Input}
                            name="committeeName"
                            // value={state.committeeName}
                            defaultValue={state.committeeName}
                            key={state.committeeName}
                            className="input-field-readonly"
                            readOnly={true}
                          />}
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Convenor Department :
                            {/* <span className="required-asterisk">*</span> */}
                          </Label>
                          <Field
                            component={Input}
                            name="ConvenorDept"
                            defaultValue={convenerDepartment}
                            key={convenerDepartment}
                            className="input-field-readonly"
                            readOnly={true}
                            style={{ borderColor: convenerBorderColor }}
                          />
                          {/* {!isNewForm && <div>{state.convenerDepartment}</div>} */}
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Chairman:
                            {/* <span className="required-asterisk">*</span> */}
                          </Label>
                          <Field
                            component={Input}
                            name="chairman"
                            // 01/04
                            defaultValue={chairmanName}
                            key={chairmanName}
                            className="input-field-readonly"
                            readOnly={true}
                            style={{ borderColor: chairmanBorderColor }}
                          />
                          {/* {!isNewForm && <div>{state.chairman}</div>} */}
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Meeting Date :
                            {(isNewForm || meetingOver) && <span className="required-asterisk">*</span>}
                          </Label>
                          {(isNewForm || meetingOver) && <DatePicker
                            format={"dd-MM-yyyy"}
                            placeholder="Choose a date..."
                            onChange={handleOnChangeMeetingDate}
                            min={new Date()}
                            value={state.meetingDate}
                            // defaultValue={new Date(state.meetingDate)}
                            style={{ borderColor: meetingDateBorderColor }}
                          // value={new DateObject(state.meetingDate).format("DD-MM-YYYY")}
                          // readOnly
                          />}
                          {!(isNewForm || meetingOver) && <Field
                            component={Input}
                            name="meetingDate"
                            defaultValue={new DateObject(new Date(state.meetingDate)).format("DD-MM-YYYY")}
                            key={new DateObject(new Date(state.meetingDate)).format("DD-MM-YYYY")}
                            className="input-field-readonly"
                            readOnly={true}
                          />}
                        </div>

                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Meeting Subject :
                            {(isNewForm || meetingOver) && <span className="required-asterisk">*</span>}
                          </Label>
                          {(isNewForm || meetingOver) && (
                            <TextArea
                              maxLength={max}
                              onChange={handleMeetingSubject}
                              value={state.meetingSubject}
                              rows={1}
                              style={{ borderColor: meetingSubjectBorderColor }}
                            />
                          )}
                          {!(isNewForm || meetingOver) && <Field
                            component={Input}
                            name="meetingSub"
                            defaultValue={state.meetingSubject}
                            key={state.meetingSubject}
                            className="input-field-readonly"
                            readOnly={true}
                          />}
                        </div>

                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Meeting Mode :
                            {(isNewForm || meetingOver) && <span className="required-asterisk">*</span>}
                          </Label>
                          {(isNewForm || meetingOver) && (
                            <DropDownList
                              data={enumsObj?.MeetingMode.map(x => x.dValue)}
                              value={state.meetingMode}
                              // defaultItem={"Select"}
                              onChange={handleMeetingMode}
                              style={{ borderColor: meetingModeBorderColor }}
                              valueRender={element => valueRender(element, state.meetingMode, 'meetingMode')}
                            />
                          )}
                          {!(isNewForm || meetingOver) && <Field
                            component={Input}
                            name="meetingMode"
                            value={state.meetingMode}
                            defaultValue={state.meetingMode}
                            key={state.meetingMode}
                            className="input-field-readonly"
                            readOnly={true}
                          />}
                        </div>

                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Meeting Link :
                            {(isNewForm || meetingOver) && <span className="required-asterisk">*</span>}
                          </Label>
                          {(isNewForm || meetingOver) && (
                            <TextArea
                              onChange={handleMeetingLink}
                              value={state.meetingLink}
                              rows={1}
                              style={{ borderColor: meetingLinkBorderColor }}
                            />
                          )}
                          {!(isNewForm || meetingOver) && <Link to={state.meetingLink}>{state.meetingLink}</Link>}
                        </div>

                      </FieldWrapper>
                    </div>
                  </div>

                  <div className="SectionHeads row">Committee Members</div>
                  <div className="SectionRow row">
                    {(isNewForm || meetingOver) && (
                      <div>
                        <div
                  
                          className="_committeeMemberContainer"
                        >

                          <MultiColumnComboBox
                            data={orgEmployees}
                            filterable={true}
                            columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                            // columns={orgUsersPplPickerColumnMapping}
                            // value={selectedCommitteeMember}
                            // textField={"displayName"}
                            value={
                              selectedCommitteeMember === null
                                ? null
                                : selectedCommitteeMember.displayName
                            }
                            // itemRender={orgUsersPplPickerItemRender}
                            onFilterChange={pplFilterMultiColumn}
                            onChange={handleComboChangeMember}
                            onOpen={handleOpenCommitteeMember}
                            style={{
                              width: "300px",
                              marginRight: "5px",
                            }}
                            placeholder="Add Member..."
                          />
                          <Button onClick={handleAddRow}>
                            <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn arrow-color"></span>
                            Add
                          </Button>
                        </div>
                        {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                        <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                      </div>
                    )}
                    <div className="cstDisableGridScroll">
                      {/* added scroll class 24/04 */}
                      <TableDraggableRows
                        //Change - Adding SR No - 05/04 - RK 
                        srCol="SR No"
                        // Change - Adding Designation- 05/04 - RK 
                        designationCol="Designation"
                        typeOfTable="Members"
                        data={committeeMembersData}
                        onDelate={handleDelete}
                        field="memberEmailName"
                        formType="committeemeeting" />
                    </div>


                    {(isNewForm || meetingOver) && <div
                 className="_meetingOverDiv"
                    >

                    </div>}
                  </div>
                  <div className="SectionHeads row">
                    Committee Guest Members
                  </div>
                  <div className="SectionRow row">
                    {(isNewForm || meetingOver) && (
                      <div>
                        <div
                       className="_committeeMemberContainer"
                        >

                          <MultiColumnComboBox
                            data={orgEmployees}
                            filterable={true}
                            // columns={orgUsersPplPickerColumnMapping}
                            columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                            // textField={"displayName"}
                            value={
                              committeeGuestMember === null
                                ? null
                                : committeeGuestMember.displayName
                            }
                            // itemRender={orgUsersPplPickerItemRender}
                            onFilterChange={pplFilterMultiColumn}
                            onChange={handleComboChangeApprover}
                            onOpen={handleOpenGuestMember}
                            style={{ width: isMobile ? "100%" : "300px",marginRight: "5px", }} // Adjust width
                            placeholder="Add Member..."
                          />
                          <Button onClick={handleAddRowGuest}>
                            <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn arrow-color"></span>
                            Add
                          </Button>
                        </div>

                        {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                        <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                      </div>
                    )}
                    <div className="cstDisableGridScroll">
                      {/* added scroll class 24/04 */}
                      <TableDraggableRows
                        //Change - Adding SR No - 05/04 - RK 
                        srCol="SR No"
                        // Change - Adding Designation- 05/04 - RK 
                        designationCol="Designation"
                        typeOfTable="Guest Members"
                        data={committeeGuestMembersData}
                        onDelate={handleDeleteCommitteeGuest}
                        field="memberEmailName"
                        formType="committeemeeting" />
                    </div>


                    {(isNewForm || meetingOver) && <div
                className="_meetingOverDiv"
                    >

                    </div>}

                  </div>
                  <div className="SectionHeads row">Committee Note Records</div>
                  <div className="SectionRow row">
                    {(isNewForm || meetingOver) && (
                      <div
                 className="_committeeMemberContainer"
                      >
                        <MultiColumnComboBox
                          data={noteRecords}
                          filterable={true}
                          columns={isMobile ? mobileNoteRecordsPickerColumnMapping : noteRecordsPickerColumnMapping}
                          // columns={noteRecordsPickerColumnMapping}
                          // textField={"displayName"}
                          value={
                            selectedCommitteeNote === null
                              ? null
                              : selectedCommitteeNote.noteNumber
                          }
                          // itemRender={orgUsersPplPickerItemRender}
                          onFilterChange={noteDataFilterMultiColumn}
                          onChange={handleComboChangeNoteRecords}
                          onOpen={handleOpencommittenote}
                          style={{ width: isMobile ? "100%" : "300px",marginRight: "5px", }} // Adjust width
                          placeholder="Add Note Record..."
                        />
                        <Button onClick={handleAddRowNoteRecords}>
                          <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn arrow-color"></span>
                          Add
                        </Button>
                      </div>
                    )}
                    {/* added scroll class 24/04 */}
                    <div className="cstDisableGridScroll">
                      <TableDraggableRows
                        typeOfTable="Note Title"
                        typeOfTable1="Committee Name"
                        Department="Department"
                        NoteLink="Note Link"
                        data={committeeMeetingsNotes}
                        onDelate={handleDeleteCommitteeNotes}
                        getpdflink={downloadBase64PDFFile}
                        
                        onedit={handleEditCommitteeNotes}
                        field="noteNumber"
                        committeefield="committeeName"
                        Departmentfield="departmentName"
                        NoteLinkfield="notePdfPath"
                        formType="committeemeetingnotes"
                        isNewForm={isNewForm}
                        meetingOver={meetingOver}
                        isReturned={isReturned} />
                    </div>
                  </div>
                  {/* {!isNewForm && isReturned && (
                    <>
                      <div className="SectionHeads row">Comments</div>
                      <div className="SectionRow row">
                        <table
                          style={{ width: "100%" }}
                          className="tableStyle"
                        >
                          <thead>
                            <tr>
                              <th>Comments</th>
                              <th>Commented By</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                <div>
                                  <textarea
                                  className="committeeMeetingTblCommnetsfld"
                                    name="Comments"
                                    // className="general-comments-Comments"
                                    row={1}
                                    value={commentsData.Comments}
                                    onChange={handleComments}
                                  ></textarea>
                                </div>
                              </td>
                              <td>{state.convener}</td>
                              <td>
                                <Button
                                  className="formBtnColor"
                                  onClick={handelAddCmts}
                                >
                                  <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                  Add comments
                                </Button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </>
                  )} */}
                  {!isNewForm && (
                    <>
                      <div className="SectionHeads row">Comments</div>
                      <div className="SectionRow row">
                        <table className="tableStyle" style={{ width: "100%" }}>
                          <thead>
                            <tr>
                              <th>Comments</th>
                              <th>Commented By</th>
                            </tr>
                          </thead>
                          <tbody>
                            {commentsData.map((comment, index) => (
                              <tr key={index}>
                                <td>{comment.comments}</td>
                                <td>{comment.memberEmailName}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}

                  {!isNewForm && (
                    <div>
                      <div className="SectionHeads eNoteAtrFormHdr row">
                        Workflow Log
                      </div>
                      <div className="SectionRow row">
                        <table className="SectionRow cstATRFormTbl tableStyle" style={{ width: "100%" }}>
                          <tr>
                            <th>Action</th>
                            <th>Action By</th>
                            <th>Action Date</th>
                          </tr>
                          {workflowLog?.map((obj, ind) => (
                            <tr key={ind}>
                              <td>{obj.action}</td>
                              <td>{obj.actionByName}</td>
                              <td>
                                {new DateObject(new Date(obj.createdDate)).format(
                                  "DD-MMM-YYYY hh:mm A"
                                )}
                              </td>
                            </tr>
                          ))}
                        </table>
                      </div>
                    </div>
                  )}
                </fieldset>
                <div className="FormButtonsContainer k-form-buttons">
                  {isNewForm && (
                    <Button
                      type={"button"}
                      onClick={handleCreateBtnClick}
                      className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                    >
                      <span className="k-icon k-font-icon k-i-track-changes cursor allIconsforPrimary-btn"></span>
                      Create Meeting
                    </Button>
                  )}
                  {(isNewForm || meetingOver) && (
                    <Button
                      onClick={() => handlePublishBtnClick()}
                      type={"submit"}
                      className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                    >
                      <span className="k-icon-sm k-font-icon k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>
                      Publish Meeting
                    </Button>
                  )}
                  {!isNewForm &&
                    meetingOver && (
                      <Button
                        onClick={handleMeetingOverBtnClick}
                        type={"submit"}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon-sm k-font-icon k-i-track-changes-enable cursor allIconsforPrimary-btn"></span>
                        Meeting Over
                      </Button>
                    )}
                  {!isNewForm && publishMom && (
                    // state.strMeetingStatus==="Meeting Over" &&
                    <Button
                      onClick={handlePublishMOMbtnClick}
                      type={"submit"}
                      className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                    >
                      <span className="k-icon-sm k-font-icon k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>
                      Publish Meeting Minutes
                    </Button>
                  )}
                  {!isNewForm && isReturned
                    // state.strMeetingStatus === "Published" &&
                    && (
                      <Button
                        onClick={handleReturnBackBtnclick}
                        type={"submit"}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon-sm k-font-icon k-i-undo cursor allIconsforPrimary-btn"></span>
                        Return Back
                      </Button>
                    )}

                  <Button
                    type={"submit"}
                    className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                    onClick={() => navigate(redirectTo)}
                  >
                    <span className="k-icon-sm k-font-icon k-i-x-circle cursor allIconsforPrimary-btn"></span>
                    Exit
                  </Button>
                </div>
                {isLoading && <PageLoader />}
                {publishMeetingValidationDialog && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setPublishMeetingValidationDialog(false)}
                  >
                    <p  className="dialogcontent_"
               
                    >

                      Please publish the meeting to record meeting over.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => setPublishMeetingValidationDialog(false)}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>

                )}
                {/* {visibleCreateMeeting && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleSaveClose}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      eCommittee Meeting Created successfully.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => navigate(redirectTo)}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visiblePublishMeeting && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleCloseDialog}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      eCommittee Meeting Published successfully.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => navigate(redirectTo)}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visibleMeetingOver && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleCloseMeetingOver}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      Meeting is Over!.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleCloseMeetingOver}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visibleMeetingMinutes && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleCloseMeetingMinutes}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      Meeting Minutes Published Successfully.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleCloseMeetingMinutes}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visibleReturnBack && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleCloseReturnBack}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      Returned Back Successfully.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleCloseReturnBack}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )} */}

                {/* {validationErrors && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleClosevalidationDialog}
                  >
                    <p
                      style={{
                        margin: "25px",
                        textAlign: "center",
                        width: "500px",
                        fontWeight: 500,
                      }}
                    >
                      Please fill up all the mandatory fields.
                    </p>
                    {/* <p style={{ textAlign: "center" }}>
                      Note: Invalid files are not allowed
                    </p> */}
                {/* <DialogActionsBar>
                      <Button
                        onClick={handleClosevalidationDialog}
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      //  style={{textAlign:'center !important'}}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog> */}
                {/* )} */}

                {showConfirmDailog && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={() => setShowConfirmDailog(false)}
                    className="dialogcontent_Refer"
                  >
                    <p className="cstDailogText" >
                      {confirmDailogObj.Confirmtext}
                    </p>
                    <p className="cstDailogTextmsg" >
                      {confirmDailogObj.Description}
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                        onClick={handleConfirmAction}
                      >
                        <span className="k-icon k-font-icon k-i-check k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                        Confirm
                      </Button>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => setShowConfirmDailog(false)}
                      >
                        <span className="k-icon k-font-icon k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}

                {showSuccessmsg && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setShowSuccessmsg(false)}
                  >
                    <p className="cstDailogTextmsg">
                      {successmsg}
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={() => { setShowSuccessmsg(false); navigate(redirectTo) }}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      //  style={{textAlign:'center !important'}}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}

                {showNotification && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setShowNotification(false)}
                  >
                    <p className="cstDailogValidmsg">
                      <div 
                      className="_cstDailogValidmsgDiv"
                       dangerouslySetInnerHTML={{ __html: notificationMsg }} />
                      {/* {notificationMsg} */}
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={() => setShowNotification(false)}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      //  style={{textAlign:'center !important'}}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {momVisible && (
                  <Dialog
                    title={<CustomDialogAddMOM />}
                    onClose={handleCloseMom}
                  >
                    {/* <p className="cstDailogText"> */}
                    <Editor
                      tools={[
                        [Bold, Italic, Underline],
                        [Subscript, Superscript],
                        [AlignLeft, AlignCenter, AlignRight, AlignJustify],
                        [Indent, Outdent],
                        [OrderedList, UnorderedList],
                        FontSize,
                        FontName,
                        FormatBlock,
                        [Undo, Redo],
                      ]}
                      contentStyle={{
                        height: 160,
                      }}
                      // value={momData}
                      // onChange={handleMomDataChange}
                      defaultContent={state.draftResolution}
                      ref={editor}
                      onChange={changeEditorValue}
                    />
                    {/* </p> */}

                    <DialogActionsBar>
                      <Button
                        onClick={handleAddMom}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn "></span>
                        Add
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
              </FormElement>
            )}
          />
        </div>
      </div>
     

      <Footer />
    </div>
  );
};