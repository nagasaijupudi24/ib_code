import React, { useState, useEffect } from "react";
import {
  Form,
  FormElement,
  FieldWrapper,
} from "@progress/kendo-react-form";
import { Input, TextArea } from "@progress/kendo-react-inputs";
import { Button } from "@progress/kendo-react-buttons";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Sidebar } from "../components/sidebar";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/forms.css";
import { Label } from "@progress/kendo-react-labels";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { infoCircleIcon } from "@progress/kendo-svg-icons";
import { useParams } from "react-router-dom";
import { useMsal, useAccount } from "@azure/msal-react";
import { SvgIcon } from "@progress/kendo-react-common";
import { PageLoader } from "../components/pageLoader";
import { useNavigate } from "react-router-dom";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import { Switch } from "@progress/kendo-react-inputs";
import { Editor, EditorTools } from "@progress/kendo-react-editor";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";
import DateObject from "react-date-object";
import "../styles/passcode.css"
import view from "../assets/view.png"
import hide from "../assets/hide.png"
import CryptoJS from 'crypto-js'; 
import { useTabContext } from "../App";

const CustomDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};

export const ECommitteeMeetingsViewForm = () => {
  const { setPasscodeNavigate } = useTabContext();
  const [isReturn, setIsReturn] = useState(false);
  // convenor Deportment
  const [isVisibleSuccssDialog, SetIsVisibleSuccssDialog] = useState(false);
  // falid dialog
  const [failedDialog, setfailedDialog] = useState(false);
  //  Succuss Msg
  const [successMsg, SetSuccessMsg] = useState("");
  // const id=useParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [meetingSubjectBorderColor, setMeetingSubjectBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [redirect] = useState("/meetingviews/All%20In-progress%20Committee%20Meeting%20Records");
  // const [combovalueApprover, setComboValueApprover] = useState();
  const committeeId = useParams();
  // comments obj
  const [commentsObj, setCommentsObj] = useState({
    comments: "",
    return: false,
    isValid: false,
  });
  // vwarliing msg
  const [aletMsg, setAlertMsg] = useState({});
  const [chairmanComments, setChairmanComments] = useState({
    comments: "",
    isValid: false,
  });
  const [commnetstext, setcommnetstext] = useState("");
  const max = 250;
  const [state, setState] = useState({});
  // comments alert
  const [commentsValidtionDialog, setCommentsValidtionDialog] = useState(false);
  const { accounts,instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [confirmDailogObj, setConfirmDailogObj] = React.useState({
    Confirmtext: "",
    Description: "",
  });
  const [currectbtn, SetCurrentBtn] = useState("");
  const [confirmationDialog, setConfirmationDialog] = useState(false);

  const [consoledatePdfLink, setConsoledatePdfLink] = useState("");
  const [statusMessage, setStatusMessage] = useState('');
  // Passcode validation and input
  const [passcodeVerification, setPasscodeVerification] = useState(false);
  const [isPasscodeVisible, setIsPasscodeVisible] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [validPasscode,setValidPasscode] = useState(false);
  const [validMsg,setValidmsg]= useState(false);
  const [verifyPasscode,setVerifypasscode] = useState("false")

  useEffect(() => {
    setIsLoading(true);
    VerifyUserPasscode();
    const fetchData = async () => {
      try {
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

        const getGeneralDetails = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.GET_CommitteeMeetingGeneralDetails}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify({ committeeMeetingId: committeeId.id }),
          }
        );
        const data = await getGeneralDetails.json();
        consoleDatePdfPathHyperlink(data?.consolidatedPDFPath, data?.consolidatedPDFBase64);
        // getSupportDocHyperlink()

        /*if(data?.convener){
        await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
            data?.convener
          )}`,
          {
            method: "GET",
            headers: {
              ...API_COMMON_HEADERS,
              Authorization: `Bearer ${accessToken}`,
            },
          }
        )
          .then((response) => {
            return response.json();
          })
          .then((data) => {
            const orgUsers = data.map(x=>{
              return {department:x.department === null?"NA":x.department,displayName:x.displayName === null?"NA":x.displayName,jobTitle:x.jobTitle === null?"NA":x.jobTitle,userPrincipalName:x.userPrincipalName}
            });
            setConvenorDepartment(orgUsers[0]?.department);
          })
          .catch((err) => {
            console.log(err);
          })}else{

            setConvenorDepartment("");
          }*/


        /*const allUserInfo = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetails}`,
          {
            method: "GET",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          }
        );
        const allUserInfoDetails = await allUserInfo.json();
        const convenorObj = allUserInfoDetails?.filter(
          (obj) => obj.userPrincipalName === data?.convener
        );
        // const convenorObj = allUserInfoDetails?.filter(obj => obj.displayName === "IBMohit");
        console.log(convenorObj, "conver");*/

        setState(data);
        setIsLoading(false);
      } catch (err) {
        console.log(err, "err");
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  // Handle consoledate pdf path link
  const consoleDatePdfPathHyperlink = (path, base64Data) => {
    if (path !== null && base64Data !== null) {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // checking file type
      const fileType = getFileType(path.toLowerCase());
      // Create a Blob object
      // const blob = new Blob([byteArray], { type: 'application/doc' });
      const blob = new Blob([byteArray], { type: `application/${fileType}` })
      setConsoledatePdfLink(window.URL.createObjectURL(blob));

    }
  }

  // getfileType
  const getFileType = (filename) => {
    let fileType = "doc"
    if (filename.endsWith(".pdf")) {
      fileType = "pdf";
    }
    if (filename.endsWith(".doc") || filename.endsWith(".docx")) {
      fileType = "doc";
    }
    if (
      filename.endsWith(".png") ||
      filename.endsWith(".jpg") ||
      filename.endsWith(".img") ||
      filename.endsWith(".svg")
    ) {
      fileType = "image";
    }
    if (filename.endsWith(".txt")) {
      fileType = "txt";
    }
    if (filename.endsWith(".xlsx")) {
      fileType = "xlsx";
    }
    if (filename.endsWith(".eml")) {
      fileType = "eml";
    }
    return fileType;

  }

  // Appeover checking
  const approverChecking = () => {
    let isApprover = false;
    const isActionsnotCompleted = state?.committeeMeetingMembersDTO?.some(
      (obj) =>
        obj.memberEmail === accounts[0].username &&
        (obj.approvalStatus === 3 || obj.approvalStatus === 0) &&
        obj.isChairman === false
    );
    if (
      isActionsnotCompleted &&
      (state?.meetingStatus === 4 || state?.meetingStatus === 5)
    ) {
      isApprover = true;
    }
    return isApprover;
  };

  // chairman checking
  const chairmanChecking = () => {
    let isChairman = false;
    let getAprovermembers = state?.committeeMeetingMembersDTO?.filter(
      (obj) => obj.isChairman === false
    );
    let isApprovedAllApproves = getAprovermembers?.every(
      (obj) => obj.approvalStatus === 1
    );
    let findChairman = state?.committeeMeetingMembersDTO?.some(
      (obj) =>
        obj.memberEmail === accounts[0].username &&
        obj.isChairman &&
        obj.approvalStatus === 3
    );
    if (
      state?.chairman === accounts[0].username &&
      isApprovedAllApproves &&
      findChairman &&
      state?.meetingStatus === 8
    ) {
      isChairman = true;
    }
    return isChairman;
  };

  // handle comments
  const onCommentsHandle = async (e) => {
    if(verifyPasscode === "true") {
        setcommnetstext(e.target.value);
      } else {
        setValidPasscode(true);
        // Changed the content --> Kavya (25-07)
        setValidmsg("Passcode is not set. Please create passcode to proceed further.");
      }

    
  };

  // Handle return for change
  const toggleChangeForReturn = (event) => {
    // Added passcode redirect page --> feedback 427 Kavya (24/07)
    if (verifyPasscode === "true") {
    setIsReturn(event.target.value);
    if (event.target.value) {
      setCommentsObj({
        ...commentsObj,
        return: event.target.value,
      });
    } else {
      setCommentsObj({
        ...commentsObj,
        return: event.target.value,
        comments: "",
        isValid: false,
      });
    }
    // Logs the current checked state of the Switch.
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  };

  // date converion
/*   const getdateconversion = (date) => {
    const convertedDate = new DateObject(date).format("DD-MMM-YYYY hh:mm A")
    // new Date(date).toDateString() + " " + new Date(date).toLocaleTimeString();
    return convertedDate;
  }; */

  // add comments Approver commnets
/*   const handleAddComments = () => {
    if (commnetstext) {
      setCommentsObj({
        ...commentsObj,
        comments: commnetstext,
        isValid: true,
      });
      setcommnetstext("");
    } else {
      setAlertMsg("Please fill in comments then click on Add Comments.");
      togglecommentsvalidationDialog();
    }
  }; */

  // chairman Comments
/*   const handleChairmanComments = (e) => {
    setcommnetstext(e.target.value);
  };
 */
/*   const handleAddChairmanComments = () => {
    if (commnetstext) {
      setChairmanComments({
        ...chairmanComments,
        comments: commnetstext,
        isValid: true,
      });
      setcommnetstext("");
    } else {
      setAlertMsg("Please fill in comments then click on Add Comments.");
      togglecommentsvalidationDialog();
    }
  }; */

  // toggle comments validation
  const togglecommentsvalidationDialog = () => {
    setCommentsValidtionDialog(true);
  };

  // Handle success dialog hide and show
  const SuccessDialogToggle = () => {
    SetIsVisibleSuccssDialog(true);
  };

  // faild dialog toggle
  const faildDialogToggle = () => {
    setfailedDialog(true);
  };

  // chairman Approve
  const onChairmanApprove = async () => {
    setIsLoading(true);
    const currentChairmanObj = state?.committeeMeetingMembersDTO?.filter(
      (obj) => obj.isChairman === true
    );
    const params = {
      committeeMeetingMemberId: currentChairmanObj[0]?.committeeMeetingMemberId,
      approvalStatus: 1,
      modifiedBy: accounts[0].username,
      committeeMeetingMemberCommentsDTO: !commnetstext ? [] :
        [
          {
            committeeMeetingMemberId:
              currentChairmanObj[0]?.committeeMeetingMemberId,
            comments: commnetstext,
          },
        ],
      committeeMeetingId: state?.committeeMeetingId,
      createdBy: accounts[0].username,
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eCommittee_Meetting_chairmanApprove}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
      }
    )
      .then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Failed") {
          setIsLoading(false);
          setStatusMessage(res.statusMessage);
          faildDialogToggle();
        } else {
          setIsLoading(false);
          SetSuccessMsg(
            "The meeting has been approved successfully."
          );
          SuccessDialogToggle();
        }
      })
      .catch((err) => {
        console.log(err);
        setIsLoading(false);
        faildDialogToggle();
        // Handle errors if needed
      });
  };

  // approver Approval function
  const onApproverApproveFunction = async () => {
    setIsLoading(true);
    const currentApproverObj = state?.committeeMeetingMembersDTO?.filter(
      (obj) => obj.memberEmail === accounts[0].username
    );
    const params = {
      committeeMeetingMemberId: currentApproverObj[0]?.committeeMeetingMemberId,
      approvalStatus: 1,
      modifiedBy: accounts[0].username,
      committeeMeetingMemberCommentsDTO: !commnetstext ? [] : [
        {
          committeeMeetingMemberId:
            currentApproverObj[0]?.committeeMeetingMemberId,
          comments: commnetstext,
        },
      ],
      committeeMeetingId: state?.committeeMeetingId,
      createdBy: accounts[0].username,
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eCommitteeMeetting_CommitteeMeetingStatusChange}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
      }
    )
      .then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Failed") {
          setIsLoading(false);
          // SetSuccessMsg("Something went wrong please try again.");
          faildDialogToggle();
        } else {
          setIsLoading(false);
          SetSuccessMsg("The meeting has been approved successfully.");
          SuccessDialogToggle();
          // setShowComboBox(false);
        }
      })
      .catch((err) => {
        console.log(err);
        setIsLoading(false);
        faildDialogToggle();
        // Handle errors if needed
      });
  };

  // return Request
  const onApproverReturn = async () => {

    setIsLoading(true);
    const currentApproverObj = state?.committeeMeetingMembersDTO?.filter(
      (obj) => obj.memberEmail === accounts[0].username
    );
    const params = {
      committeeMeetingMemberId:
        currentApproverObj[0]?.committeeMeetingMemberId,
      approvalStatus: 2,
      modifiedBy: accounts[0].username,
      committeeMeetingMemberCommentsDTO: [
        {
          committeeMeetingMemberId:
            currentApproverObj[0]?.committeeMeetingMemberId,
          comments: commnetstext,
        },
      ],
      committeeMeetingId: state?.committeeMeetingId,
      createdBy: accounts[0].username,
    };

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eCommitteeMeetting_CommitteeMeetingStatusChange}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(params),
      }
    )
      .then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Failed") {
          setIsLoading(false);
          // SetSuccessMsg("Something went wrong please try again.");
          faildDialogToggle();
        } else {
          setIsLoading(false);
          SetSuccessMsg("The meeting has been returned successfully.");
          SuccessDialogToggle();
          // setShowComboBox(false);
        }
      })
      .catch((err) => {
        console.log(err);
        setIsLoading(false);
        faildDialogToggle();
      });

  };

  // Handle redirect to passcode page 
  const handleRedirectToPasscode = () => {
    setPasscodeNavigate("View");
    navigate('/ecommitteepasscode'); // Adjust the path to your target route
  };

  // Handle verify user passcode 
  const VerifyUserPasscode = async () => {
    let userPasscodeExist = 'false';
    try {
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
          // Call eNote_VerifyUserPasscode API first
          const userPasscodeResponse = await fetch(
              `${API_BASE_URL}${API_ENDPOINTS.eCommittee_VerifyUserPasscode(accounts[0].username)}`,
              {
                method: "POST",
                // body: JSON.stringify({ UserMail: accounts[0].username}),
                headers: {
                  ...API_COMMON_HEADERS,
                  Authorization: `Bearer ${accessToken}`,
                  'Content-Type': 'application/json'
                },
              }
          );
  
          const userData = await userPasscodeResponse.text();
          if (userData) {
            userPasscodeExist = userData;
            setVerifypasscode(userData);
          }
        } catch (err) {
            console.error(err);
            // Handle error state or throw it further
            throw err;
        }
        return userPasscodeExist;
  }
  
  // Handle passcode change 
  const handlePasscodeChange = (e) => {
    const { value } = e.target;
    // Regular expression to allow only alphanumeric characters
    const alphanumericRegex = /^[a-zA-Z0-9]*$/;
    
    if (alphanumericRegex.test(value)) {
      setPasscode(value);
    }
  }

  //Handle  Verifing the passcode
  const passcodeVerificationFunction = async () => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account}, instance);
      // Replace with your own secret key
      const secretKey = "SHA256";
  
      // Compute HMAC-SHA256 hash of the passcode with the secret key
      const hashedPasscode = CryptoJS.SHA256(passcode, secretKey).toString(CryptoJS.enc.Hex);
  
      const params = {
        Passcode: hashedPasscode,
        UserMail: accounts[0].username
      };
  
      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_VerifyPasscode}`,
        {
          method: "POST",
          body: JSON.stringify(params),
          headers: {
          ...API_COMMON_HEADERS,
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
          },
        }
      );
      
      const data = await response.text();
    
      if (data === "Passcode verification successful") {
      setPasscodeVerification(false);
  
      const confirmDialogSettings = {
        "Approve": {
          Confirmtext: "Are you sure you want to approve this meeting?",
          Description: "Please click on Confirm button to approve meeting.",
        },
        "ChairmanApprove": {
          Confirmtext: "Are you sure you want to approve this meeting?",
          Description: "Please click on Confirm button to approve meeting.",
        },
        "Return": {
          Confirmtext: "Are you sure you want to retrun this meeting?",
          Description: "Please click on Confirm button to return meeting.",
        }
      };
  
      if (currectbtn in confirmDialogSettings) {
        setConfirmDailogObj(confirmDialogSettings[currectbtn]);
        toggleDailogForConfirmation();
      }

    } else {
      setError('Verification failed. Please try again.');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handle close passcode dialog
  const handlepasscodeClose = () => {
    setPasscodeVerification(false);
    setError(false);
  }

  //  Handle redirectHomePage
  const redirectHomePage = () => {
    navigate(redirect);
    SetIsVisibleSuccssDialog(false);
  };

  // open confirmation dialog
  const toggleDailogForConfirmation = () => {
    setConfirmationDialog(true)
  }

  // Handle on click of approve btn 
  const approveClick = async () => {
    // SetCurrentBtn("Approve");
    // setPasscode('');
    // setPasscodeVerification(true);
    
    if(verifyPasscode === "true") {
      setPasscode('');
      setPasscodeVerification(true);
      SetCurrentBtn("Approve");
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
      SetCurrentBtn("Approve");
    }
    // Commented for passcode functionality
    // setConfirmDailogObj({
    //   Confirmtext: " Are you sure you want to approve this meeting?",
    //   Description:
    //     "Please click on Confirm button to approve meeting.",
    // });
    // toggleDailogForConfirmation()
  }

  // Handle on click of approver btn
  const returnClick = async () => {
    SetCurrentBtn("Return");
    if (!commnetstext) {
      setAlertMsg("Please fill in comments then click on return.");
      togglecommentsvalidationDialog();
    } else {
      // SetCurrentBtn("Return");
      // setPasscode('');
      // setPasscodeVerification(true);
      if(verifyPasscode === "true") {
        setPasscode('');
        setPasscodeVerification(true);
        SetCurrentBtn("Return");
      } else {
        setValidPasscode(true);
        // Changed the content --> Kavya (25-07)
        setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
        SetCurrentBtn("Return");
      }
      // Commented for passcode functionality
      // setConfirmDailogObj({
      //   Confirmtext: " Are you sure you want to retrun this meeting?",
      //   Description:
      //     "Please click on Confirm button to return meeting.",
      // });
      // toggleDailogForConfirmation();
    }
  }

  // Handle on click of chairman
  const chairmanClick = async () => {
  
    if(verifyPasscode === "true") {
      setPasscode('');
      setPasscodeVerification(true);
      SetCurrentBtn("ChairmanApprove");
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
      SetCurrentBtn("ChairmanApprove");
    }
    // Commented for passcode functionality
    // setConfirmDailogObj({
    //   Confirmtext: " Are you sure you want to approve this meeting?",
    //   Description:
    //     "Please click on Confirm button to approve meeting.",
    // });
    // toggleDailogForConfirmation()
  }

  // confirmation
  const onCofiormation = () => {
    if (currectbtn === "Approve") {
      onApproverApproveFunction();
      setConfirmationDialog(false)
    }
    if (currectbtn === "Return") {
      onApproverReturn();
      setConfirmationDialog(false)

    }
    if (currectbtn === "ChairmanApprove") {
      onChairmanApprove();
      setConfirmationDialog(false)
    }
  }

  // Handle Custom Confirmtion Title Bar 
  const CustomConfirmtionTitleBar = () => {
    return (
      <div className="custom-title ">
        <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span> Confirmation
      </div>
    );
  };

  // createing base64 to url
 /*  const getpdflink = (path, base64Data) => {
    let pdfLink = ""
    if (path !== null && base64Data !== null) {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: `application/pdf` });
      pdfLink = window.URL.createObjectURL(blob)
    }
    return pdfLink;
  } */

    // Handle download base64 pdf file 
  const downloadBase64PDFFile = async (path) => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const parmas = {
      supportingDocumentPath: path
    }
    const notePDFINfo = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)

      }
    );
    const pdfDetails = await notePDFINfo?.text();
    if (pdfDetails !== "File Not Available!") {
      const byteCharacters = atob(pdfDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      // pdfLink = window.URL.createObjectURL(blob)
      // Commented for pdf open in new tab --> Kavya (06-08)
      // window.open(window.URL.createObjectURL(blob))

      const url = URL.createObjectURL(blob);
  
      // Create a link element
      const link = document.createElement('a');
      link.href = url;
      link.download = path; // specify the filename
      document.body.appendChild(link);
      link.click();
  
      // Clean up
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }
   // approval icons rendr
   const renderApproverIcon = (approverStatus) => {
    let icon = "k-i-rotate";
    if (approverStatus === 3) {
        icon = "k-i-clock"
    }
    if (approverStatus === 1) {
        icon = "k-i-check-circle"
    }
   
    if (approverStatus === 2) {
        icon = "k-i-undo"
    }
   
    return icon;
}
  return (
    <div>
      <Navbar header="IB Smart Office - eNote" />
      <Sidebar />
      <div className="FormMaincontainer">
        <div className="container">
          <div className="HeaderButtonsContainer row">
            <div className="col-md-4 formHeaderTilesStatus mobileTitleNewForm">{`Status: ${state?.strMeetingStatus}`}</div>
            <div className="col-md-4 formHeaderTilesTitle mobileTitleNewForm">
              eCommittee Meeting - {state.meetingNumber || ""}
            </div>
            <div className="col-md-4 formHeaderTilesDate mobileTitleNewForm" >
              {` Created: ${new DateObject(new Date(state.createdDate)).format("DD-MMM-YYYY hh:mm A")}`}
            </div>
          </div>
        </div>
        <div className="container">
          <div className="SectionHeads row">General Section</div>
          <Form
            render={() => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Meeting ID:
                          </Label>

                          <Input
                            component={Input}
                            value={state.meetingNumber}
                            // defaultValue={accounts[0].username}
                            // defaultValue={userDepartment}
                            // style={{ border: "none" }}
                            readOnly
                          />
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Committee Name :
                            {/* \<span className="required-asterisk">*</span> */}
                          </Label>

                          <Input
                            component={Input}
                            // name="MeetingId"
                            value={state.committeeName}
                            // defaultValue={accounts[0].username}
                            // defaultValue={userDepartment}
                            // style={{ border: "none" }}
                            readOnly
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Convenor Department :
                          </Label>
                          <Input value={state?.departmentName || ""} readOnly />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Chairman:</Label>
                          <Input value={state.chairmanName || ""} readOnly />
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Meeting Date :</Label>
                          <Input
                            value={new DateObject(state.meetingDate).format("DD-MM-YYYY")}
                            readOnly
                          />
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Meeting Subject :
                          </Label>
                          <TextArea
                            maxLength={max}
                            value={state.meetingSubject}
                            rows={1}
                            style={{ borderColor: meetingSubjectBorderColor }}
                            readOnly
                          />
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Meeting Mode :</Label>
                          <Input value={state?.strMeetingMode} readOnly />
                        </div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">Meeting Link :</Label>
                          <Label>
                            <a
                              href={state?.meetingLink}
                              target="_blank"
                              className="_customAnchorTag"
                            >
                              {state?.meetingLink}
                            </a>
                          </Label>
                        </div>
                      </FieldWrapper>
                    </div>
                  </div>
                  <div className="SectionHeads row">Committee Members</div>
                  <div className="SectionRow row">
                  <div className="table-responsive">
                    <table className="custom-table tableStyle mob_table">
                      <thead>
                   
                        <tr>
                          {/* Bug fix - 294 - 28/03 */}
                          
                          <th className="approvalform-tableCol-width-2">Member Name </th>
                          <th className="approvalform-tableCol-width-1">SR No</th>
                          <th className="approvalform-tableCol-width-2">Designation</th>
                          <th className="approvalform-tableCol-width-2">Status </th>
                          <th className="approvalform-tableCol-width-3">Action Date </th>
                        </tr>
                      </thead>
                      <tbody>
                        {state?.committeeMeetingMembersDTO?.map(
                          (obj, index) => {
                            if (obj.isChairman === false) {
                              return (
                                <tr key={index}>
                                
                                  <td className="approvalform-tableCol-width-2">
                                    {obj.memberEmailName}
                                  </td>
                                  <td className="approvalform-tableCol-width-1">
                                    {obj.srNo}
                                  </td>
                                  <td className="approvalform-tableCol-width-2">{obj.designation?obj.designation:"NA"}</td>
                                  <td className="approvalform-tableCol-width-2">
                                  <span className={`k-icon k-font-icon ${renderApproverIcon(obj.approvalStatus)}  allIconsforPrimary-btn`}></span>
                                    {obj.strApprovalStatus}
                                  </td>
                                  <td className="approvalform-tableCol-width-2">

                                  {(obj.approvalStatus ===1 ||obj.approvalStatus ===2) &&new DateObject(new Date(obj.modifiedDate)).format("DD-MMM-YYYY hh:mm A")}</td>
                                </tr>
                              );
                            }
                          }
                        )}
                      </tbody>
                    </table>
                    </div>
                  </div>
                  <div className="SectionHeads row">Committee Guest Members</div>
                  <div className="SectionRow row">
                  <div className="table-responsive">
                    <table className="custom-table tableStyle">
                      <thead>
                      <tr>
                          {/* Bug fix - 294 - 28/03 */}
                         
                          <th className="approvalform-tableCol-width-7">Guest Member Name </th>
                          <th className="approvalform-tableCol-width-1">SR No</th>
                          <th className="approvalform-tableCol-width-2">Designation</th>
                          {/* <th className="approvalform-tableCol-width-2">Status </th> */}
                          {/* <th className="approvalform-tableCol-width-3">Action Date </th> */}
                        </tr>
                      </thead>
                      <tbody>
                        {state?.committeeMeetingGuestMembersDTO?.map(
                          (obj, index) =>

                            <tr key={obj.memberEmail}>
                            
                              <td className="approvalform-tableCol-width-7">
                                {obj.memberEmailName}
                              </td>
                              <td className="approvalform-tableCol-width-1">
                              {obj.srNo}
                              </td>
                              <td className="approvalform-tableCol-width-2">
                              {obj.designation?obj.designation:"NA"}
                              </td>
                            </tr>
                        )}
                      </tbody>
                    </table>
                    </div>
                  </div>
                  <div className="SectionHeads row">Meeting Minutes </div>
                  <div className="SectionRow row">
                  <div className="table-responsive ">
                    <table className="custom-table mob_tableCommittee">
                      <thead>
                        <tr>
                          <th className="approvalform-tableCol-width-1">
                            S.No
                          </th>
                          <th className="approvalform-tableCol-width-1">
                            Note#
                          </th>
                          <th className="approvalform-tableCol-width-2">
                            Committee Name
                          </th>
                          <th className="approvalform-tableCol-width-2">
                            Department
                          </th>
                          <th className="approvalform-tableCol-width-2">
                            Meeting Minutes
                          </th>
                          <th className="approvalform-tableCol-width-2">
                            Note Link
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {state?.committeeMeetingNoteDTO?.map((obj, index) => (
                          <tr key={index}>
                            <td className="approvalform-tableCol-width-1">
                              {index + 1}
                            </td>
                            <td className="approvalform-tableCol-width-1">
                              {obj.noteNumber}
                            </td>
                            <td className="approvalform-tableCol-width-2">
                              {obj.committeeName}
                            </td>
                            <td className="approvalform-tableCol-width-2">
                              {obj.departmentName}
                            </td>
                            <td className="approvalform-tableCol-width-2">
                              <Editor
                                value={obj.mom || ""}
                              />
                            </td>
                            <td className="approvalform-tableCol-width-2">

                              <span className="link-style"
                                              onClick={() => downloadBase64PDFFile(obj.notePdfPath,)}
                                           
                                            >
                                              {obj.notePdfPath}
                                            </span>

                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    </div>
                  </div>
                  {approverChecking() && (
                    <>
                      <div className="SectionHeads row">Return</div>
                      <div className="SectionRow row">
                        <div className="col-md-6">
                          <FieldWrapper>
                            <div className="k-form-field-wrap committee-meetting-label">
                              <Label className="k-form-label return-label-committee-meeting-approvalForm">
                                Do you want Return ?
                              </Label>
                              <Switch
                                className="retun-radioBtn-meetingapproval-form"
                                size={"small"}
                                onLabel={"Yes"} offLabel={"No"}
                                onChange={toggleChangeForReturn}
                                checked={isReturn}
                              />
                            </div>
                          </FieldWrapper>
                        </div>
                      </div>
                    </>
                  )}
                  {state?.meetingStatus === 7 && (
                    <>
                      <div className="SectionHeads row">
                        Consolidated PDF link
                      </div>
                      <div className="SectionRow row">
                        {state && (
                          <p>
                            Consolidated PDF link :
                       
                             <span className="link-style"
                                              onClick={() => downloadBase64PDFFile(state?.consolidatedPDFPath)}
                                            >
                                              {state?.consolidatedPDFPath}
                                            </span>
                            
                          </p>
                        )}
                      </div>
                    </>
                  )}
                  <div className="SectionHeads row">Comments </div>
                  {(chairmanChecking() || approverChecking()) && (<>
                    <div className="SectionRow row">
                      <div className="committee-meetings-approval-for-cmts-textarea">
                        <Label className="k-form-label">
                          Comments {isReturn && (<span className="required-asterisk">*</span>)} :
                        </Label>
                        <TextArea
                          onChange={onCommentsHandle}
                          value={commnetstext || ""}
                          rows={3}
                     
                        />
                      </div>
                    </div>
                  </>)

                  }
                  <div className="SectionRow row">

                    <table className="custom-table tableStyle">
                      <thead>
                        <tr>
                          <th className="approvalform-tableCol-width-6">
                            Comments
                          </th>
                          <th className="approvalform-tableCol-width-4">
                            Commented by
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {state?.committeeMeetingMemberCommentsDTO?.map(
                          (obj, index) => (
                            <tr key={index}>
                              <td className="approvalform-tableCol-width-6">
                                {obj.comments}
                              </td>
                              <td className="approvalform-tableCol-width-4">
                                {obj.memberEmailName}
                              </td>
                            </tr>
                          )
                        )}

                      </tbody>
                    </table>
                  </div>
                  <div className="SectionHeads row">Workflow Log </div>
                  <div className="SectionRow row">
                    <table className="tableStyle">
                      <thead>
                        <tr>
                          <th className="approvalform-tableCol-width-3 ">
                            Action
                          </th>
                          <th className="approvalform-tableCol-width-4">
                            Action By
                          </th>
                          <th className="approvalform-tableCol-width-3">
                            Action Date
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {state?.committeeMeetingWorkflowLogsDTO?.map(
                          (obj, index) => (
                            <tr key={index}>
                              <td className="approvalform-tableCol-width-3">
                                {obj.action}
                              </td>
                              <td className="approvalform-tableCol-width-4">
                                {obj.actionByName}
                              </td>
                              <td className="approvalform-tableCol-width-3">
                                {new DateObject(new Date(obj.modifiedDate)).format("DD-MMM-YYYY hh:mm A")}
                              </td>
                            </tr>
                          )
                        )}
                      </tbody>
                    </table>
                  </div>
                </fieldset>
              </FormElement>
            )}
          />
        </div>
      </div>
      {isLoading && <PageLoader />}
      {confirmationDialog && (
        <Dialog
          title={<CustomConfirmtionTitleBar />}
          onClose={() => setConfirmationDialog(false)}
        >
          <p className="dialogcontent_"
     
          >
            {confirmDailogObj.Confirmtext}
          </p>
          <p className="dialogcontent_"
         
          >
            {confirmDailogObj.Description}
          </p>

          <DialogActionsBar>
            <Button className="formBtnColor" onClick={onCofiormation}>
              <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
              Confirm
            </Button>

            <Button onClick={() => setConfirmationDialog(false)}>
              <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
              Cancel</Button>
          </DialogActionsBar>
        </Dialog>
      )}
      <div className="approvalAction-foreNoteForm-contaioner">
        {/* {(currentActionerEmail === accounts[0].username && (noteData.status === 2 || noteData.status === 3) && noteData !== null && noteData?.noteApproversDTO.some(obj=>obj.approverEmail === currentActionerEmail &&obj.approverEmail ===accounts[0].username )) && */}
        <div>
          {approverChecking() && !isReturn && (
            <span className="eNote-ApprovalButton">
              <Button themeColor="success" onClick={approveClick}>
                <span className="k-icon-sm k-font-icon k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>
                Approve
              </Button>
            </span>
          )}
          {chairmanChecking() && (
            <span className="eNote-ApprovalButton">
              <Button themeColor="success" onClick={chairmanClick}>
                <span className="k-icon-sm k-font-icon k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>
                Approve
              </Button>
            </span>
          )}
          {approverChecking() && isReturn && (
            <span className="eNote-ApprovalButton">
              <Button className="formBtnColor" onClick={returnClick}>
                <span className="k-icon-sm k-font-icon k-i-undo cursor allIconsforPrimary-btn"></span>
                Return
              </Button>
            </span>
          )}
          <span className="eNote-ApprovalButton">
            <Button onClick={redirectHomePage}>
              <span className="k-icon-sm k-font-icon k-i-x-circle cursor allIconsforPrimary-btn"></span > Exit</Button>
          </span>
        </div>
      </div>
      <Footer />
      {/* commnets alert */}
      {commentsValidtionDialog && (
        <Dialog
          title={<CustomDialogTitleBar />}
          onClose={() => setCommentsValidtionDialog(false)}
        >
          <p  className="dialogcontent_"
       
          >
            {/* please fill in comments then click on Add Comments. */}
            {aletMsg}
          </p>
          <DialogActionsBar>
            <Button
              className="notifyDailogOkBtn"
              onClick={() => setCommentsValidtionDialog(false)}
            >
              <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}

      {isVisibleSuccssDialog && (
        <Dialog title={<CustomDialogTitleBar />} onClose={redirectHomePage}>
          <p className="dialogcontent_"
     
          >
            {successMsg}
          </p>
          <DialogActionsBar>
            <Button className="notifyDailogOkBtn" onClick={redirectHomePage}>
              <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {failedDialog && (
        <Dialog
          title={<CustomDialogTitleBar />}
          onClose={() => setfailedDialog(false)}
        >
          <p  className="dialogcontent_"
        
          >
            {`Something went wrong: ${statusMessage}`}
          </p>
          <DialogActionsBar>
            <Button
              className="notifyDailogOkBtn"
              onClick={() => setfailedDialog(false)}
            >
              <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {/* Passcode dialog */}
        {passcodeVerification && (
        <Dialog title="Passcode Verification" onClose={handlepasscodeClose}>
         <form className="form-container dialogcontent_" style={customStyles.dialogAlignment}>
          <label>
            Enter your passcode for verification:
            <div className="passcode-input-wrapper">
              <input
                  type={isPasscodeVisible ? 'text' : 'password'}
                  value={passcode}
                  onChange={handlePasscodeChange}
                  className="passcode-input"
                  maxLength="6"
                  pattern="\d*"
                  title="Please enter 6-characters, Combination of Alphabets and Numbers"
                   // Commented for passcode text field numeric input type --> Kavya(16-08)
                  // inputMode="numeric"
              />
              <span
                  className="eye-icon-view"
                  onClick={() => setIsPasscodeVisible(!isPasscodeVisible)}
              >
                  {isPasscodeVisible ? <img alt="view" src={view} /> : <img alt="hide" src={hide} />}
              </span>
            </div>
          </label>
          <div>
          {error && <span className='error'>{error}</span>}
          </div>
        </form>
        <DialogActionsBar>
        <Button
            className="formBtnColor"
            onClick={passcodeVerificationFunction}>
            <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
            Verify
          </Button>
          <Button
            onClick={handlepasscodeClose}>
            <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
            Cancel
          </Button>
        
        </DialogActionsBar>
        </Dialog>
      )}
       {validPasscode && (
        <Dialog title="Passcode Verification" onClose={() => setValidPasscode(false)}>
          <div  style={customStyles.dialogAlignment}>
            <p>{validMsg}</p>
          </div>
        <DialogActionsBar>
        <Button
            className="formBtnColor"
            onClick={handleRedirectToPasscode}>
            <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
            Create Passcode
          </Button>
          <Button
            onClick={() => setValidPasscode(false)}>
            <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
            Cancel
          </Button>
        </DialogActionsBar>
        </Dialog>
      )}
    </div>
  );
};  
const customStyles = {
  dialogAlignment :{ margin: "25px",textAlign: "center",width: "500px" }
}