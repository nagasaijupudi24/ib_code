import React, { useState, useEffect } from "react";
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import { Link } from "react-router-dom";
import { Button } from "@progress/kendo-react-buttons";
import { ColumnMenu } from "./custom-cells";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { useParams } from "react-router";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import { CSVLink } from "react-csv";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
import { useMsal, useAccount } from "@azure/msal-react";
import { getter } from "@progress/kendo-react-common";
import { Sidebar } from "../components/sidebar";

import "../styles/datagridpage.css";
import "../styles/forms.css";
import { API_BASE_URL, API_ENDPOINTS,API_COMMON_HEADERS ,loginRequest} from "../config";
import { PageLoader } from "../components/pageLoader";
import DateObject from "react-date-object";
import { orderBy } from "@progress/kendo-data-query";
import { getAccessToken } from "../App";

const initialSort = [
  {
    field: "modifiedDate",
    dir: "desc",
  },
];


const DATA_ITEM_KEY = "noteId";
// const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};

const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};

const MeetingViews = () => {

  const idGetter = getter(DATA_ITEM_KEY);

  const { id } = useParams();
  const [filterValue, setFilterValue] = React.useState("");
  const [filteredData, setFilteredData] = React.useState();
  const [currentSelectedState, setCurrentSelectedState] = React.useState({});
  const [dataState, setDataState] = React.useState(initialDataState);
  const [data, setData] = React.useState(filteredData);
  const [apiData, setApiData] = React.useState([]);
  const [dataResult, setDataResult] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentHeading, setCurrentHeading] = useState();
  const [selectedView, setSelectedView] = useState("");
  const [enumObj, setEnumObj] = useState();

  const { accounts,instance } = useMsal();
  const account = useAccount(accounts[0] || {});

  // Handle get request by status 
  const getRequestByStatus = async(noteId) => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
    });
    const enumsObj = await dropdowns.json();
    setEnumObj(enumsObj);

    switch (noteId) {
      case "Committee Unmapped Records":
        fetchApiData(API_ENDPOINTS.MeetingView_UnMappedRecords);
        setSelectedView(noteId);
        break;
      case "All In-progress Committee Meeting Records":
        fetchApiData(API_ENDPOINTS.MeetingView_AllInProgress);
        setSelectedView(noteId);
        break; 
      case "My Pending Committee Records":
        fetchApiData(API_ENDPOINTS.MeetingView_MyPending);
        setSelectedView(noteId);
        break;
      case "My Approved Committee Records":
        fetchApiData(API_ENDPOINTS.MeetingView_MyApproved);
        setSelectedView(noteId);
        break;
      case "All Approved Committee Meetings":
        fetchApiData(API_ENDPOINTS.MeetingView_AllApproved);
        setSelectedView(noteId);
        break;
      default:
        fetchApiData(API_ENDPOINTS.MeetingView_AllApproved);
        setSelectedView("All Approved Committee Meetings");
        return 0;
    }
  };

  // Handle get switch noteId
  const switchNoteId = async (id) => {
    setCurrentHeading(id);
    setIsLoading(true);
    getRequestByStatus(id);
  }

  useEffect(() => {
    switchNoteId(id); // Set the default noteId
  }, [id]);

  // Handle get data 
  const fetchApiData = async (endPoint) => {
    setFilterValue('');
    try {

      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
      });

      const enumsObj = await dropdowns.json();
      setEnumObj(enumsObj);
      
      const response = await fetch(
        `${API_BASE_URL}${endPoint}`,
        {
          method: "POST",
          body: JSON.stringify({CreatedBy:accounts[0].username}),
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
        }
      );

      if (response.ok) {
        const apiOutput = await response.json();
        const resData = apiOutput.meetingList;
        const upObj = orderBy(resData, initialSort);
        const apiData = upObj.map(x=>({...x,modifiedDate:new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm A"),
        createdDate:new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm A"),meetingDate:new DateObject(new Date(x.meetingDate)).format("DD-MMM-YYYY")}));

        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle on filter change 
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);
      // }

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      // setFilteredData(newData);
      let clearedPagerDataState = {
        ...dataState,
        take: 10,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiData.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );

  //Handle data status change 
  const dataStateChange = (event) => {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
  };

  // Handle on expand change 
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );

  // Handle selected value change 
  const setSelectedValue = (data) => {
    let newData = data.map((item) => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items),
        };
      } else {
        return {
          ...item,
          ["selected"]: currentSelectedState[idGetter(item)],
        };
      }
    });
    return newData;
  };
  const newData = setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: [],
  });

/*   let _pdfExport;
  const exportExcel = () => {
    _export.save();
  };
  let _export;
  const exportPDF = () => {
    _pdfExport.save();
  }; */

  // Handle expport CSV header change  
  const exportCSVHeader = (id) => {

    let headerColumnConfig;

    switch (id) {
      case "Committee Unmapped Records":
        headerColumnConfig = [
          { key: "noteNumber", label: "Note#" },
          { key: "departmentName", label: "Department" },
          { key: "committeeName", label: "Committee" },
          { key: "subject", label: "Subject" },
          { key: "createdDate", label: "Created Date" },
        ];
        break;
        default:
          headerColumnConfig = [
          { key: "meetingNumber", label: "Title" },
          { key: "meetingSubject", label: "Meeting Subject" },
          { key: "strMeetingMode", label: "Meeting Mode" },
          { key: "meetingDate", label: "Meeting Date" },
          { key: "committeeName", label: "Committee Name" },
          { key: "strMeetingStatus", label: "Status" },
          // Bug fix - 293 - 27/03
          { key: "approvedByName", label: "Approved By" },
          { key: "createdDate", label: "Created Date" },
        ];
    }
    return headerColumnConfig;
  };

  // Handle render column with data 
  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    let columnsConfig = [];

    switch (id) {
      case "Committee Unmapped Records":
        columnsConfig = [
          { field: "noteNumber", title: "Note#" },
          { field: "departmentName", title: "Department" },
          { field: "committeeName", title: "Committee" },
          { field: "subject", title: "Subject" },
          { field: "createdDate", title: "Created Date" },
        ];
        break;
        default:
        columnsConfig = [
          { field: "meetingNumber", title: "Title" },
          { field: "meetingSubject", title: "Meeting Subject" },
          { field: "strMeetingMode", title: "Meeting Mode" },
          { field: "meetingDate", title: "Meeting Date" },
          { field: "committeeName", title: "Committee Name" },
          { field: "strMeetingStatus", title: "Status" },
          // Bug fix - 293 - 27/03
          // Bug fixed 01/04
          { field: "approvedBy", title: "Approved By" },
          { field: "createdDate", title: "Created Date" },
        ];
    }

    console.log(accounts);

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "meetingNumber" ? (
            <td>
              <Link
                style={{ color: "red" }}
                to={
                  (props.dataItem["meetingStatus"] === enumObj.CommitteeMeetingStatus.find((x) => x.dValue === "Created").id ||
                    props.dataItem["meetingStatus"] === enumObj.CommitteeMeetingStatus.find((x) => x.dValue === "Published").id ||
                    props.dataItem["meetingStatus"] === enumObj.CommitteeMeetingStatus.find((x) => x.dValue === "Meeting Over").id ||
                    props.dataItem["meetingStatus"] === enumObj.CommitteeMeetingStatus.find((x) => x.dValue === "Returned").id) &&
                  props.dataItem["createdBy"] === accounts[0].username
                  ? `${"/ecommitteemeetingform/"}${props.dataItem["committeeMeetingId"]}`
                  : `${"/ecommitteemeetingviewform/"}${props.dataItem["committeeMeetingId"]}`
               }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {/* {column.title.includes("Date")
                ? new Date(props.dataItem[column.field]).toDateString() +
                  " " +
                  new Date(props.dataItem[column.field]).toLocaleTimeString()
                : props.dataItem[column.field]} */}
                
                {column.field === "noteNumber" ? <Link style={{ color: "red" }} to={`${"/ecommitteeviewform/"}${props.dataItem["noteId"]}`}>{props.dataItem[column.field]}</Link>:props.dataItem[column.field]}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  return (
    <div>
      <Navbar header="IB Smart Office - eNote" />
      <Sidebar />
      <div className="container datagridpage">

        <div className="SectionHeads row mobileSectionHeads">{currentHeading}</div>
        {/* Add a section for displaying headings and allow the user to switch between them*/}
        {isLoading ? (
          <PageLoader />
        ) : (
          <Grid
            className="cstGridStyles"
            pageable={{ pageSizes: true }}
            data={dataResult}
            sortable={true}
            total={resultState.total}
            onDataStateChange={dataStateChange}
            {...dataState}
            onExpandChange={onExpandChange}
            expandField="expanded"
            dataItemKey={DATA_ITEM_KEY}
            // groupable={true}
            size={"small"}
            resizable={true}
          >
            <GridToolbar>
              <Input
                value={filterValue}
                onChange={onFilterChange}
         className="searchCSS"
                placeholder="Search in all columns..."
              />
              <div className="export-btns-container">
                <Button className="_exportCSVBtn">
                  <CSVLink filename={`eCommittee-${selectedView.replace(/ /g, '')}${new DateObject(new Date()).format("DDMMYYYYhhmmss")}` } data={filteredData} headers={exportCSVHeader(currentHeading)} >Export CSV</CSVLink>
                </Button>
              </div>
            </GridToolbar>
            {renderColumnsWithData(dataResult)}
          </Grid>
        )}
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};

export default MeetingViews;