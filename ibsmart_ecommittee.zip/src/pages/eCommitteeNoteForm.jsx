import React, { useState, useEffect } from "react";
import {
  Form,
  Field,
  FormElement,
  FieldWrapper,
} from "@progress/kendo-react-form";
import { Input, NumericTextBox, TextArea } from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import { Button } from "@progress/kendo-react-buttons";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { Sidebar } from "../components/sidebar";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/forms.css";
import "../styles/responsiveDesign.css";
import { Label, Hint } from "@progress/kendo-react-labels";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { infoCircleIcon } from "@progress/kendo-svg-icons";
import { Link, useParams } from "react-router-dom";
import { useMsal, useAccount } from "@azure/msal-react";
import { SvgIcon } from "@progress/kendo-react-common";
import { TableDraggableRows } from "../components/tableDragRows";
import { PageLoader } from "../components/pageLoader";
import { useNavigate } from "react-router-dom";
import {
  filePdfIcon,
  fileWordIcon,
  fileImageIcon,
  fileTxtIcon,
  fileDataIcon,
  fileIcon,
  xIcon
} from "@progress/kendo-svg-icons";
import DateObject from "react-date-object";
import Clock from "react-live-clock";
import { API_BASE_URL, API_ENDPOINTS, loginRequest,API_COMMON_HEADERS  } from "../config";
import { MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
import { getAccessToken,useTabContext } from "../App";
import useAutosave from "../hooks/useAutoSave.hook";
import "../styles/responsiveDesign.css";

const CustomDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <SvgIcon icon={infoCircleIcon} /> Alert!
    </div>
  );
};

const CustomConfirmDialogTitleBar = () => {
  return (
    <div className="custom-title cstDailogIbHeader">
      <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span> Confirmation
    </div>
  );
};

const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",
  },

  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "120px",
  },
];

// mobile view responsive
const mobileColumns = [
  {
    field: "displayName",
    header: "Person Name",
    width: "100px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "100px",
  },
  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "70px",
  },
];



export const ECommitteeNewForm = () => {
  const valueRender = (element, value, fieldName) => {
    const clearValue = (e) => {
      e.stopPropagation();
      e.preventDefault();
      setState(prevState => ({
        ...prevState,
        [fieldName]: '',
      }));

    };
    if (!value) {
      return element;
    }
    const children = [
      <span key={1} style={{
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        flexGrow: 1
      }}>
        {element.props.children}
      </span>,
      <SvgIcon icon={xIcon} onClick={clearValue} />
    ];
    return React.cloneElement(element, { ...element.props }, children);
  };

  // change -13/05  clear  department Value 
  // const valueRenderDepartment = (element, value) => {
  //   const clearValue = (e) => {
  //     e.stopPropagation();
  //     e.preventDefault();
  //     setSelectedDepartment(null);
  //     //  change 16/05  on clear of department approver and reviwers need to clear 
  //     setUserDepertment('');
  //     setNoteApproverData([]);
  //     setNoteReviewerData([])
  //   };
  //   if (!value) {
  //     return element;
  //   }
  //   const children = [
  //     <span key={1} style={{
  //       overflow: 'hidden',
  //       textOverflow: 'ellipsis',
  //       flexGrow: 1
  //     }}>
  //       {element.props.children}
  //     </span>,
  //     <SvgIcon icon={xIcon} onClick={clearValue} />
  //   ];
  //   return React.cloneElement(element, {
  //     ...element.props
  //   }, children);
  // };
  const  {setTab} =useTabContext();
  const navigate = useNavigate();
  const [committeeNameDropDown, setCommitteeNameDropDown] = useState([]);
  const [natureofnote, setNatureOfNote] = useState([]);
  const [notetype, setNoteTypeData] = useState([]);
  const [fintype, setFinType] = useState([]);
  const [natureofapprsanc, setNatureofApprSanc] = useState([]);
  const [noteapproverData, setNoteApproverData] = useState([]);
  const [notereviewerData, setNoteReviewerData] = useState([]);
  const [showNatureOfApprSanc, setShowNatureOfApprSanc] = useState(false);
  const [showTypeOfFinNote, setshowTypeOfFinNote] = useState(false);
  const [showAmount, setshowAmount] = useState(false);
  const [showPurpose, setshowPurpose] = useState(false);
  const [showPurpose1, setshowPurpose1] = useState(false);
  const [showPurpose2, setshowPurpose2] = useState(false);
  const [value] = useState("");
  const [departmentError] = useState("");
  const [noteBorderColor, setNoteBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const urlParam = useParams();
  const [noteId] = useState(urlParam.id);
  // const [draftId, setDraftId] = useState(0);
  // const [redirectTo] = useState("/views/In%20Progress");
  const [redirectTo] = useState("/ecommittehome");
  const [searchBorderColor, setSearchBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [subjectBorderColor, setSubjectBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [natureofapprsancBorderColor, setNatureofapprsancBorderColor] =
    useState("rgba(0, 0, 0, 0.12)");
  const [notetypeBorderColor, setNotetypeBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [typeoffinBorderColor, setTypeOfFinBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [amountBorderColor, setAmountBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [natureofnoteBorderColor, setNatureOfNoteBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [purposeBorderColor, setPurposeBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [purposeOthersBorderColor, setPurposeOthersBorderColor] = useState(
    "rgba(0, 0, 0, 0.12)"
  );
  const [purpose1BorderColor, setPurpose1BorderColor] = useState("");
  const [purpose2BorderColor, setPurpose2BorderColor] = useState("");
  const [approverEmailsList] = useState();
  const [selectedReveiwer, setSelectedReviewer] = useState(null);
  const [combovalueApprover, setComboValueApprover] = useState(null);
  const [visible, setVisible] = React.useState(false);
  const [visibleCancelCfrm, setVisibleCancelCfrm] = React.useState(false);
  const [alertvisible, setAlertVisible] = useState(false);
  const [visiblesave, setVisibleSave] = React.useState(false);
  const [validationErrors, setValidationErrors] = React.useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [isSecretaryExist, setisSecretaryExist] = useState(false);
  const [showNotification, setShowNotification] = React.useState(false);
  const [notificationMsg, setNotificationMsg] = React.useState(false);
  const [enumsObj, setEnumsObj] = React.useState(null);
  const [isNewForm] = React.useState(noteId === "new");
  const [amount, setAmount] = React.useState("");
  const [purpose, setPurpose] = React.useState("");
  const [purposeOthers, setPurposeOthers] = React.useState("");
  const [drpOptPurposeApproval, setDrpOptPurposeApproval] = React.useState([]);
  const [drpOptPurposeInformation, setDrpOptPurposeInformation] = React.useState([]);
  const [allOrgUsers, setAllOrgUsers] = useState([]);
  const [notepath,setNotePath] = useState(null);
  const [wordPath,setWordPath] = useState(null);
  const isMobile = window.innerWidth <= 768;
  const [noteComments, setNoteComments] = useState([]);
  // const [currentTime, setCurrentTime] = React.useState(new Date());
  const max = 250;

  const [state, setState] = useState({
    Department: "",
    committeeName: "",
    Subject: "",
    NatureOfNote: "",
    NatureOfApprSanc: "",
    NoteType: "",
    TypeOfFinNote: "",
    Amount: "",
    Search: "",
    Purpose: "",
    PurposeApproval: "",
    PurposeInformation: "",
    notePdfPath: "",
    noteWordPath: "",
    supportingdocument: "",
    createdBy: "",
    status: "",
    statusMsg: "",
    createdDate: "",
  });

  const [filesInfo, SetFileinfo] = useState([]);
  const [supportingDocError, setSupportingError] = useState("");
  const [wordandPdfWarring, SetWordPDFInfowarring] = useState({
    PDFInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
    },
    wordInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
    },
  });

  const [supportDocWarning, SetSupportDocWarning] = useState({});

  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [userDepartment, setUserDepertment] = useState("");
  const [userDesignation, setUserDesignation] = useState("");
  const [isSaveAndSubmitActionCompleted, setisSaveAndSubmitActionCompleted] = useState(false);
  const [draftId, setDraftId] = useState(noteId === "new" ? 0 : noteId);
  const [departmentBorderColor, setDepartmentBorderColor] = useState("rgba(0, 0, 0, 0.12)");
  const [selectedDepartment, setSelectedDepartment] = useState(null);
  useEffect(() => {
    setIsLoading(true);
    getUserDepartment();
  }, []);


  //Get login users department and designation
  const getUserDepartment = async () => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const obj = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetailsByPrincipalName(
          accounts[0].username
        )}`,
        {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        }
      );
      const departmentDetails = await obj.json();
      setUserDepertment(departmentDetails[0].department);
      setUserDesignation(departmentDetails[0].jobTitle);
      // getDefaultConfigData(departmentDetails[0].department);
      getDefaultConfigData(departmentDetails[0].department);
      // if (!isNewForm) {
      //   fetcheNotedetails(departmentDetails[0].department);
      // }
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  };

  // Change 13/05 API call for department list
/*   const getDepartmentList = async () => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const obj = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_Departments_List}`
      , {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
      }
    );
    const departmentDetailsList = await obj.json();
    setDepartmentList(departmentDetailsList)
  }  */

  //Find secretary exists for the added Approvers/Reviewers
  const findSecrateries = async (apprObj, userDepartment) => {
    let param = apprObj.map((x) => ({
      approverType: x.approverType,
      approverEmail: x.approverEmail,
    }));

    let secretaryExists = false;
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    if (userDepartment) {

      try {
        await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eCommittee_GetNoteSecretaryofApprover}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify({
              noteApproversMasterlst: param,
              departmentName: userDepartment,
            }),
          }
        )
          .then((response) => {
            return response.json();
          })
          .then((data) => {
            setisSecretaryExist(data.secretaryExist);
            secretaryExists = data.secretaryExist;
          });
      } catch (error) {
        console.error("Error fetching data from API:", error);
      }
    }
    return secretaryExists;
  };
  /* get defalutApprovers on change of department 

  Change 16/05 on change department this function will call */
  // commented for department select
  // const getDefaultConfigApprovers = async (userDepartment) => {
  //   // if (isNewForm) {
  //   const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
  //   const approverresponse = await fetch(
  //     `${API_BASE_URL}${API_ENDPOINTS.eCommittee_GetNoteApprovers(userDepartment)}`, {
  //     method: "GET",
  //     headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
  //   }
  //   );

  //   const reviewerresponse = await fetch(
  //     `${API_BASE_URL}${API_ENDPOINTS.eCommittee_GetNoteReviewer(userDepartment)}`, {
  //     method: "GET",
  //     headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
  //   }
  //   );

  //   const noteapprover = await approverresponse.json();
  //   const notereviewer = await reviewerresponse.json();
  //   if (noteapprover) {
  //     setNoteApproverData(noteapprover);
  //     await findSecrateries(noteapprover, userDepartment);
  //   }
  //   if (notereviewer)
  //     setNoteReviewerData(notereviewer);

  // }

  //Get all the dropdowns and pre configured data
  const getDefaultConfigData = async (userDepartment) => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const dropdowns = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`,
        {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        }
      );
      const dropdownslist = await dropdowns.json();


      //Removed this function due to loading impact users will be filtered on search box enter - 22/03
      /*const orgUsers = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.GET_UserDetails}`,
        {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
        }
      );
      const orgMembers = await orgUsers.json();


      const reConstructArr = orgMembers.map((x) => {
        return {
          department: x.department === null ? "NA" : x.department,
          displayName: x.displayName === null ? "NA" : x.displayName,
          jobTitle: x.jobTitle === null ? "NA" : x.jobTitle,
          userPrincipalName: x.userPrincipalName,
        };
      });

      setOrgEmployees(reConstructArr);
      setApproverEmailsObject(reConstructArr);*/

      // getDepartmentList();
      setEnumsObj(dropdownslist);
      setCommitteeNameDropDown(dropdownslist.committeeName);
      setNatureOfNote(dropdownslist.natureofNote);
      setNoteTypeData(dropdownslist.noteType);
      setFinType(dropdownslist.financialType);
      setNatureofApprSanc(dropdownslist.natureOfApprovalOrSanction);
      setDrpOptPurposeApproval(dropdownslist.PurposeonApproval);
      setDrpOptPurposeInformation(dropdownslist.PurposeonInformation);

      if (!(isNewForm)) {
        await fetcheNotedetails(userDepartment, dropdownslist.PurposeonApproval);
      }

      // Comment get default approvers on onload
         if (isNewForm) {
          const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
  
          const approverresponse = await fetch(
            `${API_BASE_URL}${API_ENDPOINTS.eCommittee_GetNoteApprovers(
              userDepartment
            )}`,
            {
              method: "GET",
              headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            }
          );
          const reviewerresponse = await fetch(
            `${API_BASE_URL}${API_ENDPOINTS.eCommittee_GetNoteReviewer(
              userDepartment
            )}`,
            {
              method: "GET",
              headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            }
          );
  
          const noteapprover = await approverresponse.json();
          const notereviewer = await reviewerresponse.json();
  
          if (noteapprover) {
            setNoteApproverData(noteapprover);
            await findSecrateries(noteapprover, userDepartment);
          }
          if (notereviewer) setNoteReviewerData(notereviewer);
          setIsLoading(false);
        } 
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    setIsLoading(false);
  };

  //Get eNote data for Edit form on load
  const fetcheNotedetails = async (userDepartment, purposeApprovalDrpOpt) => {
    setIsLoading(true);
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommitte_GetGeneralDetails}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify({ noteId: noteId }),
        }
      );

      if (!response.ok) {
        // Handle error, for example set an error state
        console.error("Error fetching data:", response.statusText);
        return;
      }
      const data = await response.json();
     

      setState({
        ...data,
        status: data.noteStatusCommittees,
        committeeName: data.committeesDTO[0]?.committeeName,
        Amount: data.amount || "",
        NatureOfNote: data.strNatureofNote === "0" ? "" : data.strNatureofNote,
        Subject: data.subject || "",
        NatureOfApprSanc:
          data.strNatureOfApprovalOrSanction === "0"
            ? ""
            : data.strNatureOfApprovalOrSanction,
        NoteType: data.strNoteType === "0" ? "" : data.strNoteType,
        FinancialType:
          data.strFinancialType === "0" ? "" : data.strFinancialType,
        TypeOfFinNote:
          data.strFinancialType === "0" ? "" : data.strFinancialType,
        Search: data.searchKeyword || "",
        Purpose: data.purpose || "",
        PurposeApproval: data.purpose === "0" ? "" : data.purpose,
        PurposeInformation: data.purpose === "0" ? "" : data.purpose,
        NotePdfFileName: data.purpose === "0" ? "" : data.purpose,
        NotePdfPath: data.notePdfPath || "",
        supportingdocument: data.noteSupportingDocumentsDTO || "",
        noteApproversDTO: data.noteApproversDTO || "",
        createdBy: data.createdBy,
        statusMsg: data.strNoteStatus,
        createdDate: new DateObject(new Date(data.createdDate)).format(
          "DD-MM-YYYY hh:mm A" // Change 23/05 Seconds hand was removed
        ),
      });

      setAmount(data.amount);
      setSelectedDepartment(data?.departmentName ? data?.departmentName : null);
      setUserDepertment(data?.departmentName ? data?.departmentName : "");
      if (data.strNatureofNote === "Approval" && purposeApprovalDrpOpt.find(x => (x.dValue === data.purpose)) === undefined) {
        setPurpose("Others");
        setPurposeOthers(data.purpose);
      } else {
        setPurpose(data.purpose);
      }
      setNoteComments(data.noteApproverCommentsDTO);
      // setPurposeApproval(data.purpose);
      // setPurposeInformation(data.purpose);
      setShowNatureOfApprSanc(
        data.strNatureofNote === "Sanction" ||
        data.strNatureofNote === "Approval"
      );
      setshowPurpose(
        data.strNatureofNote === "Sanction" ||
        data.strNatureofNote === "Ratification"
      );
      setshowPurpose1(data.strNatureofNote === "Approval");
      setshowPurpose2(data.strNatureofNote === "Information");
      setshowTypeOfFinNote(data.strNoteType === "Financial");
      setshowAmount(data.strNoteType === "Financial");

      SetWordPDFInfowarring({
        PDFInfo: {
          fileName: data?.notePdfFileName,
          warningMsg: "",
          filePath: data?.notePdfPath,
          isValid: (data?.notePdfFileName === "" || data?.notePdfFileName === null) ? false : true
        },
        wordInfo: {
          fileName: data?.noteWordFileName,
          warningMsg: "",
          filePath: data?.noteWordPath,
          isValid: (data?.noteWordFileName === "" || data?.noteWordFileName === null) ? false : true
        },
      });
      setNotePath(data?.notePdfPath);
      setWordPath(data?.noteWordPath);
      SetFileinfo(data?.noteSupportingDocumentsDTO);
      // SetFileinfo(supportingDocDetails?.noteSupportingDocumentsDTO);
      const fetchNoteApprover = data.noteApproversDTO?.filter(
        (obj) => obj.approverType === 2
      );
      if (fetchNoteApprover?.length > 0) {
        await findSecrateries(fetchNoteApprover, data?.departmentName ? data?.departmentName : null);
      }
      setNoteApproverData(fetchNoteApprover);

      setNoteReviewerData(
        data.noteApproversDTO?.filter((obj) => obj.approverType === 1)
      );
      // getDefaultConfigData();
    } catch (error) {
      console.error("Error fetching data:", error.message);
    }
    setIsLoading(false);
  };

  // Delete Approvers from Approvers/Reviewers table
  const deletereviewer = (data) => {
    if (data && data.approverType === 1) {
      const updatedData = notereviewerData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      setNoteReviewerData(updatedData)
    }
    if (data && data.approverType === 2) {
      const updatedData = noteapproverData.filter(
        (row) => row.approverOrder !== data.approverOrder
      );
      updatedData.forEach((item, index) => {
        item.approverOrder = index + 1;
      });
      setNoteApproverData(updatedData)
    }
  }

  //  Approvers orderChange from Approvers/Reviewers table   
  const orderChange = (data) => {
    if (data.some(obj => obj.approverType === 1)) {
      setNoteReviewerData(data)
    }
    if (data.some(obj => obj.approverType === 2)) {
      setNoteApproverData(data);
    }

  }

  // autosave function will call here
  useAutosave(() => {
    if (!isSaveAndSubmitActionCompleted && isNewForm) {
      handleAutoSave();
    }
  }, 3 * 60 * 1000);

  /* -------------------Form fields handlers START ---------------------- */
  /* Data Handles */
  const handleCommitteeName = (event) => {
    setState((prevState) => ({
      ...prevState,
      committeeName: event.target.value,
    }));
    setNoteBorderColor("");

  };

  // Handle subject change 
  const handleSubjectChange = (event) => {
    setState((prevState) => ({ ...prevState, Subject: event.target.value }));
    setSubjectBorderColor("");

  };

  // Handle nature of note  change 
  const handleNatureOfNoteChange = (event) => {
    setState((prevState) => ({
      ...prevState,
      NatureOfNote: event.target.value,
    }));
    setNatureOfNoteBorderColor("");

    const selectedValue = event.target.value;

    if (selectedValue === "Sanction" || selectedValue === "Ratification")
      setState((prevState) => ({
        ...prevState,
        PurposeApproval: "",
        PurposeInformation: "",
      }));

    if (selectedValue === "Approval")
      setState((prevState) => ({
        ...prevState,
        Purpose: "",
        PurposeInformation: "",
      }));

    if (selectedValue === "Information")
      setState((prevState) => ({
        ...prevState,
        PurposeApproval: "",
        Purpose: "",
      }));

    setShowNatureOfApprSanc(
      selectedValue === "Sanction" || selectedValue === "Approval"
    );
    setshowPurpose(
      selectedValue === "Sanction" || selectedValue === "Ratification"
    );
    setshowPurpose1(selectedValue === "Approval");
    setshowPurpose2(selectedValue === "Information");

    setPurpose('');
    setPurposeOthers('');
  };

  // Handle nature  of appr/sanc change 
  const handleNatureOfApprSancChange = (event) => {
    setState((prevState) => ({
      ...prevState,
      NatureOfApprSanc: event.target.value,
    }));
    setNatureofapprsancBorderColor("");

  };

  // Handle note type change 
  const handleNoteType = (event) => {
    setState((prevState) => ({ ...prevState, NoteType: event.target.value }));

    if (!(event.target.value === "Financial"))
      setState((prevState) => ({ ...prevState, TypeOfFinNote: "", Amount: 0 }));

    setNotetypeBorderColor("");
    setshowTypeOfFinNote(event.target.value === "Financial");
    setshowAmount(event.target.value === "Financial");
  };

  // Handle type of financial change 
  const handleTypeOfFin = (event) => {
    setState((prevState) => ({
      ...prevState,
      TypeOfFinNote: event.target.value,
    }));

    setTypeOfFinBorderColor("");
  };

  // Handle amount change 
  const handleAmount = (event) => {
    // Bug fix - 297 - 27/03
    {/* Change - Adding decimals - 05/04 - RK  */ }
    if (/^\d*\.?\d{0,2}$/.test(event.target.value)) {
      // if(/^\d*$/.test(event.target.value)){
      setState((prevState) => ({ ...prevState, Amount: event.target.value }));
      setAmount(event.target.value);
      setAmountBorderColor("");

    }
  };

  // Hnadle search Change 
  const handleSearchChange = (event) => {
    setState((prevState) => ({ ...prevState, Search: event.target.value }));
    setSearchBorderColor("");

  };

  // Handle purpose change
  const handlePurpose = (event) => {
    setState((prevState) => ({ ...prevState, Purpose: event.target.value }));
    setPurpose(event.target.value);
    setPurposeBorderColor("");

  };

  // Handle purpose approval
  const handlePurposeApproval = (event) => {
    setState((prevState) => ({
      ...prevState,
      PurposeApproval: event.target.value,
    }));
    // setPurposeApproval(event.target.value);
    setPurpose(event.target.value);
    setPurposeOthers('');
    setPurpose1BorderColor("");

  };

  // Handle purpose information
  const handlePurposeInformation = (event) => {
    setState((prevState) => ({
      ...prevState,
      PurposeInformation: event.target.value,
    }));
    // setPurposeInformation(event.target.value);
    setPurpose(event.target.value);
    setPurpose2BorderColor("");

  };

  // Handle purpose info others
  const handlePurposeInfoOthers = (event) => {
    setPurposeOthers(event.target.value);
    setPurposeOthersBorderColor("");

  };
  /* -------------------Form fields handlers END ---------------------- */

  /* Form mandatory fields and file validation handler */
  const validateForm = (isApproverValid, isReviewerValid) => {
    const errors = {};
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }

    /*  let isFilesValid = true;
 
     if (filesInfo > 0) {
       filesInfo.map((x) => {
         if (x.supportingDocumentFileName in supportDocWarning)
           isFilesValid = !(x.supportingDocumentFileName in supportDocWarning);
       });
     } */
    if (!userDepartment) {
      errors["Depertment"] = "Department";
      setDepartmentBorderColor("#f31700");
    } else {
      setDepartmentBorderColor("");

    }

    if (!state.committeeName) {
      errors["committeName"] = "CommitteName";
      setNoteBorderColor("#f31700");
    } else {
      setNoteBorderColor("");
    }
    if (!state.Subject.trim()) {
      errors["Subject"] = "Subject";
      setSubjectBorderColor("#f31700");
    } else {
      setSubjectBorderColor("");
    }
    if (!state.NatureOfNote) {
      errors["NatureOfNote"] = "Nature Of Note";
      setNatureOfNoteBorderColor("#f31700");
    } else {
      setNatureOfNoteBorderColor("");
    }
    if (showNatureOfApprSanc && !state.NatureOfApprSanc) {
      errors["NatureOfApprSanc"] = "Nature Of Appr/Sanc";
      setNatureofapprsancBorderColor("#f31700");
    } else {
      setNatureofapprsancBorderColor("");
    }
    if (!state.NoteType) {
      errors["NoteType"] = "Note Type";
      setNotetypeBorderColor("#f31700");
    } else {
      setNotetypeBorderColor("");
    }
    if (showTypeOfFinNote && !state.TypeOfFinNote) {
      errors["TypeOfFinNote"] = "Type of Financial Note";
      setTypeOfFinBorderColor("#f31700");
    } else {
      setTypeOfFinBorderColor("");
    }
    if (showAmount && !amount) {
      errors["Amount"] = "Amount";
      setAmountBorderColor("#f31700");
    } else {
      setAmountBorderColor("");
    }
    // Bug fix - 297 - 27/03
    if (showAmount && Number(amount) <= 0) {
      errors["Amount"] = "Amount";
      setAmountBorderColor("#f31700");
    } else {
      setAmountBorderColor("");
    }
    if (!state.Search.trim()) {
      errors["Search"] = "Search Text";
      setSearchBorderColor("#f31700");
    } else {
      setSearchBorderColor("");
    }
    if (showPurpose && !purpose.trim()) {
      errors["Purpose"] = "Purpose";
      setPurposeBorderColor("#f31700");
    } else {
      setPurposeBorderColor("");
    }
    if (showPurpose1 && !purpose) {
      errors["Purpose1"] = "Purpose";
      setPurpose1BorderColor("#f31700");
    } else {
      setPurpose1BorderColor("");
      // errors["Purpose1"] = "";
    }
    if (showPurpose2 && !purpose) {
      errors["Purpose2"] = "Purpose";
      setPurpose2BorderColor("#f31700");
    } else {
      setPurpose2BorderColor("");
      // errors["Purpose2"] = "";
    }
    if (showPurpose1 && purpose === "Others" && !purposeOthers.trim()) {
      errors["Purpose2"] = "Others";
      setPurposeOthersBorderColor("#f31700");
    } else {
      setPurposeOthersBorderColor("");
      // errors["Purpose2"] = "";
    }
    if (noteapproverData.length === 0) {
      errors["Approvers"] = "Please select atleast one Approver to submit request"

    }

    if (isApproverValid || isReviewerValid) {
      errors["Login user"] = "Login user cannont be part of Approvers/Reviewers."
    }

    /* if (
      (wordandPdfWarring?.PDFInfo.fileName === null ||
        wordandPdfWarring?.PDFInfo.fileName === "") &&
      wordandPdfWarring?.PDFInfo.isValid === false
    ) {
      errors["PDFInfo"] = "Please select Valid Pdf File";
    }
    if (
      noteapproverData.length > 0 &&
      isSecretaryExist &&
      (wordandPdfWarring?.wordInfo.fileName === "" ||
        wordandPdfWarring?.wordInfo.fileName === null) &&
      wordandPdfWarring?.wordInfo.isValid === false
    ) {
      errors["wordDocInfo"] = "Please select Valid Word Doc File";
    } */
    if (
      (wordandPdfWarring?.PDFInfo.fileName === null ||
        wordandPdfWarring?.PDFInfo.fileName === "" ||
        wordandPdfWarring?.PDFInfo.isValid === false)
    ) {
      errors["PDFInfo"] = "Please select Valid Pdf File";
    }
    if (
      noteapproverData.length > 0 &&
      isSecretaryExist &&
      (wordandPdfWarring?.wordInfo.fileName === "" ||
        wordandPdfWarring?.wordInfo.fileName === null ||
        wordandPdfWarring?.wordInfo.isValid === false)
    ) {
      errors["wordDocInfo"] = "Please select Valid Word Doc File";
    }
    // if (filesInfo.length === 0) {
    //   errors["Supporting Documents"] = "Please add supporting documents";
    // }
    /*   if (Object.keys(supportDocWarning).length>0) {
        errors["Supporting Documents"] = "Please select valid files";
      } */
    if (Object.keys(supportDocWarning).length > 0 || totalFileSize > 26214400) {
      if (Object.keys(supportDocWarning).length > 0) {
        errors["Supporting Documents"] = "Please select vaild files";
      }
      if (totalFileSize > 26214400) {
        errors["Supporting DocumentsMaxSize"] = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";

      }

    }
    if (Object.keys(errors).length > 0) {
      const errorMessagesArray = Object.values(errors);
      setErrorMessages(errorMessagesArray);
      setValidationErrors(true);
    }
    return errors;
  };

  /* Auto save Form Data */
  const handleAutoSave = async () => {
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    // }

    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });

    try {
      const updatedNoteReviewerData = notereviewerData.map((item, ind) => ({
        ...item,
        strApproverStatus: ind === 0 ? "Pending" : "Waiting",
      }));
      const updatedNoteApproverData = noteapproverData.map((item, ind) => ({
        ...item,
        strApproverStatus:
          notereviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
      }));
      const base64PDFParams = wordandPdfWarring.PDFInfo.filePath;
      const base64WordParams = wordandPdfWarring.wordInfo.filePath || {};

      const params = {
        autosave: true,
        noteId: isNewForm ? draftId : noteId,
        noteForCommittees: enumsObj.noteFor.find(
          (x) => x.dValue === "Regular"
        ).id,
        noteStatusCommittees: enumsObj.NoteStatus.find(
          (x) => x.dValue === "Draft"
        ).id,
        // departmentId: 0,
        // departmentName: userDepartment,
        //  Change 13/05 
        departmentName: userDepartment,
        // noteTo: state.NoteTo
        //   ? noteto.find((x) => x.dValue === state.NoteTo).id
        //   : 0,
        // committeeId: 0,
        committeeName: state.committeeName,
        subject: state.Subject,
        designation: userDesignation,
        NatureofNoteCommittees: state.NatureOfNote ? natureofnote.find((x) => x.dValue === state.NatureOfNote).id : 0,
        NatureOfApprovalOrSanctionCommittees: state.NatureOfApprSanc ? natureofapprsanc.find((x) => x.dValue === state.NatureOfApprSanc).id : 0,
        NoteTypeCommittees: state.NoteType ? notetype.find((x) => x.dValue === state.NoteType).id : 0,
        FinancialTypeCommittees: state.TypeOfFinNote ? fintype.find((x) => x.dValue === state.TypeOfFinNote).id : 0,
        amount: amount ? amount : 0,
        createdBy: accounts[0].username,
        modifiedBy: accounts[0].username,
        noteSupportingDocumentsDTO: totalFileSize > 26214400 ? [] : fileupdated,
        noteApproversDTO: [
          ...updatedNoteReviewerData,
          ...updatedNoteApproverData,
        ],
        searchKeyword: state.Search,
        Purpose: (showPurpose1 && purpose === "Others") ? purposeOthers : purpose,
        NotePdfPath: isNewForm ? null : (wordandPdfWarring.PDFInfo.filePath !== notepath ? null : notepath),
        NotePdfPathPart1: base64PDFParams.part1,
        NotePdfPathPart2: base64PDFParams.part2,
        NotePdfPathPart3: base64PDFParams.part3,
        NotePdfPathPart4: base64PDFParams.part4,
        NotePdfPathPart5: base64PDFParams.part5,
        NotePdfPathPart6: base64PDFParams.part6,
        NotePdfPathPart7: base64PDFParams.part7,
        NotePdfPathPart8: base64PDFParams.part8,
        NotePdfPathPart9: base64PDFParams.part9,
        NotePdfPathPart10: base64PDFParams.part10,
        NotePdfFileName: wordandPdfWarring.PDFInfo.fileName,
        NoteWordPathPart1: base64WordParams.part1 || null,
        NoteWordPathPart2: base64WordParams.part2 || null,
        NoteWordPathPart3: base64WordParams.part3 || null,
        NoteWordPathPart4: base64WordParams.part4 || null,
        NoteWordPathPart5: base64WordParams.part5 || null,
        NoteWordPathPart6: base64WordParams.part6 || null,
        NoteWordPathPart7: base64WordParams.part7 || null,
        NoteWordPathPart8: base64WordParams.part8 || null,
        NoteWordPathPart9: base64WordParams.part9 || null,
        NoteWordPathPart10: base64WordParams.part10 || null,
        // NoteWordPath: wordandPdfWarring.wordInfo.filePath || null,
        NoteWordPath: isNewForm ? null : (wordandPdfWarring.wordInfo.filePath !== wordPath ? null : wordPath),
        // NotePdfPath: (wordandPdfWarring?.PDFInfo.fileName && wordandPdfWarring?.PDFInfo.isValid === false) ? null : wordandPdfWarring.PDFInfo.filePath,
        // NotePdfFileName: (wordandPdfWarring?.PDFInfo.fileName && wordandPdfWarring?.PDFInfo.isValid === false) ? null : wordandPdfWarring.PDFInfo.fileName,
        // NoteWordPath: (isSecretaryExist && wordandPdfWarring?.wordInfo.fileName && wordandPdfWarring?.wordInfo.isValid === false) ? null : wordandPdfWarring.wordInfo.filePath || null,
        NoteWordFileName: (isSecretaryExist && wordandPdfWarring?.wordInfo.fileName && wordandPdfWarring?.wordInfo.isValid === false) ? null : wordandPdfWarring.wordInfo.fileName || null,
      };


      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${(isNewForm && draftId === 0)
          ? API_ENDPOINTS.eCommittee_AddNote
          : API_ENDPOINTS.eCommittee_EditNote
        }`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          if (data.statusMessage === "Success") {
            setDraftId(data.noteId);
          } else {
            // console.error("Error submitting form:");
            // setShowNotification(true);
            console.log(
              "eCommittee form submission failed. Please try again."
            );
          }
        })
        .catch((err) => {
          console.error(err, "Error submitting form");
          // setShowNotification(true);
          // setNotificationMsg(err);
        });
    } catch (error) {
      console.error("Error submitting form:", error);
      // setShowNotification(true);
      // setNotificationMsg(error);
    }
  };

  //It helps to cansel the note
  const onCancelNote = async () => {
    setIsLoading(true);
    setVisibleCancelCfrm(false);

    let params = {
      noteId: noteId,
      createdBy: accounts[0].username,
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(`${API_BASE_URL}${API_ENDPOINTS.eCommittee_CancelNote}`, {
      method: "POST",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(params),
    })
      .then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Failed") {
          setShowNotification(true);
          setNotificationMsg("Something went wrong please try again.");
        } else {
          setSuccessMessage(
            "The request for cancellation has been successfull."
          );
          setVisibleSave(!visiblesave);
        }
        setIsLoading(false);
      })
      .catch((err) => {
        setShowNotification(true);
        setNotificationMsg("Something went wrong please try again.");
        console.log(err);
        setIsLoading(false);
      });
  };

  /* it helps tp save or update draft data on Save as draft*/
  const handleSave = async () => {
    setisSaveAndSubmitActionCompleted(true);
    const errors = {};
    setIsLoading(true);
    let isFilesValid = true;
    let totalFileSize = 0;

    filesInfo.map((x) => {
      isFilesValid = !(x.supportingDocumentFileName in supportDocWarning);
    });
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });


    if (
      isSecretaryExist && wordandPdfWarring?.wordInfo.fileName && wordandPdfWarring?.wordInfo.isValid === false
    ) {
      errors["wordDocInfo"] = "Please select vaild file";
    }
    if (
      wordandPdfWarring?.PDFInfo.fileName && wordandPdfWarring?.PDFInfo.isValid === false
    ) {
      errors["PDFInfo"] = "Please select vaild file";
    }
    if (filesInfo.length > 0 && !isFilesValid) {
      errors["Supporting Documents"] = "Please select vaild files";
    }
    if ((filesInfo.length > 0 && !isFilesValid) || totalFileSize > 26214400) {
      if (filesInfo.length > 0 && !isFilesValid) {
        errors["Supporting Documents"] = "Please select vaild files"
      }
      if (totalFileSize > 26214400) {
        errors["Supporting DocumentsMaxSize"] = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
      }
    }

    if (Object.keys(errors).length === 0) {
      try {
        const updatedNoteReviewerData = notereviewerData.map((item, ind) => ({
          ...item,
          strApproverStatus: ind === 0 ? "Pending" : "Waiting",
        }));

        const updatedNoteApproverData = noteapproverData.map((item, ind) => ({
          ...item,
          strApproverStatus:
            notereviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
        }));

        const base64PDFParams = wordandPdfWarring.PDFInfo.filePath;
        const base64WordParams = wordandPdfWarring.wordInfo.filePath || {};
        const params = {
          autosave: false,
          noteId: isNewForm ? draftId : noteId,
          noteForCommittees: enumsObj.noteFor.find(
            (x) => x.dValue === "Regular"
          ).id,
          noteStatusCommittees: enumsObj.NoteStatus.find(
            (x) => x.dValue === "Draft"
          ).id,
          // departmentName: userDepartment,
          //  Change 13/05 
          departmentName: userDepartment,
          committeeName: state.committeeName,
          subject: state.Subject,
          designation: userDesignation,
          NatureofNoteCommittees: state.NatureOfNote ? natureofnote.find((x) => x.dValue === state.NatureOfNote).id : 0,
          NatureOfApprovalOrSanctionCommittees: state.NatureOfApprSanc ? natureofapprsanc.find((x) => x.dValue === state.NatureOfApprSanc).id : 0,
          NoteTypeCommittees: state.NoteType ? notetype.find((x) => x.dValue === state.NoteType).id : 0,
          FinancialTypeCommittees: state.TypeOfFinNote ? fintype.find((x) => x.dValue === state.TypeOfFinNote).id : 0,
          amount: amount ? amount : 0,
          createdBy: accounts[0].username,
          modifiedBy: accounts[0].username,
          noteSupportingDocumentsDTO: fileupdated,
          noteApproversDTO: [
            ...updatedNoteReviewerData,
            ...updatedNoteApproverData,
          ],
          searchKeyword: state.Search,
          Purpose: (showPurpose1 && purpose === "Others") ? purposeOthers : purpose,
          NotePdfPath: isNewForm ? null : (wordandPdfWarring.PDFInfo.filePath !== notepath ? null : notepath),
          NotePdfPathPart1: base64PDFParams.part1,
          NotePdfPathPart2: base64PDFParams.part2,
          NotePdfPathPart3: base64PDFParams.part3,
          NotePdfPathPart4: base64PDFParams.part4,
          NotePdfPathPart5: base64PDFParams.part5,
          NotePdfPathPart6: base64PDFParams.part6,
          NotePdfPathPart7: base64PDFParams.part7,
          NotePdfPathPart8: base64PDFParams.part8,
          NotePdfPathPart9: base64PDFParams.part9,
          NotePdfPathPart10: base64PDFParams.part10,
          NotePdfFileName: wordandPdfWarring.PDFInfo.fileName,
          NoteWordPathPart1: base64WordParams.part1 || null,
          NoteWordPathPart2: base64WordParams.part2 || null,
          NoteWordPathPart3: base64WordParams.part3 || null,
          NoteWordPathPart4: base64WordParams.part4 || null,
          NoteWordPathPart5: base64WordParams.part5 || null,
          NoteWordPathPart6: base64WordParams.part6 || null,
          NoteWordPathPart7: base64WordParams.part7 || null,
          NoteWordPathPart8: base64WordParams.part8 || null,
          NoteWordPathPart9: base64WordParams.part9 || null,
          NoteWordPathPart10: base64WordParams.part10 || null,
          // NoteWordPath: wordandPdfWarring.wordInfo.filePath || null,
          NoteWordPath: isNewForm ? null : (wordandPdfWarring.wordInfo.filePath !== wordPath ? null : wordPath),
          // NotePdfPath: wordandPdfWarring.PDFInfo.filePath,
          // NotePdfFileName: wordandPdfWarring.PDFInfo.fileName,
          // NoteWordPath: wordandPdfWarring.wordInfo.filePath || null,
          NoteWordFileName: wordandPdfWarring.wordInfo.fileName || null,
        };

      
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

        await fetch(`${API_BASE_URL}${(isNewForm && draftId === 0) ? API_ENDPOINTS.eCommittee_AddNote : API_ENDPOINTS.eCommittee_EditNote}`, {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }).then(response => {
          return response.json();
        }).then(data => {
          if (data.statusMessage === "Success") {
            setSuccessMessage("The request for eCommittee note has been drafted successfull.");
            setVisibleSave(true);
            // setAlertVisible(true);
          } else {
            // console.error("Error submitting form:");
            setShowNotification(true);
            // setNotificationMsg("eCommittee note submission failed. Please try again.");
            setNotificationMsg(`eCommittee note submission failed. 
            ${data.statusMessage}`);
          }
        }).catch(err => {
          console.error("Error submitting form:", err);
          setShowNotification(true);
          setNotificationMsg(err);
        })
      } catch (error) {
        console.error("Error submitting form:", error);
        setShowNotification(true);
        setNotificationMsg(error);
      }
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "Invalid files attached. Kindly remove the invalid files."
      );
    }
    setIsLoading(false);
  };

  /* It helps create or update note on Submit*/
  const handleSubmit = async () => {
    setIsLoading(true);
    setVisible(false);
    setisSaveAndSubmitActionCompleted(true);
    let fileupdated = filesInfo?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });
    // const errors = validateForm();
    // if (Object.keys(errors).length === 0) {
    try {
      const updatedNoteReviewerData = notereviewerData.map((item, ind) => ({
        ...item,
        strApproverStatus: ind === 0 ? "Pending" : "Waiting",
      }));
      const updatedNoteApproverData = noteapproverData.map((item, ind) => ({
        ...item,
        strApproverStatus:
          notereviewerData.length === 0 && ind === 0 ? "Pending" : "Waiting",
      }));
      
      const base64PDFParams = wordandPdfWarring.PDFInfo.filePath;
      const base64WordParams = wordandPdfWarring.wordInfo.filePath || {};
      const params = {
        autosave: false,
        noteId: isNewForm ? draftId : noteId,
        noteForCommittees: enumsObj.noteFor.find(
          (x) => x.dValue === "Committee"
        ).id,
        noteStatusCommittees: enumsObj.NoteStatus.find(
          (x) => x.dValue === "Submitted"
        ).id,
        // departmentId: 0,
        // departmentName: userDepartment,
        //  Change 13/05 
        departmentName: userDepartment,
        // noteTo: state.NoteTo
        //   ? noteto.find((x) => x.dValue === state.NoteTo).id
        //   : 0,
        // committeeId: 0,
        committeeName: state.committeeName,
        subject: state.Subject,
        designation: userDesignation,
        NatureofNoteCommittees: state.NatureOfNote ? natureofnote.find((x) => x.dValue === state.NatureOfNote).id : 0,
        NatureOfApprovalOrSanctionCommittees: state.NatureOfApprSanc ? natureofapprsanc.find((x) => x.dValue === state.NatureOfApprSanc).id : 0,
        NoteTypeCommittees: state.NoteType ? notetype.find((x) => x.dValue === state.NoteType).id : 0,
        FinancialTypeCommittees: state.TypeOfFinNote ? fintype.find((x) => x.dValue === state.TypeOfFinNote).id : 0,
        amount: amount ? amount : 0,
        createdBy: accounts[0].username,
        modifiedBy: accounts[0].username,
        noteSupportingDocumentsDTO: fileupdated,
        noteApproversDTO: [
          ...updatedNoteReviewerData,
          ...updatedNoteApproverData,
        ],
        searchKeyword: state.Search,
        Purpose: (showPurpose1 && purpose === "Others") ? purposeOthers : purpose,
        NotePdfPath: isNewForm ? null : (wordandPdfWarring.PDFInfo.filePath !== notepath ? null : notepath),
        NotePdfPathPart1: base64PDFParams.part1,
        NotePdfPathPart2: base64PDFParams.part2,
        NotePdfPathPart3: base64PDFParams.part3,
        NotePdfPathPart4: base64PDFParams.part4,
        NotePdfPathPart5: base64PDFParams.part5,
        NotePdfPathPart6: base64PDFParams.part6,
        NotePdfPathPart7: base64PDFParams.part7,
        NotePdfPathPart8: base64PDFParams.part8,
        NotePdfPathPart9: base64PDFParams.part9,
        NotePdfPathPart10: base64PDFParams.part10,
        NotePdfFileName: wordandPdfWarring.PDFInfo.fileName,
        NoteWordPathPart1: base64WordParams.part1 || null,
        NoteWordPathPart2: base64WordParams.part2 || null,
        NoteWordPathPart3: base64WordParams.part3 || null,
        NoteWordPathPart4: base64WordParams.part4 || null,
        NoteWordPathPart5: base64WordParams.part5 || null,
        NoteWordPathPart6: base64WordParams.part6 || null,
        NoteWordPathPart7: base64WordParams.part7 || null,
        NoteWordPathPart8: base64WordParams.part8 || null,
        NoteWordPathPart9: base64WordParams.part9 || null,
        NoteWordPathPart10: base64WordParams.part10 || null,
        NoteWordPath: isNewForm ? null : (wordandPdfWarring.wordInfo.filePath !== wordPath ? null : wordPath),
        // NotePdfPath: wordandPdfWarring.PDFInfo.filePath,
        // NotePdfFileName: wordandPdfWarring.PDFInfo.fileName,
        // NoteWordPath: wordandPdfWarring.wordInfo.filePath || null,
        NoteWordFileName: wordandPdfWarring.wordInfo.fileName || null,
      };
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${(isNewForm && draftId === 0)
          ? API_ENDPOINTS.eCommittee_AddNote
          : API_ENDPOINTS.eCommittee_EditNote
        }`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(params),
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          if (data.statusMessage === "Success") {
            setAlertVisible(true);
          } else {
            setShowNotification(true);
            setNotificationMsg(`eCommittee form submission failed. 
              ${data.statusMessage}`);
          }
        })
        .catch((err) => {
          console.error(err, "Error submitting form");
          setShowNotification(true);
          setNotificationMsg(err);
        });
    } catch (error) {
      console.error("Error submitting form:", error);
      setShowNotification(true);
      setNotificationMsg(error);
    }
    // }
    setIsLoading(false);
    setVisible(!visible);
  };

  //Submit handler helps to vlidate mandatory fields and prompt confirm dailog
  const handleOpenDialog = async () => {
    let isApproverValid =
      noteapproverData.find((x) => x.approverEmail === accounts[0].username) !==
      undefined;
    let isReviewerValid =
      notereviewerData.find((x) => x.approverEmail === accounts[0].username) !==
      undefined;

    if (!userDepartment) {
      setShowNotification(true);
      setNotificationMsg(
        "User department cannot be blank. Please contact system administrator."
      );
      return;
    }


    // if (noteapproverData.length === 0) {
    //   setShowNotification(true);
    //   setNotificationMsg(
    //     "Approvers cannot be blank. Please add approvers to submit request."
    //   );
    //   return;
    // }

    // if (isApproverValid || isReviewerValid) {
    //   setShowNotification(true);
    //   setNotificationMsg("Login user cannont be part of Approvers/Reviewers.");
    //   return;
    // }

    const errors = validateForm(isApproverValid, isReviewerValid);
    if (Object.keys(errors).length === 0) {
      setVisible(!visible);
    }
  };

  // Handle close dialog
  const handleCloseDialog = async () => {
    setVisible(!visible);
  };

  // Handle close save dialog
  const handleSaveClose = async () => {
    setVisibleSave(false);
  };

  // Handle close   validation dialog
  const handleClosevalidationDialog = async () => {
    setValidationErrors(false);
  };

  //It helps to validate and convert to Base64 to attach documents - Word Info
  const convertBase64Word = () => {
    var selectedFile = document.getElementById("WordDocfile").files;
    let cstWarningMsg = "";
    let isValidFile = true;
    if (selectedFile.length > 0) {
      var fileExtension = selectedFile[0].name.split(".");
      const fileName = selectedFile[0].name;

      if (
        !(
          fileName.toLowerCase().endsWith("docx") ||
          fileName.toLowerCase().endsWith("doc")
        )
      ) {
        cstWarningMsg = "File type not allowed";
        isValidFile = false;
      }

      /* Bug -396 
  *For Note pdf the maximum allowed size should be decreased from 25 MB to 10 MB.
  25 mb = 26214400
  10 mb = 10485760
   */
      if (selectedFile[0].size > 10485760) {
        cstWarningMsg = "File size should not exceed more then 10 MB";
        isValidFile = false;
      }
      if (checkingSpl(selectedFile[0].name)) {
        isValidFile = false;
        cstWarningMsg = "File name sholud not contain special characters";
      }

      if (isValidFile) {
        var fileToLoad = selectedFile[0];
        // FileReader function for read the file.
        var fileReader = new FileReader();
        // Onload of file read the file content
        fileReader.onload = function (fileLoadedEvent) {
          // let base64 = fileLoadedEvent.target.result;
          // const RemovedHeaderFormBase64 = base64.split(",");
          let base64 = fileLoadedEvent.target.result;
          const RemovedHeaderFormBase64 = base64.split(",")[1];
  
          const partLength = Math.ceil(RemovedHeaderFormBase64.length / 10);
          const parts = [];
  
          for (let i = 0; i < 10; i++) {
            parts.push(RemovedHeaderFormBase64.slice(i * partLength, (i + 1) * partLength));
          }
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            wordInfo: {
              fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
              fileName: selectedFile[0].name,
              // filePath: RemovedHeaderFormBase64[1],
              filePath: {
                part1: parts[0],
                part2: parts[1],
                part3: parts[2],
                part4: parts[3],
                part5: parts[4],
                part6: parts[5],
                part7: parts[6],
                part8: parts[7],
                part9: parts[8],
                part10: parts[9]
              },
              isValid: isValidFile,
              warningMsg: cstWarningMsg,
            },
          });
        };
        // Convert data to base64
        fileReader.readAsDataURL(fileToLoad);
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: null,
            isValid: isValidFile,
            warningMsg: cstWarningMsg,
          },
        });
      }
    }
  };

  //It helps to validate and convert to Base64 to attach documents - PDF Info
  const convertPDFToBase64 = () => {
    var selectedFile = document.getElementById("PDFDocfile").files;
    let cstWarningMsg = "";
    let isValidFile = true;
    if (selectedFile.length > 0) {
      var fileExtension = selectedFile[0].name.split(".");
      const fileNname = selectedFile[0].name
      if (!(fileNname.toLowerCase().endsWith("pdf"))) {
        cstWarningMsg = "File type not allowed";
        isValidFile = false;
      }
      /* Bug -396 
    *For Note pdf the maximum allowed size should be decreased from 25 MB to 10 MB.
    25 mb = 26214400
    10 mb = 10485760
     */

      else if (checkingSpl(selectedFile[0].name)) {
        isValidFile = false;
        cstWarningMsg = "File name sholud not contain special characters";
      }
      else if (selectedFile[0].size > 10485760) {
        cstWarningMsg = "File size should not exceed more then 10 MB";
        isValidFile = false;
      }

      if (isValidFile) {
        var fileToLoad = selectedFile[0];
        // FileReader function for read the file.
        var fileReader = new FileReader();
        // Onload of file read the file content
        fileReader.onload = function (fileLoadedEvent) {
          // let base64 = fileLoadedEvent.target.result;
          // const RemovedHeaderFormBase64 = base64.split(",");
          let base64 = fileLoadedEvent.target.result;
          const RemovedHeaderFormBase64 = base64.split(",")[1];
  
          const partLength = Math.ceil(RemovedHeaderFormBase64.length / 10);
          const parts = [];
  
          for (let i = 0; i < 10; i++) {
            parts.push(RemovedHeaderFormBase64.slice(i * partLength, (i + 1) * partLength));
          }
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            PDFInfo: {
              fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
              fileName: selectedFile[0].name,
              // filePath: RemovedHeaderFormBase64[1],
              filePath: {
                part1: parts[0],
                part2: parts[1],
                part3: parts[2],
                part4: parts[3],
                part5: parts[4],
                part6: parts[5],
                part7: parts[6],
                part8: parts[7],
                part9: parts[8],
                part10: parts[9]
              },
              isValid: isValidFile,
              warningMsg: cstWarningMsg,
            },

          });
        };
        // Convert data to base64
        fileReader.readAsDataURL(fileToLoad);
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          PDFInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: null,
            isValid: isValidFile,
            warningMsg: cstWarningMsg,
          },

        });
      }
    }
  };

  //Helps to validate multiple docs - Support documents
  const checkingSpl = (test) => {
    var specialCharPattern = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;

    // Test the input string against the pattern
    return specialCharPattern.test(test);
  };

  //It helps to validate and attach documents - support documents
  // const multipleDocUpload = () => {
  //   let waringmsg = "";
  //   let isValidFile = true;
  //   const arrayExtension = [
  //     // ".png",
  //     // ".jpg",
  //     ".pdf",
  //     ".doc",
  //     ".docx",
  //     ".xlsx",
  //     ".PDF",
  //     ".DOC",
  //     ".DOCX",
  //     ".XLSX",
  //     // ".eml",
  //   ];
  //   let reamingFileSize = 26214400;
  //   let totalFileSize = 0;
  //   const inValidFileNames = Object.keys(supportDocWarning).filter(
  //     (fileName) => supportDocWarning[fileName]?.isValid === false
  //   );
  //   // filter valid files only if()
  //   if (filesInfo.length > 0) {
  //     const vaildMultiplefile = filesInfo.filter(obj => {
  //       if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
  //         return obj;
  //       }
  //     });
  //     vaildMultiplefile.map(obj =>
  //       reamingFileSize = reamingFileSize - obj.supportingDocumentPathLength
  //     );
  //   }
  //   const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
  //   const selectedFile = document.getElementById("multiDoc").files;
  //   const TempfileInfo = filesInfo;

  //   const promises = [];
  //   const fileCount = selectedFile.length;

  //   for (let i = 0; i < fileCount; i++) {
  //     const fileToLoad = selectedFile[i];
  //     const fileExtession = fileToLoad.name.split(".");

  //     // Check for special characters in the filename
  //     if (!filesInfo?.some(obj => obj.supportingDocumentFileName === fileToLoad.name)) {
  //       if (
  //         !arrayExtension.includes(`.${fileExtession[fileExtession.length - 1]}`)
  //       ) {
  //         isValidFile = false;
  //         waringmsg = "File type is not allowed";
  //         SetSupportDocWarning({
  //           ...supportDocWarning,
  //           [fileToLoad.name]: {
  //             filename: fileToLoad.name,
  //             isValid: true,
  //             warningMsg: waringmsg,
  //             fileExtnsion: fileExtession[fileExtession.length - 1],
  //           },
  //         });
  //         // return;
  //       }

  //       else if (validname.test(fileToLoad.name)) {
  //         isValidFile = false;
  //         waringmsg = "File name should not contain special characters";
  //         SetSupportDocWarning({
  //           ...supportDocWarning,
  //           [fileToLoad.name]: {
  //             filename: fileToLoad.name,
  //             isValid: true,
  //             warningMsg: waringmsg,
  //             fileExtnsion: fileExtession[fileExtession.length - 1],
  //           },
  //         });
  //       }

  //       // Check if the file type is allowed
  //       /*  if (
  //          !arrayExtension.includes(`.${fileExtession[fileExtession.length - 1]}`)
  //        ) {
  //          isValidFile = false;
  //          waringmsg = "File type is not allowed";
  //          SetSupportDocWarning({
  //            ...supportDocWarning,
  //            [fileToLoad.name]: {
  //              filename: fileToLoad.name,
  //              isValid: true,
  //              warningMsg: waringmsg,
  //              fileExtnsion: fileExtession[fileExtession.length - 1],
  //            },
  //          });
  //          // return;
  //        }
  //   */
  //       // Check file size (5MB limit)
  //       /* File size increse 5mb to 25MB */
  //       /*   25 mb = 26214400
  //         10 mb = 10485760 */
  //       else if (fileToLoad.size > reamingFileSize) {
  //         isValidFile = false;
  //         waringmsg = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
  //         setSupportingError(waringmsg)
  //         // isValidFile = false;
  //         /*  SetSupportDocWarning({
  //            ...supportDocWarning,
  //            [fileToLoad.name]: {
  //              filename: fileToLoad.name,
  //              isValid: true,
  //              warningMsg: "",
  //              fileExtnsion: fileExtession[fileExtession.length - 1],
  //            },
  //          }); */
  //         // return;
  //       }

  //       const fileReader = new FileReader();
  //       const promise = new Promise((resolve) => {
  //         fileReader.onload = function (fileLoadedEvent) {
  //           const base64 = fileLoadedEvent.target.result.split(",")[1];
  //           const partLength = Math.ceil(base64.length / 10);
  //           const parts = [];
  //           for (let j = 0; j < 10; j++) {
  //             parts.push(base64.slice(j * partLength, (j + 1) * partLength));
  //           }
  //           resolve({
  //             name: fileToLoad.name,
  //             base64: fileLoadedEvent.target.result,
  //             size: fileToLoad.size
  //           });
  //         };
  //       });

  //       fileReader.readAsDataURL(fileToLoad);
  //       promises.push(promise);


  //       Promise.all(promises)
  //         .then((fileDataArray) => {
  //           const updatedTempFileInfo = fileDataArray.reduce(
  //             (acc, fileData) => {
  //               const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
  //               if (!ObjExist.includes(fileData.name)) {
  //                 acc.push({
  //                   noteSupportingDocumentId: 0,
  //                   noteId: 0,
  //                   supportingDocumentPath: fileData.base64.split(",")[1],
  //                   supportingDocumentFileName: fileData.name,
  //                   createdDate: new Date(),
  //                   createdBy: accounts[0].username,
  //                   modifiedDate: new Date(),
  //                   modifiedBy: accounts[0].username,
  //                   supportingDocumentPathPart1: fileData.parts[0],
  //                   supportingDocumentPathPart2: fileData.parts[1],
  //                   supportingDocumentPathPart3: fileData.parts[2],
  //                   supportingDocumentPathPart4: fileData.parts[3],
  //                   supportingDocumentPathPart5: fileData.parts[4],
  //                   supportingDocumentPathPart6: fileData.parts[5],
  //                   supportingDocumentPathPart7: fileData.parts[6],
  //                   supportingDocumentPathPart8: fileData.parts[7],
  //                   supportingDocumentPathPart9: fileData.parts[8],
  //                   supportingDocumentPathPart10: fileData.parts[9],
  //                   supportingDocumentPathLength: fileData.size
  //                 });
  //               }
  //               return acc;
  //             },
  //             [...TempfileInfo]
  //           );

  //           SetFileinfo(updatedTempFileInfo);
  //         })
  //         .catch((error) => {
  //           console.error("Error reading files:", error);
  //         });
  //     }
  //   }
  // };
  const multipleDocUpload = () => {
    let isValidFile = true;
    let waringmsg = "";
    let reamingFileSize = 26214400;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
  
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.forEach(obj => 
        reamingFileSize -= obj.supportingDocumentPathLength
      );
    }

    const arrayExtension = [
      ".pdf", ".doc", ".docx", ".xlsx",
      ".PDF", ".DOC", ".DOCX", ".XLSX"
    ];
    const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
    const selectedFile = document.getElementById("multiDoc").files;
    const TempfileInfo = filesInfo;
  
    const promises = [];
    const fileCount = selectedFile.length;
  
    for (let i = 0; i < fileCount; i++) {
      const fileToLoad = selectedFile[i];
      const fileExtession = fileToLoad.name.split(".");
  
      if (!filesInfo?.some(obj => obj.supportingDocumentFileName === fileToLoad.name)) {
        if (!arrayExtension.includes(`.${fileExtession[fileExtession.length - 1]}`)) {
          isValidFile = false;
          waringmsg = "File type is not allowed";
          SetSupportDocWarning({
            ...supportDocWarning,
            [fileToLoad.name]: {
              filename: fileToLoad.name,
              isValid: true,
              warningMsg: waringmsg,
              fileExtnsion: fileExtession[fileExtession.length - 1],
            },
          });
        } else if (validname.test(fileToLoad.name)) {
          isValidFile = false;
          waringmsg = "File name should not contain special characters";
          SetSupportDocWarning({
            ...supportDocWarning,
            [fileToLoad.name]: {
              filename: fileToLoad.name,
              isValid: true,
              warningMsg: waringmsg,
              fileExtnsion: fileExtession[fileExtession.length - 1],
            },
          });
        } else if (fileToLoad.size > reamingFileSize) {
          isValidFile = false;
          waringmsg = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
          setSupportingError(waringmsg);
        }
      }
  
      const fileReader = new FileReader();
  
      const promise = new Promise((resolve) => {
        fileReader.onload = function (fileLoadedEvent) {
          const base64 = fileLoadedEvent.target.result.split(",")[1];
          const partLength = Math.ceil(base64.length / 10);
          const parts = [];
          for (let j = 0; j < 10; j++) {
            parts.push(base64.slice(j * partLength, (j + 1) * partLength));
          }
  
          resolve({
            name: fileToLoad.name,
            parts: parts,
            size: fileToLoad.size
          });
        };
      });
  
      fileReader.readAsDataURL(fileToLoad);
      promises.push(promise);
    }
  
    Promise.all(promises)
      .then((fileDataArray) => {
        const updatedTempFileInfo = fileDataArray.reduce((acc, fileData) => {
          const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
          if (!ObjExist.includes(fileData.name)) {
            acc.push({
              noteSupportingDocumentId: 0,
              noteId: 0,
              supportingDocumentFileName: fileData.name,
              createdDate: new Date(),
              createdBy: accounts[0].username,
              modifiedDate: new Date(),
              modifiedBy: accounts[0].username,
              supportingDocumentPathPart1: fileData.parts[0],
              supportingDocumentPathPart2: fileData.parts[1],
              supportingDocumentPathPart3: fileData.parts[2],
              supportingDocumentPathPart4: fileData.parts[3],
              supportingDocumentPathPart5: fileData.parts[4],
              supportingDocumentPathPart6: fileData.parts[5],
              supportingDocumentPathPart7: fileData.parts[6],
              supportingDocumentPathPart8: fileData.parts[7],
              supportingDocumentPathPart9: fileData.parts[8],
              supportingDocumentPathPart10: fileData.parts[9],
              supportingDocumentPathLength: fileData.size
            });
          }
          return acc;
        }, [...TempfileInfo]);
  
        SetFileinfo(updatedTempFileInfo);
      })
      .catch((error) => {
        console.error("Error reading files:", error);
      });
  };

  /* Add Reviewers and Approvers Data */
  const handleComboChangeReviewer = (event) => {
    setSelectedReviewer(event.value);
  };

  // Handle Approver change 
  const handleComboChangeApprover = (event) => {
    setComboValueApprover(event.value);
  };

  //Helps to add selected reviewer to the reviewers table
  const handleAddRow = async () => {
    if (!selectedReveiwer) {
      setShowNotification(true);
      setNotificationMsg("Please select reviewer then click on Add.");
      return;
    }


    //Removed this function due to loading impact users will be filtered on search box enter - 22/03
    // setOrgEmployees(approveremailsObject);

    let isApproverValid =
      noteapproverData.find(
        (x) => x.approverEmail === selectedReveiwer.userPrincipalName
      ) === undefined;
    let isReviewerValid =
      notereviewerData.find(
        (x) => x.approverEmail === selectedReveiwer.userPrincipalName
      ) === undefined;

    if (
      isApproverValid &&
      isReviewerValid &&
      selectedReveiwer.userPrincipalName !== accounts[0].username &&
      selectedReveiwer.userPrincipalName !== state.createdBy
    ) {
      const newRow = {
        approverType: 1,
        approverEmail: selectedReveiwer.userPrincipalName,
        approverOrder: notereviewerData.length + 1,
        approverStatus: 1,
        // Bug fix - 294 - 27/03
        srNo: selectedReveiwer.srNo,
        designation: selectedReveiwer.jobTitle,
        approverEmailName: selectedReveiwer.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
      };
      setNoteReviewerData((prevData) => [...prevData, newRow]);

    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected reviewer cannont be same as existing Reviewers/Requester/CurrentActioner."
      );
    }
    setSelectedReviewer(null);
    setOrgEmployees([]);
  };

  // Change -13/05 added dropdown for department user will select department name 
/*   const handleSelectedDepartment = (event) => {
    setSelectedDepartment(event.target.value);
    // on departmet change  call getDefaultConfigApprovers function and update userDepartment
    setUserDepertment(event.target.value);
    getDefaultConfigApprovers(event.target.value);
    setDepartmentBorderColor("");
  } */
  //Helps to custom render Multi column dropdown options
  /*const orgUsersPplPickerItemRender = (li, props) => {
    const children = orgUsersPplPickerColumnMapping.map((col, i) => {
      if (col.field === "department") {
        return (
          <span
            className="k-table-td"
            style={{
              width: col.width,
            }}
            key={col.width + i}
          >
            {props.dataItem[col.field] === null
              ? "NA"
              : props.dataItem[col.field]}
          </span>
        );
      } else if(col.field === "jobTitle") {
        return (
          <span
            className="k-table-td"
            style={{
              width: col.width,
            }}
            key={col.width + i}
          >
            {props.dataItem[col.field] === null ? "NA" : props.dataItem[col.field]}
          </span>
        );
      } else {
        return <span
          className="k-table-td"
          style={{
            width: col.width,
          }}
          key={col.width + i}
        >
          {props.dataItem[col.field]}
        </span>
      }
    });
    return React.cloneElement(
      li,
      {
        ...li.props,
      },
      children
    );
  };*/

// Handle open reveiwer combo options  
  const handleOpenReveiwer = () => {
    if (!selectedReveiwer) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(selectedReveiwer.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  // Handle open approver combo options
  const handleOpenApprover = () => {
    if (!combovalueApprover) {
      setOrgEmployees([]);
    } else {
      const filteredUsers = allOrgUsers.filter(user => 
        user.displayName.toLowerCase().includes(combovalueApprover.displayName.toLowerCase())
      );
      setOrgEmployees(filteredUsers);
    }
  }

  //Helps to add selected approver to the approvers table
  const handleAddRowApprover = async () => {
    if (!combovalueApprover) {
      setShowNotification(true);
      setNotificationMsg("Please select approver then click on Add.");
      return;
    }

    //Removed this function due to loading impact users will be filtered on search box enter - 22/03
    // setOrgEmployees(approveremailsObject);

    let isApproverValid =
      noteapproverData.find(
        (x) => x.approverEmail === combovalueApprover.userPrincipalName
      ) === undefined;
    let isReviewerValid =
      notereviewerData.find(
        (x) => x.approverEmail === combovalueApprover.userPrincipalName
      ) === undefined;

    if (
      isApproverValid &&
      isReviewerValid &&
      combovalueApprover.userPrincipalName !== accounts[0].username &&
      combovalueApprover.userPrincipalName !== state.createdBy
    ) {

      const newRow = {
        approverType: 2,
        approverEmail: combovalueApprover.userPrincipalName,
        approverOrder: noteapproverData.length + 1,
        approverStatus: 1,
        // Bug fix - 294 - 27/03
        srNo: combovalueApprover.srNo,
        designation: combovalueApprover.jobTitle,
        approverEmailName: combovalueApprover.displayName,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
      };
      setNoteApproverData((prevData) => [...prevData, newRow]);

      let upApprObj = [...noteapproverData, newRow];
      if (upApprObj?.length > 0) {
        const secretaryValChk = await findSecrateries(
          upApprObj,
          userDepartment
        );
        if (!secretaryValChk) {
          SetWordPDFInfowarring({
            ...wordandPdfWarring,
            wordInfo: {
              fileExtension: "",
              fileName: "",
              filePath: "",
              isValid: false,
            },
          });
        }
      } else {
        SetWordPDFInfowarring({
          ...wordandPdfWarring,
          wordInfo: {
            fileExtension: "",
            fileName: "",
            filePath: "",
            isValid: false,
          },
        });
      }
    } else {
      setShowNotification(true);
      setNotificationMsg(
        "The selected approver cannont be same as existing Reviewers/Requester/CurrentActioner."
      );
    }
    setComboValueApprover(null);
    setOrgEmployees([]);
  };

  //It helps to remove Word/PDF attachments
  const onRemoveAttachmentWarning = (key) => {
    if (key === "PDFInfo") {
      SetWordPDFInfowarring({
        ...wordandPdfWarring,
        [key]: { fileExtension: "", fileName: "", isValid: false },
      });
    }
    if (key === "wordInfo") {
      SetWordPDFInfowarring({
        ...wordandPdfWarring,
        [key]: { fileExtension: "", fileName: "", isValid: false },
      });
    }
  };

  //Helps to attache icon based on file extension
  const getFileIcon = (filename) => {
    const fileSplit = filename.split(".");
    const extnsion = `.${fileSplit[fileSplit.length - 1]}`;
    const fileExtension = extnsion.toLowerCase();
    let fileType = fileIcon;
    if (fileExtension === ".pdf") {
      fileType = filePdfIcon;
    }
    if (fileExtension === ".doc" || fileExtension === ".docx") {
      fileType = fileWordIcon;
    }
    if (fileExtension === ".png" || fileExtension === ".jpg") {
      fileType = fileImageIcon;
    }
    if (fileExtension === ".txt") {
      fileType = fileTxtIcon;
    }
    if (fileExtension === ".xlsx") {
      fileType = fileDataIcon;
    }
    return fileType;
  };

  // remove multiple attchemnts - support documents
  const onRemoveMultiAttachment = (id) => {
    const filename = filesInfo.find((obj, index) => index === id).supportingDocumentFileName;
    delete supportDocWarning[filename];
    SetSupportDocWarning(supportDocWarning);
    let reamingFileSize = 26214400;
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map((obj, index) => {
        if (index !== id) {
          totalFileSize = totalFileSize + obj.supportingDocumentPathLength
        }
      }

      );

      if (totalFileSize <= 26214400) {
        setSupportingError("");
      }
    }
    SetFileinfo(filesInfo.filter((obj, ind) => ind !== id));
  };

  const [orgEmployees, setOrgEmployees] = React.useState(approverEmailsList);

  //Helps to filter the people picker dropdown vaules

  const pplFilterMultiColumn = async (event) => {

    //Removed this function due to loading impact users will be filtered on search box enter - 22/03
    /*let enteredVal = event.filter.value;
    const filteredObj = approveremailsObject.filter((x, i) => {
      return (
        x["department"].toLowerCase().includes(enteredVal.toLowerCase()) ||
        x["displayName"].toLowerCase().includes(enteredVal.toLowerCase()) ||
        x["jobTitle"].toLowerCase().includes(enteredVal.toLowerCase()) ||
        x["userPrincipalName"].toLowerCase().includes(enteredVal.toLowerCase())
      );
    });
    setOrgEmployees(filteredObj); */
    //Added  ----------------- 22/03 --------------------
    if (event.filter.value.length >= 4) {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            return { ...x, department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName, srNo: x.srNo === null ? "NA" : x.srNo }
          });
          setOrgEmployees(orgUsers);
          setAllOrgUsers(orgUsers);
        })
        .catch((err) => {
          setOrgEmployees([]);
          console.log(err);
        });


    }
    else {
      setOrgEmployees([]);
    }

    //Added  ----------------- 22/03 --------------------
  };

  //HTML - render
  return (
    <div>
      <Navbar header="IB Smart Office - eCommittee" />
      <Sidebar />
      {/* {isNewForm || (!isNewForm && ((state.status === 1 || state.status === 4 ||state.status === 8 ) && state.createdBy === accounts[0].username)) ? */}
      <div className="FormMaincontainer">
        <div className="container">
          <div className="HeaderButtonsContainer row">
            <div className="cstformHdrLeftContainer mobileTitleNewForm">
              {isNewForm ? "" : `Status: ${state.statusMsg}`}
            </div>
            <div className="cstformHdrMiddleContainer mobileTitleNewForm">
              eCommittee Note - {isNewForm ? "New" : state.noteId}
            </div>
            <div className="cstformHdrRightContainer mobileTitleNewForm">
              {isNewForm ? (
                <span>
                  Date:{" "}
                  <Clock
                    format={"DD-MM-YYYY HH:mm:ss A"}
                    ticking={true}
                    timezone={"Asia/Kolkata"}
                  />
                </span>
              ) : (
                `Created: ${state.createdDate}`
              )}
            </div>
          </div>
        </div>
        <div className="container">
          <Form
            render={() => (
              <FormElement>
                <fieldset className={"k-form-fieldset"}>
                  <div className="errorMsg">All fields marked "*" are mandatory</div>
                  <div className="SectionHeads row">General Section</div>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Department:
                            <span className="required-asterisk">*</span>
                          </Label>
                           {userDepartment && (
                            <Field
                              component={Input}
                              name="Department"
                              value={state.Department}
                              defaultValue={userDepartment}
                              readOnly
                              className="_departmentfieldStyle"
                            />
                          )} 
                          {/* Removing this field  and added dropdown -13/05*/}
                          {/* <DropDownList
                            data={departmentList.map((x) => x.departmentName)}
                            // defaultItem={"Select"}
                            onChange={handleSelectedDepartment}
                            value={userDepartment}
                            name="DepartMent"
                            // required={true}
                            style={{ borderColor: departmentBorderColor }}
                            valueRender={element => valueRenderDepartment(element, userDepartment)}
                          /> */}
                        </div>
                        <div className="errorMsg">{departmentError}</div>
                      </FieldWrapper>
                    </div>

                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Committee Name:
                            <span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            data={committeeNameDropDown.map((x) => x.dValue)}
                            defaultItem={"Select"}
                            onChange={handleCommitteeName}
                            value={state.committeeName}
                            name="committeName"
                            // required={true}
                            style={{ borderColor: noteBorderColor }}
                            valueRender={element => valueRender(element, state.committeeName, 'committeeName')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Subject:<span className="required-asterisk">*</span>
                          </Label>
                          <TextArea
                            maxLength={max}
                            onChange={handleSubjectChange}
                            value={state.Subject}
                            rows={1}
                            style={{ borderColor: subjectBorderColor }}
                             className="mobileFieldHeight"
                          />
                          <Hint direction={"end"}>
                            {state.Subject.length} / {max}
                          </Hint>
                        </div>
                      </FieldWrapper>
                    </div>
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Nature of Note:
                            <span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            name="NatureOfNote"
                            data={natureofnote.map((x) => x.dValue)}
                            // defaultItem={"Select"}
                            value={state.NatureOfNote}
                            onChange={handleNatureOfNoteChange}
                            style={{ borderColor: natureofnoteBorderColor }}
                            valueRender={element => valueRender(element, state.NatureOfNote, 'NatureOfNote')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    {showNatureOfApprSanc && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Nature of Approval/Sanction:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              name="NatureOfApprSanc"
                              value={state.NatureOfApprSanc}
                              data={natureofapprsanc.map((x) => x.dValue)}
                              // defaultItem={"Select"}
                              onChange={handleNatureOfApprSancChange}
                              style={{
                                borderColor: natureofapprsancBorderColor,
                              }}
                              valueRender={element => valueRender(element, state.NatureOfApprSanc, 'NatureOfApprSanc')}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Note Type:
                            <span className="required-asterisk">*</span>
                          </Label>
                          <DropDownList
                            data={notetype.map((x) => x.dValue)}
                            value={state.NoteType}
                            // defaultItem={"Select"}
                            onChange={handleNoteType}
                            style={{ borderColor: notetypeBorderColor }}
                            valueRender={element => valueRender(element, state.NoteType, 'NoteType')}
                          />
                        </div>
                      </FieldWrapper>
                    </div>
                    {showTypeOfFinNote && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Type of Financial Note:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              data={fintype.map((x) => x.dValue)}
                              value={state.TypeOfFinNote}
                              // defaultItem={"Select"}
                              onChange={handleTypeOfFin}
                              style={{ borderColor: typeoffinBorderColor }}
                              valueRender={element => valueRender(element, state.TypeOfFinNote, 'TypeOfFinNote')}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {showAmount && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Amount:
                              <span className="required-asterisk">*</span>
                            </Label>
                            {/* Bug fix - 297 - 27/03 */}
                            {/* <NumericTextBox
                              // format="n2"
                              onChange={handleAmount}
                              value={amount}
                              defaultValue={amount}
                              style={{ borderColor: amountBorderColor }}
                            /> */}
                            <Input
                              value={amount}
                              onChange={handleAmount}
                              defaultValue={amount}
                              style={{ borderColor: amountBorderColor }}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    <div className="col-md-6">
                      <FieldWrapper>
                        <div className="k-form-field-wrap">
                          <Label className="k-form-label">
                            Search Text:
                            <span className="required-asterisk">*</span>
                          </Label>
                          <TextArea
                            maxLength={max}
                            // value={value}
                            value={state.Search}
                            onChange={handleSearchChange}
                            rows={1}
                            style={{ borderColor: searchBorderColor }}
                             className="mobileFieldHeight"
                          />
                          <Hint direction={"end"}>
                            {state.Search.length} / {max}
                          </Hint>
                        </div>
                      </FieldWrapper>
                    </div>
                    {showPurpose && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Purpose:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <Input
                              // component={Input}
                              value={purpose}
                              name="Purpose"
                              // defaultValue={purpose}
                              // key={state.Purpose}
                              onChange={handlePurpose}
                              style={{ borderColor: purposeBorderColor }}
                               className="mobileFieldHeight"
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {showPurpose1 && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Purpose:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              data={drpOptPurposeApproval.map((x) => x.dValue)}
                              // defaultItem={"Select"}
                              value={state.PurposeApproval}
                              onChange={handlePurposeApproval}
                              style={{ borderColor: purpose1BorderColor }}
                              valueRender={element => valueRender(element, state.PurposeApproval, 'PurposeApproval')}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {showPurpose2 && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Purpose:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <DropDownList
                              data={drpOptPurposeInformation.map(
                                (x) => x.dValue
                              )}
                              // defaultItem={"Select"}
                              value={state.PurposeInformation}
                              onChange={handlePurposeInformation}
                              style={{ borderColor: purpose2BorderColor }}
                              valueRender={element => valueRender(element, state.PurposeInformation, 'PurposeInformation')}
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                    {(showPurpose1 && purpose === "Others") && (
                      <div className="col-md-6">
                        <FieldWrapper>
                          <div className="k-form-field-wrap">
                            <Label className="k-form-label">
                              Others:
                              <span className="required-asterisk">*</span>
                            </Label>
                            <Input
                              // component={Input}
                              value={purposeOthers}
                              name="PurposeOthers"
                              // defaultValue={purpose}
                              // key={state.Purpose}
                              onChange={handlePurposeInfoOthers}
                              style={{ borderColor: purposeOthersBorderColor }}
                               className="mobileFieldHeight"
                            />
                          </div>
                        </FieldWrapper>
                      </div>
                    )}
                  </div>

                  <div className="SectionHeads row">Approver Details</div>
                  <div className="SectionRow row">
                    <div
                 className="_approverDeatilsTable"
                    >

                      <MultiColumnComboBox
                        data={orgEmployees}
                        filterable={true}
                        // columns={orgUsersPplPickerColumnMapping}
                        columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                        // textField={"displayName"}
                        value={
                          selectedReveiwer === null
                            ? null
                            : selectedReveiwer.displayName
                        }
                        // itemRender={orgUsersPplPickerItemRender}
                        onFilterChange={pplFilterMultiColumn}
                        onChange={handleComboChangeReviewer}
                        onOpen={handleOpenReveiwer}
                        style={{ width: isMobile ? "100%" : "300px",marginRight: "5px", }} // Adjust width
                        placeholder="Add Reviewer..."
                      />
                      <Button onClick={handleAddRow}>
                        {" "}
                        <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn arrow-color"></span>
                        Add
                      </Button>
                    </div>
                    {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                    <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                    <div className="cstDisableGridScroll">
                      {/* added scroll class 24/04 */}
                      <TableDraggableRows
                        //Change - Adding SR No - 05/04 - RK 
                        srCol="SR No"
                        // Change - Adding Designation- 05/04 - RK 
                        designationCol="Designation"
                        typeOfTable="Reviewer"
                        data={notereviewerData}
                        onDelate={deletereviewer}
                        onOrderChange={orderChange}
                        field="approverEmailName"
                        formType="committeeform" />
                    </div>
                    <div
                className="_approverDeatilsTable"
                    >

                    </div>
                    <div
                 className="_approverDeatilsTableReviewer"
                    >

                      <MultiColumnComboBox
                        data={orgEmployees}
                        filterable={true}
                        // columns={orgUsersPplPickerColumnMapping}
                        columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                        // textField={"displayName"}
                        value={
                          combovalueApprover === null
                            ? null
                            : combovalueApprover.displayName
                        }
                        // itemRender={orgUsersPplPickerItemRender}
                        onFilterChange={pplFilterMultiColumn}
                        onChange={handleComboChangeApprover}
                        onOpen={handleOpenApprover}
                        style={{ width: isMobile ? "100%" : "300px",marginRight: "5px", }} // Adjust width
                        placeholder="Add Approver..."
                      />
                      <Button onClick={handleAddRowApprover}>
                        {" "}
                        <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn arrow-color"></span>
                        Add
                      </Button>
                    </div>
                    {/* Added this message based on change happend due to loading impact users will be filtered on search box enter - 22/03 */}
                    <div className="cstUserSearchMsg">(Please enter minimum 4 characters to search)</div>
                    <div className="cstDisableGridScroll">
                      {/* added scroll class 24/04 */}
                      <TableDraggableRows
                        //Change - Adding SR No - 05/04 - RK 
                        srCol="SR No"
                        // Change - Adding Designation- 05/04 - RK 
                        designationCol="Designation"
                        typeOfTable="Approver"
                        data={noteapproverData}
                        onDelate={deletereviewer}
                        onOrderChange={orderChange}
                        field="approverEmailName"
                        formType="committeeform" />
                    </div>

                  </div>
                  {/* Added comments --> Kavya(28-08) */}
                  {(!isNewForm && state.status === enumsObj?.NoteStatus.find(x => x.dValue === "Returned").id) &&
                    (<div>
                      <div className="SectionHeads eNoteAtrFormHdr row">
                        Comments
                      </div>
                      <div className="SectionRow row">
                      <div className="table-responsive">
                        <table className="SectionRow cstATRFormTbl tableStyle" style={{ width: "100%" }}>
                          <tr>
                            <th className="approvalform-tableCol-width-1">Page#</th>
                            <th className="approvalform-tableCol-width-1">Doc Reference</th>
                            <th className="approvalform-tableCol-width-5">Comments</th>
                            <th className="approvalform-tableCol-width-3">Comment By</th>
                          </tr>
                          {noteComments?.map((comment) => (
                            <tr key={comment.noteApproverCommentID}>
                              <td className="approvalform-tableCol-width-1">{comment.pageNumber}</td>
                              <td className="approvalform-tableCol-width-1">{comment.docReferrence}</td>
                              <td className="approvalform-tableCol-width-5">{comment.comments}</td>
                              <td className="approvalform-tableCol-width-3">{comment.createdBy}</td>
                            </tr>
                          )
                          )}
                        </table>
                      </div>
                      </div>
                    </div>
                    )}
                  <div className="SectionHeads row">File Attachments</div>
                  <div className="SectionRow row">
                    <div className="col-md-6">
                      {" "}
                      <Label className="k-form-label">
                        Note PDF<span className="required-asterisk">*</span>
                      </Label>
                      {/* <Upload batch={false} onBeforeUpload={onBeforeUpload} restrictions={{ allowedExtensions: [".pdf"], maxFileSize: 26214400, }} multiple={false} defaultFiles={[]} withCredentials={false} accept="string"  saveUrl={'https://indianbankxenciaapp.azurewebsites.net/api/ENote/AddNote'}/> */}
                      <div className="Attachemntfileinfo-ind">
                        <input
                          type="file"
                          id="PDFDocfile"
                          onChange={convertPDFToBase64}
                          style={{ width: "100px" }}
                        />
                      </div>
                      {wordandPdfWarring?.PDFInfo.fileName === null ||
                        wordandPdfWarring?.PDFInfo.fileName === "" ? null : (
                        <div className="Attachemntfileinfo-ind">
                          <span className="attachemntIconInfoConationer">
                            <span className="AttchemntIconWraper">
                              <SvgIcon
                                icon={getFileIcon(
                                  wordandPdfWarring?.PDFInfo.fileName
                                )}
                                size="xxlarge"
                              />
                              <span className="attachemnrt-warningifoConatiner">
                                <div className="attachemnrt-warningifo-fileinfo">
                                  {wordandPdfWarring?.PDFInfo.fileName}
                                </div>
                                <span
                               className="inCorrectFileError"
                                >
                                  {wordandPdfWarring?.PDFInfo.warningMsg}
                                </span>
                              </span>
                            </span>
                            <span
                              className="AttchemntIconWraperCancel"
                              onClick={() =>
                                onRemoveAttachmentWarning("PDFInfo")
                              }
                            >
                              X
                            </span>
                          </span>
                        </div>
                      )}
                      <div className="_fileFormatHintMsg">
                        Allowed only one PDF. Up to 10MB max.
                      </div>
                    </div>
                    {noteapproverData?.length > 0 && isSecretaryExist && (
                      <div className="col-md-6">
                        <Label className="k-form-label">
                          Word Document
                          <span className="required-asterisk">*</span>
                        </Label>

                        <div className="Attachemntfileinfo-ind">
                          {" "}
                          <input
                            type="file"
                            id="WordDocfile"
                            onChange={convertBase64Word}
                            style={{ width: "100px" }}
                          />
                        </div>
                        {wordandPdfWarring?.wordInfo.fileName === null ||
                          wordandPdfWarring?.wordInfo.fileName === "" ? null : (
                          <div className="Attachemntfileinfo-ind">
                            <span className="attachemntIconInfoConationer">
                              <span className="AttchemntIconWraper">
                                <SvgIcon
                                  icon={getFileIcon(
                                    wordandPdfWarring?.wordInfo.fileName
                                  )}
                                  size="xxlarge"
                                />
                                {/* <span>{wordandPdfWarring?.wordInfo.fileName}<br /><span style={{ color: "red", fontSize: "10px" }}>{fileWordWarning}</span></span> */}
                                <span className="attachemnrt-warningifoConatiner">
                                  <div className="attachemnrt-warningifo-fileinfo">
                                    {wordandPdfWarring?.wordInfo.fileName}
                                  </div>
                                  <span
                                   className="inCorrectFileError"
                                  >
                                    {wordandPdfWarring?.wordInfo.warningMsg}
                                  </span>
                                </span>
                              </span>
                              <span
                                className="AttchemntIconWraperCancel"
                                onClick={() =>
                                  onRemoveAttachmentWarning("wordInfo")
                                }
                              >
                                X
                              </span>
                            </span>
                          </div>
                        )}

                        <div className="_fileFormatHintMsg">
                          Allowed only one Word Document. Up to 10MB max.
                        </div>
                      </div>
                    )}
                    <div className="col-md-6">
                      <Label className="k-form-label">
                        Supporting Documents
                        {/* <span className="required-asterisk">*</span> */}
                      </Label>
                      {/* multidoc controller */}
                      <div className="Attachemntfileinfo-ind">
                        <input
                          type="file"
                          id="multiDoc"
                          onChange={multipleDocUpload}
                          style={{ width: "100px" }}
                        />
                        <div>
                          <span
className="inCorrectFileError"
                          >
                            {
                              supportingDocError
                            }
                          </span>
                        </div>
                      </div>
                      {filesInfo?.map((obj, ind) => (
                        <div className="Attachemntfileinfo-ind" key={ind}>
                          <span className="attachemntIconInfoConationer">
                            <span className="AttchemntIconWraper">
                              {/* Assuming you have different icons for different file types */}
                              <SvgIcon
                                icon={getFileIcon(
                                  obj.supportingDocumentFileName
                                )}
                                size="xxlarge"
                              />
                              <span className="attachemnrt-warningifoConatiner">
                                <div className="attachemnrt-warningifo-fileinfo">
                                  {obj.supportingDocumentFileName}
                                </div>
                                <span
                                 className="inCorrectFileError"
                                >
                                  {
                                    supportDocWarning[
                                      obj.supportingDocumentFileName
                                    ]?.warningMsg
                                  }
                                </span>
                              </span>
                              {/* <span>{obj.supportingDocumentFileName}<br /><span style={{ color: "red", fontSize: "10px" }}>{supportDocWarning[obj.supportingDocumentFileName]?.warningMsg}</span></span> */}
                            </span>
                            <span
                              className="AttchemntIconWraperCancel"
                              onClick={() => onRemoveMultiAttachment(ind)}
                            >
                              X
                            </span>
                          </span>
                        </div>
                      ))}
                  
                      <div className="_fileFormatHintMsg">
                        Allowed Formats (pdf,doc,docx,xlsx only) Upto 25MB max.
                      </div>
                    </div>
                  </div>
                </fieldset>
                <div className="FormButtonsContainer k-form-buttons">
                  {(isNewForm ||
                    (!isNewForm &&
                      state.status === 1 &&
                      state.createdBy === accounts[0].username)) && (
                      <Button
                        type={"button"}
                        onClick={handleSave}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon-xs k-font-icon k-i-save cursor allIconsforPrimary-btn"></span>
                        Save as Draft
                      </Button>
                    )}
                  {/* {isNewForm && <Autosave interval={5000} onSave={handleAutoSave} />} */}
                  {(isNewForm ||
                    (!isNewForm &&
                      (state.status === 1 ||
                        state.status === 4 ||
                        state.status === 8) &&
                      state.createdBy === accounts[0].username)) && (
                      <Button
                        onClick={handleOpenDialog}
                        type={"submit"}
                        className="FormButtons k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon k-i-launch cursor allIconsforPrimary-btn"></span>
                        Submit
                      </Button>
                    )}
                  {!isNewForm &&
                    state.status === 4 &&
                    state.createdBy === accounts[0].username && (
                      <span className="eNote-ApprovalButton">
                        <Button
                          onClick={() => setVisibleCancelCfrm(true)}
                          className="formBtnColor"
                        >
                          <span className="k-icon-sm k-font-icon k-i-cancel cursor allIconsforPrimary-btn"></span>
                          Cancel Note
                        </Button>
                      </span>
                    )}
                  <Link to={redirectTo}>
                    <Button
                      type={"submit"}
                      className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                    >
                      <span className="k-icon-sm k-font-icon k-i-x-circle cursor allIconsforPrimary-btn"></span>
                      Exit
                    </Button>
                  </Link>
                </div>
                {isLoading && <PageLoader />}
                {visiblesave && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleSaveClose}
                  >
                    <p className="dialogcontent_"
                 
                    >
                      {successMessage}
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => {setTab("My Pending Notes");navigate(redirectTo)}}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visible && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={handleCloseDialog}
                    className="dialogcontent_Refer"
                  >
                    <p className="dialogcontent_"
                 
                    >
                      Are you sure you want to submit this request?
                    </p>
                    <p  className="dialogcontent_"
                  
                    >
                      Please check the details filled along with attachment and
                      click on Confirm button to submit request.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                        onClick={handleSubmit}
                      >
                        <span className="k-icon k-font-icon k-i-check k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                        Confirm
                      </Button>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={handleCloseDialog}
                      >
                        <span className="k-icon k-font-icon k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {visibleCancelCfrm && (
                  <Dialog
                    title={<CustomConfirmDialogTitleBar />}
                    onClose={() => setVisibleCancelCfrm(false)}
                    className="dialogcontent_Refer"
                  >
                    <p className="dialogcontent_"
              
                    >
                      Are you sure you want to cancel this request?
                    </p>
                    <p className="dialogcontent_"
                 
                    >
                      Please click on Confirm button to cancel request.
                    </p>
                    <DialogActionsBar>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base formBtnColor"
                        onClick={onCancelNote}
                      >
                        <span className="k-icon k-font-icon k-i-check k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
                        Confirm
                      </Button>
                      <Button
                        className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => setVisibleCancelCfrm(false)}
                      >
                        <span className="k-icon k-font-icon k-i-close-circle cursor allIconsforPrimary-btn"></span>
                        Cancel
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
                {alertvisible && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setAlertVisible(false)}
                  >
                    <p className="dialogcontent_"
                 
                    >
                      The request for eCommittee has been submitted
                      successfully.
                    </p>
                    <DialogActionsBar>
                   
                      <Button
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                        onClick={() => {setTab("My Pending Notes");navigate(redirectTo)}}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}

                {validationErrors && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={handleClosevalidationDialog}
                  >
                    <p
                      className="cstDailogValidmsg"
                    >
                      <div style={{ textAlign: 'left' }}>
                        <p style={{ marginBottom: '5px', fontWeight: 'bold' }}>Please fill up all the mandatory fields</p>
                        <ul style={{ padding: '2% 3%' }}>
                          {errorMessages.map((message, index) => (
                            <li style={{ marginBottom: '5px' }} key={index}>{message}</li>
                          ))}
                        </ul>
                        <p>
                          <strong>Note: </strong>Invalid files are not allowed
                        </p>
                      </div>
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={handleClosevalidationDialog}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}

                {showNotification && (
                  <Dialog
                    title={<CustomDialogTitleBar />}
                    onClose={() => setShowNotification(false)}
                  >
                    <p className="dialogcontent_"
                    >
                      {notificationMsg}
                    </p>
                    <DialogActionsBar>
                      <Button
                        onClick={() => setShowNotification(false)}
                        className="notifyDailogOkBtn k-button k-button-md k-rounded-md k-button-solid k-button-solid-base"
                      //  style={{textAlign:'center !important'}}
                      >
                        <span className="k-icon k-font-icon k-i-redo cursor allIconsforPrimary-btn"></span>
                        Ok
                      </Button>
                    </DialogActionsBar>
                  </Dialog>
                )}
              </FormElement>
            )}
          />
        </div>
      </div>
      <Footer />
    </div>
  );
};