import React, { useState, useEffect, useRef } from "react";
import "../styles/homepage.css";
import "../styles/responsiveDesign.css";
import Navbar from "../components/navbar";
import { Sidebar } from "../components/sidebar";
import Footer from "../components/footer";
import { useMsal, useAccount } from "@azure/msal-react";
import { useParams } from "react-router-dom";
import { enoteviewformitems } from "./datagridlistitems";
import { API_BASE_URL, API_ENDPOINTS } from "../config";
import {
  ExpansionPanel,
  ExpansionPanelContent,
} from "@progress/kendo-react-layout";
import {
  ComboBox
} from "@progress/kendo-react-dropdowns";
import { SvgIcon } from "@progress/kendo-react-common";
import {
  filePdfIcon,
  fileWordIcon,
  fileImageIcon,
  fileTxtIcon,
  fileDataIcon,
  fileIcon,
  infoCircleIcon,
} from "@progress/kendo-svg-icons";
import "../styles/forms.css";
import { Reveal } from "@progress/kendo-react-animation";
import { Button } from "@progress/kendo-react-buttons";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
// navigetor
import { useNavigate } from "react-router-dom";
// loader
import { PageLoader } from "../components/pageLoader";
// multiplecolum commbo box
import { MultiColumnComboBox } from "@progress/kendo-react-dropdowns";
import { getAccessToken } from "../App";
import { loginRequest } from "../config";
import { API_COMMON_HEADERS } from "../config";
import DateObject from "react-date-object";
import { useTabContext } from "../App";
// Import css styles,images and encrypt function for passcode
import "../styles/passcode.css"
import view from "../assets/view.png"
import hide from "../assets/hide.png"
import CryptoJS from 'crypto-js';

import * as pdfjsLib from 'pdfjs-dist';
import 'pdfjs-dist/web/pdf_viewer.css';

import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.entry';
import "../styles/pdf_viewer.css"

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

const orgUsersPplPickerColumnMapping = [
  {
    field: "displayName",
    header: "Person Name",
    width: "200px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "180px",
  },
  // Change - Adding SR No - 05/04 - Venkat
  {
    field: "srNo",
    header: "SR No",
    width: "120px",
  },
];
// mobile view responsive
const mobileColumns = [
  {
    field: "displayName",
    header: "Person Name",
    width: "100px",
  },
  {
    field: "department",
    header: "Department",
    width: "180px",
  },
  {
    field: "jobTitle",
    header: "Designation",
    width: "100px",
  },
  {
    field: "srNo",
    header: "SR No",
    width: "70px",
  },
];
//Change 05/04 Removing open option PDF viewer component
const tools = [
  "pager",
  "spacer",
  "zoomInOut",
  "zoom",
  "selection",
  "spacer",
  "search",

  "download",
  "print",
];
export const ECommitteeViewForm = () => {
  const id = useParams();
  const { setTab } = useTabContext();
  const { setPasscodeNavigate } = useTabContext();
  const navigate = useNavigate();
  const { accounts, instance } = useMsal(); //for mail username
  const account = useAccount(accounts[0] || {});
  const [expanded, setExpanded] = useState("General Section");
  const [noteData, setNoteData] = useState(null);
  // const [redirect] = useState("/views/In%20Progress");
  const [redirect] = useState("/ecommittehome");
  // general Commenta
  const [generalcmtInfoobj, SetGeneralCmtInfoObj] = useState({
    DocRef: "",
    Comments: "",
    PageNo: "",
    iEdit: false,
  });
  // add refer comments
  const [referCommentsObj, setReferCommentsObj] = useState({
    DocRef: "",
    Comments: "",
    PageNo: "",
    isEdit: false,
  });
  // dialog box for refer and  change Approver
  const [isVisibleSelectingUser, setisVisibleSelectingUser] = useState(false);
  // General info array
  const [generalcmtforAllCmt, SetGeneralcmtforAllCmt] = useState([]);
  // ATR
  const [combovalueApprover, setComboValueApprover] = useState("");
  // ATR Creaters
  const [aTRCreaters, SetATRCreaters] = useState([]);
  // Assigner list
  const [assigneerUser, SetAssigneerUser] = useState([]);
  // dupliacte for atr assigness
  const [assigneerUserDetails, setAssigneerUserDetails] = useState([]);
  // assignees info
  const [assigneerUserinfo, setAssigneerUserinfo] = useState([]);
  //  supportDoc files info  //
  const [filesInfo, SetFileinfo] = useState([]);
  //word and Attachments gist Doc //
  const [wordandPdfInfo, SetWordPDFInfowarring] = useState({
    wordInfo: {
      fileExtension: "",
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
      isDownloadble: false,
      base64: ""
    },
  });
  // word unvaild file error message info //
  const [fileWordWarning, SetfilesWordWarning] = useState("");
  // support docment error  msg //
  const [supportDocWarning, SetSupportDocWarning] = useState({

  });
  //  expend state inligation;
  const [expendJson, SetExpendJson] = useState(enoteviewformitems);
  // isCurrect Secoerotery
  const [isCurrentSecretary, SetIsCurrentSecretary] = useState(false);
  const [isCurrentATRCreator, setIsCurrentATRCreator] = useState(false);
  // isreferred user
  const [isreferredUser, SetIsreferredUser] = useState(false);
  // current button
  const [currectbtn, SetCurrentBtn] = useState("");
  //  dailog
  const [isVisible, SetIsVisible] = useState(false);

  // getNoteSeceriory
  const [getNoteSecUserInfo, SetGetNoteSecUserInfo] = useState([]);
  // Get Note Refer user
  const [getAllUserInfo, SetGetAllUserInfo] = useState([]);
  // selected refer User info
  const [selectedrefer, SetSelectedRefer] = useState(null);
  // Succuss Dialog
  const [isVisibleSuccssDialog, SetIsVisibleSuccssDialog] = useState(false);
  // falid dialog
  const [failedDialog, setfailedDialog] = useState(false);

  //  Succuss Msg
  const [successMsg, SetSuccessMsg] = useState("");
  // current actioner
  const [currentActionerEmail, SetCurrentActionerEmail] = useState("");
  // mark info
  const [markInfoUserEmail, SetMarkInfoUserEmail] = useState([]);
  // selected mark info
  const [selectedMarjUserInfo, SetSelectedMarjUserInfo] = useState(null);
  // loading state intial false
  const [isLoading, SetIsLoading] = useState(true);
  // alert box dailog and dcesiption
  const [confirmDailogObj, setConfirmDailogObj] = React.useState({
    Confirmtext: "",
    Description: "",
  });
  const [callbackvisible, setCallBackVisible] = useState(false);
  const [changeapprovervisible, setChangeApproverVisible] = useState(false);
  //  user alert validation
  const [userComboValidationDialog, setUserComboValidationDialog] = useState(false);
  const [userNotifyInfo, setUserNotifyInfo] = useState("");
  // reidirect
  // change Approver
  const [changeApprovercombovalue, setChangeApprovercombovalue] = useState(null);
  const timeout = React.useRef();
  const [supportDoclink, setSupportDoclinks] = useState({});
  const [changeApproverhaveSecretary, setChangeApproverhaveSecretary] = useState(false);
  // noteWord
  const [noteWordDoc, setNoteWordDoc] = useState({
    noteWordDocInfo: {
      fileName: "",
      warningMsg: "",
      filePath: "",
      isValid: false,
    }
  })
  const [statusMessage, setStatusMessage] = useState('');
  const [supportingDocError, setSupportingError] = useState("");

  // change 05/04 Adding  state for PDF full width
  const [isPDFFullWidth, setIsPDFFullWidth] = useState(false);
  const [getNotePDF, setGetNotePDF] = useState("");
  // Passcode validation and input
  const [passcodeVerification, setPasscodeVerification] = useState(false);
  const [isPasscodeVisible, setIsPasscodeVisible] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [validPasscode, setValidPasscode] = useState(false);
  const [validMsg, setValidmsg] = useState(false);

  // pdf component state
  const [pdfDocument, setPdfDocument] = useState(null);
  const [pdfData, setPdfData] = useState(null);
  const [zoomLevel, setZoomLevel] = useState(1.1); // Default zoom level
  const [currentPage, setCurrentPage] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [pages, setPages] = useState([]);
  const pdfViewerRef = useRef(null);
  const [pdfpath, setPdfPath] = useState(null);
  const pageRefs = useRef([]);
  const [displayedPage, setDisplayedPage] = useState(null);
  const [verifyPasscode, setVerifypasscode] = useState("false");
  const isMobile = window.innerWidth <= 768;
  const [mobileCommentsDialog, setMobileCommentsDialog] = useState(false);
  const [mobileCommentsEditDialog, setMobileCommentsEditDialog] = useState(false);
  const [currentEditComment, setCurrentEditComment] = useState("");
  const [editIndex, setEditIndex] = useState(null);

  useEffect(() => {
    SetIsLoading(true);
    VerifyUserPasscode();
    let isCrntSecretary = false;
    const fetchData = async () => {
      try {
        const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
        const getENoteGeneralDetailsresponse = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eCommitte_GetGeneralDetails}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify({ noteId: id.id }),
          }
        );
        const fetchPDF = getPDFbase64(accessToken);

        // Perform the fetch requests in parallel
        const [generalDetailsResponse] = await Promise.all([getENoteGeneralDetailsresponse, fetchPDF]);

        // Process the responses
        const data = await generalDetailsResponse.json();
        // Commented for parallel api call for get general details and get base 64 - 16-07
        // const data = await getENoteGeneralDetailsresponse.json();
        // if (data?.notePdfPath !== null) {
        //   await getPDFbase64(data?.notePdfPath, accessToken);
        // }
        /*     downloadBase64PDFFile(data?.notePdfBase64, data.notePdfFileName);
            downloadBase64WordFile(data?.noteWordBase64, data.noteWordFileName);
            getSupportDocHyperlink(data?.noteSupportingDocumentsDTO) */
        /*  downloadBase64PDFFile(accessToken);
         downloadBase64WordFile(accessToken);
         getSupportDocHyperlink(accessToken) */

        //    get current actioner info obj
        const currentUserObj = data.noteApproversDTO?.filter(
          (obj) => obj.approverEmail === data.currentActioner
        );

        const getNoteSecerioryresponse = await fetch(
          `${API_BASE_URL}${API_ENDPOINTS.eCommitte_GetNoteSecretary}`,
          {
            method: "POST",
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
            body: JSON.stringify({
              noteId: id.id,
              noteApproverId: currentUserObj[0]?.noteApproverId,
            }),
          }
        );
        const getNoteSecerioryArray = await getNoteSecerioryresponse.json();

        // Get ATR Creator info
        const aTRCreatersResponase = await fetch(`${API_BASE_URL}${API_ENDPOINTS.eCommitte_GetATRCreators}`, {
          method: "GET",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` }
        });
        const aTRCreatoruserInfo = await aTRCreatersResponase.json();

        // SetGetAllUserInfo(getALlUserInfo);
        // SetGetAllUserInfoDeatils(getALlUserInfo);

        SetIsLoading(false);
        SetCurrentActionerEmail(data.currentActioner);
        // CurrentStatus = data.Status;
        setNoteData(data);

        // mark info 
        const markforinfo = [];
        if (data?.noteMarkedInfoDTO?.length > 0) {
          data?.noteMarkedInfoDTO?.map((obj, index) => {
            markforinfo.push({
              noteId: obj.noteId,
              markedEmail: obj.markedEmail,
              createdBy: obj.createdBy,
              markedEmailName: obj.markedEmailName //Bug -293 29/03

            })
          })
        }
        SetMarkInfoUserEmail(markforinfo);
        // referred user info ...

        const referredUserInfo =
          data.noteReferrerDTO !== null ? data?.noteReferrerDTO : [];
        if (referredUserInfo?.length > 0) {
          //referrerStatus
          const referredObj = referredUserInfo?.some(
            (obj) =>
              obj.referrerEmail === data.currentActioner &&
              obj.referrerStatus === 1 &&
              obj.referrerEmail === accounts[0].username
          );
          SetIsreferredUser(referredObj);
        }
        const getNoteSecerioryTempArray = [];

        getNoteSecerioryArray?.map((obj) => {
          getNoteSecerioryTempArray.push(obj);  //need change name
        });

        const crntApvrObj = [];
        data.noteApproversDTO?.filter(
          (obj) => {
            if (obj.approverEmail === accounts[0].username &&
              obj.approverType === 2) {
              crntApvrObj.push(obj)
            }
          }

        );

        isCrntSecretary = data?.noteSecretaryDTO?.some(
          obj => obj.secretaryEmail === accounts[0].username || obj.approverEmail === crntApvrObj[0]?.approverEmail)

        SetIsCurrentSecretary(
          isCrntSecretary
        );
        getAttachGistDoc(data);
        SetGetNoteSecUserInfo(getNoteSecerioryTempArray);

        const aTRCreatorEmails = aTRCreatoruserInfo?.map(
          (obj) => obj.atrCreatorEmail
        );
        // checking atr creator is current actioner and approver =login user
        let isATRCreator = false;
        // const currentApproverObj = data?.noteApproversDTO?.filter(_x => _x.approverEmail === data?.currentActioner && _x.approverEmail === accounts[0].username);
        const currentApproverObj = data?.noteApproversDTO?.filter(
          (_x) => _x.approverEmail === accounts[0].username &&
            _x.approverType === 2
        );
        if (currentApproverObj.length > 0) {
          isATRCreator = aTRCreatoruserInfo?.some(
            (obj) =>
              obj.atrCreatorEmail === currentApproverObj[0]?.approverEmail

          );
          // isATRCreator = aTRCreatoruserInfo?.some(obj => obj.atrCreatorEmail === accounts[0].username)
        }

        setIsCurrentATRCreator(isATRCreator);
        SetATRCreaters(aTRCreatoruserInfo);

        if (isATRCreator) {
          // get assignees user info
          const refAccessToken = await getAccessToken({ ...loginRequest, account }, instance);
          const parmas = {
            "ATRCreatorEmail": accounts[0].username
          }
          await fetch(
            `${API_BASE_URL}${API_ENDPOINTS.eCommitte_GetATRAssignees}`, {
            method: "POST",
            body: JSON.stringify(parmas),
            headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${refAccessToken}` },
          }
          ).then(async aTRAssigneesUsers => {
            // get AssignUserInfo
            const aTRAssigneesUsersEmail = await aTRAssigneesUsers.json();
            if (aTRAssigneesUsersEmail) {
              SetAssigneerUser(aTRAssigneesUsersEmail);
              setAssigneerUserDetails(aTRAssigneesUsersEmail);
            }
          }).catch((err) => {
            console.log(err);
          });
        }

        ValidationForExpendpanel(isATRCreator, isCrntSecretary, data);
        // SetIsLoading(false);
      } catch (error) {
        SetIsLoading(false);
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);


  // Handle throttle
  const throttle = (func, limit) => {
    let inThrottle;
    return function () {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  };

  // to set zoom value, page scroll,select dropdown
  useEffect(() => {
    // Update PDF rendering when zoom level changes
    if (pdfDocument) {
      renderAllPages(pdfDocument, currentPage);
      setNumPages(pdfDocument.numPages);

    }
    if (pages.length > 0 && currentPage > 0) {
      setDisplayedPage(pages[currentPage - 1]);
    }

    const handleScroll = throttle(() => {
      const pdfViewer = pdfViewerRef.current;
      if (!pdfViewer) return;

      const scrollTop = pdfViewer.scrollTop;
      const pageHeight = pdfViewer.scrollHeight / numPages;
      const newPage = Math.floor(scrollTop / pageHeight) + 1;

      if (newPage !== currentPage) {
        setCurrentPage(newPage);
        renderAllPages(pdfDocument, newPage); // Update visible pages
      }
    }, 200);

    const pdfViewer = pdfViewerRef.current;
    if (pdfViewer) {
      pdfViewer.addEventListener('scroll', handleScroll);
    }

    return () => {
      if (pdfViewer) {
        pdfViewer.removeEventListener('scroll', handleScroll);
      }
    };
  }, [pdfDocument, zoomLevel, currentPage, pages, numPages]);

  // get base 64 api change --> Kavya 16-07
  const getPDFbase64 = async (path) => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    // let base64="";
    // const parmas = {
    //   supportingDocumentPath: path
    // }
    const notePDFINfo = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_Base64PDF}?noteId=` + id.id,
      {
        method: "GET",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      }
    );
    const pdfDetails = await notePDFINfo?.text();
    if (pdfDetails !== "File Not Available!") {
      // base64=pdfDetails;
      setGetNotePDF(pdfDetails);
      renderPDF(pdfDetails); // pdf base64 to render pdf
    }
    // return base64;
  }

  // Will convert base64 to pdf--> Kavya (12-07)
  const renderPDF = (pdfDetails) => {
    setPdfPath(pdfDetails);
    try {
      const binaryString = window.atob(pdfDetails);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; ++i) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      setPdfData(bytes);
      const loadingTask = pdfjsLib.getDocument({ data: bytes });

      loadingTask.promise.then((pdf) => {
        renderInitialPages(pdf);
        setPdfDocument(pdf);
        setNumPages(pdf.numPages);
        renderAllPagesfortoolbar(pdf);
      });
    } catch (error) {
      console.error('Error creating loading task:', error);
    }
  };

  // Handle render initial pages
  const renderInitialPages = (pdf) => {
    renderPages(pdf, 1, 2);
  };

  // will render all pages in pdf viewer--> Kavya (12-07)
  const renderAllPagesfortoolbar = (pdf) => {
    const pagePromises = Array.from(new Array(pdf.numPages), (el, index) =>
      pdf.getPage(index + 1)
    );

    Promise.all(pagePromises).then((pages) => {
      const renderPromises = pages.map((page) => {
        const scale = zoomLevel; // Adjust the scale as needed
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
          canvasContext: context,
          viewport,
        };

        return page.render(renderContext).promise.then(() => ({
          pageNum: page.pageNumber,
          canvas: canvas.toDataURL(),
        }));
      });

      Promise.all(renderPromises).then((renderedPages) => {
        setPages(renderedPages);
      });
    });
  };

  // Handle render all pages 
  const renderAllPages = (pdf, currentPage) => {
    const buffer = 2;
    const startPage = Math.max(currentPage - buffer, 1);
    const endPage = Math.min(currentPage + buffer, numPages);
    renderPages(pdf, startPage, endPage);
  };

  // Handle render pages 
  const renderPages = (pdf, startPage, endPage) => {
    const pagePromises = [];
    for (let i = startPage; i <= endPage; i++) {
      pagePromises.push(pdf.getPage(i));
    }

    Promise.all(pagePromises).then((pages) => {
      const renderPromises = pages.map((page) => {
        const scale = zoomLevel;
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
          canvasContext: context,
          viewport,
        };

        return page.render(renderContext).promise.then(() => ({
          pageNum: page.pageNumber,
          canvas: canvas.toDataURL(),
        }));
      });

      Promise.all(renderPromises).then((renderedPages) => {
        setPages((prevPages) => {
          const updatedPages = [...prevPages];
          renderedPages.forEach((renderedPage) => {
            updatedPages[renderedPage.pageNum - 1] = renderedPage;
          });
          return updatedPages;
        });
      });
    });
  };

  // Handle the zoom select dropdown--> Kavya (12-07)
  const handleZoomChange = (event) => {
    const selectedZoom = parseFloat(event.target.value);
    setZoomLevel(selectedZoom);
  };

  // Handle next page navigate when we click on next icon--> Kavya (12-07)
  const handleNextPage = () => {
    if (currentPage < numPages) {
      setCurrentPage((prevPage) => {
        const nextPage = prevPage + 1;
        const nextPageRef = pageRefs.current[nextPage - 1];
        if (nextPageRef) {
          pdfViewerRef.current.scrollTo({
            top: nextPageRef.offsetTop,
            behavior: 'smooth'
          });
        }
        return nextPage;
      });
    }
  };

  // Handle previous page navigate when we click on previous icon--> Kavya (12-07)
  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prevPage) => {
        const previousPage = prevPage - 1;
        const previousPageRef = pageRefs.current[previousPage - 1];
        if (previousPageRef) {
          pdfViewerRef.current.scrollTo({
            top: previousPageRef.offsetTop,
            behavior: 'smooth'
          });
        }
        return previousPage;
      });
    }
  };

  // Zoom in the file--> Kavya (12-07)
  const handleZoomIn = () => {
    setZoomLevel((prevZoom) => Math.min(prevZoom + 0.25, 4.0)); // Increment zoom level, capped at 4.0
  };

  // Zoom out the file--> Kavya (12-07)
  const handleZoomOut = () => {
    setZoomLevel((prevZoom) => Math.max(prevZoom - 0.25, 0.25)); // Decrement zoom level, minimum zoom level is 0.25
  };

  // to print the pdf file--> Kavya (12-07)
  const handlePrint = () => {
    const printContent = document.createElement('div');
    pages.forEach((page) => {
      const img = new Image();
      img.src = page.canvas;
      img.style.width = '100%';
      printContent.appendChild(img);
      printContent.appendChild(document.createElement('br'));
    });

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write('<html><head><title>Print</title></head><body>');
    printWindow.document.write(printContent.innerHTML);
    printWindow.document.write('</body></html>');

    printWindow.document.close();

    // Trigger print dialog
    printWindow.print();
    printWindow.close();
  };

  // Download the pdf and save as file name of note--> Kavya (12-07)
  const handleSave = () => {
    if (!pdfpath) {
      console.error('No PDF data available for download.');
      return;
    }
    try {
      const binaryString = atob(pdfpath);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);

      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const blob = new Blob([bytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(noteData?.noteNumber || 'downloaded').replace(/\//g, '_')}.pdf`;

      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error handling save:', error);
    }
  };

  // Handle download  pdf file 
  const downloadBase64PDFFile = async (path) => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const parmas = {
      supportingDocumentPath: path
    }
    const notePDFINfo = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)
      }
    );
    const pdfDetails = await notePDFINfo?.text();
    if (pdfDetails !== "File Not Available!") {
      const byteCharacters = atob(pdfDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      // Commeneted for pdf open in new tab --> Kavya (06-08)
      // window.open(window.URL.createObjectURL(blob))
      // setPdfLink(window.URL.createObjectURL(blob))
      const url = URL.createObjectURL(blob);

      // Create a link element
      const link = document.createElement('a');
      link.href = url;
      link.download = noteData?.notePdfFileName; // specify the filename
      document.body.appendChild(link);
      link.click();

      // Clean up
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }

  //Handle downLoad word file 
  const downloadBase64WordFile = async (path, fileName) => {
    SetIsLoading(true);
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const parmas = {
      supportingDocumentPath: path
    }
    const wordDoc = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)

      }
    );
    const wordDocDetails = await wordDoc?.text();
    if (wordDocDetails !== "File Not Available!") {

      // Convert base64 to binary
      const byteCharacters = atob(wordDocDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: "application/doc" });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = fileName;
      document.body.appendChild(link);
      link.click();

      // Clean up and remove the link
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);

      // window.open(window.URL.createObjectURL(blob))
    }
    SetIsLoading(false);
  }

  //Convert base64 to URL - supportDoc
  const getSupportDocHyperlink = async (filePath, fileName) => {
    SetIsLoading(true);
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const parmas = {
      supportingDocumentPath: filePath
    }
    const getSupportingDocs = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)

      }
    );
    const supportDocDetails = await getSupportingDocs?.text();

    if (supportDocDetails !== "File Not Available!") {
      const byteCharacters = atob(supportDocDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      // Create a Blob object
      const byteArray = new Uint8Array(byteNumbers);
      // checking file type
      const fileType = getFileType(fileName);
      // Create a Blob object
      const blob = new Blob([byteArray], { type: `application/${fileType}` });
      // Commented for pdf open in new tab --> Kavya(06-08)
      // if (fileType.toLowerCase() === "pdf") {
      //   window.open(window.URL.createObjectURL(blob));
      //   SetIsLoading(false);
      // } else {
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = fileName;
      document.body.appendChild(link);
      link.click();

      // Clean up and remove the link
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
    }
    // }
    SetIsLoading(false);
  }

  // const updateSupportDoclink = (fileName, url) => {
  //   setSupportDoclinks(prevLinks => ({
  //     ...prevLinks,
  //     [fileName]: { fileName: fileName, href: url }
  //   }));
  // };

  // getfileType
  const getFileType = (filename) => {
    let fileType = "doc"
    if (filename.endsWith(".pdf")) {
      fileType = "pdf";
    }
    if (filename.endsWith(".doc") || filename.endsWith(".docx")) {
      fileType = "doc";
    }
    if (
      filename.endsWith(".png") ||
      filename.endsWith(".jpg") ||
      filename.endsWith(".img") ||
      filename.endsWith(".svg")
    ) {
      fileType = "image";
    }
    if (filename.endsWith(".txt")) {
      fileType = "txt";
    }
    if (filename.endsWith(".xlsx")) {
      fileType = "xlsx";
    }
    if (filename.endsWith(".eml")) {
      fileType = "eml";
    }
    return fileType;
  }

  // expansion panel
  const ValidationForExpendpanel = (isATRCreator, isCurrentSecretary, data) => {
    const updatedExpend = expendJson?.map((obj) => {
      if (
        isATRCreator &&
        obj.id === "ATR Assignees"
        // &&
        // (data?.status === 2 || data?.status === 3 || data?.status ===5)
      ) {
        return {
          ...obj,
          isVisible: !obj.isVisible,
        };
      } else if (
        isCurrentSecretary &&
        obj.id === "Gist Document"

      ) {
        return {
          ...obj,
          isVisible: !obj.isVisible,
        };
      } else if (
        (obj.id === "General Comments" ||
          obj.id === "Attach Supporting Documents") &&
        (data?.noteStatusCommittees === 2 || data?.noteStatusCommittees === 3 || data?.noteStatusCommittees === 9) &&
        (data?.noteApproversDTO?.some(
          (obj) =>
            obj.approverEmail === accounts[0].username &&
            obj.approverEmail === data?.currentActioner
        ) ||
          data?.noteReferrerDTO?.some(
            (obj) =>
              obj.referrerEmail === accounts[0].username &&
              obj.referrerEmail === data?.currentActioner
          ))
      ) {
        return {
          ...obj,
          isVisible: !obj.isVisible,
        };
      } else if (
        obj.id === "Mark for Information Section" &&
        data?.noteStatusCommittees === 5 &&
        data?.createdBy === accounts[0]?.username
      ) {
        return {
          ...obj,
          isVisible: !obj.isVisible,
        };
      } else {
        return obj;
      }
    });
    SetExpendJson(updatedExpend);
    return updatedExpend;
  };

  // get converting base64 to url
  // const getConvertingGistDocBase64ToUrl = async (path, fileName) => {

  //   let base64Url = "";
  //   const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
  //   const parmas = {
  //     supportingDocumentPath: path
  //   }
  //   const wordDoc = await fetch(
  //     `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
  //     {
  //       method: "POST",
  //       headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
  //       body: JSON.stringify(parmas)

  //     }
  //   );
  //   const wordDocDetails = await wordDoc?.text();

  //   // const wordDocDetails = await wordDoc?.text();
  //   if (wordDocDetails !== "File Not Available!") {
  //     const byteCharacters = atob(wordDocDetails);
  //     const byteNumbers = new Array(byteCharacters.length);
  //     for (let i = 0; i < byteCharacters.length; i++) {
  //       byteNumbers[i] = byteCharacters.charCodeAt(i);
  //     }
  //     const byteArray = new Uint8Array(byteNumbers);
  //     // checking file type
  //     const fileType = getFileType(fileName);
  //     // Create a Blob object
  //     const blob = new Blob([byteArray], { type: `application/${fileType}` });
  //     base64Url = window.URL.createObjectURL(blob);
  //     return base64Url;
  //   }
  // }

  // Handle coverting base64 t url 
  const getConvertingGistDocBase64ToUrl = async (filePath, fileName) => {
    let base64Url = "";
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const parmas = {
      supportingDocumentPath: filePath
    }
    const getSupportingDocs = await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.GET_Base64}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parmas)
      }
    );
    const supportDocDetails = await getSupportingDocs?.text();

    if (supportDocDetails !== "File Not Available!") {
      const byteCharacters = atob(supportDocDetails);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      // Create a Blob object
      const byteArray = new Uint8Array(byteNumbers);
      // checking file type
      const fileType = getFileType(fileName.toLowerCase());
      // Create a Blob object

      const blob = new Blob([byteArray], { type: `application/${fileType}` });
      base64Url = URL.createObjectURL(blob);
      SetWordPDFInfowarring({
        ...wordandPdfInfo,
        wordInfo: {
          fileExtension: "",
          fileName: fileName === null ? "" : fileName,
          filePath: "",
          isValid: false,
          // isDownloadble: fileName === null ? false : true,
          isDownloadble: true,
          base64: base64Url,
        },
      });
    }
    return base64Url;
  }

  // Get Gist Doc info -coverting base64 to url 
  const getAttachGistDoc = (data) => {
    // checking login user = secretaryEmail or approverEmail ,displaying  doc for login user
    data?.noteSecretaryDTO?.filter(obj => {
      if (obj.secretaryEmail === accounts[0].username ||
        obj.approverEmail === accounts[0].username) {
        if (obj.gistWordDocumentFileName !== null &&
          obj.gistWordDocumentPath !== null) {
          getConvertingGistDocBase64ToUrl(obj.gistWordDocumentPath, obj.gistWordDocumentFileName);
    
        }
      }
    });
  }

  // call back API call
  const handleCallBackAPICall = async () => {
    SetIsLoading(true);
    let params = {
      noteId: id.id,
      createdBy: accounts[0].username,
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(`${API_BASE_URL}${API_ENDPOINTS.eCommitte_CallBackNote}`, {
      method: "POST",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(params),
    })

      .then(async (data) => {
        const res = await data.json();
        SetIsLoading(false);
        if (res.statusMessage === "Failed") {
          SetIsLoading(false);
          setStatusMessage(res.statusMessage)
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          SetSuccessMsg(
            "The request for call back has been successfull."
          );
          SuccessDialogToggle();
          // SetCurrentBtn("Call Back")

        }
      })
      .catch((err) => {
        faildDialogToggle();
        console.log(err);
      });
  }

  // call back function
  const handleCallBack = async () => {
    if (verifyPasscode === "true") {
      setPasscodeVerification(true);
      setPasscode('');
      SetCurrentBtn("Call Back")
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
    SetIsLoading(false);
  };

  // handle change approver API call 
  const handleChangeApproverAPICal = async () => {
    SetIsLoading(false);
    let params = {
      noteId: id.id,
      createdBy: accounts[0].username,
      approverEmail: changeApprovercombovalue.userPrincipalName,
      noteWordPath: changeApproverhaveSecretary ? noteWordDoc?.noteWordDocInfo.filePath : null,
      noteWordFileName: changeApproverhaveSecretary ? noteWordDoc?.noteWordDocInfo.fileName : null
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    // Make API call
    await fetch(`${API_BASE_URL}${API_ENDPOINTS.eCommitte_ChangeApprover}`, {
      method: "POST",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(params),
    })
      // .then((res) => res.json())
      .then(async (data) => {
        const res = await data.json();
        if (res.statusMessage === "Failed") {
          SetIsLoading(false);
          SetSuccessMsg(`Something went wrong ${res.statusMessage}`);
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          setisVisibleSelectingUser(false);
          setChangeApproverVisible(true);
        }
      })
      .catch((err) => {
        console.log(err);
        SetIsLoading(false);
        faildDialogToggle();
        // Handle errors if needed
      });

  }
  //  Handle change name
  const handleApproverChange = async () => {
    // const value = valueObj.userPrincipalName;
    const isPasscodeExist = await VerifyUserPasscode();
    let isChangeApproverhaveSec = true;
    if (changeApproverhaveSecretary) {
      if (noteWordDoc?.noteWordDocInfo.isValid) {
        isChangeApproverhaveSec = true
      }
      else {
        isChangeApproverhaveSec = false;
      }
    }

    if (changeApprovercombovalue && isChangeApproverhaveSec) {
      // Define parameters for API call
      if (isPasscodeExist.toString() === "true") {
        setPasscodeVerification(true);
        setPasscode('');
        SetCurrentBtn("ChangeApprover");
        setisVisibleSelectingUser(false);
      }
      else {
        setValidPasscode(true);
        setValidmsg("Passcode is not set. Please create passcode to proceed further.");
      }
    }

    else {
      setisVisibleSelectingUser(false);
      setUserNotifyInfo(
        // "Please select approver then click on Submit."
        "Please fill up all the mandatory fields."
      );
      setUserComboValidationDialog(true);
    }
  };

  // Handle  change approver 
  const handleChangeApproverCombo = (e) => {
    const { value } = e.target;
    let isSecretaryExist = false;

    if (value) {
      const isApprover = noteData?.noteApproversDTO?.some(
        (obj) => obj.approverEmail === value.userPrincipalName
      );
      const isreferredUser = noteData?.noteReferrerDTO?.some(
        (obj) => obj.referredEmail === value.userPrincipalName
      );
      if (
        value.userPrincipalName === noteData?.createdBy ||
        value.userPrincipalName === noteData.currentActioner ||
        value.userPrincipalName === accounts[0].username ||
        isApprover ||
        isreferredUser
      ) {
        setisVisibleSelectingUser(false)
        setUserNotifyInfo(
          // "The selected approver should not be login user, requester, approver, reviewer, referrer."
          "The selected approver cannont be same as existing Reviewers/Requester/referee/CurrentActioner"
        );
        setUserComboValidationDialog(true);
        // setComboValueApprover("");
        setChangeApprovercombovalue("")
      } else {

        noteData?.noteApproversDTO?.filter(async obj => {
          if (obj.approverEmail === noteData?.currentActioner && obj.approverType === 2) {
            isSecretaryExist = await findSecrateries(obj.approverType, value);
            if (isSecretaryExist && noteData?.noteWordFileName === null && noteData?.noteWordPath === null) {
              setChangeApproverhaveSecretary(true);
            }
          }
        })
        setChangeApprovercombovalue(value);

      }

    }
    else {
      setChangeApprovercombovalue(value);
      setChangeApproverhaveSecretary(false);
      setNoteWordDoc({
        noteWordDocInfo: {
          fileName: "",
          filePath: "",
          isValid: false,
          warningMsg: ""
        }
      })
    }


    // onRequsterApprvrChangeChecking(value, oldApproverObj);
  };

  //Find secretary exists for the added Approvers/Reviewers
  const findSecrateries = async (approverType, user) => {
    let param = {
      noteApproversMasterlst: [{ approverType: approverType, approverEmail: user.userPrincipalName }],
      departmentName: user.department
    }
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    let secretaryExists = false;

    try {
      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_GetNoteSecretaryofApprover}`,
        {
          method: "POST",
          headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify(param),
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          secretaryExists = data.secretaryExist;
        });
    } catch (error) {
      console.error("Error fetching data from API:", error);
    }
    return secretaryExists;
  };

  // if sectory exist   allow to add word doc 
  const noteWordconvertBase64Word = () => {
    var selectedFile = document.getElementById("noteWordDocfile").files;
    let cstWarningMsg = "";
    let isValidFile = true;
    if (selectedFile.length > 0) {
      var fileName = selectedFile[0].name;

      if (
        !(
          fileName.toLowerCase().endsWith(".docx") ||
          fileName.toLowerCase().endsWith("doc")
        )
      ) {
        cstWarningMsg = "File type not allowed";
        isValidFile = false;
      }
      /* Bug -396 
       *For Note pdf the maximum allowed size should be decreased from 25 MB to 10 MB.
       25 mb = 26214400
       10 mb = 10485760
        */
      if (selectedFile[0].size > 10485760) {
        cstWarningMsg = "File size should not exceed more then 10 MB";
        isValidFile = false;
      }
      if (checkingSpl(selectedFile[0].name)) {
        isValidFile = false;
        cstWarningMsg = "File name sholud not contain special characters";
      }

      if (isValidFile) {
        var fileToLoad = selectedFile[0];
        // FileReader function for read the file.
        var fileReader = new FileReader();
        // Onload of file read the file content
        fileReader.onload = function (fileLoadedEvent) {
          let base64 = fileLoadedEvent.target.result;
          const RemovedHeaderFormBase64 = base64.split(",");
          setNoteWordDoc({
            noteWordDocInfo: {
              fileName: selectedFile[0].name,
              filePath: RemovedHeaderFormBase64[1],
              isValid: isValidFile,
              warningMsg: cstWarningMsg
            },
          });
        };
        // Convert data to base64
        fileReader.readAsDataURL(fileToLoad);
      } else {
        setNoteWordDoc({
          noteWordDocInfo: {
            fileName: selectedFile[0].name,
            filePath: "",
            isValid: isValidFile,
            warningMsg: cstWarningMsg
          },
        });
      }
    }
  };

  // remove noteWordDoc
  const onNoteWordDocRemoveAttachmentWarning = () => {
    setNoteWordDoc({
      noteWordDocInfo: {
        fileName: "",
        warningMsg: "",
        filePath: "",
        isValid: false,
      }
    })
  };

  // handle change Approve btn click
  const onChangeApproverBtnClick = async () => {
    SetCurrentBtn("ChangeApprover");
    setisVisibleSelectingUser(true)
  };

  /* const handleCancel = () => {
    SetCurrentBtn("CancelNote");
    setConfirmDailogObj({
      Confirmtext: " Are you sure you want to cancel this request?",
      Description:
        "Please click on Confirm button to cancel request.",
    });
    toggleDailogForConfirmation();

  }

  const onCancelNote = async () => {
    SetIsLoading(true);
    let params = {
      noteId: id.id,
      modifiedBy: accounts[0].username,
    };
    await fetch(`${API_BASE_URL}${API_ENDPOINTS.eNote_CancelNote}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(params),
    })

      .then(async (data) => {
        const res = await data.json();
        SetIsLoading(false);
        if (res.statusMessage === "Failed") {
          SetIsLoading(false);
          setfailedDialog(true);
          //   SetSuccessMsg("Something went wrong please try again.");
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          SetSuccessMsg(
            "The request for cancelled has been successfull."
          );

          SuccessDialogToggle();
        }

      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  }; */

  // Handle close dialog 
  const handleCloseDialog = () => {
    setCallBackVisible(false);
    setChangeApproverVisible(false);
    setTab("My Pending Notes");
    navigate(redirect);
  };

  // handel general comments text area value
  const handelGenralComments = async (e) => {
    // Added passcode redirect page --> feedback 427 Kavya (24/07)
    if (verifyPasscode === "true") {
      // e.preventDefault();
      const { name, value } = e.target;
      //  if(name==="DocRef"){
      if (name === "PageNo") {
        if (value.length <= 5) {
          SetGeneralCmtInfoObj({
            ...generalcmtInfoobj,
            [name]: value,
          });
        }
        else {
          setUserNotifyInfo(
            // "The selected approver should not be login user, requester, approver, reviewer, referrer."
            "Cannot add more than 5 characters."
          );
          setUserComboValidationDialog(true);
        }
      }
      else {
        SetGeneralCmtInfoObj({
          ...generalcmtInfoobj,
          [name]: value,
        });
      }
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  };

  // on change handler for edit fields
  // const handelGenralCommentsEdit = (e) => {
  //   // e.preventDefault();
  //   const { name, value, id } = e.target;
  //   const editGrid = generalcmtforAllCmt.map((obj, index) => {
  //     if (index === Number(id) && name === "PageNo") {
  //       // if (name === "PageNo" && value.length <= 5) {
  //       if (value.length <= 5) {
  //         return {
  //           ...obj,
  //           [name]: value,
  //         };
  //       }
  //       else {
  //         setUserNotifyInfo(
  //           // "The selected approver should not be login user, requester, approver, reviewer, referrer."
  //           "Cannot add more than 5 characters."
  //         );
  //         setUserComboValidationDialog(true);
  //         return obj
  //       }

  //     }
  //     else if (index === Number(id) && name === "DocRef") {
  //       return {
  //         ...obj,
  //         [name]: value,
  //       };
  //     }
  //     else if (index === Number(id) && name === "Comments") {
  //       return {
  //         ...obj,
  //         [name]: value,
  //       };
  //     }
  //     else {
  //       return obj;
  //     }
  //   });
  //   SetGeneralcmtforAllCmt(editGrid);

  // };

  
  // Handle opem comments dialog
  const handleOpenCommentDialog = () => {
    setMobileCommentsDialog(true);
  }

  // Handle opem comments edit dialog 
  const handleCommentsEditMobile = (comment, index) => {
    const isMobile = window.innerWidth <= 767;
    if (isMobile) {
      setCurrentEditComment(comment);  // Set the current comment to be edited
      setEditIndex(index);
      setMobileCommentsEditDialog(true);
    }
  }

  // Handle open comments dialog
  const handleCommentsMobile = () => {
    const isMobile = window.innerWidth <= 767;
    if (isMobile) {
      setMobileCommentsDialog(true);
    }
  };

  // Handle close commenets dialog
  const handleCloseCommentsDialog = () => {
    setMobileCommentsDialog(false);
    setCurrentEditComment("");
    setMobileCommentsEditDialog(false);
  }

  // Handel comments edit 
  const handelGenralCommentsEdit = (e) => {
    const { name, value, id } = e.target;
    const editGrid = generalcmtforAllCmt.map((obj, index) => {
      if (index === Number(id) && name === "PageNo") {
        const trimmedValue = value.replace(/\s/g, '');
        if (trimmedValue.length <= 5) {
          return {
            ...obj,
            [name]: trimmedValue,
          };
        }
        else {
          setUserNotifyInfo(
            "Cannot add more than 5 characters."
          );
          setUserComboValidationDialog(true);
          return obj
        }

      }
      else if (index === Number(id) && name === "DocRef") {
        return {
          ...obj,
          [name]: value,
        };
      }
      else if (index === Number(id) && name === "Comments") {
        return {
          ...obj,
          [name]: value,
        };
      }
      else {
        return obj;
      }
    });
    SetGeneralcmtforAllCmt(editGrid);

  };
  // save edited comments
  // const handleGeneraleditedcommentsSave = (ind) => {
  //   const cmtsObj = [];
  //   generalcmtforAllCmt.map((obj, index) => {
  //     if (index === ind) {
  //       cmtsObj.push({
  //         DocRef: obj.DocRef,
  //         Comments: obj.Comments,
  //         PageNo: obj.PageNo,
  //       })
  //     }
  //   })
  //   if (
  //     /* (cmtsObj[0]?.DocRef).trim() !== "" &&
  //     (cmtsObj[0]?.PageNo).trim() !== "" && */
  //     (cmtsObj[0]?.Comments).trim() !== ""
  //   ) {

  //     const editGrid = generalcmtforAllCmt.map((obj, index) => {
  //       if (index === ind) {
  //         return {
  //           ...obj,
  //           isEdit: false,
  //         };
  //       } else {
  //         return obj
  //       }
  //     });
  //     SetGeneralcmtforAllCmt(editGrid);
  //   } else {
  //     setUserNotifyInfo(
  //       "Please fill in Comments fields and then click Save."
  //     );
  //     setUserComboValidationDialog(true);
  //   }

  //   /*  const editGrid = generalcmtforAllCmt.map((obj, index) => {
  //      if (index === ind) {
  //        return {
  //          ...obj,
  //          isEdit: false,
  //        };
  //      } else {
  //        return obj
  //        //  {
  //        //   ...obj,
  //        //   isEdit: false,
  //        // };
  //      }
  //    }); */
  //   // SetGeneralcmtforAllCmt(editGrid);

  // }

  // Handle commengts edit 
  const handleGeneraleditedcommentsSave = (ind) => {
    const cmtsObj = [];
    generalcmtforAllCmt.map((obj, index) => {
      if (index === ind) {
        cmtsObj.push({
          DocRef: obj.DocRef.trim() !== "" ? obj.DocRef : "NA",
          Comments: obj.Comments.trim() !== "" ? obj.Comments : "NA",
          PageNo: obj.PageNo.trim() !== "" ? obj.PageNo : "NA",
        });
      }
    });

    if ((cmtsObj[0]?.Comments).trim() !== "") {
      const editGrid = generalcmtforAllCmt.map((obj, index) => {
        if (index === ind) {
          return {
            ...obj,
            isEdit: false,
            PageNo: cmtsObj[0].PageNo, // Ensure "NA" is set if needed
            DocRef: cmtsObj[0].DocRef, // Ensure "NA" is set if needed
          };
        }
        return obj;
      });
      SetGeneralcmtforAllCmt(editGrid);
    } else {
      setUserNotifyInfo("Please fill in Comments fields and then click Save.");
      setUserComboValidationDialog(true);
    }
  };

  // enable inputs onclick of edit
  const handelingEdit = (ind) => {
    // e.preventDefault();

    const editGrid = generalcmtforAllCmt.map((obj, index) => {
      if (index === ind) {
        return {
          ...obj,
          isEdit: true,
        };
      } else {
        return {
          ...obj,
          isEdit: false,
        };
      }
    });
    SetGeneralcmtforAllCmt(editGrid);
  };


  //   mobile comments save
  // const handleMobileSave = () => {
  //   console.log("test")
  //   const cmtsObj = [];

  //   generalcmtforAllCmt.forEach((obj, index) => {
  //     if (index === editIndex) {
  //       cmtsObj.push({
  //         DocRef: obj.DocRef.trim() !== "" ? obj.DocRef : "NA",
  //         Comments: currentEditComment.trim() !== "" ? currentEditComment : "NA",
  //         PageNo: obj.PageNo.trim() !== "" ? obj.PageNo : "NA",
  //       });
  //     }
  //   });

  //   // Validate and update the state
  //   if (cmtsObj[0]?.Comments.trim() !== "") {
  //     const editGrid = generalcmtforAllCmt.map((obj, index) => {
  //       if (index === editIndex) {
  //         return {
  //           ...obj,
  //           isEdit: false,
  //           PageNo: cmtsObj[0].PageNo,
  //           DocRef: cmtsObj[0].DocRef,
  //           Comments: cmtsObj[0].Comments,
  //         };
  //       }
  //       return obj;
  //     });

  //     SetGeneralcmtforAllCmt(editGrid);
  //     // handleCloseCommentsDialog(); // Close the dialog for mobile
  //   } else {
  //     setUserNotifyInfo("Please fill in Comments fields and then click Save.");
  //     setUserComboValidationDialog(true);
  //   }
  // };

  // Handle comments save on mobile 
  const handleMobileSave = () => {
    const cmtsObj = [];

    // Collect the edited comment
    generalcmtforAllCmt.forEach((obj, index) => {
      if (obj.isEdit) {
        cmtsObj.push({
          DocRef: obj.DocRef.trim() !== "" ? obj.DocRef : "NA",
          Comments: obj.Comments.trim() !== "" ? obj.Comments : "NA",
          PageNo: obj.PageNo.trim() !== "" ? obj.PageNo : "NA",
        });
      }
    });

    // Validate and update the state
    if (cmtsObj[0]?.Comments.trim() !== "") {
      const editGrid = generalcmtforAllCmt.map((obj, index) => {
        if (obj.isEdit) {
          return {
            ...obj,
            isEdit: false,
            PageNo: cmtsObj[0].PageNo,
            DocRef: cmtsObj[0].DocRef,
            Comments: cmtsObj[0].Comments,
          };
        }
        return obj;
      });

      SetGeneralcmtforAllCmt(editGrid);
      handleCloseCommentsDialog(); // Close the dialog for mobile
    } else {
      setUserNotifyInfo("Please fill in the Comments field and then click Save.");
      setUserComboValidationDialog(true);
    }
};


  // add commnents obj to array varible
  const handelAddCmts = async (e) => {
    e.preventDefault();
    if (verifyPasscode === "true") {
      if (generalcmtInfoobj.Comments !== "") {
        // Set "NA" for empty DocRef and PageNo fields
        const updatedGeneralCmtInfoObj = {
          ...generalcmtInfoobj,
          DocRef: generalcmtInfoobj.DocRef.trim() === "" ? "NA" : generalcmtInfoobj.DocRef,
          PageNo: generalcmtInfoobj.PageNo.trim() === "" ? "NA" : generalcmtInfoobj.PageNo,
        };

        SetGeneralcmtforAllCmt((prevState) => [...prevState, updatedGeneralCmtInfoObj]);
        SetGeneralCmtInfoObj({
          DocRef: "",
          Comments: "",
          PageNo: "",
          isEdit: false,
        });
        setMobileCommentsDialog(false);
      } else {
        setUserNotifyInfo("Please fill in the Comments field and then click Add Comments.");
        setUserComboValidationDialog(true);
      }
    } else {
      setValidPasscode(true);
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  };

  // delete general cmt
  const handelDeleteCmt = (ind) => {
    SetGeneralcmtforAllCmt(
      generalcmtforAllCmt.filter((obj, index) => index !== ind)
    );
  };

  // Handle assinees change 
  const handleComboChangeAssignees = async (event) => {
    // Added passcode redirect page --> feedback 427 Kavya (24/07)
    if (verifyPasscode === "true") {
      setComboValueApprover(event.value);
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }

  };

  // add Assignees ATR
  const handleAddRowAssignees = async () => {
    // Added passcode redirect page --> feedback 427 Kavya (23/07)
    if (verifyPasscode === "true") {
      const atrAssigndessArray = [];
      if (
        combovalueApprover === "" ||
        combovalueApprover === undefined ||
        combovalueApprover === null
      ) {
        setUserNotifyInfo(
          "Please select the Assignee then click on Add."
        );
        setUserComboValidationDialog(true);
      } else {
        // const currentApproverdObj = noteData?.noteApproversDTO?.filter(
        //   (obj) =>
        //     obj.approverEmail === currentActionerEmail &&
        //     obj.approverEmail === accounts[0].username
        // );
        const currentATRCreatorObj = aTRCreaters?.filter(
          (obj) =>
            obj.atrCreatorEmail === currentActionerEmail
          // &&
          // obj.atrCreatorEmail === currentApproverdObj[0]?.approverEmail
        );
        const ObjExist = assigneerUserinfo?.some(
          (obj) => obj.atrAssignerEmail === assigneerUser?.find(obj => obj.atrAssignerEmailName === combovalueApprover)?.atrAssignerEmail
        );
        /* const isAssigneesExist = noteData?.atrAssigneesDTO?.some(
          obj => obj.atrAssignerEmail === combovalueApprover
        ) */
        if (ObjExist) {
          // const CurrentObj = noteData.atrAssigneesDTO?.filter(obj => obj.atrAssignerEmail === combovalueApprover);
          setUserNotifyInfo(
            "The selected assignee already exist. Kindly choose another assignee."
          );
          setUserComboValidationDialog(true);
          setComboValueApprover("");

        } else {
          atrAssigndessArray.push({
            atrCreatorEmail: currentATRCreatorObj[0]?.atrCreatorEmail,
            atrAssignerEmail: assigneerUser?.find(obj => obj.atrAssignerEmailName === combovalueApprover)?.atrAssignerEmail,
            noteRequesterComments: `${generalcmtforAllCmt
              ?.map((obj) => `${obj.PageNo} ${obj.DocRef} ${obj.Comments}`)
              .join(", ")}`,
            createdDate: new Date(),
            createdBy: accounts[0].username,
            modifiedDate: new Date(),
            modifiedBy: accounts[0].username,
            // Bug -293 28/03
            atrAssignerEmailName: combovalueApprover

          });
        }
      }
      setComboValueApprover("");
      setAssigneerUserinfo([...assigneerUserinfo, ...atrAssigndessArray]);
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  };

  // onDelete ATR Info user
  const onDeleteAssigneeUser = (ind) => {
    setAssigneerUserinfo(
      assigneerUserinfo.filter((obj, index) => index !== ind)
    );
  };

  // checking on specialCharPattern char inn file name
  const checkingSpl = (test) => {
    var specialCharPattern = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;

    // Test the input string against the pattern
    return specialCharPattern.test(test);
  };
  
  // Handle  Add supporting docs
  const multipleDocUpload = async () => {
    // Added passcode redirect page --> feedback 427 Kavya (23/07)
    if (verifyPasscode === "true") {
      let reamingFileSize = 26214400;
      let totalFileSize = 0;
      const inValidFileNames = Object.keys(supportDocWarning).filter(
        (fileName) => supportDocWarning[fileName]?.isValid === false
      );
      // filter valid files only if()
      if (filesInfo.length > 0) {
        const vaildMultiplefile = filesInfo.filter(obj => {
          if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
            return obj;
          }
        });
        vaildMultiplefile.map(obj =>
          reamingFileSize = reamingFileSize - obj.supportingDocumentPathLength
        );
      }
      if (noteData?.noteSupportingDocumentsDTO.length > 0) {
        noteData?.noteSupportingDocumentsDTO.map(obj => {
          reamingFileSize = reamingFileSize - obj.supportingDocumentPathLength
          // totalFileSize =totalFileSize+ obj.supportingDocumentPathLength
        });
      }
      let warningmsg = "";
      // const arrayExtension = [".png", ".jpg", ".pdf", ".doc", ".docx", ".xlsx", ".eml", ".img", ".svg"];
      const validname = /[!@#$%^&*(){}\[\];:,<>\?\/\\]/;
      const selectedFile = document.getElementById("multiDoc").files;
      const TempfileInfo = filesInfo;

      const promises = [];
      const fileCount = selectedFile.length;

      for (let i = 0; i < fileCount; i++) {
        const fileToLoad = selectedFile[i];
        const fileExtession = fileToLoad.name.split(".");
        if (!noteData?.noteSupportingDocumentsDTO?.some(obj => obj.supportingDocumentFileName === fileToLoad.name)) {  // Check if the file type is allowed
          // Check for special characters in the filename
          if (validname.test(fileToLoad.name)) {
            warningmsg = "File name should not contain special characters";
            updateSupportDocWarning(
              fileToLoad.name,
              warningmsg,
              fileExtession[fileExtession.length - 1]
            );
          }

          // Check if the file type is allowed
          if (
            !(
              (fileToLoad.name).toLowerCase().endsWith(".docx") ||
              (fileToLoad.name).toLowerCase().endsWith(".doc") ||
              (fileToLoad.name).toLowerCase().endsWith(".pdf") ||
              (fileToLoad.name).toLowerCase().endsWith(".xlsx")
              /*    fileToLoad.name.endsWith(".png") ||
                 fileToLoad.name.endsWith(".jpg") ||
                 fileToLoad.name.endsWith(".img") ||
                 fileToLoad.name.endsWith(".eml") */
            )
          ) {
            warningmsg = "File type is not allowed";
            updateSupportDocWarning(
              fileToLoad.name,
              warningmsg,
              fileExtession[fileExtession.length - 1]
            );
          }

          // Check file size (5MB limit)
          /* 
         * Bug -396 fixed
         File size increse 5mb to 25MB 
    25 mb = 26214400
      10 mb = 10485760 */
          if (fileToLoad.size > reamingFileSize) {
            warningmsg = "Cumulative size of all the supporting documents should not be exceeded 25 MB.";
            /*   updateSupportDocWarning(
                fileToLoad.name,
                warningmsg,
                fileExtession[fileExtession.length - 1]
              ); */
            setSupportingError(warningmsg)
          }
          // File Reader.....
          const fileReader = new FileReader();
          const promise = new Promise((resolve) => {
            fileReader.onload = function (fileLoadedEvent) {
              const base64 = fileLoadedEvent.target.result.split(",")[1];
              const partLength = Math.ceil(base64.length / 10);
              const parts = [];
              for (let j = 0; j < 10; j++) {
                parts.push(base64.slice(j * partLength, (j + 1) * partLength));
              }

              resolve({
                name: fileToLoad.name,
                parts: parts,
                size: fileToLoad.size
              });
            }
          });

          fileReader.readAsDataURL(fileToLoad);
          promises.push(promise);

          Promise.all(promises)
            .then((fileDataArray) => {
              const updatedTempFileInfo = fileDataArray.reduce(
                (acc, fileData) => {
                  const ObjExist = acc.map((obj) => obj.supportingDocumentFileName);
                  if (!ObjExist.includes(fileData.name)) {
                    acc.push({
                      // noteSupportingDocumentId: 0,
                      noteId: noteData.noteId,
                      // supportingDocumentPath: fileData.base64.split(",")[1],
                      supportingDocumentPathPart1: fileData.parts[0],
                      supportingDocumentPathPart2: fileData.parts[1],
                      supportingDocumentPathPart3: fileData.parts[2],
                      supportingDocumentPathPart4: fileData.parts[3],
                      supportingDocumentPathPart5: fileData.parts[4],
                      supportingDocumentPathPart6: fileData.parts[5],
                      supportingDocumentPathPart7: fileData.parts[6],
                      supportingDocumentPathPart8: fileData.parts[7],
                      supportingDocumentPathPart9: fileData.parts[8],
                      supportingDocumentPathPart10: fileData.parts[9],
                      supportingDocumentFileName: fileData.name,
                      createdDate: new Date(),
                      createdBy: accounts[0].username,
                      modifiedDate: new Date(),
                      modifiedBy: accounts[0].username,
                      supportingDocumentPathLength: fileData.size
                    });
                  }
                  return acc;
                },
                [...TempfileInfo]
              );
              SetFileinfo(updatedTempFileInfo);
            })
            .catch((error) => {
              console.error("Error reading files:", error);
            });
        }
      }
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }
  };

  //update supportDoc warnings
  const updateSupportDocWarning = (fileName, warningMsg, fileExtension) => {
    SetSupportDocWarning((prevState) => ({
      ...prevState,
      [fileName]: {
        filename: fileName,
        isValid: false,
        warningMsg: warningMsg,
        fileExtnsion: fileExtension,
      },
    }));
  };

  // checking file type and return file icon
  const getFileIcon = (filename) => {
    let fileType = fileIcon;
    if (filename.endsWith(".pdf")) {
      fileType = filePdfIcon;
    }
    if (filename.endsWith(".doc") || filename.endsWith(".docx")) {
      fileType = fileWordIcon;
    }
    if (
      filename.endsWith(".png") ||
      filename.endsWith(".jpg") ||
      filename.endsWith(".img") ||
      filename.endsWith(".svg")
    ) {
      fileType = fileImageIcon;
    }
    if (filename.endsWith(".txt")) {
      fileType = fileTxtIcon;
    }
    if (filename.endsWith(".xlsx")) {
      fileType = fileDataIcon;
    }
    return fileType;
  };

  // remove multiple attchemnts suppoutDoc
  const onRemoveMultiAttachment = (id) => {
    /* const filename = filesInfo.find((obj, index) => index === id).supportingDocumentFileName;
    delete supportDocWarning[filename];
    SetSupportDocWarning(supportDocWarning) */
    const filename = filesInfo.find((obj, index) => index === id).supportingDocumentFileName;
    delete supportDocWarning[filename];
    SetSupportDocWarning(supportDocWarning);
    let reamingFileSize = 26214400;
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map((obj, index) => {
        if (index !== id) {
          totalFileSize = totalFileSize + obj.supportingDocumentPathLength
        }
      });
    }
    if (noteData?.noteSupportingDocumentsDTO?.length > 0) {
      noteData?.noteSupportingDocumentsDTO.map(obj => {
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      })
    }

    if (totalFileSize <= 26214400) {
      setSupportingError("");
    }

    SetFileinfo(filesInfo.filter((obj, ind) => ind !== id));
  };

  //   remove attacment for gist
  const onRemoveAttachmentWarning = (key) => {
    SetWordPDFInfowarring({
      ...wordandPdfInfo,
      [key]: {
        fileExtension: "", fileName: "", filePath: "", isValid: false, isDownloadble: false,
        base64: ""
      },
    });
  };

  // date converion
  const getdateconversion = (date) => {
    //Chnage 23/05 Seconds hand was removed
    const convertedDate = new DateObject(new Date(date)).format("DD-MMM-YYYY hh:mm A")
    // new Date(date).toDateString() + " " + new Date(date).toLocaleTimeString();
    return convertedDate;
  };

  // get all supporting sizes
  const getAllSupportingDocSize = () => {
    let totalFileSize = 0;
    const inValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only if()supportDocfilesInfo
    if (filesInfo.length > 0) {
      const vaildMultiplefile = filesInfo.filter(obj => {
        if (!inValidFileNames.includes(obj.supportingDocumentFileName)) {
          return obj;
        }
      });
      vaildMultiplefile.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );

    }
    if (noteData?.noteSupportingDocumentsDTO?.length > 0) {
      noteData?.noteSupportingDocumentsDTO.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );
    }
    return totalFileSize

  }

  // onchange passcode 
  const handlePasscodeChange = (e) => {
    const { value } = e.target;
    // Regular expression to allow only alphanumeric characters
    const alphanumericRegex = /^[a-zA-Z0-9]*$/;

    if (alphanumericRegex.test(value)) {
      setPasscode(value);
    }
    // Only allow numeric input
    // const value = e.target.value.replace(/\D/g, '');
    // setPasscode(value);
  };

  // Handle rediret to passcode page 
  const handleRedirectToPasscode = () => {
    setPasscodeNavigate("View");
    navigate('/ecommitteepasscode'); // Adjust the path to your target route
  };

  // Handle verify user passcode 
  const VerifyUserPasscode = async () => {
    let userPasscodeExist = 'false';
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      // Call eNote_VerifyUserPasscode API first
      const userPasscodeResponse = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_VerifyUserPasscode(accounts[0].username)}`,
        {
          method: "POST",
          // body: JSON.stringify({ UserMail: accounts[0].username}),
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
        }
      );

      const userData = await userPasscodeResponse.text();
      if (userData) {
        userPasscodeExist = userData;
        setVerifypasscode(userData);
      }
    } catch (err) {
      console.error(err);
      // Handle error state or throw it further
      throw err;
    }
    return userPasscodeExist;
  }

  // Verifing the passcode
  const passcodeVerificationFunction = async () => {
    try {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
      // Replace with your own secret key
      const secretKey = "SHA256";

      // Compute HMAC-SHA256 hash of the passcode with the secret key
      const hashedPasscode = CryptoJS.SHA256(passcode, secretKey).toString(CryptoJS.enc.Hex);

      const params = {
        Passcode: hashedPasscode,
        UserMail: accounts[0].username
      };

      const response = await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.eCommittee_VerifyPasscode}`,
        {
          method: "POST",
          body: JSON.stringify(params),
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
        }
      );

      const data = await response.text();

      if (data === "Passcode verification successful") {
        setPasscodeVerification(false);

        const confirmDialogSettings = {
          "Approve": {
            Confirmtext: `Are you sure you want to ${isApprover() ? "note" : "approve"} this request?`,
            Description: `Please check the details filled along with attachment and click on Confirm button to ${isApprover() ? "note" : "approve"} request.`,
          },
          "Reject": {
            Confirmtext: "Are you sure you want to reject this request?",
            Description: "Please check the details filled along with attachment and click on Confirm button to reject request.",
          },
          "Refer Back": {
            Confirmtext: "Are you sure you want to Refer Back this request?",
            Description: "Please check the details filled along with attachment and click on Confirm button to refer back request.",
          },
          "Return": {
            Confirmtext: "Are you sure you want to return this request?",
            Description: "Please check the details filled along with attachment and click on Confirm button to return request.",
          }
        };

        if (currectbtn in confirmDialogSettings) {
          setConfirmDailogObj(confirmDialogSettings[currectbtn]);
          toggleDailogForConfirmation();
        }

        if (currectbtn === "Call Back") {
          handleCallBackAPICall();
          // SetSuccessMsg(
          //   "The request for call back has been successfull."
          // );
          // SuccessDialogToggle();
        }

        if (currectbtn === "ChangeApprover") {
          handleChangeApproverAPICal();

        }

        if (currectbtn === "Refer") {
          try {
            await Promise.all([approverStatusChange()]);
            SetIsVisible(false);
            setisVisibleSelectingUser(false);

          } catch (error) {
            console.error("Error:", error);
          }
        }
      } else {
        // 05/07 change 
        setError('Incorrect passcode entered please try again.');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handle close passcode dialog
  const handlepasscodeClose = () => {
    setPasscodeVerification(false);
    setError(false);
  }

  // on click approver btn 
  const approvalFunction = async () => {
    // approverStatusChange()
    let maxFileSize = 26214400;
    let totalFileSize = getAllSupportingDocSize();
    if (Object.keys(supportDocWarning).length > 0 || totalFileSize > maxFileSize) {
      SetCurrentBtn("Approve");
      if (totalFileSize > maxFileSize) {
        setUserNotifyInfo("Cumulative size of all the supporting documents should not be exceeded 25 MB.")

      }
      else if (Object.keys(supportDocWarning).length > 0) {
        setUserNotifyInfo(
          "Please check and remove if there are any invalid files attached."
        );
      }
      setUserComboValidationDialog(true);

    } else {
      // Added passcode create redirect dialog to show when passcode is not created --> Kavya
      if (verifyPasscode === "true") {
        setPasscode('');
        setPasscodeVerification(true);
        SetCurrentBtn("Approve");
      } else {
        setValidPasscode(true);
        // Changed the content --> Kavya (25-07)
        setValidmsg("Passcode is not set. Please create passcode to proceed further.");
        SetCurrentBtn("Approve");
      }
      // C
      // setPasscode('');
      // setPasscodeVerification(true);
      // SetCurrentBtn("Approve");
      // Commented for passcode functionality
      // setConfirmDailogObj({
      //   Confirmtext: `Are you sure you want to ${isApprover()?"note":"approve"} this request?`,
      //   Description:
      //     `Please check the details filled along with attachment and click on Confirm button to ${isApprover()?"note":"approve"} request.`,
      // });
      // toggleDailogForConfirmation();
    }
  };

  //  on click of reject btn
  const rejectFunction = async () => {
    // comments are required for refer back  14/05
    // Added passcode redirect page --> feedback 427 Kavya (24/07)
    if (verifyPasscode === "true") {
      let maxFileSize = 26214400;
      let totalFileSize = getAllSupportingDocSize();

      if (Object.keys(supportDocWarning).length > 0 || totalFileSize > maxFileSize) {
        SetCurrentBtn("Reject");
        if (totalFileSize > maxFileSize) {
          setUserNotifyInfo("Cumulative size of all the supporting documents should not be exceeded 25 MB.")

        }
        else if (Object.keys(supportDocWarning).length > 0) {
          setUserNotifyInfo(
            "Please check and remove if there are any invalid files attached."
          );
        }
        setUserComboValidationDialog(true);

      } else {
        if (generalcmtforAllCmt?.length === 0) {
          SetCurrentBtn("Reject");
          setUserNotifyInfo(
            "Please fill in comments then click on Reject."
          );
          setUserComboValidationDialog(true);

        }
        else {
          // Added passcode create redirect dialog to show when passcode is not created --> Kavya
          if (verifyPasscode === "true") {
            setPasscode('');
            setPasscodeVerification(true);
            SetCurrentBtn("Reject");
          } else {
            setValidPasscode(true);
            // Changed the content --> Kavya (25-07)
            setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
            SetCurrentBtn("Reject");
          }
          // SetCurrentBtn("Reject");
          // setPasscode('');
          // setPasscodeVerification(true);
          // Commented for passcode functionality
          // setConfirmDailogObj({
          //   Confirmtext: "Are you sure you want to reject  this request?",
          //   Description:
          //     "Please check the details filled along with attachment and click on Confirm button to reject request.",
          // });

          // toggleDailogForConfirmation();
        }
      }
    } else {
      setValidPasscode(true);
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }

  };
  // on click of refer btn 
  const referFunction = async () => {
    // Added passcode redirect page --> feedback 427 Kavya (23/07)
    if (verifyPasscode === "true") {
      SetCurrentBtn("Refer");
      toggleSelectingUser();
    } else {
      setValidPasscode(true);
      // Changed the content --> Kavya (25-07)
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
      SetCurrentBtn("Refer");
    }

    /*   setConfirmDailogObj({
        Confirmtext: "Are you sure you want to refer this request?",
        Description:
          "Please check the details filled along with attachment and click on Confirm button to approve request.",
      });
      toggleDailogForConfirmation(); */
  };

  // add refer data Api change Approver submit fucntion
  const onSubmitforAddReferandChangeApprover = async () => {
    if (currectbtn === "Refer") {
      if (referCommentsObj.Comments !== "") {

        if (selectedrefer) {
          const isApproverExist = noteData?.noteApproversDTO?.some(
            (obj) => obj.approverEmail === selectedrefer.userPrincipalName
          );
          if (isApproverExist || selectedrefer.userPrincipalName === noteData.createdBy) {
            setUserNotifyInfo(
              "Referrer cannot be the existing approver/reviewer or requester."
            );
            setUserComboValidationDialog(true);
            SetIsVisible(false);
            setisVisibleSelectingUser(false)
          } else {
            setisVisibleSelectingUser(false);
            // setPasscode('');
            // setPasscodeVerification(true);
            // Added passcode create redirect dialog to show when passcode is not created --> Kavya
            if (verifyPasscode === "true") {
              setisVisibleSelectingUser(false);
              setPasscode('');
              setPasscodeVerification(true);
              // SetCurrentBtn("Reject");
            } else {
              setisVisibleSelectingUser(false);
              setValidPasscode(true);
              // Changed the content --> Kavya (25-07)
              setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
              // SetCurrentBtn("Reject");
            }
            // Commented for passcode functionality
            // await Promise.all([approverStatusChange()])
            //   .then(() => {
            //     SetIsVisible(false);
            //     setisVisibleSelectingUser(false)
            //   })
            //   .catch((error) => {
            //     console.error("Error:", error);
            //   });
          }
        } else {
          SetIsVisible(false);
          setisVisibleSelectingUser(false)
          setUserNotifyInfo("Please select the Referrer then click on Submit.");
          setUserComboValidationDialog(true);
        }
      }
      else {
        SetIsVisible(false);
        setisVisibleSelectingUser(false)
        setUserNotifyInfo("Please fill in comments then click on Submit.");
        setUserComboValidationDialog(true);
      }
    }
    if (currectbtn === "ChangeApprover") {
      handleApproverChange()

    }
  }

  // toggle dialog for add refer and change approver
  const toggleSelectingUser = () => {
    setisVisibleSelectingUser(true);
  }

  // 0n click of refer back btn
  const referBackfunction = async () => {
    // comments are required for refer back  14/05
    let maxFileSize = 26214400;
    let totalFileSize = getAllSupportingDocSize();

    if (Object.keys(supportDocWarning).length > 0 || totalFileSize > maxFileSize) {
      SetCurrentBtn("Refer Back");
      if (totalFileSize > maxFileSize) {
        setUserNotifyInfo("Cumulative size of all the supporting documents should not be exceeded 25 MB.")

      }
      else if (Object.keys(supportDocWarning).length > 0) {
        setUserNotifyInfo(
          "Please check and remove if there are any invalid files attached."
        );
      }
      setUserComboValidationDialog(true);

    } else {
      if (generalcmtforAllCmt?.length === 0) {
        SetCurrentBtn("Refer Back");
        setUserNotifyInfo(
          "Please fill in comments then click on Refer Back."
        );
        setUserComboValidationDialog(true);

      } else {
        /* setPasscode('');
        setPasscodeVerification(true);
        SetCurrentBtn("Refer Back"); */
        // Added passcode create redirect dialog to show when passcode is not created --> Kavya
        if (verifyPasscode === "true") {
          setPasscode('');
          setPasscodeVerification(true);
          SetCurrentBtn("Refer Back");
        } else {
          setValidPasscode(true);
          // Changed the content --> Kavya (25-07)
          setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
          SetCurrentBtn("Refer Back");
        }
        // Commented for passcode functionality
        // setConfirmDailogObj({
        //   Confirmtext: "Are you sure you want to Refer Back this request?",
        //   Description:
        //     "Please check the details filled along with attachment and click on Confirm button to refer back request.",
        // });
        // toggleDailogForConfirmation();
      }
    }
  };

  // on  click of return btn
  const returnfunction = async () => {
    // Added passcode redirect page --> feedback 427 Kavya (24/07)
    if (verifyPasscode === "true") {
      let maxFileSize = 26214400;
      let totalFileSize = getAllSupportingDocSize();

      if (Object.keys(supportDocWarning).length > 0 || totalFileSize > maxFileSize) {
        SetCurrentBtn("Return");
        if (totalFileSize > maxFileSize) {
          setUserNotifyInfo("Cumulative size of all the supporting documents should not be exceeded 25 MB.")

        }
        else if (Object.keys(supportDocWarning).length > 0) {
          setUserNotifyInfo(
            "Please check and remove if there are any invalid files attached."
          );
        }
        setUserComboValidationDialog(true);

      } else {
        if (generalcmtforAllCmt?.length === 0) {
          SetCurrentBtn("Return");
          setUserNotifyInfo(
            "Please fill in comments then click on Return."
          );
          setUserComboValidationDialog(true);

        }
        else {
          /*   setPasscode('');
            setPasscodeVerification(true);
            SetCurrentBtn("Return"); */
          if (verifyPasscode === "true") {
            setPasscode('');
            setPasscodeVerification(true);
            SetCurrentBtn("Return");
          } else {
            setValidPasscode(true);
            // Changed the content --> Kavya (25-07)
            setValidmsg(`Passcode is not set. Please create passcode to proceed further.`);
            SetCurrentBtn("Return");
          }
          // Commented for passcode functionality
          // setConfirmDailogObj({
          //   Confirmtext: "Are you sure you want to return this request?",
          //   Description:
          //     "Please check the details filled along with attachment and click on Confirm button to return request.",
          // });
          // toggleDailogForConfirmation();
        }
      }
    } else {
      setValidPasscode(true);
      setValidmsg("Passcode is not set. Please create passcode to proceed further.");
    }

  };

  // add referr comments 
  // handel general comments text area value
  const handelReferGenralComments = (e) => {
    // e.preventDefault();
    const { name, value } = e.target;
    //  if(name==="DocRef"){
    setReferCommentsObj({
      ...generalcmtInfoobj,
      [name]: value,
      DocRef: "NA",
      // Comments: "",
      PageNo: "NA",
      isEdit: true
    });
  };

  // toggle cofirmation dialog
  const toggleDailogForConfirmation = () => {
    SetIsVisible(!isVisible);
  };

  // Success Dilaog toggle function
  const SuccessDialogToggle = () => {
    SetIsVisibleSuccssDialog(!isVisibleSuccssDialog);
  };

  // failled dialog toggle
  const faildDialogToggle = () => {
    setfailedDialog(true);
  };

  // redirectHomePage
  const redirectHomePage = () => {
    setTab("My Pending Notes");
    navigate(redirect);
    SetIsVisibleSuccssDialog(false);
  };

  // Handle Approver status 
  const approverStatusChange = async () => {
    SetIsVisible(false);
    setisVisibleSelectingUser(false);
    SetIsLoading(true);
    let maxFileSize = 26214400;
    let totalFileSize = 0;
    // Bug -293 -28/03
    let selectedAssignees = assigneerUserinfo?.map(item => {
      const { atrAssignerEmailName: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'class' property
    });

    //get invaild file name 
    const unValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only (Naren...)
    const vaildMultiplefile = filesInfo.filter((obj) => {
      if (!unValidFileNames.includes(obj.supportingDocumentFileName)) {
        return obj;
      }
    });
    vaildMultiplefile.map(obj =>
      totalFileSize = totalFileSize + obj.supportingDocumentPathLength
    );
    if (noteData?.noteSupportingDocumentsDTO?.length > 0) {
      noteData?.noteSupportingDocumentsDTO?.map(obj =>
        totalFileSize = totalFileSize + obj.supportingDocumentPathLength
      );

    }
    let fileupdated = vaildMultiplefile?.map(item => {
      const { supportingDocumentPathLength: _, ...rest } = item; // Destructure 'atrAssignerEmailName' and collect the rest
      return rest; // Return object without 'atrAssignerEmailName' property
    });
    const generalCmts = generalcmtforAllCmt;
    const ApproverComments = [];
    if (selectedrefer && referCommentsObj?.isEdit) {
      generalCmts.push(referCommentsObj);

    }
    const currenArry = noteData.noteApproversDTO?.filter(
      (obj) => obj.approverEmail === accounts[0].username
    );
    const currentObj = currenArry;
    // get refer user info
    // const selectedUser = getAllUserInfo?.filter(
    //   (obj) => obj.userPrincipalName === selectedrefer
    // );
    const referredEmail = selectedrefer === null ? null : selectedrefer.userPrincipalName;
    // selectedUser?.length > 0 ? selectedUser[0]?.userPrincipalName : null;
    // get all Comments Info
    generalCmts?.map((obj) => {
      ApproverComments.push({
        // "noteApproverCommentID": 0,
        // "noteApproverId": currentObj.approverId,
        pageNumber: obj.PageNo,
        docReferrence: obj.DocRef,
        comments: obj.Comments,
        createdDate: new Date(),
        createdBy: accounts[0].username,
        modifiedDate: new Date(),
        modifiedBy: accounts[0].username,
        noteId: noteData?.noteId,
        // "approverOrder": currentObj.approverOrder,
        approverEmail: accounts[0].username,
        approverType: currentObj.length > 0 ? currentObj[0].approverType : 2,
        // "approverType": 2,
        // "approverStatus":currectApproverObj[0]?.approverStatus,
        approverStatus:
          currectbtn === "Approve"
            ? 3
            : currectbtn === "Reject"
              ? 4
              : currectbtn === "Refer"
                ? 6
                : currectbtn === "Return"
                  ? 5
                  : 1,
        // "strApproverStatus":currectApproverObj[0]?.strApproverStatus
        strApproverStatus:
          currectbtn === "Approve"
            ? "Approved"
            : currectbtn === "Reject"
              ? "Rejected"
              : currectbtn === "Refer"
                ? "Referred"
                : currectbtn === "Return"
                  ? "Returned"
                  : "",
      });
    });
    const loadingObj = {
      noteApproverId: currentObj[0]?.noteApproverId,
      noteId: currentObj[0]?.noteId,
      ReferrerEmail: referredEmail,
      approverType: currentObj[0]?.approverType,
      approverEmail: currentObj[0]?.approverEmail,
      approverOrder: currentObj[0]?.approverOrder,
      approverStatus:
        currectbtn === "Approve"
          ? 3
          : currectbtn === "Reject"
            ? 4
            : currectbtn === "Refer"
              ? 6
              : currectbtn === "Return"
                ? 5
                : 1,
      createdDate: new Date(),
      createdBy: accounts[0].username,
      modifiedDate: new Date(),
      modifiedBy: accounts[0].username,
      strApproverType: currentObj[0]?.strApproverType,
      strApproverStatus:
        currectbtn === "Approve"
          ? "Approved"
          : currectbtn === "Reject"
            ? "Rejected"
            : currectbtn === "Refer"
              ? "Referred"
              : currectbtn === "Return"
                ? "Returned"
                : "",
      noteApproverCommentsDTO: ApproverComments,
      noteSupportingDocumentsDTO: (currectbtn === "Refer" && totalFileSize > maxFileSize) ? [] : fileupdated,
      atrAssigneesDTO: currectbtn === "Approve" ? selectedAssignees : [] //assigneerUserinfo
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eCommitte_NoteApproverStatusChange}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(loadingObj),
      }
    )
      .then(async (data) => {
        const rep = await data.json();
        SetIsLoading(false);
        if (rep.statusMessage === "Failed") {
          SetIsLoading(false);
          setfailedDialog(true);
          setStatusMessage(rep.statusMessage);
          //   SetSuccessMsg("Something went wrong please try again.");
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          if (currectbtn === "Approve") {
            SetSuccessMsg(
              `The request for committee note has been ${isApprover() ? "noted" : "approved"} successfully.`
            );
            SuccessDialogToggle();
          }
          if (currectbtn === "Reject") {
            SetSuccessMsg(
              "The request for committee note has been rejected successfully."
            );
            SuccessDialogToggle();
          }
          if (currectbtn === "Refer") {
            SetSuccessMsg(
              "The request for committee note has been referred successfully."
            );
            SuccessDialogToggle();
          }
          if (currectbtn === "Return") {
            SetSuccessMsg(
              "The request for committee note has been returned successfully."
            );
            SuccessDialogToggle();
          }
        }
      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  };

  // Attchments for gist doc
  const attchemtsForGistDoc = () => {
    var selectedFile = document.getElementById("WordDocfile").files;
    let waringmsg = "";
    let isValidFile = true;
    if (selectedFile.length > 0) {
      var fileExtension = selectedFile[0].name.split(".");
      const nameFile = selectedFile[0].name;
      if (
        !(
          nameFile.toLowerCase().endsWith(".docx") ||
          nameFile.toLowerCase().endsWith(".doc") ||
          nameFile.toLowerCase().endsWith(".pdf")
        )
      ) {
        waringmsg = "File type not allowed";
        SetfilesWordWarning(waringmsg);
        isValidFile = false;
        SetWordPDFInfowarring({
          ...wordandPdfInfo,
          wordInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: "",
            isValid: false,
            isDownloadble: false,
            base64: ""
          },
        });

        return isValidFile;
      }
      /* 5MB = 5242880  */
      if (selectedFile[0].size > 5242880) {
        waringmsg = "File size should not exceed more then 5 MB";
        isValidFile = false;
        SetfilesWordWarning(waringmsg);
        SetWordPDFInfowarring({
          ...wordandPdfInfo,
          wordInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: "",
            isValid: false,
            isDownloadble: false,
            base64: ""
          },
        });
        return isValidFile;
      }
      if (checkingSpl(selectedFile[0].name)) {
        isValidFile = false;
        waringmsg = "File name sholud not contain special characters";
        SetfilesWordWarning(waringmsg);
        SetWordPDFInfowarring({
          ...wordandPdfInfo,
          wordInfo: {
            fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
            fileName: selectedFile[0].name,
            filePath: "",
            isValid: false,
            isDownloadble: false,
            base64: ""
          },
        });
        return isValidFile;
      }
      if (isValidFile === true) {
        var fileToLoad = selectedFile[0];
        // FileReader function for read the file.
        var fileReader = new FileReader();
        // var base64;
        // Onload of file read the file content
        fileReader.onload = function (fileLoadedEvent) {
          let base64 = fileLoadedEvent.target.result;
          const RemovedHeaderFormBase64 = base64.split(",")[1];

          const partLength = Math.ceil(RemovedHeaderFormBase64.length / 10);
          const parts = [];

          for (let i = 0; i < 10; i++) {
            parts.push(RemovedHeaderFormBase64.slice(i * partLength, (i + 1) * partLength));
          }
          SetfilesWordWarning("");
          SetWordPDFInfowarring({
            ...wordandPdfInfo,
            wordInfo: {
              fileExtension: `.${fileExtension[fileExtension.length - 1]}`,
              fileName: selectedFile[0].name,
              // filePath: RemovedHeaderFormBase64[1],
              filePath: {
                part1: parts[0],
                part2: parts[1],
                part3: parts[2],
                part4: parts[3],
                part5: parts[4],
                part6: parts[5],
                part7: parts[6],
                part8: parts[7],
                part9: parts[8],
                part10: parts[9]
              },
              isValid: true,
              isDownloadble: false,
              base64: ""
            },
          });
        };
        // Convert data to base64
        fileReader.readAsDataURL(fileToLoad);
      }
    }
  };

  // referred back function calling api
  const onReferredback = async () => {
    SetIsLoading(true);
    const referComments = [];
    const referredDocs = [];
    const curntReferredBackUserObj = noteData.noteReferrerDTO?.filter(
      (obj) => obj.referrerEmail === currentActionerEmail
    );
    const currentApproverInfo = noteData.noteApproversDTO?.filter(
      (obj) => obj.approverEmail === curntReferredBackUserObj[0].approverEmail
    );
    // get all Comments Info
    generalcmtforAllCmt?.map((obj) => {
      referComments.push({
        pageNumber: obj.PageNo,
        docReferrence: obj.DocRef,
        referrerComment: obj.Comments,
      });
    });
    //get invaild file name 
    const unValidFileNames = Object.keys(supportDocWarning).filter(
      (fileName) => supportDocWarning[fileName]?.isValid === false
    );
    // filter valid files only (Naren...)
    filesInfo.filter((obj) => {
      if (!unValidFileNames.includes(obj.supportingDocumentFileName)) {
        referredDocs?.push({
          supportingDocumentPath: obj.supportingDocumentPath,
          supportingDocumentFileName: obj.supportingDocumentFileName,
        });
      }
    });
    const updatingObj = {
      noteId: noteData.noteId,
      approverType: currentApproverInfo[0].approverType,
      approverEmail: curntReferredBackUserObj[0].approverEmail,
      referrerStatus: 2,
      createdBy: accounts[0].username,
      noteReferrerCommentDTO: referComments,
      noteSupportingDocumentsDTO: referredDocs,
    };
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eCommitte_UpdateNoteReferresStatus}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(updatingObj),
      }
    )
      .then(async (data) => {
        const resp = await data.json();
        if (resp.statusMessage === "Failed") {
          SetIsLoading(false);
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          SetSuccessMsg(
            "The request for committee note has been referred back successfully."
          );
          SuccessDialogToggle();
          SetMarkInfoUserEmail([]);
        }
      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  };

  // confirmation
  const onCofiormation = async () => {
    if (
      currectbtn === "Approve" ||
      currectbtn === "Return" ||
      currectbtn === "Reject"
    ) {
      await Promise.all([approverStatusChange()])
        .then(() => {
          SetIsVisible(false);
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }

    if (currectbtn === "AttchGistDoc") {
      addAttachmentsGistDoc();
      SetIsVisible(false);
    }
    if (currectbtn === "Refer Back") {
      onReferredback();
      SetIsVisible(false);
    }
    if (currectbtn === "MarkInfo") {
      addmarkInfotoDataBase();
      SetIsVisible(false);
    }
    // if (currectbtn === "CancelNote") {
    //   // onCancelNote()
    //   SetIsVisible(false);
    // }
  };

  // Selected Refer user
  const selectedReferrUser = (event) => {
    SetSelectedRefer(event.value);
  };

  //  attach gist documents
  const onSubmitForAttcGISTDoc = () => {
    // change 16/04 gist doc is mandtoary
    if (wordandPdfInfo?.wordInfo?.isValid) {
      SetCurrentBtn("AttchGistDoc");
      setConfirmDailogObj({
        Confirmtext: "Are you sure you want to submit this request?",
        Description: "Please click on Confirm button to submit request.",
      });
      toggleDailogForConfirmation();
    } else {
      SetCurrentBtn("AttchGistDoc");
      setUserNotifyInfo(
        "Please select vaild Gist Document then click on Submit."
      );
      setUserComboValidationDialog(true);
    }
  };

  //  addattchement gist Doc
  const addAttachmentsGistDoc = async () => {
    SetIsLoading(true);
    /*   "noteSecretarieId": cuurentSecretaryObj[0]?.noteSecretarieId,
      ": ,
  "noteApproverId": 0,
  edBy": "string""noteId": 0,
  "secretaryEmail": "string",
  "approverEmail": "string",
  "gistWordDocumentPath": "string",
  "gistWordDocumentFileName": "string",
  "createdDate": "2024-03-02T06:04:28.810Z",
  "creat */
    const cuurentSecretaryObj = noteData.noteSecretaryDTO?.filter(
      (obj) => obj.secretaryEmail === accounts[0].username

    );
    const base64Parts = wordandPdfInfo.wordInfo.filePath;
    const attchmentDocObj = {
      "noteSecretarieId": cuurentSecretaryObj[0]?.noteSecretarieId,
      noteApproverId: cuurentSecretaryObj[0]?.noteApproverId,
      noteId: noteData.noteId,
      secretaryEmail: cuurentSecretaryObj[0]?.secretaryEmail,
      // "secretaryEmail": accounts[0].username,
      approverEmail: cuurentSecretaryObj[0]?.approverEmail,
      // "approverEmail":accounts[0].username,
      // gistWordDocumentPath: wordandPdfInfo.wordInfo.filePath,
      gistWordDocumentFileName: wordandPdfInfo.wordInfo.fileName,
      createdDate: new Date(),
      createdBy: accounts[0].username,
      // modifiedDate: new Date(),
      // modifiedBy: accounts[0].username,
    };
    // Dynamically add the GistWordDocumentPathPart keys -- Kavya (22/07)
    for (let i = 1; i <= 10; i++) {
      attchmentDocObj[`GistWordDocumentPathPart${i}`] = base64Parts[`part${i}`];
    }
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(`${API_BASE_URL}${API_ENDPOINTS.eCommitte_InserNoteSecretary}`, {
      method: "POST",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(attchmentDocObj),
    })
      .then(async (data) => {
        const resp = await data.json();

        if (resp.statusMessage === "Failed") {
          SetIsLoading(false);
          faildDialogToggle();
        } else {
          SetIsLoading(false);
          SetSuccessMsg(
            "The request has been updated successfully."
          );
          SuccessDialogToggle();
          SetMarkInfoUserEmail([]);
        }
      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  };

  // mark info  row in table
  const addUserInForMarkInfo = () => {
    // SetIsLoading(true);
    // SetGetAllUserInfo(getAllUserInfoDeatils);
    const userSlength = markInfoUserEmail?.length;
    if (userSlength <= 9) {
      if (
        selectedMarjUserInfo === "" ||
        selectedMarjUserInfo === undefined ||
        selectedMarjUserInfo === null
      ) {
        setUserNotifyInfo(
          "Please select the user then click on Add User."
        );
        setUserComboValidationDialog(true);
      } else {
        const ismarkedEmailExist = markInfoUserEmail.some(
          (obj) => obj.markedEmail === selectedMarjUserInfo.userPrincipalName
        );
        /*  const ismarkedEmailExist = noteData?.noteMarkedInfoDTO?.some(
           obj => obj.markedEmail === selectedMarjUserInfo.userPrincipalName
         ) */

        // if (isObjExist || ismarkedEmailExist) {
        if (ismarkedEmailExist) {
          setUserNotifyInfo(
            "The selected user already exist. Kindly choose another user."
          );
          setUserComboValidationDialog(true);

        } else {

          const newMarkInfoUserEmail = [
            ...markInfoUserEmail,
            {
              noteId: noteData.noteId,
              markedEmail: selectedMarjUserInfo.userPrincipalName,
              createdBy: accounts[0].username,
              // Bug -293 29/03
              markedEmailName: selectedMarjUserInfo.displayName
            },
          ];

          SetMarkInfoUserEmail(newMarkInfoUserEmail);
          SetSelectedMarjUserInfo(null);
        }
      }
    } else {
      setUserNotifyInfo(
        "Maximum 10 users allowed."
      );
      setUserComboValidationDialog(true);

    }
    // SetIsLoading(false);
  };

  // remove user for mark info
  const removeUserFromMarkInfo = (id) => {
    SetMarkInfoUserEmail(markInfoUserEmail.filter((obj, ind) => ind !== id));
  };

  // select mark info user
  const onchangehanleMarkInfo = (event) => {
    SetSelectedMarjUserInfo(event.value);
  };

  // mark info add to  API
  const addmarkInfotoDataBase = async () => {
    SetIsLoading(true);
    // Bug 293 29/03
    let markinfouserDetails = markInfoUserEmail?.map(item => {
      const { markedEmailName: _, ...rest } = item; // Destructure 'markedEmailName' and collect the rest
      return rest; // Return object without 'markedEmailName' property
    });

    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    await fetch(
      `${API_BASE_URL}${API_ENDPOINTS.eCommitte_AddNoteMarkedInformation}`,
      {
        method: "POST",
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(markinfouserDetails) // markInfoUserEmail
      }
    )
      .then(async (data) => {
        const rep = await data.json();
        SetIsLoading(false);
        if (rep.statusMessage === "Failed") {
          faildDialogToggle();
        } else {
          SetSuccessMsg(
            "The mark for information has been updated successfully."
          );
          SuccessDialogToggle();
          SetMarkInfoUserEmail([]);
        }
      })
      .catch((err) => {
        SetIsLoading(false);
        faildDialogToggle();
        console.log(err);
      });
  };

  // confirm dialog box adding title and  icons
  const CustomTitleBar = () => {
    return (
      <div
        className="custom-title"
        style={{
          fontSize: "16px",
          lineHeight: "1.3em",
        }}
      >
        <SvgIcon icon={infoCircleIcon} />{" "}
        {currectbtn === "Refer" ? " Add Referee" : currectbtn === "ChangeApprover" ? "Change Approver" : "Alert!"}
      </div>
    );
  };

  // conformiation 
  const CustomConfirmtionTitleBar = () => {
    return (
      <div className="custom-title ">
        <span className="k-icon k-font-icon k-i-borders-show-hide cursor allIconsforPrimary-btn"></span> Confirmation
      </div>
    );
  };
  //  <div className="custom-title ">

  const CustomSuccussTitleBar = () => {
    return (
      <div
        className="custom-title"
        style={{
          fontSize: "16px",
          lineHeight: "1.3em",
        }}
      >
        <SvgIcon icon={infoCircleIcon} /> Alert!
      </div>
    );
  };

  // Approval checking if current actioner is approver or reviewer  and is  login user  display the buttons
  const approverChecking = () => {
    let isCurrentActioner = false;
    if (
      currentActionerEmail === accounts[0].username &&
      (noteData.noteStatusCommittees === 2 || noteData.noteStatusCommittees === 3) &&
      noteData !== null &&
      noteData?.noteApproversDTO.some(
        (obj) =>
          obj.approverEmail === currentActionerEmail &&
          obj.approverEmail === accounts[0].username
      )
    ) {
      isCurrentActioner = true;
    }
    return isCurrentActioner;
  };

  // Approver finding
  const isApprover = () => {
    let isCurrentActioner = false;
    if (
      currentActionerEmail === accounts[0].username &&
      noteData?.strNatureofNote === "Information" &&
      (noteData.noteStatusCommittees === 2 || noteData.noteStatusCommittees === 3) &&
      noteData !== null &&
      noteData?.noteApproversDTO.some(
        (obj) =>
          obj.approverEmail === currentActionerEmail &&
          obj.approverEmail === accounts[0].username &&
          obj.approverType === 2
      )
    ) {
      isCurrentActioner = true;
    }
    return isCurrentActioner;
  };

  // Handle fileter  assignees 
  const filterAssigneesInfo = (filter) => {
    const getAllUser = assigneerUserDetails.filter((item) =>
      item.atrAssignerEmail
        .toLowerCase()
        .includes(filter.value.toLowerCase())
    )
    return getAllUser;

  }

  // ATR assignees filtr functionality
  const onFilterChangeForAtrAssigness = (event) => {

    clearTimeout(timeout.current);
    timeout.current = setTimeout(() => {
      SetAssigneerUser(filterAssigneesInfo(event.filter));
      // setLoading(false);
    });
    // setLoading(true);
  };

  // filter all users
  const onFillterALLUser = async (event) => {
    if (event.filter.value.length >= 4) {
      const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

      await fetch(
        `${API_BASE_URL}${API_ENDPOINTS.Search_UserDetails(
          event.filter.value
        )}`,
        {
          method: "GET",
          headers: {
            ...API_COMMON_HEADERS,
            Authorization: `Bearer ${accessToken}`,
          },
        }
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          const orgUsers = data.map(x => {
            return { ...x, department: x.department === null ? "NA" : x.department, displayName: x.displayName === null ? "NA" : x.displayName, jobTitle: x.jobTitle === null ? "NA" : x.jobTitle, userPrincipalName: x.userPrincipalName, srNo: x.srNo === null ? "NA" : x.srNo }
          });
          SetGetAllUserInfo(orgUsers);
        })
        .catch((err) => {
          SetGetAllUserInfo([]);
          console.log(err);
        });
    }
    else {
      SetGetAllUserInfo([]);
    }
  }

  // Handle close notify dialog
  const oncloseUseNotify = () => {
    if (currectbtn === "Return" || currectbtn === "Reject" || currectbtn === "Refer Back") {
      setExpanded("General Comments")
      setUserComboValidationDialog(false)
    }
    else if (currectbtn === "ChangeApprover") {
      setisVisibleSelectingUser(true);
      SetCurrentBtn("ChangeApprover");

    }
    setUserComboValidationDialog(false);

  }

  // approval icons render
  const renderApproverIcon = (approverStatus) => {
    let icon = "k-i-clock";
    if (approverStatus === 1) {
      // icon="k-i-rotate-circle"
      icon = "k-i-rotate"
    }
    if (approverStatus === 2) {
      icon = "k-i-clock"
    }
    if (approverStatus === 3) {
      icon = "k-i-check-circle"
    }
    if (approverStatus === 4) {
      icon = "k-i-close-outline k-i-x-outline"
    }
    if (approverStatus === 5) {
      icon = "k-i-undo"
    }
    if (approverStatus === 6) {
      icon = "k-i-arrow-root"

    }
    /*  switch (approverStatus) {
       case 1:
         return <span className="k-icon k-font-icon k-i-rotate-circle cursor allIconsforPrimary-btn"></span>;
       case 2:
         return <span className="k-icon k-font-icon k-i-clock cursor allIconsforPrimary-btn"></span>;
       case 3:
         return <span className="k-icon k-font-icon k-i-check-circle cursor allIconsforPrimary-btn"></span>;
       case 4:
         return <span className="k-icon k-font-icon k-i-close-outline k-i-x-outline cursor allIconsforPrimary-btn"></span>;
       case 5:
         return <span className="k-icon k-font-icon k-i-undo cursor allIconsforPrimary-btn"></span>;
       default:
         return <span className="k-icon k-font-icon k-i-undo cursor allIconsforPrimary-btn"></span>;
     } */
    return icon
  }

  return (
    <div>
      <Navbar />
      <Sidebar />
      <div className="FormMaincontainer">
        <div className="container">
          <fieldset className={"k-form-fieldset"}>
            <div className="container">
              <div className="container viewHeader">
                {/* <div className="SectionHeads row"> */}
                <div className="SectionHeads-viewForm">
                  <span className="cstformHdrLeftContainer mobiletitle">
                    {/* Bug -293 28/03 */}
                    {`pending with: ${noteData?.currentActionerName || ""}`}
                  </span>
                  <span className="cstformHdrMiddleContainer mobiletitle">
                    eCommittee Note - {noteData?.noteNumber || ""}

                  </span>
                  <span className="cstformHdrRightContainer mobiletitle">

                    {`Status : ${noteData ? noteData?.strNoteStatus : ""}`}
                  </span>
                </div>
              </div>
              <div className="viewFormhomepageContainer">
                <div className={isPDFFullWidth ? "homesectionPdf-1" : "viewFormSection-1"}>
                  {expendJson.map((item) =>
                    item.isVisible ? (
                      <ExpansionPanel
                        title={
                          <div className="_expensionPanel_div">
                            <div />
                            {item.id}
                          </div>
                        }
                        expanded={expanded === item.id}

                        tabIndex={0}
                        onAction={(event) => {
                          setExpanded(event.expanded ? "" : item.id);
                        }}
                      >
                        <Reveal>
                          {noteData !== null && (
                            <>
                              {expanded === item.id && (
                                <ExpansionPanelContent>
                                  {item.id === "General Section" &&
                                    item.isVisible && (
                                      <>
                                        {" "}
                                        {noteData && (
                                          <table className="ib-forms-custom-table tableStyle">

                                            <tbody>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Note Number</th>
                                                <td className="approvalform-tableCol-width-5">{noteData.noteNumber}</td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Requester </th>
                                                {/* Bug -293 28/03 */}
                                                <td className="approvalform-tableCol-width-5">{noteData.createdByName}</td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Request Date </th>
                                                <td className="approvalform-tableCol-width-5">
                                                  {getdateconversion(
                                                    noteData.createdDate
                                                  )}
                                                </td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Status </th>
                                                <td className="approvalform-tableCol-width-5">
                                                  {noteData.strNoteStatus}
                                                </td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Current Approver </th>
                                                {/* Bug -293 28/03 */}
                                                <td className="approvalform-tableCol-width-5">{noteData.currentActionerName}</td>
                                              </tr>
                                              {/* <tr>
                                                <th className="approvalform-tableCol-width-5">Note to </th>
                                                <td className="approvalform-tableCol-width-5">{noteData.strNoteTo}</td>
                                              </tr> */}
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Department </th>
                                                <td className="approvalform-tableCol-width-5">
                                                  {noteData.departmentName}
                                                </td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Subject</th>
                                                <td className="approvalform-tableCol-width-5">{noteData.subject}</td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Nature of the Note </th>
                                                <td className="approvalform-tableCol-width-5">
                                                  {noteData.strNatureofNote}
                                                </td>
                                              </tr>
                                              {(noteData.strNatureofNote === "Sanction" || noteData.strNatureofNote === "Approval") && (
                                                <tr>
                                                  <th className="approvalform-tableCol-width-5">
                                                    Nature of Approval / Sanction{" "}
                                                  </th>
                                                  <td className="approvalform-tableCol-width-5">
                                                    {
                                                      noteData.strNatureOfApprovalOrSanction === "0" ? "NA" : noteData.strNatureOfApprovalOrSanction
                                                      // noteData.strNatureOfApprovalOrSanction
                                                    }
                                                  </td>
                                                </tr>
                                              )}
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Note Type </th>
                                                <td className="approvalform-tableCol-width-5">{noteData.strNoteType}</td>
                                              </tr>
                                              {noteData.strNoteType === "Financial" && (<tr>
                                                <th className="approvalform-tableCol-width-5">Amount</th>
                                                <td className="approvalform-tableCol-width-5">{noteData.strAmount}</td>
                                                {/* <td className="approvalform-tableCol-width-5">{amountCoversion(noteData?.amount)}</td> */}
                                              </tr>

                                              )}
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Search Keyword </th>
                                                <td className="approvalform-tableCol-width-5">
                                                  {noteData.searchKeyword}
                                                </td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Committee Name</th>
                                                <td className="approvalform-tableCol-width-5">
                                                  {noteData?.committeesDTO[0]?.committeeName || ""}

                                                </td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Committee Status</th>
                                                <td className="approvalform-tableCol-width-5">
                                                  {noteData.strNoteStatus}
                                                </td>
                                              </tr>
                                              <tr>
                                                <th className="approvalform-tableCol-width-5">Purpose</th>
                                                <td className="approvalform-tableCol-width-5">{noteData.purpose}</td>
                                              </tr>
                                            </tbody>
                                          </table>
                                        )}
                                      </>
                                    )}
                                  {item.id === "Reviewers Section" &&
                                    item.isVisible && (
                                      <div className="table-responsive">
                                        {noteData && (
                                          <table className="ib-forms-custom-table tableStyle">

                                            <tbody>
                                              <tr>
                                                {/* Bug fix - 294 - 28/03 */}

                                                <th className="approvalform-tableCol-width-2">Reviewer Name </th>
                                                <th className="approvalform-tableCol-width-1">SR No</th>
                                                <th className="approvalform-tableCol-width-2">Designation</th>
                                                <th className="approvalform-tableCol-width-2">Status </th>
                                                <th className="approvalform-tableCol-width-3">Action Date </th>
                                              </tr>
                                              {noteData.noteApproversDTO?.map(
                                                (obj) =>
                                                  obj.approverType === 1 && (
                                                    <tr key={obj.approverEmail} className={`${obj.approverStatus === 2 ? "selected-row" : ""}`}>
                                                      {/* Bug fix - 294 - 28/03 */}

                                                      <td className="approvalform-tableCol-width-2">
                                                        {obj.approverEmailName}
                                                        {/* )} */}
                                                      </td>
                                                      <td className="approvalform-tableCol-width-1">{obj.srNo}</td>
                                                      <td className="approvalform-tableCol-width-2">{obj.designation}</td>
                                                      {/* <td>{obj.approverEmail}</td> */}
                                                      <td className="approvalform-tableCol-width-2">
                                                        {/* {renderApproverIcon(obj.approverStatus)}   */}
                                                        <span className={`k-icon k-font-icon ${renderApproverIcon(obj.approverStatus)}  allIconsforPrimary-btn`}></span>
                                                        {obj.strApproverStatus}
                                                      </td>
                                                      <td className="approvalform-tableCol-width-3">
                                                        {
                                                          (obj.approverStatus === 1 ||
                                                            obj.approverStatus === 2) ? ""
                                                            :
                                                            getdateconversion(
                                                              obj.modifiedDate
                                                            )}
                                                      </td>
                                                    </tr>
                                                  )
                                              )}
                                            </tbody>
                                          </table>
                                        )}
                                      </div>
                                    )}
                                  {item.id === "Approvers Section" &&
                                    item.isVisible && (
                                      <div className="table-responsive">
                                        {" "}
                                        <table className="ib-forms-custom-table tableStyle">
                                          <tbody></tbody>{" "}
                                          <tr>
                                            {/* Bug fix - 294 - 28/03 */}

                                            <th className="approvalform-tableCol-width-2">Approver Name </th>
                                            <th className="approvalform-tableCol-width-1">SR No</th>
                                            <th className="approvalform-tableCol-width-2">Designation</th>
                                            <th className="approvalform-tableCol-width-2">Status </th>
                                            <th className="approvalform-tableCol-width-3">Action Date </th>
                                          </tr>
                                          {noteData.noteApproversDTO?.map(
                                            obj =>
                                              obj.approverType === 2 && (
                                                <tr key={obj.approverEmail} className={`${obj.approverStatus === 2 ? "selected-row" : ""}`}>
                                                  {/* Bug fix - 294 - 28/03 */}

                                                  <td className="approvalform-tableCol-width-2">
                                                    {obj.approverEmailName}
                                                    {/* )} */}
                                                  </td>
                                                  <td className="approvalform-tableCol-width-1">{obj.srNo}</td>
                                                  <td className="approvalform-tableCol-width-2">{obj.designation}</td>
                                                  {/* <td>{obj.approverEmail}</td> */}
                                                  <td className="approvalform-tableCol-width-2">
                                                    {/* {renderApproverIcon(obj.approverStatus)}  */}
                                                    <span className={`k-icon k-font-icon ${renderApproverIcon(obj.approverStatus)}  allIconsforPrimary-btn`}></span>
                                                    {obj.strApproverStatus}
                                                  </td>
                                                  <td className="approvalform-tableCol-width-3">
                                                    {
                                                      (obj.approverStatus === 1 ||
                                                        obj.approverStatus === 2) ? ""
                                                        :
                                                        getdateconversion(
                                                          obj.modifiedDate
                                                        )}
                                                  </td>
                                                </tr>
                                              )
                                          )}
                                        </table>
                                      </div>
                                    )}
                                  {item.id === "General Comments" &&
                                    item.isVisible && (
                                      <div >
                                     
                                      <div className="table-responsive">
                                        <table className="ib-forms-custom-table tableStyle mob_table">
                                          <thead>
                                            <tr>
                                              <th className="approvalform-tableCol-width-1">Page#</th>
                                              <th className="approvalform-tableCol-width-1">Doc Reference</th>
                                              <th className="approvalform-tableCol-width-6">Comments</th>
                                              <th className="approvalform-tableCol-width-2">Action</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            <tr className="non_mobileResponsive">
                                              <td className="approvalform-tableCol-width-1">
                                                <div onKeyDown={(e) => e.stopPropagation()}>
                                                  <input
                                                    className="general-comments-pageNo"
                                                    type="text"
                                                    name="PageNo"
                                                    value={generalcmtInfoobj.PageNo}
                                                    onChange={handelGenralComments}
                                                  />
                                                </div>
                                              </td>
                                              <td className="approvalform-tableCol-width-1">
                                                <div onKeyDown={(e) => e.stopPropagation()}>
                                                  <input
                                                    className="general-comments-DocRef"
                                                    name="DocRef"
                                                    value={generalcmtInfoobj.DocRef}
                                                    onChange={handelGenralComments}
                                                  />
                                                </div>
                                              </td>
                                              <td className="approvalform-tableCol-width-6">
                                                {/* <div> */}
                                                <div onKeyDown={(e) => e.stopPropagation()}>
                                                  {/* <textarea
                                                  name="Comments"
                                                  className="general-comments-Comments"
                                                  row={1}
                                                  value={
                                                    generalcmtInfoobj.Comments
                                                  }
                                                  onChange={
                                                    handelGenralComments
                                                  }
                                                ></textarea> */}
                                                  <textarea
                                                    name="Comments"
                                                    className="general-comments-Comments"
                                                    row={1}
                                                    value={generalcmtInfoobj.Comments}
                                                    onChange={handelGenralComments}
                                                    onClick={handleCommentsMobile}
                                                    disabled={mobileCommentsDialog} // This should be true when dialog is open
                                                  ></textarea>
                                                </div>
                                              </td>
                                              <td className="approvalform-tableCol-width-2">
                                                {/* <span hidden={isCurrentSecretary}> */}
                                                <Button
                                                  className="formBtnColor non_mobileResponsive"
                                                  onClick={handelAddCmts}
                                                >
                                                  <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                                  Add
                                                </Button>
                                                <Button
                                                  className="formBtnColor _mobileResponsive"
                                                  onClick={handelAddCmts}
                                                >
                                                  <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>

                                                </Button>
                                                {/* </span> */}
                                              </td>
                                            </tr>
                                            {generalcmtforAllCmt?.map(
                                              (obj, index) => (
                                                <tr key={index}>
                                                  <td className="approvalform-tableCol-width-1">
                                                    {obj.isEdit ? (
                                                      <div onKeyDown={(e) => e.stopPropagation()}>
                                                        <input
                                                          type="text"
                                                          className="general-comments-pageNo"
                                                          value={obj.PageNo}
                                                          name="PageNo"
                                                          id={index}
                                                          onChange={
                                                            handelGenralCommentsEdit
                                                          }
                                                          onClick={() => handleCommentsEditMobile(obj.Comments, obj.PageNo, obj.DocRef, index)}
                                                        />
                                                      </div>
                                                    ) : (
                                                      obj.PageNo
                                                    )}
                                                  </td>
                                                  <td className="approvalform-tableCol-width-1">
                                                    {obj.isEdit ? (
                                                      <div onKeyDown={(e) => e.stopPropagation()}>
                                                        <input
                                                          type="text"
                                                          className="general-comments-DocRef"
                                                          value={obj.DocRef}
                                                          name="DocRef"
                                                          id={index}
                                                          onChange={
                                                            handelGenralCommentsEdit
                                                          }
                                                          onClick={() => handleCommentsEditMobile(obj.Comments, obj.PageNo, obj.DocRef, index)}
                                                        />
                                                      </div>
                                                    ) : (
                                                      obj.DocRef
                                                    )}
                                                  </td>
                                                  {/* <td>{obj.isEdit?<textarea rows={1} value={(generalcmtInfoobjEdit["DocRef"].isEdit && Number(generalcmtInfoobjEdit["DocRef"].id) === index) ? generalcmtInfoobjEdit["DocRef"].value : obj.DocRef} name="DocRef" id={index} onChange={handelGenralCommentsEdit}></textarea>:obj.DocRef}</td> */}
                                                  <td className="approvalform-tableCol-width-6">
                                                    {obj.isEdit ? (
                                                      // <div>
                                                      <div onKeyDown={(e) => e.stopPropagation()}>
                                               
                                                        <textarea
                                                          value={obj.Comments}
                                                          className="general-comments-Comments"
                                                          name="Comments"
                                                          id={index}
                                                          onChange={
                                                            handelGenralCommentsEdit
                                                          }
                                                          onClick={() => handleCommentsEditMobile(obj.Comments, obj.PageNo, obj.DocRef, index)}
                                                          disabled={mobileCommentsEditDialog}
                                                        ></textarea>
                                                      </div>
                                                    ) : (
                                                      obj.Comments
                                                    )}
                                                  </td>
                                                  <td className="approvalform-tableCol-width-1">
                                                    {
                                                      obj.isEdit ?
                                                        <>
                                                          <Button
                                                            className="formBtnColor non_mobileResponsive"
                                                            onClick={() =>
                                                              handleGeneraleditedcommentsSave(index)
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-save cursor allIconsforPrimary-btn"></span>
                                                            Save
                                                          </Button>
                                                          <Button
                                                            className="formBtnColor _mobileResponsive"
                                                            onClick={() =>
                                                              handleGeneraleditedcommentsSave(index)
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-save cursor allIconsforPrimary-btn"></span>

                                                          </Button> </> : <>

                                                          <Button
                                                            className="non_mobileResponsive"
                                                            onClick={() =>
                                                              handelDeleteCmt(index)
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>
                                                            Delete
                                                          </Button>
                                                          <Button
                                                            className="_mobileResponsive"
                                                            onClick={() =>
                                                              handelDeleteCmt(index)
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>

                                                          </Button>
                                                          <Button
                                                            className="non_mobileResponsive"
                                                            onClick={() =>
                                                              handelingEdit(index)
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-edit cursor allIconsforPrimary-btn"></span>
                                                            Edit
                                                          </Button>
                                                          <Button
                                                            className=" _mobileResponsive"
                                                            onClick={() =>
                                                              handelingEdit(index)
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-edit cursor allIconsforPrimary-btn"></span>

                                                          </Button>
                                                        </>

                                                    }
                                                  </td>
                                                </tr>
                                              )
                                            )}
                                          </tbody>
                                        </table>
                                      </div>
                                      <div className="mobileCommentButton">
                                      <Button
                                          className="formBtnColor _mobileResponsive addMobile"
                                          onClick={handleOpenCommentDialog}
                                        >
                                          <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                          Add
                                        </Button>
                                      </div>
                                      </div>
                                    )}

                                  {item.id === "ATR Assignees" &&
                                    item.isVisible && (
                                      <>
                                        <div className="committeeNote-Assignees-container">
                                          <div onKeyDown={(e) => e.stopPropagation()}>
                                            <ComboBox
                                              disabled={!noteData?.noteApproversDTO?.some(
                                                obj => obj.approverEmail === accounts[0].username &&
                                                  obj.approverEmail === noteData?.currentActioner &&
                                                  obj.approverType === 2 && obj.approverStatus === 2)}
                                              data={[
                                                ...new Set(
                                                  assigneerUser.map(
                                                    (obj) =>
                                                      obj.atrAssignerEmailName
                                                    // obj.atrAssignerEmailName
                                                  )
                                                ),
                                              ]}
                                              value={combovalueApprover}
                                              // value={assigneerUser.find(obj=>obj.atrAssignerEmail ===combovalueApprover)?.atrAssignerEmailName ||""}
                                              filterable={true}
                                              onFilterChange={
                                                onFilterChangeForAtrAssigness
                                              }
                                              onChange={
                                                handleComboChangeAssignees
                                              }
                                              placeholder="Select Assignee.."
                                             
                                              className="_atrAssineesCombobox"
                                            />
                                          </div>
                                          <Button
                                            className="formBtnColor non_mobileResponsive"
                                            onClick={handleAddRowAssignees}
                                            disabled={!noteData?.noteApproversDTO?.some(
                                              obj => obj.approverEmail === accounts[0].username &&
                                                obj.approverEmail === noteData?.currentActioner &&
                                                obj.approverStatus === 2)}
                                          >
                                            <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                            Add
                                          </Button>
                                          <Button
                                            className="formBtnColor _mobileResponsive"
                                            onClick={handleAddRowAssignees}
                                            disabled={!noteData?.noteApproversDTO?.some(
                                              obj => obj.approverEmail === accounts[0].username &&
                                                obj.approverEmail === noteData?.currentActioner &&
                                                obj.approverStatus === 2)}
                                          >
                                            <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>

                                          </Button>

                                        </div>
                                        {" "}
                                        <div className="table-responsive">
                                          <table className="ib-forms-custom-table tableStyle">
                                            <thead>
                                              <tr>
                                                <th className="approvalform-tableCol-width-3">Comments</th>
                                                <th className="approvalform-tableCol-width-3">Assigned To</th>
                                                <th className="approvalform-tableCol-width-2"> Status</th>
                                                {/* Atr comments & status 29/03 */}
                                                {noteData?.noteApproversDTO?.some(
                                                  obj => obj.approverEmail === accounts[0].username &&
                                                    obj.approverEmail === noteData?.currentActioner &&
                                                    obj.approverStatus === 2) && (<th className="approvalform-tableCol-width-2"> Action</th>)}


                                              </tr>
                                            </thead>
                                            <tbody>
                                              {/* <tr>
                                              <td className="approvalform-tableCol-width-3"></td>

                                              <td className="approvalform-tableCol-width-3">
                                                <div onKeyDown={(e) => e.stopPropagation()}>
                                                  <ComboBox
                                                    disabled={!noteData?.noteApproversDTO?.some(
                                                      obj => obj.approverEmail === accounts[0].username &&
                                                        obj.approverEmail === noteData?.currentActioner &&
                                                        obj.approverType === 2 && obj.approverStatus === 2)}
                                                    data={[
                                                      ...new Set(
                                                        assigneerUser.map(
                                                          (obj) =>
                                                            obj.atrAssignerEmail
                                                        )
                                                      ),
                                                    ]}
                                                    value={combovalueApprover}
                                                    filterable={true}
                                                    onFilterChange={
                                                      onFilterChangeForAtrAssigness
                                                    }
                                                    onChange={
                                                      handleComboChangeAssignees
                                                    }
                                                    placeholder="Select Assignee.."
                                                    style={{
                                                      width: "100%",
                                                      marginRight: "5px",
                                                    }}
                                                  />
                                                </div>
                                              </td>
                                              <td className="approvalform-tableCol-width-2"></td>

                                              <td className="approvalform-tableCol-width-2">
                                                <Button
                                                  className="formBtnColor"
                                                  onClick={handleAddRowAssignees}
                                                  disabled={!noteData?.noteApproversDTO?.some(
                                                    obj => obj.approverEmail === accounts[0].username &&
                                                      obj.approverEmail === noteData?.currentActioner &&
                                                      obj.approverStatus === 2)}
                                                >
                                                  <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                                  Add
                                                </Button>
                                              </td>
                                            </tr> */}
                                              {noteData?.atrAssigneesDTO?.map((obj, index) =>
                                                obj.approverEmail === accounts[0].username && (
                                                  <tr key={obj.atrAssignerEmail}>
                                                    <td>
                                                      {obj.noteApproverComments}
                                                    </td>
                                                    <td>
                                                      {/* Bug -293 28/03 */}
                                                      {obj?.atrAssignerEmailName}
                                                      {/* {obj.atrAssignerEmail} */}
                                                    </td>
                                                    <td>
                                                      {obj.strATRStatus}
                                                    </td>
                                                    {/* 29/03 */}
                                                    {noteData?.noteApproversDTO?.some(
                                                      obj => obj.approverEmail === accounts[0].username &&
                                                        obj.approverEmail === noteData?.currentActioner &&
                                                        obj.approverStatus === 2) && (


                                                        <td>
                                                          {""}
                                                        </td>
                                                      )}

                                                  </tr>

                                                )

                                              )}
                                              {assigneerUserinfo?.map(
                                                (obj, index) => (
                                                  <tr key={obj.atrAssignerEmail}>
                                                    <td className="approvalform-tableCol-width-3">
                                                      {generalcmtforAllCmt
                                                        ?.map(
                                                          (obj) =>
                                                            `${obj.PageNo} ${obj.DocRef} ${obj.Comments}`
                                                        )
                                                        .join(", ")}
                                                    </td>
                                                    <td className="approvalform-tableCol-width-3">
                                                      {/* {obj.atrAssignerEmail} */}
                                                      {/* Bug-293 28/03 */}
                                                      {obj?.atrAssignerEmailName}
                                                    </td>
                                                    <td className="approvalform-tableCol-width-2">Submitted</td>
                                                    <td className="approvalform-tableCol-width-2">
                                                      <Button
                                                        className="non_mobileResponsive"
                                                        onClick={() =>
                                                          onDeleteAssigneeUser(
                                                            index
                                                          )
                                                        }
                                                      >
                                                        <span className="k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>
                                                        Delete
                                                      </Button>
                                                      <Button
                                                        className="_mobileResponsive"
                                                        onClick={() =>
                                                          onDeleteAssigneeUser(
                                                            index
                                                          )
                                                        }
                                                      >
                                                        <span className="k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>

                                                      </Button>
                                                    </td>
                                                  </tr>
                                                )
                                              )}
                                            </tbody>
                                          </table>
                                        </div>
                                      </>
                                    )}

                                  {item.id === "Comments Log" &&
                                    item.isVisible && (
                                      <div className="table-responsive">
                                        {" "}
                                        <table className="ib-forms-custom-table tableStyle mob_table">
                                          <tbody>
                                            {" "}
                                            <tr>
                                              <th className="approvalform-tableCol-width-1">Page#</th>
                                              <th className="approvalform-tableCol-width-1">Doc Reference</th>
                                              <th className="approvalform-tableCol-width-5">Comments</th>
                                              <th className="approvalform-tableCol-width-3">Comment By</th>
                                            </tr>
                                            {noteData.noteApproverCommentsDTO.map(
                                              (comment) => (

                                                <tr
                                                  key={
                                                    comment.noteApproverCommentID
                                                  }
                                                >
                                                  <td className="approvalform-tableCol-width-1">{comment.pageNumber}</td>
                                                  <td className="approvalform-tableCol-width-1">
                                                    {comment.docReferrence}
                                                  </td>
                                                  <td className="approvalform-tableCol-width-5">{comment.comments}</td>
                                                  {/* Bug -293 28/03 */}
                                                  <td className="approvalform-tableCol-width-3">{comment.approverEmailName}</td>
                                                </tr>
                                              )
                                            )}
                                            {generalcmtforAllCmt?.map(
                                              (obj, index) => (
                                                !obj.isEdit && (<tr key={index}>
                                                  <td className="approvalform-tableCol-width-1">{obj.PageNo || "NA"}</td>
                                                  <td className="approvalform-tableCol-width-1">{obj.DocRef || "NA"}</td>
                                                  <td className="approvalform-tableCol-width-5">{obj.Comments}</td>
                                                  <td className="approvalform-tableCol-width-3">
                                                    {accounts[0].name}
                                                  </td>
                                                </tr>)

                                              )
                                            )}
                                          </tbody>{" "}
                                        </table>
                                      </div>
                                    )}
                                  {item.id === "Attach Supporting Documents" &&
                                    item.isVisible && (
                                      <>
                                        <div className="SectionRow row">
                                          <div className="col">
                                            <span className="k-form-label">
                                              Attach Supporting Documents
                                            </span>
                                            <div className="Attachemntfileinfo-ind">
                                              {/* <span hidden={isCurrentSecretary}> */}
                                              <input
                                                type="file"
                                                id="multiDoc"
                                                multiple
                                                onChange={multipleDocUpload}
                                                style={{ width: "107px" }}
                                              />
                                              <div>
                                                <span
                                               className="inCorrectFileError"
                                                >
                                                  {
                                                    supportingDocError
                                                  }
                                                </span>
                                              </div>
                                              {/* </span> */}
                                            </div>
                                            {filesInfo?.map((obj, ind) => (
                                              <div
                                                className="Attachemntfileinfo-ind"
                                                key={ind}
                                              >
                                                <span className="attachemntIconInfoConationer">
                                                  <span className="AttchemntIconWraper">
                                                    {/* Assuming you have different icons for different file types */}
                                                    <SvgIcon
                                                      icon={getFileIcon(
                                                        obj.supportingDocumentFileName
                                                      )}
                                                      size="xxlarge"
                                                    />
                                                    <span className="attachemnrt-warningifoConatiner">
                                                      <div className="attachemnrt-warningifo-fileinfo attachment_warn">
                                                        {
                                                          obj.supportingDocumentFileName
                                                        }
                                                      </div>
                                                      <span
                                                     className="inCorrectFileError"
                                                      >
                                                        {
                                                          supportDocWarning[
                                                            obj
                                                              .supportingDocumentFileName
                                                          ]?.warningMsg
                                                        }
                                                      </span>
                                                    </span>
                                                  </span>
                                                  <span
                                                    className="AttchemntIconWraperCancel"
                                                    onClick={() =>
                                                      onRemoveMultiAttachment(
                                                        ind
                                                      )
                                                    }
                                                  >
                                                    X
                                                  </span>
                                                </span>
                                              </div>
                                            ))}
                                            <div
                                            className="_fileFormatHintMsg"
                                            >
                                            
                                              Allowed Formats (pdf,doc,docx,xlsx only) Upto 25MB max.
                                            </div>
                                          </div>
                                        </div>
                                      </>
                                    )}
                                  {item.id === "Gist Document" &&
                                    item.isVisible && (
                                      <>
                                        <div className="SectionRow row">
                                          <div className="col">
                                            <span className="k-form-label">
                                              Gist Document
                                            </span>
                                            {noteData?.noteSecretaryDTO?.some(
                                              obj => obj.secretaryEmail === accounts[0].username &&
                                                obj.approverEmail === noteData?.currentActioner) &&
                                              noteData?.noteApproversDTO?.some(
                                                obj => obj.approverEmail === noteData?.currentActioner &&
                                                  obj.approverType === 2) &&
                                              (
                                                <div className="Attachemntfileinfo-ind">
                                                  {" "}
                                                  <input
                                                    type="file"
                                                    id="WordDocfile"
                                                    onChange={attchemtsForGistDoc}
                                                    style={{ width: "100px" }}
                                                  // readOnly={noteData?.noteSecretaryDTO?.some(
                                                  //   obj => obj.secretaryEmail === accounts[0].username &&
                                                  //     obj.approverEmail === noteData?.currentActioner)}
                                                  // disabled={noteData?.noteSecretaryDTO?.some(
                                                  //   obj => obj.secretaryEmail === accounts[0].username &&
                                                  //     obj.approverEmail === noteData?.currentActioner)}
                                                  />
                                                </div>
                                              )
                                            }



                                            {wordandPdfInfo?.wordInfo
                                              .fileName === "" ? null : (
                                              <div className="Attachemntfileinfo-ind">
                                                <span className="attachemntIconInfoConationer">
                                                  <span className="AttchemntIconWraper">
                                                    <SvgIcon
                                                      icon={getFileIcon(
                                                        wordandPdfInfo?.wordInfo
                                                          .fileName
                                                      )}
                                                      size="xxlarge"
                                                    />
                                                    {/* <span>{wordandPdfWarring?.wordInfo.fileName}<br /><span style={{ color: "red", fontSize: "10px" }}>{fileWordWarning}</span></span> */}
                                                    <span className="attachemnrt-warningifoConatiner">
                                                      <div className="attachemnrt-warningifo-fileinfo">
                                                        {wordandPdfInfo?.wordInfo.isDownloadble ? (
                                                          <a href={wordandPdfInfo?.wordInfo.base64}
                                                            download={wordandPdfInfo.wordInfo.fileName}
                                                          >
                                                            {wordandPdfInfo
                                                              ?.wordInfo.fileName}
                                                          </a>
                                                        ) :

                                                          wordandPdfInfo
                                                            ?.wordInfo.fileName
                                                        }                                                            </div>


                                                      <span
                                                         className="inCorrectFileError"
                                                      >
                                                        {fileWordWarning}
                                                      </span>
                                                    </span>
                                                  </span>
                                                  {/*  <span>
                                                    {wordandPdfInfo?.wordInfo.isDownloadble && (
                                                      <a href={wordandPdfInfo?.wordInfo.base64}
                                                      download={wordandPdfInfo.wordInfo.fileName}
                                                      >
                                                        <span className="k-icon k-font-icon  k-i-download cursor allIconsforPrimary-btn"></span>
                                                      </a>
                                                    )} */}
                                                  {
                                                    noteData?.noteSecretaryDTO?.some(
                                                      obj => obj.secretaryEmail === accounts[0].username &&
                                                        obj.approverEmail === noteData?.currentActioner) &&
                                                    noteData?.noteApproversDTO?.some(
                                                      obj => obj.approverEmail === noteData?.currentActioner &&
                                                        obj.approverType === 2) &&
                                                    (
                                                      <span
                                                        className="AttchemntIconWraperCancel"
                                                        onClick={() =>
                                                          onRemoveAttachmentWarning(
                                                            "wordInfo"
                                                          )
                                                        }
                                                      >
                                                        X
                                                      </span>
                                                    )
                                                  }
                                                  {/* </span> */}

                                                </span>
                                              </div>
                                            )}
                                            {noteData?.noteSecretaryDTO?.some(
                                              obj => obj.secretaryEmail === accounts[0].username &&
                                                obj.approverEmail === noteData?.currentActioner) &&
                                              noteData?.noteApproversDTO?.some(
                                                obj => obj.approverEmail === noteData?.currentActioner &&
                                                  obj.approverType === 2) && (
                                                <div
                                                    className="_fileFormatHintMsg"
                                                >
                                                  Allowed Formats (pdf,doc,docx only).Up to 5MB max.
                                                </div>

                                              )}

                                          </div>
                                        </div>

                                      </>
                                    )}

                                  {item.id === "Workflow Log" &&
                                    item.isVisible && (
                                      <div className="table-responsive">
                                        <table className="ib-forms-custom-table tableStyle">
                                          <tbody>
                                            {" "}
                                            <tr>
                                              <th className="approvalform-tableCol-width-4">Action</th>
                                              <th className="approvalform-tableCol-width-3">Action By</th>
                                              <th className="approvalform-tableCol-width-3">Action Date</th>
                                            </tr>
                                            {noteData?.workFlowLogDTO?.map(
                                              (obj, index) => (
                                                <tr>
                                                  <td className="approvalform-tableCol-width-4">
                                                    {obj.action}
                                                  </td>
                                                  <td className="approvalform-tableCol-width-3">
                                                    {/* Bug -293 28/03 */}
                                                    {obj.actionByName}
                                                  </td>
                                                  <td className="approvalform-tableCol-width-3">
                                                    {getdateconversion(
                                                      obj.modifiedDate
                                                    )}
                                                  </td>
                                                </tr>
                                              )
                                            )}
                                          </tbody>{" "}
                                        </table>
                                      </div>
                                    )}

                                  {item.id === "File Attachments" &&
                                    item.isVisible && (
                                      <div>
                                        {noteData && (
                                          <p>
                                            Main Note link :
                                            <span className="link-style"
                                              onClick={() => downloadBase64PDFFile(noteData?.notePdfPath)}
                                        
                                            >
                                              {noteData?.notePdfFileName}
                                            </span>
                                          </p>
                                        )}
                                        {(isCurrentSecretary || getNoteSecUserInfo?.some(obj => obj.approverEmail === accounts[0].username && obj.approverType === 2)) && (
                                          <>
                                            {noteData && (
                                              <p>
                                                Main Note word document link :
                                                <span className="link-style"
                                                  onClick={() => downloadBase64WordFile(noteData?.noteWordPath, noteData?.noteWordFileName)}
                                             
                                                >
                                                  {noteData?.noteWordFileName}
                                                </span>
                                              </p>
                                            )}
                                          </>
                                        )}

                                        <p>Support Documents :</p>
                                        <div className="table-responsive">
                                          <table className="tableStyle">
                                            <tbody>
                                              {" "}
                                              <tr>
                                                <th
                                                  className="approvalform-tableCol-width-4"
                                                >
                                                  Document link
                                                </th>
                                                <th
                                                  className="approvalform-tableCol-width-3"
                                                >Attached By</th>
                                                <th
                                                  className="approvalform-tableCol-width-3"
                                                >Attached Date</th>
                                              </tr>
                                              {/* {noteData?.noteSupportingDocumentsDTO?.map( */}
                                              {noteData?.noteSupportingDocumentsDTO?.map(
                                                (doc) => (
                                                  <tr
                                                    key={
                                                      doc.noteSupportingDocumentId
                                                    }
                                                  >
                                                    <td
                                                      className="approvalform-tableCol-width-4"
                                                    >
                                                      <span
                                                        className="link-style"
                                                        onClick={() => getSupportDocHyperlink(doc.supportingDocumentPath, doc.supportingDocumentFileName)

                                                        }
                                                     
                                                      >
                                                        {
                                                          doc.supportingDocumentFileName
                                                        }
                                                        {/* </Link> */}
                                                      </span>
                                                    </td>

                                                    <td
                                                      className="approvalform-tableCol-width-3"

                                                    >
                                                      {/*Bug - 293 28/03  */}
                                                      {doc.createdByName}</td>
                                                    <td
                                                      className="approvalform-tableCol-width-3"
                                                    >
                                                      {getdateconversion(
                                                        doc.createdDate
                                                      )}
                                                    </td>
                                                  </tr>
                                                )
                                              )}
                                            </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    )}
                                  {item.id === "Mark for Information Section" &&
                                    item.isVisible && (
                                      <>
                                        <div className="SectionRow row">
                                          <div

                                          >
                                            {/* <div> */}

                                            <div onKeyDown={(e) => e.stopPropagation()} className="_markInfocontainer">
                                              <MultiColumnComboBox
                                                data={getAllUserInfo}
                                                filterable={true}
                                                columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
                                                value={selectedMarjUserInfo === null ? null : selectedMarjUserInfo.displayName}
                                                onFilterChange={onFillterALLUser}
                                                onChange={onchangehanleMarkInfo}
                                                className="_markinfoCombobox"
                                                placeholder="Add Users..."
                                              />
                                           
                                              <Button
                                                onClick={addUserInForMarkInfo}

                                                className="formBtnColor non_mobileResponsive"
                                              >
                                                <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>
                                                Add User
                                              </Button>
                                              <Button
                                                onClick={addUserInForMarkInfo}
                                                className="_mobileResponsive"
                                              >
                                                <span className="k-icon k-font-icon k-i-plus cursor allIconsforPrimary-btn"></span>

                                              </Button>
                                            </div>

                                            <div className="table-responsive">
                                              <table
                                                className="tableStyle"
                                              >
                                                <thead>
                                                  <tr>
                                                    <th
                                                      className="approvalform-tableCol-width-1"
                                                    >S.No</th>
                                                    <th
                                                      className="approvalform-tableCol-width-6"
                                                    >User Info</th>
                                                    <th
                                                      className="approvalform-tableCol-width-3"
                                                    >Action</th>
                                                  </tr>
                                                </thead>
                                                <tbody>

                                                  {markInfoUserEmail?.map(
                                                    (obj, index) => (
                                                      <tr key={index}>
                                                        <td
                                                          className="approvalform-tableCol-width-1"
                                                        >
                                                          {index + 1}</td>
                                                        <td
                                                          className="approvalform-tableCol-width-6">
                                                          {/* Bug - 293 */}
                                                          {obj.markedEmailName}
                                                        </td>
                                                        <td

                                                          className="approvalform-tableCol-width-3">
                                                          <Button
                                                            className="non_mobileResponsive"
                                                            onClick={() =>
                                                              removeUserFromMarkInfo(
                                                                index
                                                              )
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>
                                                            Delete
                                                          </Button>
                                                          <Button
                                                            className="_mobileResponsive"
                                                            onClick={() =>
                                                              removeUserFromMarkInfo(
                                                                index
                                                              )
                                                            }
                                                          >
                                                            <span className="k-icon k-font-icon k-i-delete k-i-trash cursor allIconsforPrimary-btn"></span>

                                                          </Button>
                                                        </td>
                                                      </tr>
                                                    )
                                                  )}
                                                </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        </div>
                                        {markInfoUserEmail?.length > 0 && (
                                          <Button
                                            themeColor="info"
                                            className="formBtnColor"
                                            onClick={addmarkInfotoDataBase}
                                          >
                                            <span className="k-icon k-font-icon k-i-launch cursor allIconsforPrimary-btn"></span>
                                            Submit
                                          </Button>
                                        )}
                                      </>
                                    )}
                                </ExpansionPanelContent>
                              )}
                            </>
                          )}
                        </Reveal>
                      </ExpansionPanel>
                    ) : null
                  )}
                </div>


                {/* Change 05/04 Adding dynamic class  */}
                <div className={isPDFFullWidth ? "homesectionPdf-2" : "viewFormSection-2"}>
                  {/* Change  05/04 Based on condtion icon will render */}
                  {isPDFFullWidth ?
                    <span className="k-icon k-font-icon k-i-fullscreen-exit k-i-full-screen-exit cursor pdfHideandShowIcons" onClick={() => setIsPDFFullWidth(!isPDFFullWidth)}></span> :
                    <span className="k-icon k-font-icon k-i-fullscreen k-i-full-screenk-i-fullscreen-enter cursor pdfHideandShowIcons" onClick={() => setIsPDFFullWidth(!isPDFFullWidth)}></span>}

                  {/* <PDFViewer
                    // data={noteData?.notePdfBase64 || ""}
                    data={getNotePDF || ""}
                    // url={noteData?.notePdfPath}
                    defaultZoom={0.85}
                    // saveFileName={`${noteData?.notePdfFileName}` ||""}
                    saveFileName={`${noteData?.noteNumber.replace(/\//g, "_")}` || ""}
                    // change 05/04 Removing open option in toolbar added custom tools 
                    tools={tools}
                    style={{
                      height: "inherit",
                    }}
                  /> */}

                  <div class="toolbar">
                    <div id="toolbarContainer">
                      <div id="toolbarViewer">
                        <div id="toolbarViewerLeft">
                          <button class="toolbarButton" title="Previous Page" id="previous" tabindex="13" disabled={currentPage <= 1} onClick={handlePreviousPage}>
                            <span data-l10n-id="pdfjs-previous-button-label">Previous</span>
                          </button>
                          <button class="toolbarButton" title="Next Page" id="next" disabled={currentPage >= numPages} onClick={handleNextPage}>
                            <span data-l10n-id="pdfjs-next-button-label">Next</span>
                          </button>
                          <span class="toolbarLabel">{currentPage} / {numPages}</span>
                        </div>
                        <div id="toolbarViewerRight">

                          <div id="editorModeSeparator" class="verticalToolbarSeparator"></div>
                          <button onClick={handlePrint} id="print" class="toolbarButton hiddenMediumView" title="Print" tabindex="41" data-l10n-id="pdfjs-print-button">
                            <span data-l10n-id="pdfjs-print-button-label">Print</span>
                          </button>

                          <button id="download" class="toolbarButton hiddenMediumView" title="Download" tabindex="42" data-l10n-id="pdfjs-save-button" onClick={handleSave}>
                            <span data-l10n-id="pdfjs-save-button-label">Save</span>
                          </button>
                        </div>
                        <div id="toolbarViewerMiddle">
                          <div class="splitToolbarButton">
                            <button id="zoomOut" class="toolbarButton" title="Zoom Out" tabindex="21" onClick={handleZoomOut}>
                              <span>Zoom Out</span>
                            </button>
                            <button id="zoomIn" class="toolbarButton" title="Zoom In" tabindex="22" onClick={handleZoomIn}>
                              <span>Zoom In</span>
                            </button>
                          </div>

                          <span id="scaleSelectContainer" className="dropdownToolbarButton">
                            <select id="scaleSelect" title="Zoom" tabIndex="23" value={zoomLevel.toString()} onChange={handleZoomChange}>
                              <option value="1.3">Actual Width</option>
                              <option value="1.2">Fit to Width</option>
                              <option value="1.1">Fit to Page</option>
                              <option value="0.5">50%</option>
                              <option value="0.75">75%</option>
                              <option value="1">100%</option>
                              <option value="1.25">125%</option>
                              <option value="1.5">150%</option>
                              <option value="2">200%</option>
                              <option value="3">300%</option>
                              <option value="4">400%</option>
                            </select>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* pdf viewer */}
                  <div className="pdf-viewer" ref={pdfViewerRef} style={customStyles.pdfViewer}>
                    {pages.map((page, index) => (
                      <div key={page?.pageNum} ref={(el) => (pageRefs.current[index] = el)} style={customStyles.pdfDiv}>
                        <img src={page?.canvas} alt={`Page ${page?.pageNum || index + 1}`} />
                      </div>
                    ))}
                  </div>
                </div>
                {/* </div> */}
              </div>
            </div>
          </fieldset>
        </div>
      </div>
      <div className="approvalAction-foreNoteForm-contaioner">
        {/* {(currentActionerEmail === accounts[0].username && (noteData.status === 2 || noteData.status === 3) && noteData !== null && noteData?.noteApproversDTO.some(obj=>obj.approverEmail === currentActionerEmail &&obj.approverEmail ===accounts[0].username )) && */}
        <div>
          {approverChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={approvalFunction} themeColor="success">
                <span className="k-icon k-font-icon  k-i-track-changes-accept cursor allIconsforPrimary-btn"></span>
                {/* Approve */}
                {isApprover() ? "Noted" : "Approve"}
              </Button>
            </span>
          )}
          {/* {(currentActionerEmail === accounts[0].username && (noteData.status === 2 || noteData.status === 3) && noteData !== null) && */}
          {approverChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={rejectFunction} themeColor="error">
                <span className="k-icon k-font-icon  k-i-track-changes-reject cursor allIconsforPrimary-btn"></span>
                Reject
              </Button>
            </span>
          )}
          {/* {(currentActionerEmail === accounts[0].username && (noteData.status === 2 || noteData.status === 3) && noteData !== null) && */}
          {approverChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={referFunction} className="formBtnColor">
                <span className="k-icon k-font-icon k-icon-xl k-i-arrow-root cursor allIconsforPrimary-btn"></span>
                Refer
              </Button>
            </span>
          )}
          {noteData?.currentActioner === accounts[0].username && isreferredUser &&
            noteData.noteStatusCommittees === 9 &&
            noteData !== null && (
              //  &&
              <span className="eNote-ApprovalButton">
                <Button onClick={referBackfunction} className="formBtnColor">
                  <span className="k-icon k-font-icon  k-i-arrow-drill cursor allIconsforPrimary-btn"></span>
                  Refer Back
                </Button>
              </span>
            )}
        </div>
        {/* {(currentActionerEmail === accounts[0].username && (noteData.status === 2 || noteData.status === 3) && noteData !== null) && */}
        <div>
          {approverChecking() && (
            <span className="eNote-ApprovalButton">
              <Button onClick={returnfunction} className="formBtnColor">
                <span className="k-icon k-font-icon  k-i-undo cursor allIconsforPrimary-btn"></span>
                Return
              </Button>
            </span>
          )}
          {/* change added submit button in bottom of the page  -16/04 */}
          {/* isCurrentSecretary && noteData?.noteSecretaryDTO?.some(
            obj => obj.secretaryEmail === accounts[0].username &&
              obj.approverEmail === noteData?.currentActioner) && (
 */
            noteData?.noteSecretaryDTO?.some(
              obj => obj.secretaryEmail === accounts[0].username &&
                obj.approverEmail === noteData?.currentActioner) &&
            noteData?.noteApproversDTO?.some(
              obj => obj.approverEmail === noteData?.currentActioner &&
                obj.approverType === 2) && (
              <span className="eNote-ApprovalButton">
                <Button onClick={onSubmitForAttcGISTDoc} className="formBtnColor">
                  <span className="k-icon k-font-icon k-i-launch cursor allIconsforPrimary-btn"></span>
                  Submit
                </Button>
              </span>
            )}
          {noteData &&
            noteData.noteStatusCommittees === 2 &&
            noteData.createdBy === accounts[0].username &&
            noteData.noteApproversDTO?.every(
              (obj) => obj.approverStatus === 1 || obj.approverStatus === 2
            ) && (
              <span className="eNote-ApprovalButton">
                <Button className="formBtnColor" onClick={handleCallBack}>
                  <span className="k-icon k-font-icon  k-i-caret-alt-to-left cursor allIconsforPrimary-btn"></span>
                  Call Back
                </Button>
              </span>
            )}
          {/* noteData.noteApproversDTO?.map(obj => obj.strApproverStatus === "Pending" || "Waiting") &&( */}
          {noteData &&
            (noteData.noteStatusCommittees === 3 || noteData.noteStatusCommittees === 9) &&
            noteData.createdBy === accounts[0].username && (
              <span className="eNote-ApprovalButton">
                <Button className="formBtnColor" onClick={onChangeApproverBtnClick}>
                  <span className="k-icon k-font-icon  	k-i-user cursor allIconsforPrimary-btn"></span>
                  Change Approver
                </Button>
              </span>
            )}
          {/* && noteData.noteApproversDTO?.map(obj => obj.strApproverStatus === "Pending" || "Referred") */}
          {/*  {noteData &&
            noteData.status === 4 &&
            noteData.createdBy === accounts[0].username &&
            noteData.noteApproversDTO?.some(
              (obj) => obj.approverStatus === 5
            ) && (
              <span className="eNote-ApprovalButton">
                <Button className="formBtnColor" onClick={handleCancel}>
                  Cancel
                </Button>
              </span>
            )} */}
          {/* && noteData.noteApproversDTO?.map((approver) => approver.strApproverStatus === 'Returned') */}


          <span className="eNote-ApprovalButton">
            <Button onClick={redirectHomePage}>
              <span className="k-icon k-font-icon  k-i-x-circle cursor allIconsforPrimary-btn"></span>
              Exit</Button>
          </span>
        </div>
      </div>
      <Footer />

      {isLoading && <PageLoader />}

      {isVisible && (
        <Dialog
          title={<CustomConfirmtionTitleBar />}
          onClose={toggleDailogForConfirmation}
        >
          <p
            className="dialogcontent_"
            style={{

              fontWeight: 500,
            }}
          >
            {confirmDailogObj.Confirmtext}
          </p>
          <p
            className="dialogcontent_"
          >
            {confirmDailogObj.Description}
          </p>


          {isCurrentATRCreator && assigneerUserinfo?.length === 0 && currectbtn === "Approve" && (
            <p
              className="dialogcontent_"
            >
              Note: ATR assignees are not found. So for this approval request
              ATR assigness will not create.
            </p>
          )}

          <DialogActionsBar>
            <Button className="formBtnColor" onClick={onCofiormation}>
              <span className="k-icon k-font-icon  k-i-checkmark-circle cursor allIconsforPrimary-btn"></span>
              Confirm
            </Button>

            <Button onClick={toggleDailogForConfirmation}>
              <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
              Cancel</Button>
          </DialogActionsBar>
        </Dialog>
      )}

      {isVisibleSuccssDialog && (
        <Dialog title={<CustomSuccussTitleBar />} onClose={redirectHomePage}>
          <p
            className="dialogcontent_"
          >
            {successMsg}
          </p>
          <DialogActionsBar>
            <Button className="notifyDailogOkBtn" onClick={redirectHomePage}>
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {failedDialog && (
        <Dialog
          title={<CustomSuccussTitleBar />}
          onClose={() => setfailedDialog(false)}
        >
          <p
            className="dialogcontent_"
          >
            {`Something went wrong: ${statusMessage}`}
          </p>
          <DialogActionsBar>
            <Button
              className="notifyDailogOkBtn"
              onClick={() => setfailedDialog(false)}
            >
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {callbackvisible && (
        <Dialog title={<CustomSuccussTitleBar />} onClose={() => setCallBackVisible(false)}>
          <p
            className="dialogcontent_"
          >
            The request for call back has been successfull.
          </p>
          <DialogActionsBar>
            <Button onClick={handleCloseDialog} className="notifyDailogOkBtn">
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {changeapprovervisible && (
        <Dialog title={<CustomSuccussTitleBar />} onClose={() => setChangeApproverVisible(false)}>
          <p
            className="dialogcontent_"
          >
            The current actioner(Approver/Reviewer/Referee) has been updated
            successfully.
          </p>
          <DialogActionsBar>
            <Button onClick={handleCloseDialog} className="notifyDailogOkBtn">
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              {/* <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span> */}
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {/* dialog for validation */}
      {userComboValidationDialog && (
        <Dialog title={<CustomSuccussTitleBar />}
          onClose={() => setUserComboValidationDialog(false)}>
          <p
            className="dialogcontent_"
          >
            {userNotifyInfo}
          </p>
          {/* change 16/04 gist doc validation */}
          {currectbtn === "AttchGistDoc" && (
            <p
              className="dialogcontent_"
            >
              <strong>Note:</strong> Invalid files are not allowed.

            </p>
          )}
          <DialogActionsBar>
            <Button
              // onClick={() => setUserComboValidationDialog(false)}
              onClick={oncloseUseNotify}
              className="notifyDailogOkBtn"

            >
              <span className="k-icon k-font-icon  k-i-redo cursor allIconsforPrimary-btn"></span>
              {/* <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span> */}
              Ok
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
      {/* add refer and change approver */}
      {isVisibleSelectingUser && (<Dialog
        title={<CustomTitleBar />}
        onClose={() => setisVisibleSelectingUser(false)}
      >


        {currectbtn === "Refer" && (<>
          <label className="addReferee-label-ChangeApprover-label">Add Referee
            <MultiColumnComboBox
              data={getAllUserInfo}
              filterable={true}
              // columns={orgUsersPplPickerColumnMapping}
              columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
              // textField={"displayName"}
              value={selectedrefer === null ? null : selectedrefer.displayName}
              // itemRender={orgUsersPplPickerItemRender}pplFilterMultiColumn
              onFilterChange={onFillterALLUser}
              // onFilterChange={pplFilterMultiColumn}
              onChange={selectedReferrUser}
              style={{
                width: "100%",
                marginRight: "5px"
              }}
              placeholder="Add Referee..."
            />
          </label>
          <br />
          <label className="addReferee-label-ChangeApprover-label">Comments
            <textarea
              name="Comments"
              className="general-comments-Comments"
              row={1}

              value={
                referCommentsObj.Comments
              }
              onChange={
                handelReferGenralComments
              }></textarea>
          </label>
        </>
        )}
        {currectbtn === "ChangeApprover" && (<>
          <label className="addReferee-label-ChangeApprover-label"> Change approver
            <span className="required-asterisk">*</span>
            <MultiColumnComboBox
              data={getAllUserInfo}
              filterable={true}
              // columns={orgUsersPplPickerColumnMapping}
              columns={isMobile ? mobileColumns : orgUsersPplPickerColumnMapping}
              // textField={"displayName"}
              value={changeApprovercombovalue === null ? null : changeApprovercombovalue.displayName}
              // itemRender={orgUsersPplPickerItemRender}
              onFilterChange={onFillterALLUser}
              onChange={handleChangeApproverCombo}
              style={{
                width: "100%",
                marginRight: "5px"
              }}
              placeholder="Change Approver..."
            />
          </label>
          <br />
          <br />
          {changeApproverhaveSecretary && (
            <>
              <label className="addReferee-label-ChangeApprover-label"> Word Document
                <span className="required-asterisk">*</span>
              </label>
              <div className="Attachemntfileinfo-ind addReferee-label-ChangeApprover-label">
                <input
                  type="file"
                  id="noteWordDocfile"
                  onChange={noteWordconvertBase64Word}
                  style={{ width: "100px" }}
                />
              </div>
              {noteWordDoc?.noteWordDocInfo.fileName && (<div className="Attachemntfileinfo-ind addReferee-label-ChangeApprover-label">
                <span className="attachemntIconInfoConationer">
                  <span className="AttchemntIconWraper">
                    <SvgIcon
                      icon={getFileIcon(
                        noteWordDoc?.noteWordDocInfo.fileName
                      )}
                      size="xxlarge"
                    />
                    {/* <span>{wordandPdfWarring?.wordInfo.fileName}<br /><span style={{ color: "red", fontSize: "10px" }}>{fileWordWarning}</span></span> */}
                    <span className="attachemnrt-warningifoConatiner">
                      <div className="attachemnrt-warningifo-fileinfo">
                        {noteWordDoc?.noteWordDocInfo.fileName}
                      </div>
                      <span
                        style={{ color: "red", fontSize: "10px" }}
                      >
                        {noteWordDoc?.noteWordDocInfo.warningMsg}
                      </span>
                    </span>
                  </span>
                  <span
                    className="AttchemntIconWraperCancel"
                    onClick={onNoteWordDocRemoveAttachmentWarning}
                  >
                    X
                  </span>
                </span>
              </div>)}
              <div style={{ textAlign: "right", color: "green" }} className="addReferee-label-ChangeApprover-label">
                Allowed only one Word Document. Upto 10MB max.
              </div>
              {/* </div> */}
            </>)}
        </>)}
        <DialogActionsBar>
          {/* <span className="eNote-ApprovalButton"> */}
          <Button
            className="formBtnColor"
            onClick={onSubmitforAddReferandChangeApprover}>
            <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
            Submit
          </Button>
          {/* </span> */}
          {/* <span className="eNote-ApprovalButton"> */}
          <Button
            onClick={() => setisVisibleSelectingUser(false)}>
            <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
            Cancel
          </Button>
          {/* </span> */}
        </DialogActionsBar>
      </Dialog>
      )}
      {/* commented for rollback passcode 28-06 */}
      {passcodeVerification && (
        <Dialog title="Passcode Verification" onClose={handlepasscodeClose}>
          <form className="form-container dialogcontent_" >
            <label>
              Enter your passcode for verification:
              <div className="passcode-input-wrapper">
                <input
                  type={isPasscodeVisible ? 'text' : 'password'}
                  value={passcode}
                  onChange={handlePasscodeChange}
                  className="passcode-input"
                  maxLength="6"
                  pattern="\d*"
                  title="Please enter 6-characters, Combination of Alphabets and Numbers"
                // inputMode="text"
                />
                <span
                  className="eye-icon-view"
                  onClick={() => setIsPasscodeVisible(!isPasscodeVisible)}
                >
                  {isPasscodeVisible ? <img alt="view" src={view} /> : <img alt="hide" src={hide} />}
                </span>
              </div>
            </label>
            <div>
              {error && <span className='error'>{error}</span>}
            </div>
          </form>
          <DialogActionsBar>
            <Button
              className="formBtnColor"
              onClick={passcodeVerificationFunction}>
              <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
              Verify
            </Button>
            <Button
              onClick={handlepasscodeClose}>
              <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
              Cancel
            </Button>

          </DialogActionsBar>
        </Dialog>
      )}
      {/* Valid passcode dialog*/}
      {validPasscode && (
        <Dialog title="Passcode Verification" onClose={() => setValidPasscode(false)}>
          <div className="dialogcontent_">
            <p>{validMsg}</p>
          </div>
          <DialogActionsBar>
            <Button
              className="formBtnColor"
              onClick={handleRedirectToPasscode}>
              <span className="k-icon k-font-icon  k-i-launch cursor allIconsforPrimary-btn"></span>
              Create Passcode
            </Button>
            <Button
              onClick={() => setValidPasscode(false)}>
              <span className="k-icon k-font-icon  k-i-close-circle cursor allIconsforPrimary-btn"></span>
              Cancel
            </Button>
          </DialogActionsBar>
        </Dialog>
      )}
       {mobileCommentsDialog && (
        <Dialog title="Add Comments" onClose={handleCloseCommentsDialog}>
          <form className="form-container dialogcontent_Comments">
            <div className="row">
              <div className="col-sm-12">
                <div onKeyDown={(e) => e.stopPropagation()}>
                  <label>Page No:  </label>
                  <br></br>
                  <input
                    className="general-comments-pageNo"
                    type="text"
                    name="PageNo"
                    value={generalcmtInfoobj.PageNo}
                    onChange={handelGenralComments}
                  />
                </div>
              </div>
              <div className="col-sm-12">
                <div onKeyDown={(e) => e.stopPropagation()}>
                  <label>Doc Reference:  </label>
                  <br></br>
                  <input
                    className="general-comments-DocRef"
                    name="DocRef"
                    value={generalcmtInfoobj.DocRef}
                    onChange={handelGenralComments}
                  />
                </div>
              </div>
              <div className="col-sm-12">
                <div onKeyDown={(e) => e.stopPropagation()}>
                  <label>Comments:  <span className="required-asterisk">*</span></label>
                  <textarea
                    name="Comments"
                    className="general-comments-Comments"
                    row={5}
                    value={generalcmtInfoobj.Comments}
                    onChange={handelGenralComments}
                  ></textarea>
                  <Button
                    className="formBtnColor mt-2 button_center"
                    onClick={handelAddCmts}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </Dialog>
      )}

      {mobileCommentsEditDialog && (
        <Dialog title="Edit Comments" onClose={handleCloseCommentsDialog}>
          <form className="form-container dialogcontent_Comments">
            <div onKeyDown={(e) => e.stopPropagation()} style={{ width: "100%" }}>

              {generalcmtforAllCmt?.map(
                (obj, index) => (
                  <div key={index}>
                    {obj.isEdit ? (
                      <div onKeyDown={(e) => e.stopPropagation()}>
                        <label className="text-left">Page No:</label>
                        <input
                          type="text"
                          className="general-comments-pageNo"
                          value={obj.PageNo}
                          name="PageNo"
                          id={index}
                          onChange={
                            handelGenralCommentsEdit
                          }
                        />
                      </div>
                    ) : (
                      obj.PageNo
                    )}
                    {obj.isEdit ? (
                      <div onKeyDown={(e) => e.stopPropagation()}>
                        <label>Doc Reference:  </label>
                        <input
                          type="text"
                          className="general-comments-DocRef"
                          value={obj.DocRef}
                          name="DocRef"
                          id={index}
                          onChange={
                            handelGenralCommentsEdit
                          }
                        />
                      </div>
                    ) : (
                      obj.DocRef
                    )}

                    {obj.isEdit ? (
                      <div onKeyDown={(e) => e.stopPropagation()}>
                        <label>Comments:  <span className="required-asterisk">*</span></label>
                        <textarea
                          value={obj.Comments}
                          className="general-comments-Comments"
                          name="Comments"
                          row={5}
                          id={index}
                          onChange={
                            handelGenralCommentsEdit
                          }

                        ></textarea>
                      </div>
                    ) : (
                      obj.Comments
                    )}
                  </div>
                )
              )}
              <Button
                className="formBtnColor mt-2 button_center"
                onClick={handleMobileSave}  // No need to pass index since it's handled in state
              >
                Update
              </Button>
            </div>
          </form>
        </Dialog>
      )}
    </div>
  );
};
const customStyles = {
  dialogAlignment: { margin: "25px", textAlign: "center", width: "500px" },
  pdfViewer: { overflowY: 'scroll', height: '81vh', border: '1px solid #00000014' },
  pdfDiv: { boxShadow: '0 6px 8px #00000014, 0 4px 16px #0000001f', alignContent: "center", margin: "10px auto", display: "table" }
}