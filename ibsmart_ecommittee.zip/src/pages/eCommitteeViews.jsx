import React, { useState, useEffect } from "react";
import {
  Grid,
  GridColumn as Column,
  GridToolbar,
} from "@progress/kendo-react-grid";
import { Link } from "react-router-dom";
import { Button } from "@progress/kendo-react-buttons";
import { ColumnMenu } from "./custom-cells";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import { useParams } from "react-router";
import { process } from "@progress/kendo-data-query";
import { Input } from "@progress/kendo-react-inputs";
import { CSVLink } from "react-csv";
import {
  setGroupIds,
  setExpandedState,
} from "@progress/kendo-react-data-tools";
import { useMsal, useAccount } from "@azure/msal-react";
import { getter } from "@progress/kendo-react-common";
import { Sidebar } from "../components/sidebar";

import "../styles/datagridpage.css";
import "../styles/forms.css";
import { API_BASE_URL, API_ENDPOINTS ,loginRequest,API_COMMON_HEADERS} from "../config";
import { PageLoader } from "../components/pageLoader";
import DateObject from "react-date-object";
import { orderBy } from "@progress/kendo-data-query";
import { getAccessToken } from "../App";

const initialSort = [
  {
    field: "modifiedDate",
    dir: "desc",
  },
];

const DATA_ITEM_KEY = "noteId";
const SELECTED_FIELD = "selected";
const initialDataState = {
  take: 10,
  skip: 0,
  group: [],
};

const processWithGroups = (data, dataState) => {
  const newDataState = process(data, dataState);
  setGroupIds({
    data: newDataState.data,
    group: dataState.group,
  });
  return newDataState;
};

const Views = () => {
  const idGetter = getter(DATA_ITEM_KEY);

  const { id } = useParams();
  const [filterValue, setFilterValue] = React.useState("");
  const [filteredData, setFilteredData] = React.useState();
  const [currentSelectedState, setCurrentSelectedState] = React.useState({});
  const [dataState, setDataState] = React.useState(initialDataState);
  const [data, setData] = React.useState(filteredData);
  const [apiData, setApiData] = React.useState([]);
  const [dataResult, setDataResult] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentHeading, setCurrentHeading] = useState();
  const [selectedView, setSelectedView] = useState("");
  const [enumObj, setEnumObj] = useState();
  const { accounts, instance } = useMsal();
  const account = useAccount(accounts[0] || {});

  // handle get request bt status number 
  const getRequestByStatus = async (noteId) => {
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);
    const dropdowns = await fetch(`${API_BASE_URL}${API_ENDPOINTS.GET_DROPDOWNDATA}`, {
      method: "GET",
      headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`}
    });

    const enumsObj = await dropdowns.json();

    setEnumObj(enumsObj);

    switch (noteId) {
      case "All Requests":
        fetchApiData(0, API_ENDPOINTS.eCommittee_GetRequests);
        setSelectedView(noteId);
        break;
        case "Draft Requests":
          fetchApiData(
            enumsObj.NoteStatus.find((x) => x.dValue === "Draft").id,
            API_ENDPOINTS.eCommittee_GetRequests
          );
          setSelectedView(noteId);
          break;
      case "In Progress":
        fetchApiData(
          enumsObj.NoteStatus.find((x) => x.dValue === "Pending").id,
          API_ENDPOINTS.eCommittee_GetRequests
        );
        setSelectedView(noteId);
        break;
      case "All Approved":
        fetchApiData(
          enumsObj.NoteStatus.find((x) => x.dValue === "Approved").id,
          API_ENDPOINTS.eCommittee_GetRequests
        );
        setSelectedView(noteId);
        break;
      case "All Rejected":
        fetchApiData(
          enumsObj.NoteStatus.find((x) => x.dValue === "Rejected").id,
          API_ENDPOINTS.eCommittee_GetRequests
        );
        setSelectedView(noteId);
        break;
      // case "Noted Notes":
      //   fetchApiData("noted", API_ENDPOINTS.eCommittee_GetNotedNoteRequests);
      //   setSelectedView(noteId);
      //   break;
      // case "Archived Notes":
      //   return 6;
      default:
        fetchApiData(0, API_ENDPOINTS.eCommittee_GetRequests);
        setSelectedView("All Requests");
        return 0;
    }
  };

  // Handle switch noteID
  const switchNoteId = async (id) => {
    setCurrentHeading(id);
    setIsLoading(true);
    getRequestByStatus(id);
    // fetchApiData(getNoteStatusId(id));
  };

  useEffect(() => {
    switchNoteId(id); // Set the default noteId
  }, [id]);

  // Handle  get data
  const fetchApiData = async (status, endPoint) => {
    setFilterValue('');
    const accessToken = await getAccessToken({ ...loginRequest, account }, instance);

    const params =
      status === "noted"
        ? { CreatedBy: accounts[0].username }
        : { Status: status, CreatedBy: accounts[0].username };

    try {
      const response = await fetch(`${API_BASE_URL}${endPoint}`, {
        method: "POST",
        body: JSON.stringify(params),
        headers: { ...API_COMMON_HEADERS, Authorization: `Bearer ${accessToken}`},
      });

      if (response.ok) {
        const apiOutput = await response.json();
        const resData = apiOutput.pendingNoteList;
        const apiData = orderBy(resData, initialSort);
        // Bug fix - 300 - 27/03
        // const apiData = upData.map(x=>({...x,modifiedDate:new DateObject(new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm:ss A"),createdDate:new DateObject(new Date(x.createdDate)).format("DD-MMM-YYYY hh:mm:ss A")}));
        
        // console.log(apiData);

        if (Array.isArray(apiData)) {
          setApiData(apiData);
          setFilteredData(apiData);
          setData(apiData);
          setDataResult(process(apiData, dataState));
          setDataState({ ...dataState, total: apiData.length });
        } else {
          console.error("Error fetching data: Invalid API response", apiData);
          setFilteredData([]);
          setDataResult(process([], dataState));
        }
      } else {
        console.error("Error fetching data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle filter change 
  const onFilterChange = (ev) => {
    let value = ev.value;
    setFilterValue(value);

    if (!value) {
      // If no filter value, reset to the original data
      setFilteredData(apiData);
      setData(apiData);
    } else {
      let newData = apiData.filter((item) => {
        for (const property in item) {
          if (
            item[property] &&
            item[property].toString &&
            item[property]
              .toString()
              .toLowerCase()
              .includes(value.toLowerCase())
          ) {
            return true;
          }
          if (
            item[property] &&
            item[property].toLocaleDateString &&
            item[property].toLocaleDateString().includes(value)
          ) {
            return true;
          }
        }
        return false;
      });

      setFilteredData(newData);
      setData(newData);
      // }

      const newDataResult = processWithGroups(newData, dataState);
      setDataResult(newDataResult);

      setDataState((prevDataState) => ({
        ...prevDataState,
        total: newData.length,
      }));
      // setFilteredData(newData);
      let clearedPagerDataState = {
        ...dataState,
        take: 8,
        skip: 0,
      };
      let processedData = process(newData, clearedPagerDataState);
      setDataResult(processedData);
      setDataState({ ...clearedPagerDataState, total: newData.length });
      setData(newData);
    }
  };

  const [resultState, setResultState] = React.useState(
    processWithGroups(
      apiData.map((item) => ({
        ...item,
        ["selected"]: currentSelectedState[idGetter(item)],
      })),
      initialDataState
    )
  );

  // Handle datastatus change 
  const dataStateChange = (event) => {
    // if (event.dataState && filteredData) {
    setDataResult(process(filteredData, event.dataState));
    setDataState(event.dataState);
    // }
  };

  // Handle expand change 
  const onExpandChange = React.useCallback(
    (event) => {
      const newData = [...dataResult.data];
      const item = event.dataItem;
      if (item.groupId) {
        const targetGroup = newData.find((d) => d.groupId === item.groupId);
        if (targetGroup) {
          targetGroup.expanded = event.value;
          setDataResult({
            ...dataResult,
            data: newData,
          });
        }
      } else {
        item.expanded = event.value;
        setDataResult({
          ...dataResult,
          data: newData,
        });
      }
    },
    [dataResult]
  );

  // Handle selected value change 
  const setSelectedValue = (data) => {
    let newData = data.map((item) => {
      if (item.items) {
        return {
          ...item,
          items: setSelectedValue(item.items),
        };
      } else {
        return {
          ...item,
          ["selected"]: currentSelectedState[idGetter(item)],
        };
      }
    });
    return newData;
  };
  const newData = setExpandedState({
    data: setSelectedValue(resultState.data),
    collapsedIds: [],
  });


//  Handle export CSV header change 
  const exportCSVHeader = (id) => {
    let headerColumnConfig;

    switch (id) {
      case "In Progress":
        headerColumnConfig = [
          { key: "noteNumber", label: "Note#" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "committeeName", label: "Board/Committee Name" },
          { key: "subject", label: "Subject" },
          { key: "strNoteStatus", label: "Status" },
          // { field: "status", title: "Status" },
          // Bug fix - 293 - 27/03
          { key: "currentActionerName", label: "Current Approver" },
          { key: "finalApprover", label: "Final Approver" },
          { key: "createdDate", label: "Created Date" },
        ];
        break;
      case "All Requests":
        headerColumnConfig = [
          { key: "noteNumber", label: "Note#" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          { key: "strNoteStatus", label: "Status" },
          // Bug fix - 293 - 27/03
          { key: "currentActionerName", label: "Current Approver" },
          { key: "lastActioner", label: "Last Approver" },
          { key: "modifiedDate", label: "Modified Date" },
          { key: "createdDate", label: "Created Date" },
        ];
        break;
      default:
        headerColumnConfig = [
          { key: "noteNumber", label: "Note#" },
          // Bug fix - 293 - 27/03
          { key: "createdByName", label: "Requester" },
          { key: "departmentName", label: "Department" },
          { key: "subject", label: "Subject" },
          { key: "createdDate", label: "Created Date" },
          // Bug fix - 300 - 27/03
          { key: "modifiedDate", label: "Modified Date" },
        ];
    }
    return headerColumnConfig;
  };

  // Handle render column with data
  const renderColumnsWithData = (data) => {
    if (!data || data.length === 0) {
      return null;
    }

    let columnsConfig = [];

    switch (id) {
      case "All Requests":
        columnsConfig = [
          { field: "noteNumber", title: "Note#" },
          // Bug fix - 293 - 27/03
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "subject", title: "Subject" },
          { field: "strNoteStatus", title: "Status" },
          // Bug fix - 293 - 27/03
          { field: "currentActionerName", title: "Current Approver" },
          { field: "lastActioner", title: "Last Approver" },
          { field: "modifiedDate", title: "Modified Date" },
          { field: "createdDate", title: "Created Date" },
        ];
        break;
        case "In Progress":
        columnsConfig = [
          { field: "noteNumber", title: "Note#" },
          // Bug fix - 293 - 27/03
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "committeeName", title: "Board/Committee Name" },
          { field: "subject", title: "Subject" },
          { field: "strNoteStatus", title: "Status" },
          // Bug fix - 293 - 27/03
          { field: "currentActionerName", title: "Current Approver" },
          { field: "finalApprover", title: "Final Approver" },
          { field: "createdDate", title: "Created Date" },
        ];
        break;
      default:
        columnsConfig = [
          { field: "noteNumber", title: "Note#" },
          // Bug fix - 293 - 27/03
          { field: "createdByName", title: "Requester" },
          { field: "departmentName", title: "Department" },
          { field: "subject", title: "Subject" },
          { field: "createdDate", title: "Created Date" },
          // Bug fix - 300 - 27/03
          { field: "modifiedDate", title: "Modified Date" },
        ];
    }

    // setColumnExport(columnsExportConfig);
    // console.log(accounts);

    return columnsConfig.map((column) => (
      <Column
        key={column.field}
        field={column.field}
        title={column.title}
        cell={(props) =>
          column.field === "noteNumber" ? (
            <td>
              <Link
                style={{ color: "red" }}
                to={
                  (props.dataItem["status"] === enumObj.NoteStatus.find((x) => x.dValue === "Draft").id ||
                    props.dataItem["status"] === enumObj.NoteStatus.find((x) => x.dValue === "Returned").id ||
                    props.dataItem["status"] === enumObj.NoteStatus.find((x) => x.dValue === "Called Back").id) &&
                    props.dataItem["createdBy"] === accounts[0].username
                    ? `${
                        props.dataItem["noteFor"] ===
                        enumObj.noteFor.find((x) => x.dValue === "Committee").id
                          ? "/ecommitteenote/"
                          : "/boardnoteform/"
                      }${props.dataItem["noteId"]}`
                    : `${
                        props.dataItem["noteFor"] ===
                        enumObj.noteFor.find((x) => x.dValue === "Committee").id
                          ? "/ecommitteeviewform/"
                          : "/boardnoteviewform/"
                      }${props.dataItem["noteId"]}`
                }
              >
                {props.dataItem[column.field]}
              </Link>
            </td>
          ) : (
            <td>
              {/* Bug fix - 300 - 27/03 */}
              {/* Change 23/05 seconds hand was removed  */}
              {column.title.includes("Date")
                ? new DateObject(new Date(props.dataItem[column.field])).format("DD-MMM-YYYY hh:mm A")
                : (column.field === "committeeName" && props.dataItem["noteFor"] === enumObj.noteFor.find((x) => x.dValue === "Board").id)?props.dataItem['boardCommitteeName']:props.dataItem[column.field]}
               {/* {props.dataItem[column.field]} */}
            </td>
          )
        }
        columnMenu={ColumnMenu}
      />
    ));
  };

  return (
    <div>
      <Navbar header="IB Smart Office - eNote" />
      <Sidebar />
      <div className="container datagridpage">
        <div className="SectionHeads row mobileSectionHeads">{currentHeading}</div>
        {/* Add a section for displaying headings and allow the user to switch between them*/}
        {isLoading ? (
          <PageLoader />
        ) : (
          <Grid
            className="cstGridStyles"
            pageable={{ pageSizes: true }}
            data={dataResult}
            sortable={true}
            total={resultState.total}
            onDataStateChange={dataStateChange}
            {...dataState}
            onExpandChange={onExpandChange}
            dataItemKey={DATA_ITEM_KEY}
            size={"small"}
            resizable={true}
          >
            <GridToolbar>
              <Input
                value={filterValue}
                onChange={onFilterChange}
          className="searchCSS"
                placeholder="Search in all columns..."
              />
              <div className="export-btns-container">
                {/* <Button onClick={exportExcel}>Export to Excel</Button>
                <Button onClick={exportPDF}>Export to PDF</Button> */}
                <Button className="_exportCSVBtn">
                  <CSVLink
                    filename={`eCommittee-${selectedView.replace(
                      / /g,
                      ""
                    )}${new DateObject(new Date()).format("DDMMYYYYhhmmss")}`}
                    // Bug fix - 300 - 27/03
                    // Change 23/05 seconds hand removed
                    data={filteredData.map((x) => ({...x, modifiedDate: new DateObject( new Date(x.modifiedDate)).format("DD-MMM-YYYY hh:mm A"),
                    createdDate: new DateObject( new Date(x.createdDate) ).format("DD-MMM-YYYY hh:mm A"),}))}
                    headers={exportCSVHeader(currentHeading)}
                  >
                    Export CSV
                  </CSVLink>
                </Button>
              </div>
            </GridToolbar>
            {renderColumnsWithData(dataResult)}
          </Grid>
        )}
      </div>
      <div className="pgFooterContainer">
        <Footer />
      </div>
    </div>
  );
};

export default Views;