import { useEffect } from "react";
import { Landingpage } from "./pages/landingpage";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useIsAuthenticated,
} from "@azure/msal-react";
import * as Msal from "msal";
import { msalConfig, loginRequest } from "./config.js";
import { useMsalAuthentication } from "@azure/msal-react";
import { InteractionType } from "@azure/msal-browser";
import { Logout } from "./pages/logout.jsx";
import PageNotFound from "./pages/404page.jsx";

// Initialize MSAL application object
const userAgentApplication = new Msal.UserAgentApplication(msalConfig);
// console.log(process.env.REACT_APP_CLIENT_ID);
// Function to get access token
export const getAccessToken = async () => {
  try {
    const response = await userAgentApplication.acquireTokenSilent(loginRequest);
    console.log("Access Token:", response.accessToken);
    return response.accessToken;
  } catch (error) {
    console.error("Failed to get access token:", error);
    throw new Error("Failed to get access token");
  }
};

function App() {
  // const isAuthenticated = useIsAuthenticated();
  
  // Silent login
  // const { login, result, error } = useMsalAuthentication(InteractionType.Silent, loginRequest);

  // Auto redirect to login
  const { login, result, error } = useMsalAuthentication(InteractionType.Redirect);

  // const { accounts } = useMsal();
  // console.log(accounts.length);
  // const { login, result, error } = useMsalAuthentication(accounts.length > 0 ?InteractionType.Redirect:InteractionType.None);

  return (
    <div className="App">
        <AuthenticatedTemplate>
          <Router>
            <Routes>
              <Route path="/" element={<Landingpage />} />
              <Route path="/home" element={<Landingpage />} />
              <Route path="/logout" element={<Logout />} />
              <Route path="*"  element={<PageNotFound />}/>
            </Routes>
          </Router>
        </AuthenticatedTemplate>
        <UnauthenticatedTemplate>
          <Router>
            <Routes>
              <Route path="/" element={<Landingpage />} />
              {/* <Route path="*"  element={<PageNotFound />}/> */}
            </Routes>
          </Router>
        </UnauthenticatedTemplate>
    </div>
  );
}

export default App;
