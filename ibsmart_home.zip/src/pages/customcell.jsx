import React, { useState, useEffect, useCallback } from 'react';
export const CustomCell = ({ dataItem, field }) => {
  const [cellData, setCellData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`https://indianbankxenciaapp.azurewebsites.net/api/ENote/getNoteList/${dataItem[field]}`);

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        setCellData(result);
      } catch (error) {
        console.error('Error fetching cell data:', error);
      }
    };

    fetchData();
  }, [dataItem[field], field]);

  useEffect(() => {
    console.log('cellData:', cellData);
    console.log('field:', field);
  }, [cellData, field]);

  return <div>{cellData ? cellData[field] : 'Loading...'}</div>;
};
