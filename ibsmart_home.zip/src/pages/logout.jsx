import { useMsal } from '@azure/msal-react';
import { IB_Domain_URL } from '../config.js';
import { useEffect } from 'react';
import { BrowserUtils } from "@azure/msal-browser";


export const Logout = (props) => {
    const { instance, accounts } = useMsal();

        // instance.logoutRedirect({
        //   postLogoutRedirectUri: IB_Domain_URL
        // });
        useEffect(() => {
          instance.logoutRedirect({
              account: instance.getAccountByHomeId(accounts[0].homeAccountId),
            //   account: instance.getActiveAccount(),
                // postLogoutRedirectUri: IB_Domain_URL
              //   onRedirectNavigate: () => !BrowserUtils.isInIframe()
              // onRedirectNavigate: () => `${IB_Domain_URL}/home`,
              postLogoutRedirectUri: `${IB_Domain_URL}/home`,
          })
      });
};